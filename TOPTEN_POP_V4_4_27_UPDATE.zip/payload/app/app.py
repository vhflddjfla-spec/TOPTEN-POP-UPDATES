# -*- coding: utf-8 -*-
from __future__ import annotations
import hashlib
import os, re, sys, time, socket, threading, webbrowser, subprocess, shutil, json, difflib, itertools
from contextlib import contextmanager
from pathlib import Path
from datetime import datetime
from typing import Any
from collections import OrderedDict

from flask import Flask, request, redirect, send_from_directory, render_template_string, jsonify
from openpyxl import load_workbook
from PIL import Image, ImageDraw, ImageFont
import fitz
import numpy as np
import cv2
from rapidfuzz import fuzz, process

_PYTESSERACT_IMPORT_ERROR = ''
try:
    import pytesseract
except Exception as exc:
    pytesseract = None
    _PYTESSERACT_IMPORT_ERROR = f'{type(exc).__name__}: {exc}'

ROOT = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parents[1]))
DATA_DIR = ROOT / 'data'
TEMPLATE_DIR = ROOT / 'templates'
PRODUCT_DIR = ROOT / 'product_images'
OUTPUT_DIR = ROOT / 'output'
CACHE_DIR = ROOT / 'cache'
LEGACY_BONUS_DIR = ROOT / 'bonus_pdfs'  # legacy migration fallback only; new PDFs use webhard_sync directly.
# V4.4.27 keeps OCR and AI mappings independently so the main screen can switch
# which engine's result is actually used for POP generation without destroying either set.
LEGACY_BONUS_MAP_FILE = DATA_DIR / 'bonus_page_matches.json'
BONUS_OCR_MAP_FILE = DATA_DIR / 'bonus_page_matches_ocr.json'
BONUS_AI_MAP_FILE = DATA_DIR / 'bonus_page_matches_ai.json'
BONUS_MODE_FILE = DATA_DIR / 'bonus_match_mode.json'
WEBHARD_SYNC_DIR = ROOT / 'webhard_sync'
SYNC_STATE_FILE = DATA_DIR / 'webhard_sync_state.json'
QUEUE_FILE = DATA_DIR / 'generation_queue.json'
OCR_CACHE_FILE = DATA_DIR / 'ocr_page_cache.json'
OCR_LEARN_FILE = DATA_DIR / 'ocr_manual_learning.json'
VISUAL_CHOICE_FILE = DATA_DIR / 'carryover_visual_choices.json'
LEGACY_BONUS_OVERRIDE_FILE = DATA_DIR / 'bonus_manual_overrides.json'
BONUS_OCR_OVERRIDE_FILE = DATA_DIR / 'bonus_manual_overrides_ocr.json'
BONUS_AI_OVERRIDE_FILE = DATA_DIR / 'bonus_manual_overrides_ai.json'
AI_PAGE_CACHE_FILE = DATA_DIR / 'ai_page_cache.json'
LEGACY_AI_PAGE_CACHE_FILES = [DATA_DIR / f'ai_page_cache_v{v}.json' for v in ('4418','4417','4416','4415')]
AI_RUNTIME_DIR = ROOT / 'runtime_ai'
AI_SITE_DIR = AI_RUNTIME_DIR / 'site-packages'
LOG_DIR = DATA_DIR / 'logs'
AI_LOG_FILE = LOG_DIR / 'ai_engine.log'
AI_RUNTIME_MARKER = DATA_DIR / 'ai_runtime.json'
AI_SINGLE_RESULT_FILE = DATA_DIR / 'ai_single_test_result.json'
AI_REVIEW_FILE = DATA_DIR / 'ai_match_review.json'
AI_WORKER = ROOT / 'ai_page_worker.py'
AI_FAST_WORKER = ROOT / 'ai_fast_ocr_worker.py'
ADULT_SMALL_TEMPLATE = TEMPLATE_DIR / 'TT_ADULT_SMALL.pdf'
CLEARANCE_TEMPLATE = TEMPLATE_DIR / 'TT_CLEARANCE.pdf'
PID_FILE = DATA_DIR / 'server.pid'
CURRENT_XLSX = DATA_DIR / 'current_promotion.xlsx'
LAST_NAME = DATA_DIR / 'last_filename.txt'
for d in (DATA_DIR,TEMPLATE_DIR,PRODUCT_DIR,OUTPUT_DIR,CACHE_DIR,WEBHARD_SYNC_DIR,AI_RUNTIME_DIR,LOG_DIR): d.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)

_ITEMS_CACHE = None
_CACHE_MTIME = None
_PRODUCT_INDEX = None
_BONUS_MAP_CACHE = {'ocr': None, 'ai': None}
_BONUS_MAP_MTIME = {'ocr': None, 'ai': None}
_RENDER_CACHE = OrderedDict()
_RENDER_CACHE_MAX = 3
_OCR_CACHE = None
_OCR_CACHE_DIRTY = False
_MATCH_SEARCH_CACHE = None
OCR_CACHE_VERSION = 'ocr-v4.4.12-region-index'
MATCH_ALGORITHM_VERSION = 'match-v4.4.27-season-gender-manual-breed-hardgate-fast-ai-review-70pct' 
OCR_AUTO_THRESHOLD = 0.78
OCR_RECOMMEND_THRESHOLD = 0.52
OCR_MARGIN_THRESHOLD = 0.08
AI_AUTO_THRESHOLD = 0.70
AI_MARGIN_THRESHOLD = 0.00
AI_PAGE_CACHE_VERSION = 'paddleocr-vl-1.6-v4419-timeoutfix1'
TITLE_STRONG_THRESHOLD = 0.78
TITLE_REGION_THRESHOLD = 0.72
TITLE_FILENAME_ONLY_CAP = 0.69

# Background scan state. Heavy PDF/OCR work never runs inside a browser request.
_SCAN_LOCK = threading.Lock()
_SCAN_STATUS_LOCK = threading.Lock()
_SCAN_CANCEL = threading.Event()
_ACTIVE_AI_PROC_LOCK = threading.Lock()
_ACTIVE_AI_PROC = None
_SCAN_STATUS = {
    'running': False, 'mode': '', 'started_at': '', 'finished_at': '',
    'message': '대기 중', 'error': '', 'processed': 0, 'cancel_requested': False,
    'ai_stage': '', 'ai_download_percent': 0.0, 'ai_download_source': '',
    'ai_downloaded_bytes': 0, 'ai_download_total_bytes': 0,
    'ai_download_speed_bps': 0.0, 'ai_download_eta_seconds': -1,
    'total': 0, 'ai_page_done': 0, 'ai_page_total': 0,
    'ai_page_cached': 0, 'ai_page_new': 0, 'ai_current_page': 0,
    'ai_current_elapsed_seconds': 0, 'ai_elapsed_seconds': 0,
    'ai_page_last_seconds': 0.0, 'ai_page_eta_seconds': -1,
    'ai_fast_done': 0, 'ai_fast_total': 0, 'ai_vl_done': 0, 'ai_vl_total': 0,
    'ai_preview_file': '', 'ai_preview_page': 0, 'ai_preview_code': '',
    'ai_preview_title': '', 'ai_preview_score': 0, 'ai_preview_method': '', 'ai_preview_text': '',
    'ai_preview_page_category':'','ai_preview_item_category':'',
    'ai_preview_seq': '', 'ai_review_count': 0, 'ai_review_status': ''
}

class ScanCancelled(Exception):
    pass

def _raise_if_scan_cancelled():
    if _SCAN_CANCEL.is_set():
        raise ScanCancelled('사용자가 매칭 중단을 요청했습니다.')

def request_scan_stop():
    global _ACTIVE_AI_PROC
    _SCAN_CANCEL.set()
    _set_scan_status(cancel_requested=True, message='중단 요청됨 · 현재 처리 중인 작업을 종료하는 중')
    with _ACTIVE_AI_PROC_LOCK:
        proc = _ACTIVE_AI_PROC
        if proc is not None and proc.poll() is None:
            try:
                proc.terminate()
            except Exception:
                pass
    return True

PREVIEW_DPI = 105
PREVIEW_MAX_WIDTH = 900

EXTS = ['.pdf','.png','.jpg','.jpeg','.webp']
# Font policy for the TOPTEN adult-small bottom bar.
# Font files are not bundled. The app searches the local fonts folder and Windows Fonts.
FONT_DIR = ROOT / 'fonts'
FONT_KO_NAMES = ['NanumBarunGothic.otf', 'NanumBarunGothic.ttf']
FONT_DIN_MEDIUM_NAMES = ['DINPro-Medium.otf', 'DINPro-Medium.ttf']
FONT_DIN_BOLD_NAMES = ['DINPro-Bold.otf', 'DINPro-Bold.ttf']

def resolve_font_file(names):
    candidates = []
    for name in names:
        candidates.extend([
            FONT_DIR / name,
            Path('C:/Windows/Fonts') / name,
            Path.home() / 'AppData/Local/Microsoft/Windows/Fonts' / name,
        ])
    for path in candidates:
        if path.exists():
            return path
    return None

FONT_KO = resolve_font_file(FONT_KO_NAMES)
FONT_DIN_MEDIUM = resolve_font_file(FONT_DIN_MEDIUM_NAMES)
FONT_DIN_BOLD = resolve_font_file(FONT_DIN_BOLD_NAMES)

DPI = 300
MM_TO_PX = DPI / 25.4
# The original TOPTEN visual PDFs are A4 masters intended to print at 100%.
A4_W_MM = 210.0
A4_H_MM = 297.0
# The acrylic case uses the full A4 width and a 240 mm high cutout.
# The original NEW ARRIVAL artwork begins 32 mm from the A4 top edge.
CUT_TOP_MM = 32.0
CUT_H_MM = 240.0
CUT_BOTTOM_MM = CUT_TOP_MM + CUT_H_MM
# Bottom bar is the measured physical size: 210 x 50 mm.
# It always covers the final 50 mm of the 210 x 240 mm finished POP.
BAR_H_MM = 50.0
BAR_TOP_MM = CUT_BOTTOM_MM - BAR_H_MM
VISUAL_VISIBLE_H_MM = BAR_TOP_MM - CUT_TOP_MM
A4_W_PX = round(A4_W_MM * MM_TO_PX)
A4_H_PX = round(A4_H_MM * MM_TO_PX)
POP_W_PX = A4_W_PX
POP_H_PX = round(CUT_H_MM * MM_TO_PX)
BAR_H_PX = round(BAR_H_MM * MM_TO_PX)
CUT_TOP_PX = round(CUT_TOP_MM * MM_TO_PX)
BAR_TOP_PX = round(BAR_TOP_MM * MM_TO_PX)

def pt_px(pt: float) -> int:
    return max(1, round(pt * DPI / 72.0))


HTML = r'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>TOPTEN POP 자동화</title><style>
*{box-sizing:border-box}body{margin:0;background:#f3f5f7;font-family:Malgun Gothic,Arial,sans-serif;color:#161616}.wrap{max-width:1560px;margin:auto;padding:24px}.top{background:#0d255f;color:white;padding:20px 24px;border-radius:12px;display:flex;justify-content:space-between;align-items:center}.top h1{margin:0;font-size:25px}.top small{opacity:.85}.panel{background:white;border-radius:12px;padding:18px;margin-top:16px;box-shadow:0 2px 10px #00000010}.row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.btn{border:0;border-radius:7px;padding:10px 16px;font-weight:700;cursor:pointer;background:#102c73;color:white;text-decoration:none;display:inline-block}.red{background:#e30613}.gray{background:#555}.green{background:#26734d}.orange{background:#b55d00}.search{padding:10px;border:1px solid #bbb;border-radius:7px;min-width:320px}.stats{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin-top:12px}.stat{background:#f7f8fa;padding:12px;border-radius:8px;text-align:center}.stat b{font-size:22px;color:#102c73}.layout{display:grid;grid-template-columns:minmax(700px,1.55fr) minmax(410px,.85fr);gap:16px;margin-top:16px}.tablebox{max-height:650px;overflow:auto;border:1px solid #ddd}table{width:100%;border-collapse:collapse;font-size:13px}th,td{padding:9px;border-bottom:1px solid #e2e2e2;text-align:center;white-space:nowrap}th{position:sticky;top:0;background:#edf1f7;z-index:2}.left{text-align:left;max-width:280px;overflow:hidden;text-overflow:ellipsis}.sale{color:#e30613;font-weight:700}.badge{padding:3px 8px;border-radius:12px;color:white;font-size:11px}.b-sale{background:#e30613}.b-normal{background:#555}.preview{min-height:440px;text-align:center;background:#f7f7f7;border-radius:8px;padding:12px}.preview img{max-width:100%;max-height:590px;box-shadow:0 3px 15px #0003;background:white}.detail{text-align:left;background:white;margin-top:10px;padding:12px;border-radius:8px;line-height:1.7}.muted{color:#777}.warn{color:#c00;font-weight:700}.queue{border:2px solid #dbe2f0;background:#fbfcff}.queue-list{max-height:245px;overflow:auto;border:1px solid #ddd;border-radius:7px;background:white}.queue-item{display:grid;grid-template-columns:28px 110px 1fr;gap:7px;align-items:center;padding:9px;border-bottom:1px solid #eee;font-size:13px}.queue-empty{padding:20px;text-align:center;color:#777}.loading{opacity:.55;pointer-events:none}.toast{position:fixed;right:24px;bottom:24px;background:#111;color:#fff;padding:12px 18px;border-radius:8px;display:none;z-index:20}@media(max-width:1050px){.layout{grid-template-columns:1fr}.stats{grid-template-columns:repeat(2,1fr)}}
</style><script>
function allcheck(x){document.querySelectorAll('#productForm input[name=codes]').forEach(e=>e.checked=x.checked)}
function checkedCodes(){return [...document.querySelectorAll('#productForm input[name=codes]:checked')].map(e=>e.value)}
function toast(t){let e=document.getElementById('toast');e.textContent=t;e.style.display='block';setTimeout(()=>e.style.display='none',1800)}
async function setVisualChoice(code,choice){let body=new URLSearchParams({code,choice});let r=await fetch('/api/visual-choice',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body});return await r.json()}
async function resolveVisualChoices(codes,force=false){if(!codes.length)return true;let qs=new URLSearchParams();codes.forEach(c=>qs.append('code',c));if(force)qs.set('force','1');let r=await fetch('/api/visual-choice-required?'+qs.toString());let d=await r.json();for(let i of (d.items||[])){let useBonus=confirm(`[${i.code}] ${i.title_ko}\n\n이월상품에 연결된 번외 POP가 있습니다.\n\n확인: 번외 POP 사용\n취소: 특별가격 POP 사용`);await setVisualChoice(i.code,useBonus?'bonus':'clearance')}return true}
async function changeVisualChoice(code){await resolveVisualChoices([code],true);await preview(code)}
async function preview(code){let box=document.getElementById('previewBox');box.classList.add('loading');try{let r=await fetch('/api/item/'+encodeURIComponent(code));let d=await r.json();document.getElementById('pv').src='/preview/'+encodeURIComponent(code)+'?v='+(d.preview_version||'1');document.getElementById('detail').innerHTML=`<b>${d.code}</b> · 시즌 ${d.season||d.season_letter||'-'}<br>상품명: ${d.title_ko}<br>정상가: ${d.normal_fmt}<br>할인가: <span class="sale">${d.sale_fmt}</span> · 할인율: <b>${d.discount_percent_fmt||'-'}</b><br>프로모션: ${d.promotion||'-'}<br>행사기간: ${d.date_range||'-'}<br>비주얼: ${d.visual_status}`}finally{box.classList.remove('loading')}}
async function queueAction(url,codes=[]){let body=new URLSearchParams();codes.forEach(c=>body.append('codes',c));let r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body});let d=await r.json();renderQueue(d.items||[]);return d}
async function addCheckedToQueue(){let c=checkedCodes();if(!c.length){toast('체크한 품번이 없습니다.');return}let d=await queueAction('/queue/add',c);toast(d.added+'개를 생성 목록에 추가했습니다.');}
async function removeQueueChecked(){let c=[...document.querySelectorAll('#queueList input[name=qcodes]:checked')].map(e=>e.value);if(!c.length){toast('삭제할 품번을 선택하세요.');return}await queueAction('/queue/remove',c);toast('목록에서 삭제했습니다.');}
async function clearQueue(){if(confirm('생성할 POP 목록을 모두 비울까요?')){await queueAction('/queue/clear');toast('목록을 비웠습니다.')}}
function renderQueue(items){let q=document.getElementById('queueList'),count=document.getElementById('queueCount');count.textContent=items.length;if(!items.length){q.innerHTML='<div class="queue-empty">체크한 상품을 목록에 추가하면 여기에 쌓입니다.</div>';return}q.innerHTML=items.map(i=>`<label class="queue-item"><input type="checkbox" name="qcodes" value="${i.code}"><b>${i.code}</b><span>${i.title_ko}</span></label>`).join('')}
async function generateQueue(){let codes=[...document.querySelectorAll('#queueList input[name=qcodes]')].map(e=>e.value);let count=codes.length;if(!count){toast('생성 목록이 비어 있습니다.');return}if(!confirm(count+'개 POP를 한꺼번에 생성할까요?'))return;let btn=document.getElementById('queueGenerate');btn.disabled=true;btn.textContent='생성 중...';try{let r=await fetch('/queue/generate',{method:'POST'});let d=await r.json();renderQueue(d.items||[]);toast(d.generated+'개 생성 완료');setTimeout(()=>location.reload(),700)}finally{btn.disabled=false;btn.textContent='목록 전체 POP 생성'}}
async function generateImmediate(mode){let form=document.getElementById('productForm');let codes=mode==='all'?[...form.querySelectorAll('input[name=codes]')].map(e=>e.value):checkedCodes();if(!codes.length){toast('생성할 품번이 없습니다.');return}let hidden=document.createElement('input');hidden.type='hidden';hidden.name='mode';hidden.value=mode;form.appendChild(hidden);form.submit()}
</script></head><body><div class="wrap">
<div class="top"><div><h1>TOPTEN 완전 자동 POP · V4.4.27 <span style="font-size:14px;font-weight:600;color:#666;margin-left:10px">Made By. 포항장성점 김대영</span></h1><small>엑셀 업로드 · 품번 이미지 자동 매칭 · 할인율 70% 이상 특별가격 · 70% 미만 번외 우선/성인소형 · 자동업데이트 지원</small></div><b>{{loaded_name}}</b></div>{% if missing_fonts %}<div class="panel warn">필수 폰트 미설치: {{missing_fonts|join(', ')}}<br>Windows에 설치하거나 fonts 폴더에 복사한 뒤 RUN.cmd를 다시 실행하세요.</div>{% endif %}
<div class="panel"><div class="row" style="margin-bottom:12px"><a class="btn green" href="/bonus">일반 OCR 번외 매칭 관리</a><a class="btn orange" href="/bonus-ai">AI 번외 매칭 관리</a><a class="btn" href="/sync">웹하드 다운로드 폴더</a></div>
<div style="background:#eef3fb;border:1px solid #cad5ea;border-radius:10px;padding:14px;margin-bottom:14px"><div class="row" style="justify-content:space-between"><div><b style="font-size:17px">POP 생성에 적용할 번외 매칭 엔진</b><div class="muted" style="margin-top:5px">OCR/AI 결과는 각각 따로 보관됩니다. 여기서 선택한 쪽만 메인 이미지 매칭 숫자와 실제 POP 생성에 적용됩니다.</div></div><div class="row"><form method="post" action="/bonus/mode"><input type="hidden" name="mode" value="ocr"><button class="btn {{'green' if bonus_mode=='ocr' else 'gray'}}">{{'✓ ' if bonus_mode=='ocr' else ''}}일반 OCR 번외 적용</button></form><form method="post" action="/bonus/mode"><input type="hidden" name="mode" value="ai"><button class="btn {{'green' if bonus_mode=='ai' else 'gray'}}">{{'✓ ' if bonus_mode=='ai' else ''}}AI 번외 적용</button></form></div></div><div class="row" style="margin-top:10px"><span><b>현재 적용:</b> {{'AI 번외 매칭' if bonus_mode=='ai' else '일반 OCR 번외 매칭'}}</span><span class="muted">OCR 저장 {{ocr_match_count}}개 · AI 저장 {{ai_match_count}}개</span></div><div class="row" style="margin-top:10px"><form method="post" action="/bonus/rematch-all" onsubmit="return confirm('일반 OCR 번외 전체 재매칭을 시작할까요? OCR 캐시는 재사용하고 품번 연결을 다시 판정합니다.')"><button class="btn gray">일반 OCR 전체 재매칭 실행</button></form><form method="post" action="/bonus-ai/rematch-main" onsubmit="return confirm('AI 전체 재매칭을 시작할까요? 현재 적용된 AI 결과는 새 결과를 확정할 때까지 유지됩니다. 수동고정은 보호되고 기존 페이지 캐시는 재사용합니다.')"><button class="btn orange">AI 전체 재매칭 실행</button></form><span class="muted">매칭 실행과 실제 적용 엔진 선택은 서로 독립적입니다.</span></div></div>
<form action="/upload" method="post" enctype="multipart/form-data" class="row"><input type="file" name="excel" accept=".xlsx,.xlsm" required><button class="btn">프로모션 엑셀 적용</button><span class="muted">인식 행사기간: <b>{{date_range or '-'}}</b></span></form>
<div class="stats"><div class="stat"><b>{{items|length}}</b><br>전체 상품</div><div class="stat"><b>{{normal_count}}</b><br>정상가</div><div class="stat"><b>{{sale_count}}</b><br>할인가</div><div class="stat"><b>{{matched_count}}</b><br>이미지 매칭</div><div class="stat"><b>{{missing_count}}</b><br>이미지 미매칭</div></div></div>
<div class="layout"><div class="panel" style="margin-top:0"><form method="get" action="/" class="row"><input class="search" name="q" value="{{q}}" placeholder="품번 또는 상품명 검색"><button class="btn">검색</button><a href="/" class="btn gray">초기화</a></form>
<form id="productForm" action="/generate" method="post"><div class="row" style="justify-content:space-between;margin:14px 0"><label><input type="checkbox" onclick="allcheck(this)"> 전체선택</label><div><button type="button" onclick="addCheckedToQueue()" class="btn orange">체크 상품을 생성 목록에 추가</button> <button type="button" onclick="generateImmediate('selected')" class="btn red">선택 POP 즉시 생성</button> <button type="button" onclick="generateImmediate('all')" class="btn green">검색결과 전체 생성</button></div></div>
<div class="tablebox"><table><thead><tr><th></th><th>구분</th><th>품번</th><th>성별/조닝</th><th>상품명</th><th>정상가</th><th>할인가</th><th>할인율</th><th>프로모션</th><th>이미지</th></tr></thead><tbody>{% for i in items %}<tr onclick="preview('{{i.code}}')" style="cursor:pointer"><td onclick="event.stopPropagation()"><input type="checkbox" name="codes" value="{{i.code}}"></td><td><span class="badge {{'b-sale' if i.is_discount else 'b-normal'}}">{{'할인가' if i.is_discount else '정상가'}}</span></td><td><b>{{i.code}}</b></td><td>{{i.gender}} / {{i.zone}}</td><td class="left">{{i.title_ko}}</td><td>{{i.normal_fmt}}</td><td class="sale">{{i.sale_fmt}}</td><td>{{i.discount_percent_fmt}}</td><td class="left">{{i.promotion or '-'}}</td><td>{{i.visual_status}}</td></tr>{% endfor %}</tbody></table></div></form></div>
<div><div class="panel queue" style="margin-top:0"><div class="row" style="justify-content:space-between"><h3 style="margin:0">생성할 POP 목록 (<span id="queueCount">{{queue_items|length}}</span>)</h3><button id="queueGenerate" class="btn red" onclick="generateQueue()">목록 전체 POP 생성</button></div><p class="muted">검색을 바꿔도 목록은 유지되며, 프로그램을 껐다 켜도 저장됩니다. 일괄 생성이 끝난 품번은 목록에서 자동 삭제됩니다.</p><div id="queueList" class="queue-list">{% for i in queue_items %}<label class="queue-item"><input type="checkbox" name="qcodes" value="{{i.code}}"><b>{{i.code}}</b><span>{{i.title_ko}}</span></label>{% else %}<div class="queue-empty">체크한 상품을 목록에 추가하면 여기에 쌓입니다.</div>{% endfor %}</div><div class="row" style="margin-top:10px"><button class="btn gray" onclick="removeQueueChecked()">선택 삭제</button><button class="btn gray" onclick="clearQueue()">목록 전체 비우기</button></div></div>
<div class="panel" style="margin-top:16px"><h3>POP 미리보기 / 상품 정보</h3><div id="previewBox" class="preview"><img id="pv" src="{{initial_preview}}"><div id="detail" class="detail">목록의 상품을 클릭하면 상품명, 가격, 프로모션 내용과 POP가 표시됩니다.</div></div></div></div></div>
{% if generated %}<div class="panel"><h3>생성 완료</h3><div class="row">{% for f in generated %}<a class="btn" href="/output/{{f}}" target="_blank">{{f}}</a>{% endfor %}</div></div>{% endif %}
</div><div id="toast" class="toast"></div></body></html>'''

def font(path, size:int, fallback_bold=False):
    candidates = []
    if path:
        candidates.append(Path(path))
    if fallback_bold:
        candidates.extend([Path('C:/Windows/Fonts/arialbd.ttf'), Path('C:/Windows/Fonts/malgunbd.ttf')])
    else:
        candidates.extend([Path('C:/Windows/Fonts/arial.ttf'), Path('C:/Windows/Fonts/malgun.ttf')])
    candidates.append(Path('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if fallback_bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
    for p in candidates:
        try:
            if p.exists():
                return ImageFont.truetype(str(p), size)
        except Exception:
            pass
    return ImageFont.load_default()

def missing_required_fonts():
    missing = []
    if FONT_KO is None: missing.append('NanumBarunGothic.otf')
    if FONT_DIN_MEDIUM is None: missing.append('DINPro-Medium.otf')
    if FONT_DIN_BOLD is None: missing.append('DINPro-Bold.otf')
    return missing

def n(v):
    try:
        if v in (None,''): return 0
        return int(float(str(v).replace(',','')))
    except:return 0

def clean_code(v): return re.sub(r'[^A-Z0-9_-]','',str(v or '').strip().upper())

def infer_gender_from_code(code, fallback=''):
    """Infer TOPTEN gender from the first digit of the final four digits.

    Store rule:
      1xxx = 남성, 2xxx = 여성, 3xxx = 공용.
    The product-code rule has priority over the promotion Excel gender value.
    If a code does not end in four digits or the first digit is not 1/2/3,
    preserve the supplied fallback value.
    """
    normalized = clean_code(code)
    match = re.search(r'(\d{4})$', normalized)
    if not match:
        return str(fallback or '').strip()
    return {'1': '남성', '2': '여성', '3': '공용'}.get(
        match.group(1)[0], str(fallback or '').strip()
    )

# TOPTEN manual product-category table (품종 대/소) supplied by store manual.
# The large-category code is directly usable as a hard matching rail.  In TOPTEN style
# codes seen in this project, the first alphabetic letter after the season digit is the
# manual large-category code (e.g. MSG2TS1002 -> T, MBG5PT1906 -> P).  The following
# letter is NOT assumed to be the manual small-category code; small category is inferred
# from the Korean/English product wording instead.
BREED_LARGE_LABELS = {
    'J':'점퍼','C':'코트','K':'자켓','V':'조끼','L':'레더','W':'우븐 셔츠',
    'T':'니트 셔츠','E':'스웨터','O':'원피스','P':'팬츠','D':'데님','R':'스커트',
    'U':'언더웨어','A':'소품(ACC)'
}
BREED_SMALL_LABELS = {
    'J': {'J':'점퍼','P':'패딩점퍼'},
    'C': {'G':'싱글코트','B':'더블코트'},
    'K': {'G':'싱글자켓','B':'더블자켓','P':'패딩자켓'},
    'V': {'P':'패딩 베스트'},
    'L': {'K':'가죽자켓','J':'가죽점퍼','V':'가죽조끼'},
    'W': {'C':'캐주얼셔츠','B':'블라우스'},
    'T': {'C':'오픈형(CARDIGAN)','R':'라운드','V':'V-넥','T':'T-에리','L':'민소매','H':'후드T','S':'VEST'},
    'E': {'C':'오픈형(CARDIGAN)','R':'라운드','V':'V-넥','T':'T-에리','L':'민소매','S':'VEST'},
    'O': {'O':'원피스'},
    'P': {'P':'팬츠(일반)','H':'반바지'},
    'D': {'P':'데님팬츠','H':'데님반바지','S':'데님스커트'},
    'R': {'L':'Long 스커트','S':'Short 스커트'},
    'U': {'T':'TOP','P':'BOTTOM'},
    'A': {'B':'가방','L':'벨트','C':'모자','S':'신발','T':'타이','M':'머플러','F':'스카프','V':'장갑','P':'지갑','J':'쥬얼리','Y':'양말','Z':'기타'},
}
BREED_LARGE_CODES = set(BREED_LARGE_LABELS)


def _breed_large_from_style_code(code):
    """Read the manual 품종 대 code from a TOPTEN style code when structurally clear.

    Examples from the user's real files:
      MSG2TS1002 -> T (니트 셔츠)
      MBG5PT1906 -> P (팬츠)
    Only the large category is decoded from SKU.  Small category is never guessed from
    the second letter because the supplied manual does not establish that mapping.
    """
    c=clean_code(code)
    m=re.search(r'\d([JCKVLWTEOPDRUA])[A-Z]\d{4}$',c)
    return m.group(1) if m and m.group(1) in BREED_LARGE_CODES else ''


def _breed_text_blob(text):
    return ' '.join(str(text or '').upper().replace('_',' ').split())


def _breed_category_from_text(text):
    """Infer manual 품종 대/소 candidates from visible Korean/English wording.

    Returns candidate large codes because some words (notably CARDIGAN/VEST) are shared
    by 니트 셔츠(T) and 스웨터(E).  Ambiguous wording is intentionally kept ambiguous
    rather than forced into one category.
    """
    raw=_breed_text_blob(text)
    compact=re.sub(r'\s+','',raw)
    large=[]; small=[]; evidence=[]
    def add_large(*codes):
        for c in codes:
            if c in BREED_LARGE_CODES and c not in large: large.append(c)
    def add_small(code):
        if code and code not in small: small.append(code)

    # ACC first: these nouns are highly specific and should not be confused with apparel.
    acc_rules=[
        ('B',(r'가방',r'백(?:\s|$)',r'\bBAG\b')),('L',(r'벨트',r'\bBELT\b')),
        ('C',(r'모자',r'캡(?:\s|$)',r'\bHAT\b',r'\bCAP\b')),('S',(r'신발',r'슈즈',r'\bSHOES?\b',r'\bSNEAKERS?\b')),
        ('T',(r'넥타이',r'\bTIE\b')),('M',(r'머플러',r'\bMUFFLER\b')),('F',(r'스카프',r'\bSCARF\b')),
        ('V',(r'장갑',r'\bGLOVES?\b')),('P',(r'지갑',r'\bWALLET\b')),('J',(r'쥬얼리',r'주얼리',r'\bJEWELRY\b',r'\bJEWELLERY\b')),
        ('Y',(r'양말',r'\bSOCKS?\b')),
    ]
    for sc,pats in acc_rules:
        if any(re.search(p,raw,re.I) for p in pats):
            add_large('A'); add_small(sc); evidence.append(BREED_SMALL_LABELS['A'][sc]); return {'large':large,'small':small,'evidence':evidence,'strength':3}

    # Leather outranks generic jacket/jumper/vest.
    if re.search(r'가죽|레더|\bLEATHER\b',raw,re.I):
        add_large('L'); evidence.append('레더/가죽')
        if re.search(r'자켓|재킷|\bJACKET\b|\bBLAZER\b',raw,re.I): add_small('K')
        elif re.search(r'점퍼|\bJUMPER\b',raw,re.I): add_small('J')
        elif re.search(r'조끼|\bVEST\b',raw,re.I): add_small('V')
        return {'large':large,'small':small,'evidence':evidence,'strength':3}

    # Denim outranks generic pants/skirt.
    if re.search(r'데님|\bDENIM\b|\bJEANS?\b',raw,re.I):
        add_large('D'); evidence.append('데님')
        if re.search(r'스커트|\bSKIRT\b',raw,re.I): add_small('S')
        elif re.search(r'반바지|쇼츠|숏팬츠|\bSHORTS?\b',raw,re.I): add_small('H')
        elif re.search(r'팬츠|바지|\bPANTS?\b|\bTROUSERS?\b|\bJEANS?\b',raw,re.I): add_small('P')
        return {'large':large,'small':small,'evidence':evidence,'strength':3}

    # Underwear.
    if re.search(r'언더웨어|속옷|\bUNDERWEAR\b|\bBRA\b|브라|팬티|드로즈|\bBRIEFS?\b|\bBOXERS?\b',raw,re.I):
        add_large('U'); evidence.append('언더웨어')
        if re.search(r'브라|브라탑|캐미|\bBRA\b|\bTOP\b',raw,re.I): add_small('T')
        if re.search(r'팬티|드로즈|\bBRIEFS?\b|\bBOXERS?\b|\bBOTTOM\b',raw,re.I): add_small('P')
        return {'large':large,'small':small,'evidence':evidence,'strength':3}

    # One-piece.
    if re.search(r'원피스|\bONE\s*PIECE\b|\bDRESS\b',raw,re.I):
        return {'large':['O'],'small':['O'],'evidence':['원피스'],'strength':3}

    # Coat / jumper / jacket / padded vest.
    if re.search(r'코트|\bCOAT\b',raw,re.I):
        add_large('C'); evidence.append('코트')
        if re.search(r'더블|\bDOUBLE\b',raw,re.I): add_small('B')
        elif re.search(r'싱글|\bSINGLE\b',raw,re.I): add_small('G')
        return {'large':large,'small':small,'evidence':evidence,'strength':3}
    if re.search(r'패딩\s*(?:베스트|조끼)|(?:베스트|조끼).*패딩|\bPADDED\s+VEST\b|\bPUFFER\s+VEST\b',raw,re.I):
        return {'large':['V'],'small':['P'],'evidence':['패딩 베스트'],'strength':3}
    if re.search(r'점퍼|\bJUMPER\b|\bBLOUSON\b',raw,re.I):
        add_large('J'); evidence.append('점퍼')
        if re.search(r'패딩|푸퍼|\bPADDED\b|\bPUFFER\b',raw,re.I): add_small('P')
        else: add_small('J')
        return {'large':large,'small':small,'evidence':evidence,'strength':3}
    if re.search(r'자켓|재킷|\bJACKET\b|\bBLAZER\b',raw,re.I):
        add_large('K'); evidence.append('자켓')
        if re.search(r'패딩|푸퍼|\bPADDED\b|\bPUFFER\b',raw,re.I): add_small('P')
        elif re.search(r'더블|\bDOUBLE\b',raw,re.I): add_small('B')
        elif re.search(r'싱글|\bSINGLE\b',raw,re.I): add_small('G')
        return {'large':large,'small':small,'evidence':evidence,'strength':3}

    # Woven shirt. Avoid T-shirt/tee wording.
    if re.search(r'블라우스|\bBLOUSE\b',raw,re.I):
        return {'large':['W'],'small':['B'],'evidence':['블라우스'],'strength':3}
    if re.search(r'우븐\s*셔츠|캐주얼\s*셔츠|\bWOVEN\s+SHIRT\b|\bCASUAL\s+SHIRT\b',raw,re.I):
        return {'large':['W'],'small':['C'],'evidence':['우븐/캐주얼 셔츠'],'strength':3}
    if ('셔츠' in raw or re.search(r'\bSHIRT\b',raw,re.I)) and not re.search(r'티셔츠|T\s*-?\s*SHIRT|TEE',raw,re.I):
        add_large('W'); add_small('C'); evidence.append('셔츠'); return {'large':large,'small':small,'evidence':evidence,'strength':2}

    # Sweater / knit-shirt family. CARDIGAN and VEST are shared by T/E in the manual.
    explicit_sweater=bool(re.search(r'스웨터|\bSWEATER\b|\bPULLOVER\b',raw,re.I))
    explicit_knit=bool(re.search(r'니트\s*셔츠|\bKNIT\s*SHIRT\b',raw,re.I))
    if explicit_sweater: add_large('E'); evidence.append('스웨터')
    elif explicit_knit: add_large('T'); evidence.append('니트 셔츠')
    elif re.search(r'가디건|CARDIGAN|\bVEST\b|베스트',raw,re.I): add_large('T','E'); evidence.append('가디건/베스트 공통')
    elif re.search(r'티셔츠|티\s*\(|그래픽\s*티|\bT\s*-?\s*SHIRT\b|\bTEE\b|후드T|후드\s*티',raw,re.I): add_large('T'); evidence.append('티셔츠/후드T')
    if large and set(large).issubset({'T','E'}):
        if re.search(r'가디건|CARDIGAN|오픈형',raw,re.I): add_small('C')
        elif re.search(r'V\s*[- ]?넥|V\s*NECK|브이넥',raw,re.I): add_small('V')
        elif re.search(r'라운드|ROUND\s*NECK|CREW\s*NECK',raw,re.I): add_small('R')
        elif re.search(r'T\s*[- ]?에리|T\s*COLLAR',raw,re.I): add_small('T')
        elif re.search(r'민소매|슬리브리스|SLEEVELESS|TANK\s*TOP',raw,re.I): add_small('L')
        elif re.search(r'후드T|후드\s*티|HOOD',raw,re.I): add_small('H')
        elif re.search(r'\bVEST\b|베스트',raw,re.I): add_small('S')
        return {'large':large,'small':small,'evidence':evidence,'strength':3 if len(large)==1 else 2}

    # Pants / skirt. Denim already handled above.
    if re.search(r'팬츠|바지|\bPANTS?\b|\bTROUSERS?\b|\bSLACKS?\b',raw,re.I):
        add_large('P'); evidence.append('팬츠')
        if re.search(r'반바지|쇼츠|숏팬츠|\bSHORTS?\b|BERMUDA',raw,re.I): add_small('H')
        else: add_small('P')
        return {'large':large,'small':small,'evidence':evidence,'strength':3}
    if re.search(r'스커트|\bSKIRT\b',raw,re.I):
        add_large('R'); evidence.append('스커트')
        if re.search(r'롱|LONG|맥시|MAXI',raw,re.I): add_small('L')
        elif re.search(r'숏|SHORT|미니|MINI',raw,re.I): add_small('S')
        return {'large':large,'small':small,'evidence':evidence,'strength':3}

    return {'large':[],'small':[],'evidence':[],'strength':0}


def _item_breed_category(item):
    text=' '.join(str(item.get(k) or '') for k in ('title_ko','title_en','zone','promotion'))
    cat=_breed_category_from_text(text)
    direct=_breed_large_from_style_code(item.get('code'))
    if direct:
        # SKU large code is the authoritative manual category; retain small-type text
        # only when the textual family is compatible or ambiguous.
        if cat['large'] and direct not in cat['large']:
            small=[]
        else:
            small=list(cat['small'])
        cat={'large':[direct],'small':small,'evidence':['SKU 품종대 '+direct+' '+BREED_LARGE_LABELS[direct]]+list(cat['evidence']),'strength':3}
    return cat


def _page_breed_category(page_text,source_desc=''):
    page=_breed_category_from_text(page_text)
    src=_breed_category_from_text(source_desc)
    # Page wording is primary.  Folder/file wording only resolves an ambiguity or fills
    # a missing category; it cannot override a clear page category.
    if page['large']:
        if len(page['large'])>1 and src['large']:
            inter=[c for c in page['large'] if c in src['large']]
            if inter:
                page=dict(page); page['large']=inter; page['evidence']=page['evidence']+['파일/폴더 품종 보조']
        return page
    if src['large']:
        out=dict(src); out['strength']=min(2,int(src.get('strength') or 0)); out['evidence']=['파일/폴더 '+x for x in src.get('evidence',[])]
        return out
    return page


def _breed_label(cat):
    if not isinstance(cat,dict) or not cat.get('large'): return '미확인'
    ls='/'.join(f"{c} {BREED_LARGE_LABELS.get(c,c)}" for c in cat.get('large',[]))
    ss=[]
    for sc in cat.get('small',[]):
        labels=[]
        for lc in cat.get('large',[]):
            lab=BREED_SMALL_LABELS.get(lc,{}).get(sc)
            if lab and lab not in labels: labels.append(lab)
        ss.append(f"{sc} {'/'.join(labels) if labels else ''}".strip())
    return ls + ((' · 소 '+', '.join(ss)) if ss else '')


def _manual_breed_relation(page_text,item,source_desc=''):
    """Return (adjustment, hard_conflict, page_cat, item_cat, reason)."""
    pc=_page_breed_category(page_text,source_desc)
    ic=_item_breed_category(item)
    pls=set(pc.get('large') or []); ils=set(ic.get('large') or [])
    if pls and ils and not pls.intersection(ils):
        return -1.0,True,pc,ic,f"품종대 불일치: 페이지 {_breed_label(pc)} / 품번 {_breed_label(ic)}"
    adj=0.0; notes=[]
    if pls and ils and pls.intersection(ils):
        adj+=0.085; notes.append('품종대 일치')
    pss=set(pc.get('small') or []); iss=set(ic.get('small') or [])
    if pss and iss and pss.intersection(iss):
        adj+=0.035; notes.append('품종소 일치')
    elif pss and iss and pls and ils and pls.intersection(ils):
        # Small category is inferred from wording, so mismatch is a penalty rather than
        # a hard reject. Large category remains the authoritative safety rail.
        adj-=0.025; notes.append('품종소 불일치')
    return adj,False,pc,ic,' · '.join(notes) if notes else '품종 단서 없음'


def normalize_date_range(value):
    """Convert common Excel/promotion period formats to M/D ~ M/D."""
    if value is None:
        return ''
    if isinstance(value, datetime):
        return f'{value.month}/{value.day}'
    text = str(value).strip()
    if not text:
        return ''
    text = re.sub(r'^.*?기간\s*[:：]?\s*', '', text)
    text = text.replace('～', '~').replace('−', '-').replace('–', '-').replace('—', '-')
    # Korean month/day, slash, dot, or dash date forms. Ignore a leading year.
    pairs = []
    patterns = [
        r'(?:(?:20\d{2})[./-])?(\d{1,2})[./-](\d{1,2})',
        r'(\d{1,2})\s*월\s*(\d{1,2})\s*일?',
    ]
    for pattern in patterns:
        pairs = re.findall(pattern, text)
        if len(pairs) >= 2:
            break
    if len(pairs) >= 2:
        (m1,d1),(m2,d2)=pairs[0],pairs[1]
        return f'{int(m1)}/{int(d1)} ~ {int(m2)}/{int(d2)}'
    # A single date is still displayed cleanly.
    if len(pairs) == 1:
        m,d=pairs[0]
        return f'{int(m)}/{int(d)}'
    return re.sub(r'\s+', ' ', text).strip()

def detect_sheet(ws):
    header=None; cols={}
    aliases={'code':['스타일','품번'],'title_ko':['상품명'],'title_en':['상품명(영문)','영문명'],'gender':['성별'],'zone':['조닝','종류'],'color':['컬러'],'normal':['정상가'],'sale':['조정가','할인가'],'promotion':['프로모션 내용'],'season':['시즌']}
    for r in range(1,min(ws.max_row,40)+1):
        vals=[str(ws.cell(r,c).value or '').strip() for c in range(1,ws.max_column+1)]
        if any(x in vals for x in ['스타일','품번']) and '정상가' in vals:
            header=r
            for key,names in aliases.items():
                for name in names:
                    if name in vals:
                        if key=='title_ko' and name=='상품명' and vals.count(name)>1: pass
                        cols[key]=vals.index(name)+1; break
            # explicit columns for this TOPTEN format
            if '상품명(영문)' in vals: cols['title_en']=vals.index('상품명(영문)')+1
            if '프로모션 내용' in vals: cols['promotion']=vals.index('프로모션 내용')+1
            break
    if not header: raise ValueError('헤더 행을 찾지 못했습니다. 품번/스타일과 정상가 열이 필요합니다.')
    return header,cols

def detect_date(ws):
    pats=[]
    for r in range(1,min(ws.max_row,20)+1):
      for c in range(1,min(ws.max_column,20)+1):
        s=str(ws.cell(r,c).value or '').strip()
        if '기간' in s or re.search(r'\d{1,2}월\s*\d{1,2}',s): pats.append(s)
    if not pats:return ''
    s=pats[0]
    s=re.sub(r'^.*?기간\s*[:：]?\s*','',s)
    s=re.sub(r'\s+',' ',s).strip()
    return s

def build_product_index():
    global _PRODUCT_INDEX
    index = {}
    if PRODUCT_DIR.exists():
        for p in PRODUCT_DIR.iterdir():
            if not p.is_file() or p.suffix.lower() not in EXTS:
                continue
            stem = clean_code(p.stem)
            base = re.split(r'[_-]', stem, maxsplit=1)[0]
            for key in {stem, base}:
                if key:
                    index.setdefault(key, []).append(p)
    for key, files in index.items():
        files.sort(key=lambda p: (EXTS.index(p.suffix.lower()), len(p.name)))
    _PRODUCT_INDEX = index
    return index

def find_visual(code):
    index = _PRODUCT_INDEX if _PRODUCT_INDEX is not None else build_product_index()
    code = clean_code(code)
    files = index.get(code, [])
    return files[0] if files else None

def normalize_product_name(text):
    """Normalize OCR/product names while keeping meaningful item words."""
    text = str(text or '').upper()
    text = re.sub(r'\([^)]*\)|\[[^]]*\]', ' ', text)
    text = re.sub(r'\d[\d,]*\s*원', ' ', text)
    text = re.sub(
        r'남성|여성|공용|키즈|정상가|할인가|기간한정|NEW\s*ARRIVAL|TOPTEN|탑텐|'
        r'봄|여름|가을|겨울|SPRING|SUMMER|FALL|WINTER|시즌|컬러|COLOR',
        ' ', text
    )
    return re.sub(r'[^0-9A-Z가-힣]+', '', text)


def _load_ocr_learning():
    try:
        raw = json.loads(OCR_LEARN_FILE.read_text('utf-8')) if OCR_LEARN_FILE.exists() else {}
        return raw if isinstance(raw, dict) else {}
    except Exception:
        return {}


def _save_ocr_learning(data):
    OCR_LEARN_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


def _learn_ocr_mapping(ocr_text, code):
    key = normalize_product_name(ocr_text)
    code = clean_code(code)
    if len(key) < 3 or not code:
        return
    data = _load_ocr_learning()
    data[key] = {'code': code, 'updated_at': datetime.now().isoformat(timespec='seconds')}
    _save_ocr_learning(data)


def _learned_code_for_text(ocr_text):
    norm = normalize_product_name(ocr_text)
    if not norm:
        return ''
    data = _load_ocr_learning()
    rec = data.get(norm)
    if isinstance(rec, dict) and rec.get('code'):
        return clean_code(rec['code'])
    best_code = ''
    best_score = 0.0
    for key, value in data.items():
        if not isinstance(value, dict) or not value.get('code'):
            continue
        score = difflib.SequenceMatcher(None, key, norm).ratio()
        if key in norm or norm in key:
            score = max(score, 0.94)
        if score > best_score:
            best_score, best_code = score, clean_code(value['code'])
    return best_code if best_score >= 0.90 else ''


def _remove_ocr_learning(codes=None, clear_all=False):
    if clear_all:
        _save_ocr_learning({})
        return
    targets = set(clean_code(c) for c in (codes or []) if clean_code(c))
    if not targets:
        return
    data = _load_ocr_learning()
    next_data = {
        key: value for key, value in data.items()
        if not isinstance(value, dict) or clean_code(value.get('code')) not in targets
    }
    if next_data != data:
        _save_ocr_learning(next_data)


def _normalize_bonus_mode(mode=None):
    mode=str(mode or '').strip().lower()
    return mode if mode in ('ocr','ai') else 'ocr'


def _bonus_map_file(mode=None):
    return BONUS_AI_MAP_FILE if _normalize_bonus_mode(mode)=='ai' else BONUS_OCR_MAP_FILE


def _bonus_override_file(mode=None):
    return BONUS_AI_OVERRIDE_FILE if _normalize_bonus_mode(mode)=='ai' else BONUS_OCR_OVERRIDE_FILE


def _read_json_dict(path):
    try:
        raw=json.loads(path.read_text('utf-8')) if path.exists() else {}
        return raw if isinstance(raw,dict) else {}
    except Exception:
        return {}


def _ensure_bonus_mode_storage():
    """One-time, lossless migration from the old shared mapping files.

    Legacy shared-mapping releases used one bonus_page_matches.json for both OCR and AI. We copy
    that legacy state into both independent stores once so switching engines can never
    make an existing mapping disappear during the upgrade.
    """
    legacy=_read_json_dict(LEGACY_BONUS_MAP_FILE)
    for path in (BONUS_OCR_MAP_FILE,BONUS_AI_MAP_FILE):
        if not path.exists():
            path.write_text(json.dumps(legacy,ensure_ascii=False,indent=2),encoding='utf-8')
    legacy_overrides=_read_json_dict(LEGACY_BONUS_OVERRIDE_FILE)
    for path in (BONUS_OCR_OVERRIDE_FILE,BONUS_AI_OVERRIDE_FILE):
        if not path.exists():
            path.write_text(json.dumps(legacy_overrides,ensure_ascii=False,indent=2),encoding='utf-8')
    if not BONUS_MODE_FILE.exists():
        # If a previous AI review was already confirmed, keep the user's current AI
        # workflow active; otherwise retain the traditional OCR behavior.
        mode='ocr'
        try:
            review=_read_json_dict(AI_REVIEW_FILE)
            if int(review.get('confirmed_count') or 0)>0: mode='ai'
        except Exception:
            pass
        BONUS_MODE_FILE.write_text(json.dumps({'mode':mode,'updated_at':datetime.now().isoformat(timespec='seconds')},ensure_ascii=False,indent=2),encoding='utf-8')


def get_bonus_match_mode():
    _ensure_bonus_mode_storage()
    data=_read_json_dict(BONUS_MODE_FILE)
    return _normalize_bonus_mode(data.get('mode'))


def set_bonus_match_mode(mode):
    mode=_normalize_bonus_mode(mode)
    _ensure_bonus_mode_storage()
    BONUS_MODE_FILE.write_text(json.dumps({'mode':mode,'updated_at':datetime.now().isoformat(timespec='seconds')},ensure_ascii=False,indent=2),encoding='utf-8')
    load_items(force=True)
    return mode


def load_bonus_matches(force=False, mode=None):
    global _BONUS_MAP_CACHE, _BONUS_MAP_MTIME
    _ensure_bonus_mode_storage()
    mode=_normalize_bonus_mode(mode or get_bonus_match_mode())
    path=_bonus_map_file(mode)
    try:
        mtime=path.stat().st_mtime_ns if path.exists() else -1
    except OSError:
        mtime=-1
    if not force and _BONUS_MAP_CACHE.get(mode) is not None and _BONUS_MAP_MTIME.get(mode)==mtime:
        return _BONUS_MAP_CACHE[mode]
    data=_read_json_dict(path)
    _BONUS_MAP_CACHE[mode]=data; _BONUS_MAP_MTIME[mode]=mtime
    return data


def save_bonus_matches(data, mode=None):
    global _BONUS_MAP_CACHE, _BONUS_MAP_MTIME
    _ensure_bonus_mode_storage()
    mode=_normalize_bonus_mode(mode or get_bonus_match_mode())
    path=_bonus_map_file(mode)
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    _BONUS_MAP_CACHE[mode]=data
    try:_BONUS_MAP_MTIME[mode]=path.stat().st_mtime_ns
    except OSError:_BONUS_MAP_MTIME[mode]=None


def _load_manual_overrides(mode=None):
    _ensure_bonus_mode_storage()
    mode=_normalize_bonus_mode(mode or get_bonus_match_mode())
    return _read_json_dict(_bonus_override_file(mode))


def _save_manual_overrides(data, mode=None):
    _ensure_bonus_mode_storage()
    mode=_normalize_bonus_mode(mode or get_bonus_match_mode())
    _bonus_override_file(mode).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')


def _set_manual_override(code, source_id, page, mode=None):
    mode=_normalize_bonus_mode(mode or get_bonus_match_mode())
    code=clean_code(code); source_id=_normalize_webhard_rel(source_id)
    if not code or not source_id:return
    data=_load_manual_overrides(mode)
    data[code]={'file':source_id,'source':source_id,'page':int(page),'updated_at':datetime.now().isoformat(timespec='seconds')}
    _save_manual_overrides(data,mode)


def _remove_manual_overrides(codes=None, filename='', clear_all=False, mode=None):
    mode=_normalize_bonus_mode(mode or get_bonus_match_mode())
    data=_load_manual_overrides(mode)
    if clear_all:
        _save_manual_overrides({},mode); return
    targets={clean_code(c) for c in (codes or []) if clean_code(c)}
    filename=_normalize_webhard_rel(filename)
    out={}
    for code,rec in data.items():
        remove=(clean_code(code) in targets) if targets else False
        if filename and _bonus_source_id(rec)==filename: remove=True
        if not remove: out[code]=rec
    if out!=data:_save_manual_overrides(out,mode)


def _normalize_webhard_rel(value):
    """Return a safe POSIX path relative to webhard_sync, or ''."""
    raw = str(value or '').strip().replace('\\', '/').lstrip('/')
    if not raw:
        return ''
    p = Path(raw)
    if p.is_absolute() or not p.parts or any(part in ('', '.', '..') for part in p.parts):
        return ''
    return p.as_posix()

def _resolve_webhard_pdf(value):
    """Resolve a mapping identifier to a PDF under webhard_sync.

    Legacy bonus_pdfs is only a fallback if legacy migration was interrupted.
    """
    rel = _normalize_webhard_rel(value)
    if rel:
        try:
            base = WEBHARD_SYNC_DIR.resolve()
            path = (WEBHARD_SYNC_DIR / Path(rel)).resolve()
            if base in path.parents and path.is_file() and path.suffix.lower() == '.pdf':
                return path
        except Exception:
            pass
    legacy_name = Path(str(value or '')).name
    legacy = LEGACY_BONUS_DIR / legacy_name
    if legacy.is_file() and legacy.suffix.lower() == '.pdf':
        return legacy
    return None

def _bonus_source_id(rec):
    if not isinstance(rec, dict):
        return ''
    return _normalize_webhard_rel(rec.get('source') or rec.get('file') or '')

def bonus_visual_for(code):
    rec = load_bonus_matches().get(clean_code(code))
    if not rec:
        return None
    source_id = _bonus_source_id(rec)
    path = _resolve_webhard_pdf(source_id or rec.get('file',''))
    return f"{path}::page={int(rec.get('page',0))}" if path and path.exists() else None

def season_letter_from_code(code):
    """TOPTEN style codes use the third alphabetic character as the season letter.

    Example: MSG2PP2501 -> G. 2026 = G, 2027 = H; E/F are carryover seasons.
    """
    code = clean_code(code)
    match = re.match(r'^[A-Z]{2}([A-Z])', code)
    return match.group(1) if match else ''


def is_carryover_code(code):
    return season_letter_from_code(code) in {'E', 'F'}


_SEASON_TOKEN_RE = re.compile(r'(?<![A-Z0-9])([A-Z])\s*[-_.]?\s*([0-9]{1,2})(?![A-Z0-9])', re.I)


def _normalize_season_token(value):
    """Return a compact TOPTEN season token such as F2/G2/G3 when visible."""
    raw=str(value or '').upper().strip()
    m=_SEASON_TOKEN_RE.search(raw)
    if m:
        return f'{m.group(1).upper()}{int(m.group(2))}'
    # Excel may occasionally contain only a season letter. Keep it as weak metadata,
    # but explicit filename tokens such as F2 are compared only to full tokens.
    m=re.search(r'(?<![A-Z])([A-Z])(?![A-Z])', raw)
    return m.group(1).upper() if m else ''


def _season_token_from_code(code):
    """Derive F2/G2/G3 style season from the style-code prefix when possible."""
    c=clean_code(code)
    m=re.match(r'^[A-Z]{2}([A-Z])([0-9])', c)
    return f'{m.group(1)}{m.group(2)}' if m else season_letter_from_code(c)


def _item_season_tokens(item):
    vals=[]
    explicit=_normalize_season_token(item.get('season'))
    derived=_season_token_from_code(item.get('code'))
    for x in (explicit,derived):
        if x and x not in vals: vals.append(x)
    return vals


def _source_season_tokens(pdf_path):
    """Extract explicit season markers from PDF filename/path. Filename is authoritative.

    Example: `0314_F2 티셔츠 POP.pdf` => {'F2'}.  When this exists, G2/G3 items
    are excluded before title similarity can promote them.
    """
    try:
        source=_sync_source_key(Path(pdf_path))
    except Exception:
        source=str(pdf_path or '')
    # Strongest evidence is the actual PDF filename. Parent folders are supplemental.
    name=Path(str(source).replace('\\','/')).name
    hits=[]
    for text in (name, str(source)):
        for m in _SEASON_TOKEN_RE.finditer(str(text).upper()):
            tok=f'{m.group(1).upper()}{int(m.group(2))}'
            if tok not in hits: hits.append(tok)
        if hits: break
    return hits


_ITEM_TYPE_RULES = [
    ('탱크탑', (r'탱크\s*탑', r'TANK\s*TOP')),
    ('슬리브리스', (r'슬리브리스', r'SLEEVELESS')),
    ('티셔츠', (r'티\s*셔츠', r'반팔\s*티', r'긴팔\s*티', r'\bT\s*-?\s*SHIRT\b', r'\bTSHIRT\b', r'\bTEE\b')),
    ('스웨터', (r'스웨터', r'\bSWEATER\b', r'\bKNIT\b')),
    ('가디건', (r'가디건', r'\bCARDIGAN\b')),
    ('셔츠', (r'(?<!티)셔츠', r'\bSHIRT\b')),
    ('팬츠', (r'팬츠', r'바지', r'슬랙스', r'\bPANTS\b', r'\bSLACKS\b', r'\bTROUSER')),
    ('스커트', (r'스커트', r'\bSKIRT\b')),
    ('원피스', (r'원피스', r'\bDRESS\b')),
    ('자켓', (r'자켓', r'재킷', r'\bJACKET\b')),
    ('점퍼', (r'점퍼', r'\bJUMPER\b', r'\bBLOUSON\b')),
]


def _extract_item_types(text):
    raw=str(text or '').upper()
    out=[]
    for label,pats in _ITEM_TYPE_RULES:
        if any(re.search(p,raw,re.I) for p in pats): out.append(label)
    return out


def _source_item_types(pdf_path):
    try: source=_sync_source_key(Path(pdf_path))
    except Exception: source=str(pdf_path or '')
    # Filename wording like `F2 티셔츠` is strong scope metadata.
    return _extract_item_types(Path(str(source).replace('\\','/')).name)


def _item_type_tokens(item):
    out=[]
    for value in (item.get('title_ko'),item.get('title_en'),item.get('zone')):
        for t in _extract_item_types(value):
            if t not in out: out.append(t)
    return out


def _season_relation(source_seasons,item):
    """Return (ok, bonus, note). Explicit full season mismatch is a hard reject."""
    src=[x for x in (source_seasons or []) if re.fullmatch(r'[A-Z][0-9]{1,2}',str(x or '').upper())]
    its=_item_season_tokens(item)
    full=[x for x in its if re.fullmatch(r'[A-Z][0-9]{1,2}',x)]
    if not src: return True,0.0,'시즌 단서 없음'
    if full and not set(src).intersection(full):
        return False,-1.0,f'PDF 시즌 {"/".join(src)} ≠ 품번 시즌 {"/".join(full)}'
    if set(src).intersection(full):
        return True,0.055,f'시즌 {next(iter(set(src).intersection(full)))} 일치'
    # No reliable item season: keep reviewable but never reward it.
    return True,0.0,f'PDF 시즌 {"/".join(src)} · 품번 시즌 확인불가'


def _type_relation(source_types,item):
    """Return (ok, bonus, note) using compatible retail item families.

    Filename class is strong, but not naively exact: `기타 스웨터` PDFs can contain
    cardigan pages, so sweater/cardigan share the KNIT family. Likewise tee/tank/
    sleeveless share a TOP family. Cross-family errors such as `티셔츠` -> `팬츠`
    are hard rejected when both sides are explicit.
    """
    src=list(source_types or [])
    its=_item_type_tokens(item)
    if not src: return True,0.0,'품종 단서 없음'
    if not its: return True,0.0,f'PDF 품종 {"/".join(src)} · 상품 품종 확인불가'
    fam={
        '티셔츠':'TOP','탱크탑':'TOP','슬리브리스':'TOP',
        '스웨터':'KNIT','가디건':'KNIT',
        '팬츠':'PANTS','셔츠':'SHIRT','스커트':'SKIRT','원피스':'DRESS',
        '자켓':'OUTER','점퍼':'OUTER',
    }
    exact=set(src).intersection(its)
    if exact:
        return True,0.035,f'품종 {next(iter(exact))} 일치'
    sf={fam.get(x,x) for x in src}; inf={fam.get(x,x) for x in its}
    compatible=sf.intersection(inf)
    if compatible:
        return True,0.018,f'품종군 호환 {"/".join(src)} ↔ {"/".join(its)}'
    return False,-1.0,f'PDF 품종 {"/".join(src)} ≠ 상품 품종 {"/".join(its)}'


def _load_visual_choices():
    try:
        data = json.loads(VISUAL_CHOICE_FILE.read_text('utf-8')) if VISUAL_CHOICE_FILE.exists() else {}
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_visual_choices(data):
    VISUAL_CHOICE_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


def _bonus_record_signature(code):
    rec = load_bonus_matches().get(clean_code(code))
    if not isinstance(rec, dict):
        return ''
    source_id = _bonus_source_id(rec)
    return f"{source_id}|{int(rec.get('page', 0))}" if source_id else ''


def get_carryover_visual_choice(code):
    code = clean_code(code)
    current_sig = _bonus_record_signature(code)
    if not current_sig:
        return ''
    rec = _load_visual_choices().get(code)
    if not isinstance(rec, dict) or rec.get('bonus_signature') != current_sig:
        return ''
    choice = str(rec.get('choice') or '')
    return choice if choice in {'bonus', 'clearance'} else ''


def set_carryover_visual_choice(code, choice):
    code = clean_code(code)
    choice = str(choice or '').strip().lower()
    if not code or choice not in {'bonus', 'clearance'}:
        return False
    sig = _bonus_record_signature(code)
    if not sig:
        return False
    data = _load_visual_choices()
    data[code] = {
        'choice': choice,
        'bonus_signature': sig,
        'updated_at': datetime.now().isoformat(timespec='seconds')
    }
    _save_visual_choices(data)
    load_items(force=True)
    return True


def _gender_template_page(gender, template_kind):
    gender = str(gender or '').strip()
    if template_kind == 'clearance':
        return {'공용': 0, '남성': 1, '여성': 2}.get(gender, 0)
    # TT adult-small: page 6 = common, 7 = men, 8 = women (zero based 5/6/7).
    return {'공용': 5, '남성': 6, '여성': 7}.get(gender, 5)


def _template_visual(template_path, page):
    return f"{template_path}::page={int(page)}"


def resolve_item_visual(code, gender, is_discount, discount_percent=0.0):
    """Apply final V4.4 routing rules.

    Final store priority:
      - Normal price: matched bonus first; NEW ARRIVAL when no bonus exists.
      - Discount 70% or more: SPECIAL PRICE POP is mandatory, even when a bonus PDF exists.
      - Discount below 70%: matched bonus first; adult-small POP when no bonus exists.
    """
    code = clean_code(code)
    bonus = bonus_visual_for(code)
    carryover = is_carryover_code(code)
    season = season_letter_from_code(code)
    try:
        discount_percent = float(discount_percent or 0.0)
    except Exception:
        discount_percent = 0.0
    result = {
        'season_letter': season,
        'is_carryover': carryover,
        'bonus_available': bool(bonus),
        'requires_bonus_choice': False,
        'bonus_choice': '',
        'discount_percent': round(discount_percent, 1),
        'discount_percent_fmt': (f'{discount_percent:.1f}%'.replace('.0%', '%') if is_discount else '-'),
    }

    # Normal price: bonus is always first, NEW ARRIVAL is fallback.
    if not is_discount:
        if bonus:
            result.update({
                'visual_mode': 'standard_overlay',
                'visual': bonus,
                'visual_status': '정상가 · 번외 PDF 우선'
            })
        else:
            result.update({
                'visual_mode': 'standard_overlay',
                'visual': str(TEMPLATE_DIR / 'NEW_ARRIVAL.pdf'),
                'visual_status': '정상가 · NEW ARRIVAL'
            })
        return result

    # 70% or deeper markdown ALWAYS uses SPECIAL PRICE and ignores bonus mapping.
    if discount_percent >= 70.0:
        page = _gender_template_page(gender, 'clearance')
        result.update({
            'visual_mode': 'clearance',
            'visual': _template_visual(CLEARANCE_TEMPLATE, page),
            'visual_status': f'할인율 {discount_percent:.1f}% · 70% 이상 특별가격 POP 필수'
        })
        return result

    # Every discounted item below 70%: bonus first, adult-small fallback.
    if bonus:
        result.update({
            'visual_mode': 'standard_overlay',
            'visual': bonus,
            'visual_status': f'할인율 {discount_percent:.1f}% · 번외 PDF 우선'
        })
    else:
        page = _gender_template_page(gender, 'adult_small')
        result.update({
            'visual_mode': 'adult_small',
            'visual': _template_visual(ADULT_SMALL_TEMPLATE, page),
            'visual_status': f'할인율 {discount_percent:.1f}% · 성인소형 POP'
        })
    return result

def extract_filename_codes(filename, items):
    """Extract known product codes from a PDF filename, preserving filename order.

    The comparison ignores spaces, underscores, hyphens and brackets. Matching against
    the current promotion item list is safer than OCR and avoids treating dates or other
    numbers as product codes.
    """
    stem = Path(filename).stem.upper()
    compact = re.sub(r'[^A-Z0-9]', '', stem)
    found = []
    seen = set()
    for item in items:
        code = clean_code(item.get('code'))
        code_compact = re.sub(r'[^A-Z0-9]', '', code)
        if not code_compact or code_compact in seen:
            continue
        pos = compact.find(code_compact)
        if pos >= 0:
            found.append((pos, -len(code_compact), code))
            seen.add(code_compact)
    found.sort()
    return [code for _, __, code in found]

def _item_by_code(items):
    return {clean_code(i.get('code')): i for i in items if clean_code(i.get('code'))}


def _saved_runtime_path(filename):
    try:
        p = DATA_DIR / filename
        return p.read_text('utf-8', errors='ignore').strip().strip('"') if p.exists() else ''
    except Exception:
        return ''


def _find_tesseract_executable():
    """Locate the exact Tesseract selected by the V4.4.27 bootstrap first."""
    env = os.environ.get('TESSERACT_CMD', '').strip()
    candidates = [
        _saved_runtime_path('tesseract_path.txt'),
        env,
        shutil.which('tesseract') or '',
        r'C:\Program Files\Tesseract-OCR\tesseract.exe',
        r'C:\Program Files (x86)\Tesseract-OCR\tesseract.exe',
        str(Path.home() / 'AppData/Local/Programs/Tesseract-OCR/tesseract.exe'),
    ]
    for candidate in candidates:
        if candidate and Path(candidate).exists():
            return str(Path(candidate))
    return ''


def _find_tessdata_dir():
    """Locate the exact verified OCR language directory selected by bootstrap."""
    program_data = os.environ.get('ProgramData', r'C:\ProgramData')
    local_appdata = os.environ.get('LOCALAPPDATA', '')
    candidates = [
        _saved_runtime_path('tessdata_path.txt'),
        os.environ.get('TOPTEN_TESSDATA_DIR', '').strip(),
        os.environ.get('TESSDATA_PREFIX', '').strip(),
        str(Path(program_data) / 'TOPTEN_POP' / 'tessdata') if program_data else '',
        str(Path(local_appdata) / 'TOPTEN_POP' / 'tessdata') if local_appdata else '',
        str(ROOT / 'ocr_tessdata'),
        str(ROOT / 'bootstrap_assets' / 'tessdata'),
        str(DATA_DIR / 'downloaded_tessdata'),
    ]
    for candidate in candidates:
        if not candidate:
            continue
        p = Path(candidate)
        if p.is_dir() and all((p / f'{lang}.traineddata').exists() for lang in ('kor','eng','osd')):
            return str(p)
    return ''


def _tessdata_config():
    path = _find_tessdata_dir()
    return f'--tessdata-dir "{path}"' if path else ''


def _decode_tesseract_console(data):
    """Decode Tesseract console output safely on Korean/legacy Windows code pages.

    Some Windows builds emit localized diagnostics in CP949/ANSI even though
    pytesseract assumes UTF-8 for ``--version``/``--list-langs``.  OCR text
    files themselves remain UTF-8; this helper is only for console metadata.
    """
    if data is None:
        return ''
    if isinstance(data, str):
        return data
    encodings = ['utf-8']
    try:
        import locale
        preferred = locale.getpreferredencoding(False)
        if preferred:
            encodings.append(preferred)
    except Exception:
        pass
    if os.name == 'nt':
        encodings.extend(['cp949', 'mbcs'])
    encodings.extend(['utf-8-sig', 'latin-1'])
    seen = set()
    for enc in encodings:
        key = str(enc).lower()
        if key in seen:
            continue
        seen.add(key)
        try:
            return data.decode(enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return data.decode('utf-8', errors='replace')


def _safe_tesseract_metadata(cmd, tessdata_dir=''):
    """Read Tesseract version/languages without pytesseract's UTF-8-only decoder."""
    version_proc = subprocess.run(
        [cmd, '--version'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        stdin=subprocess.DEVNULL, timeout=20, check=False
    )
    version_output = _decode_tesseract_console(version_proc.stdout)
    if version_proc.returncode != 0:
        raise RuntimeError(f'Tesseract --version 실패: {version_output.strip()[:180]}')
    first = next((line.strip() for line in version_output.splitlines() if line.strip()), '')
    version = first.replace('tesseract', '').strip() or first or 'unknown'

    args = [cmd]
    if tessdata_dir:
        args += ['--tessdata-dir', tessdata_dir]
    args += ['--list-langs']
    langs_proc = subprocess.run(
        args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        stdin=subprocess.DEVNULL, timeout=30, check=False
    )
    langs_output = _decode_tesseract_console(langs_proc.stdout)
    if langs_proc.returncode not in (0, 1):
        raise RuntimeError(f'Tesseract --list-langs 실패: {langs_output.strip()[:180]}')
    langs = sorted({line.strip() for line in langs_output.splitlines()
                    if re.fullmatch(r'[A-Za-z0-9_+-]+', line.strip())
                    and not line.lower().startswith('list of available')})
    return version, langs


def _patch_pytesseract_console_decode():
    """Make pytesseract error decoding tolerant of Korean Windows ANSI output."""
    if pytesseract is None:
        return
    try:
        module = pytesseract.pytesseract
        def _safe_get_errors(error_bytes):
            return ' '.join(_decode_tesseract_console(error_bytes).splitlines()).strip()
        module.get_errors = _safe_get_errors
    except Exception:
        pass


def ocr_engine_status():
    """Return a truthful OCR status and retry a delayed pytesseract import."""
    global pytesseract, _PYTESSERACT_IMPORT_ERROR
    if pytesseract is None:
        try:
            import importlib
            pytesseract = importlib.import_module('pytesseract')
            _PYTESSERACT_IMPORT_ERROR = ''
        except Exception as exc:
            _PYTESSERACT_IMPORT_ERROR = f'{type(exc).__name__}: {exc}'
            return False, f'pytesseract 불러오기 실패: {_PYTESSERACT_IMPORT_ERROR[:140]}'
    cmd = _find_tesseract_executable()
    if not cmd:
        return False, 'Tesseract 실행파일을 찾지 못함 (설치 경로 또는 TESSERACT_CMD 확인)'
    try:
        pytesseract.pytesseract.tesseract_cmd = cmd
        _patch_pytesseract_console_decode()
        tessdata_dir = _find_tessdata_dir()
        version, langs = _safe_tesseract_metadata(cmd, tessdata_dir)
        if 'kor' not in langs:
            return False, f'한국어 OCR 데이터(kor) 없음 · 감지 언어: {", ".join(langs) or "없음"}'
        return True, f'정상 · Tesseract {version} · 언어: {", ".join(langs)}'
    except Exception as exc:
        return False, f'Tesseract 연결 오류: {type(exc).__name__}: {str(exc)[:140]}'


def _load_ocr_cache():
    global _OCR_CACHE
    if _OCR_CACHE is not None:
        return _OCR_CACHE
    try:
        _OCR_CACHE = json.loads(OCR_CACHE_FILE.read_text('utf-8')) if OCR_CACHE_FILE.exists() else {}
    except Exception:
        _OCR_CACHE = {}
    return _OCR_CACHE


def _save_ocr_cache():
    global _OCR_CACHE_DIRTY
    if not _OCR_CACHE_DIRTY:
        return
    OCR_CACHE_FILE.write_text(json.dumps(_load_ocr_cache(), ensure_ascii=False, indent=2), encoding='utf-8')
    _OCR_CACHE_DIRTY = False


def _ocr_cache_key(pdf_path, page_no):
    p = Path(pdf_path)
    st = p.stat()
    return hashlib.sha1(f'{p.resolve()}|{st.st_size}|{st.st_mtime_ns}|{page_no}|{OCR_CACHE_VERSION}'.encode('utf-8', errors='ignore')).hexdigest()


def _prepare_ocr_image(page, dpi=220):
    """Render one PDF page once and enhance text with OpenCV.

    V4.4.27 keeps OCR preprocessing deterministic so the page cache can be reused
    across Excel uploads.  OpenCV improves contrast on coloured/low-contrast POPs.
    """
    pix = page.get_pixmap(matrix=fitz.Matrix(dpi/72, dpi/72), alpha=False, colorspace=fitz.csRGB)
    rgb = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width, 3)
    gray_raw = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    # Plain autocontrast keeps black text on coloured title bars intact.
    from PIL import ImageEnhance, ImageOps
    plain = ImageOps.autocontrast(Image.fromarray(gray_raw), cutoff=1)
    plain = ImageEnhance.Contrast(plain).enhance(1.45)
    plain = plain.resize((int(plain.width*1.20), int(plain.height*1.20)), Image.Resampling.BICUBIC)
    # Binary copy is used only for cheap layout detection/lower-page OCR.
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    enhanced = clahe.apply(gray_raw)
    enhanced = cv2.resize(enhanced, None, fx=1.20, fy=1.20, interpolation=cv2.INTER_CUBIC)
    _, binary = cv2.threshold(enhanced, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return plain, Image.fromarray(binary)


def _ocr_one_image(im, psm=11):
    config = f'--oem 3 --psm {int(psm)} -c preserve_interword_spaces=1 ' + _tessdata_config()
    try:
        text = pytesseract.image_to_string(im, lang='kor+eng', config=config)
    except Exception:
        return ''
    return re.sub(r'\s+', ' ', str(text or '')).strip()


def _detect_two_column_layout(binary: Image.Image) -> bool:
    """Cheap visual test for a real centre gutter.

    It is intentionally conservative.  A false split is worse than doing one extra
    full-page match; multiple filename codes still force left/right OCR because many
    headquarters POPs are explicit multi-product layouts.
    """
    arr = np.asarray(binary.convert('L'))
    if arr.ndim != 2 or arr.shape[1] < 500 or arr.shape[0] < 500:
        return False
    h, w = arr.shape
    # Ignore very top/bottom decorative bands. Text/visual columns generally occupy
    # the central 70% of these POP pages.
    roi = arr[int(h*0.16):int(h*0.88), :]
    ink = (roi < 210).mean(axis=0)
    lo, hi = int(w*0.36), int(w*0.64)
    if hi <= lo:
        return False
    center = ink[lo:hi]
    if center.size == 0:
        return False
    # Smooth into ~1% width windows and look for a vertical low-ink gutter.
    k = max(5, int(w*0.012))
    kernel = np.ones(k, dtype=np.float32) / k
    smooth = np.convolve(center.astype(np.float32), kernel, mode='same')
    valley = float(smooth.min())
    left_density = float(np.median(ink[int(w*0.08):int(w*0.33)]))
    right_density = float(np.median(ink[int(w*0.67):int(w*0.92)]))
    side = max(0.001, min(left_density, right_density))
    return valley <= max(0.012, side * 0.42)


def _crop_relative(im: Image.Image, x0, y0, x1, y1):
    w, h = im.size
    return im.crop((max(0, int(w*x0)), max(0, int(h*y0)), min(w, int(w*x1)), min(h, int(h*y1))))


def ocr_pdf_page_analysis(pdf_path, page_no, page=None, force=False, force_split=False):
    """OCR a page into reusable semantic regions.

    V4.4.27 checks the page cache *before* asking Tesseract for status.  On a 400-PDF
    rematch this avoids hundreds of needless tesseract --version/--list-langs launches.
    The OCR image is rendered again only for a truly new/changed page or explicit retry.
    """
    global _OCR_CACHE_DIRTY
    key = _ocr_cache_key(pdf_path, page_no)
    cache = _load_ocr_cache()
    rec = cache.get(key)
    if isinstance(rec, dict) and rec.get('regions') and not force:
        regions = dict(rec.get('regions') or {})
        regions.setdefault('split', bool(rec.get('split')))
        regions['combined'] = re.sub(r'\s+', ' ', ' '.join(str(regions.get(k,'') or '') for k in ('full','lower','left','right'))).strip()
        return regions
    ok, _ = ocr_engine_status()
    if not ok:
        return {'full':'', 'lower':'', 'left':'', 'right':'', 'split':False, 'combined':''}
    own_doc = None
    try:
        if page is None:
            own_doc = fitz.open(str(pdf_path))
            page = own_doc.load_page(page_no)
        gray, binary = _prepare_ocr_image(page)
        full = _ocr_one_image(gray, 11)
        lower_img = _crop_relative(binary, 0.0, 0.45, 1.0, 0.97)
        lower = _ocr_one_image(lower_img, 11)
        split = bool(force_split or _detect_two_column_layout(binary))
        left = right = ''
        if split:
            # TOPTEN headquarters POPs place product names in a band below the photos.
            # A narrow gray-image crop avoids model/photo clutter and is dramatically
            # better at separating two products on one page (e.g. left vest/right cardigan).
            left_img = _crop_relative(gray, 0.00, 0.64, 0.51, 0.83)
            right_img = _crop_relative(gray, 0.49, 0.64, 1.00, 0.83)
            left = _ocr_one_image(left_img, 6)
            right = _ocr_one_image(right_img, 6)
        regions = {'full':full, 'lower':lower, 'left':left, 'right':right, 'split':split}
        regions['combined'] = re.sub(r'\s+', ' ', ' '.join(x for x in (full,lower,left,right) if x)).strip()
        cache[key] = {
            'text': regions['combined'], 'regions': {k:v for k,v in regions.items() if k != 'combined'},
            'split': split, 'at': datetime.now().isoformat(timespec='seconds')
        }
        _OCR_CACHE_DIRTY = True
        _save_ocr_cache()
        return regions
    except Exception:
        return {'full':'', 'lower':'', 'left':'', 'right':'', 'split':False, 'combined':''}
    finally:
        if own_doc is not None:
            own_doc.close()


def ocr_pdf_page(pdf_path, page_no, page=None, force=False):
    """Compatibility wrapper used by older routes."""
    return ocr_pdf_page_analysis(pdf_path, page_no, page=page, force=force).get('combined','')


def _title_tokens(text):
    cleaned = str(text or '').upper()
    cleaned = re.sub(r'NEW\s*ARRIVAL|정상가|할인가|기간한정|TOPTEN|탑텐|POP|F\d+', ' ', cleaned)
    return [t for t in re.findall(r'[0-9A-Z가-힣]+', cleaned) if len(t) >= 2]


def _filename_description(filename, filename_codes):
    text = Path(str(filename or '')).stem
    for code in filename_codes or []:
        text = re.sub(re.escape(str(code)), ' ', text, flags=re.I)
    text = re.sub(r'(^|[^0-9])\d{3,4}([^0-9]|$)', ' ', text)
    text = re.sub(r'\bF\d+\b|\bPOP\b|기타', ' ', text, flags=re.I)
    text = re.sub(r'[_\-(),\[\]]+', ' ', text).strip()
    if len(normalize_product_name(text)) < 4:
        return ''
    return text


_GENERIC_META_TOKENS = {
    '남성','여성','공용','키즈','여류','남류','라인업','기타','상품','제품','소재','기능','데일리','기본','베이직',
    '티','티셔츠','반팔','긴팔','탱크탑','탱크','슬리브리스','스웨터','가디건','팬츠','바지','슬랙스','셔츠','블라우스',
    '자켓','재킷','점퍼','아우터','원피스','스커트','셋업','세트','코튼','그래픽','립','리브','쿨링','컴포트',
    'MEN','WOMEN','UNISEX','KIDS','LINEUP','BASIC','DAILY','COTTON','GRAPHIC','TEE','TSHIRT','SHIRT','PANTS',
    'SLACKS','SWEATER','CARDIGAN','TANK','TOP','SETUP','SET','COOLING','COMFORT','AIR'
}


def _semantic_tokens(text):
    out=[]
    for tok in _title_tokens(text):
        t=tok.upper()
        if t in _GENERIC_META_TOKENS:
            continue
        if re.fullmatch(r'\d+', t):
            continue
        if len(t) < 2:
            continue
        out.append(t)
    return out


def _item_anchor_tokens(item):
    toks=[]
    for value in (item.get('title_ko'), item.get('title_en')):
        for t in _semantic_tokens(value):
            if t not in toks:
                toks.append(t)
    return toks[:8]


def _source_anchor_tokens(source_desc):
    toks=[]
    for t in _semantic_tokens(source_desc):
        if t not in toks:
            toks.append(t)
    return toks[:8]


def _anchor_relation(source_desc, item):
    """Return (match, hard_conflict, source_anchors, item_anchors).

    Folder/file names often carry the strongest product-line clue (e.g. 쿨에어).
    Generic item words like 탱크탑 are intentionally excluded.  This prevents a HOTSTUFF
    tank top from being auto-linked to a COOL AIR lineup just because both say 탱크탑.
    """
    src=_source_anchor_tokens(source_desc)
    it=_item_anchor_tokens(item)
    if not src or not it:
        return False, False, src, it
    def same(a,b):
        aa=normalize_product_name(a); bb=normalize_product_name(b)
        if not aa or not bb: return False
        return aa==bb or aa in bb or bb in aa or fuzz.ratio(aa,bb)>=88
    matched=any(same(a,b) for a in src for b in it)
    # Only call it a hard conflict when metadata has a small, clear set of line anchors.
    # Broad descriptive filenames with many tokens do not receive a hard negative.
    conflict=(not matched and len(src) <= 3 and len(it) <= 5)
    return matched, conflict, src, it


def _source_description(pdf_path, filename_codes):
    try:
        source_id=_sync_source_key(Path(pdf_path))
    except Exception:
        source_id=Path(pdf_path).name
    parts=[]
    for part in Path(str(source_id).replace('\\','/')).parts:
        cleaned=_filename_description(part, filename_codes)
        if cleaned:
            parts.append(cleaned)
    return ' '.join(parts).strip()


def _match_search_index(items):
    global _MATCH_SEARCH_CACHE
    sig=hashlib.sha1('|'.join(
        f"{clean_code(i.get('code'))}:{i.get('title_ko','')}:{i.get('title_en','')}:{i.get('gender','')}:{i.get('zone','')}:{_breed_large_from_style_code(i.get('code'))}"
        for i in items
    ).encode('utf-8',errors='ignore')).hexdigest()
    if isinstance(_MATCH_SEARCH_CACHE,dict) and _MATCH_SEARCH_CACHE.get('sig')==sig:
        return _MATCH_SEARCH_CACHE
    choices={}
    anchors={}
    for idx,item in enumerate(items):
        title=' '.join(x for x in (
            normalize_product_name(item.get('title_ko')),
            normalize_product_name(item.get('title_en'))
        ) if x).strip()
        if title:
            choices[idx]=title
        anchors[idx]=_item_anchor_tokens(item)
    _MATCH_SEARCH_CACHE={'sig':sig,'choices':choices,'anchors':anchors}
    return _MATCH_SEARCH_CACHE


def _filename_scope_items(items, filename_codes):
    allowed = {clean_code(c) for c in (filename_codes or []) if clean_code(c)}
    if not allowed:
        return []
    return [i for i in items if clean_code(i.get('code')) in allowed]


def _fast_candidate_items(region_text, items, filename_codes=None, source_desc='', limit=28):
    """Fast retrieval with TOPTEN manual 품종대 gating before expensive fuzzy scoring.

    Filename SKU membership still never implies page order.  A clear page/product manual
    large-category mismatch is removed early; unknown categories remain eligible so OCR
    errors cannot make the candidate set empty.
    """
    page_cat=_page_breed_category(region_text,source_desc)
    page_large=set(page_cat.get('large') or [])
    def breed_filter(rows):
        rows=list(rows)
        if not page_large:
            return rows
        good=[]; unknown=[]
        for it in rows:
            ic=_item_breed_category(it); il=set(ic.get('large') or [])
            if il and il.intersection(page_large): good.append(it)
            elif not il: unknown.append(it)
        # Known matching category first; retain unknowns as safe fallback.
        return good+unknown if good else rows

    scoped=_filename_scope_items(items, filename_codes)
    if scoped:
        return breed_filter(scoped)
    idx=_match_search_index(items)
    query=normalize_product_name(f'{source_desc} {region_text}')
    selected=[]; seen=set()
    if query and idx['choices']:
        try:
            hits=process.extract(query, idx['choices'], scorer=fuzz.WRatio,
                                 limit=min(int(limit)*2,len(idx['choices'])), score_cutoff=30)
        except Exception:
            hits=[]
        for _,__,item_idx in hits:
            if item_idx in seen: continue
            seen.add(item_idx); selected.append(items[item_idx])
    src=set(_source_anchor_tokens(source_desc))
    if src:
        for item_idx,toks in idx['anchors'].items():
            if item_idx in seen: continue
            if src.intersection(toks):
                seen.add(item_idx); selected.append(items[item_idx])
                if len(selected)>=limit*2: break
    selected=breed_filter(selected)
    if selected:
        return selected[:max(limit,1)]
    fallback=breed_filter(items)
    return fallback[:min(len(fallback),max(limit,1))]
def _cluster_candidate_codes(items, filename_codes):
    scoped = _filename_scope_items(items, filename_codes)
    groups = []
    for item in scoped:
        title = normalize_product_name(item.get('title_ko') or item.get('title_en') or '')
        placed = False
        for group in groups:
            gtitle = group['title']
            similar = bool(title and gtitle and (title == gtitle or fuzz.ratio(title, gtitle) >= 92))
            if similar:
                group['items'].append(item); placed=True; break
        if not placed:
            groups.append({'title': title, 'items': [item]})
    return groups


def _rapid_title_score(source_text, title):
    source = normalize_product_name(source_text)
    target = normalize_product_name(title)
    if not source or not target or len(target) < 2:
        return 0.0
    if target in source:
        return 0.99 if len(target) >= 5 else 0.92
    ratio = fuzz.ratio(target, source) / 100.0
    partial = fuzz.partial_ratio(target, source) / 100.0
    wratio = fuzz.WRatio(target, source) / 100.0
    score = max(ratio * 0.92, partial * 0.90, wratio * 0.94)
    if len(target) <= 4:
        score = min(score, 0.84)
    return max(0.0, min(1.0, score))


def _title_match_score(ocr_text, item):
    raw = str(ocr_text or '')
    best = 0.0
    for title in (item.get('title_ko'), item.get('title_en')):
        best = max(best, _rapid_title_score(raw, title))
    return best


def _context_bonus(text, item):
    raw = str(text or '').upper()
    bonus = 0.0
    gender = str(item.get('gender') or '').strip()
    zone = str(item.get('zone') or '').strip()
    if gender and gender.upper() in raw:
        bonus += 0.025
    if zone:
        zone_tokens = [t for t in _title_tokens(zone) if len(t) >= 2]
        if zone_tokens and any(t in raw for t in zone_tokens):
            bonus += 0.02
    return bonus


def _score_items_hybrid(region_text, items, filename_codes=None, source_desc='', limit=None, page_hint_code=''):
    allowed = set(clean_code(c) for c in (filename_codes or []) if clean_code(c))
    learned = _learned_code_for_text(region_text)
    scope_items = _fast_candidate_items(region_text, items, filename_codes, source_desc, limit=30)
    if learned and all(clean_code(i.get('code')) != learned for i in scope_items):
        learned_item = next((i for i in items if clean_code(i.get('code')) == learned), None)
        if learned_item is not None:
            scope_items = list(scope_items) + [learned_item]
    scope_size = len(scope_items)
    scored = []
    for item in scope_items:
        code = clean_code(item.get('code'))
        title_score = _title_match_score(region_text, item)
        source_title = _title_match_score(source_desc, item) if source_desc else 0.0
        anchor_match, anchor_conflict, src_anchors, item_anchors = _anchor_relation(source_desc, item)
        filename_bonus = 0.10 if code in allowed else 0.0
        page_order = bool(page_hint_code and code == clean_code(page_hint_code))
        pg,ig,gender_adj,gender_reason=_ai_gender_relation(region_text,item)
        breed_adj,breed_conflict,page_breed,item_breed,breed_reason=_manual_breed_relation(region_text,item,source_desc)
        score = max(title_score, source_title * 0.92)
        if gender_adj < 0 or breed_conflict:
            score = 0.0
        else:
            score += filename_bonus + _context_bonus(region_text, item) + gender_adj + breed_adj
            if anchor_match: score += 0.13
            if page_order: score += 0.08
        if anchor_conflict:
            score=min(score,0.49)
        score=min(1.0,max(0.0,score))
        learned_candidate = bool(learned and code == learned and gender_adj >= 0 and not breed_conflict)
        if learned_candidate:
            score = max(score, 0.97); anchor_conflict=False
        scored.append({
            'score': float(score), 'title_score': float(title_score),
            'filename_title_score': float(source_title), 'item': item,
            'filename_candidate': code in allowed, 'scope_size': scope_size,
            'learned_candidate': learned_candidate, 'anchor_match':anchor_match,
            'anchor_conflict':anchor_conflict, 'source_anchors':src_anchors,
            'item_anchors':item_anchors, 'page_order_candidate':page_order,
            'gender_conflict': gender_adj < 0, 'gender_reason': gender_reason,
            'breed_conflict': breed_conflict, 'breed_reason': breed_reason,
            'page_breed': page_breed, 'item_breed': item_breed,
        })
    scored.sort(key=lambda x: (
        x.get('gender_conflict',False), x.get('breed_conflict',False), x.get('anchor_conflict',False),
        -x['score'], -x['title_score'], clean_code(x['item'].get('code'))
    ))
    return scored if limit is None else scored[:limit]
def _suggestions_from_hybrid(scored, limit=3):
    out=[]
    for x in scored[:limit]:
        item=x['item']
        out.append({
            'code':clean_code(item.get('code')), 'title':str(item.get('title_ko') or ''),
            'score':round(x['score']*100),'gender':_ai_item_gender(item) or '-',
            'category':_breed_label(_item_breed_category(item)),
        })
    return out
def _code_present_in_text(text, code):
    compact_text = re.sub(r'[^A-Z0-9]', '', str(text or '').upper())
    compact_code = re.sub(r'[^A-Z0-9]', '', clean_code(code).upper())
    return bool(compact_code and compact_code in compact_text)


def _present_codes(text, codes):
    found=[]
    for code in codes:
        c=clean_code(code)
        if c and _code_present_in_text(text,c) and c not in found:
            found.append(c)
    return found


def _unique_present_code(text, codes):
    present=_present_codes(text,codes)
    return present[0] if len(present)==1 else ''


def _grade_candidate(best, second_score, exact_page_code=False):
    if not best:
        return False, 'E', 0.0
    score=float(best.get('score') or 0); title=float(best.get('title_score') or 0)
    source_title=float(best.get('filename_title_score') or 0)
    margin=max(0.0, score-float(second_score or 0)); scope_size=int(best.get('scope_size') or 0)
    if best.get('gender_conflict') or best.get('breed_conflict'):
        return False,'D',margin
    if best.get('learned_candidate') or exact_page_code:
        return True,'A',margin
    if best.get('anchor_conflict'):
        return False,'D',margin
    anchor=bool(best.get('anchor_match')); page_order=bool(best.get('page_order_candidate'))
    if best.get('filename_candidate'):
        # Filename code means this style belongs to the PDF; it never means "pick the first code".
        # Weak title/path corroboration is enough, while a line conflict above blocks it.
        if scope_size <= 1:
            if title>=0.42 or source_title>=0.56 or anchor:
                return True,'B',margin
        else:
            if title>=0.56 and margin>=0.02: return True,'A',margin
            if title>=0.45 and margin>=0.03: return True,'B',margin
            if page_order and (title>=0.35 or source_title>=0.45 or anchor): return True,'B',margin
            if anchor and title>=0.36: return True,'B',margin
        return (False,'C',margin) if score>=0.50 else (False,'D',margin)
    # No code in filename: require strong visible title, but path-line agreement can lower
    # the threshold safely. This is where HOTSTUFF vs COOL AIR is explicitly guarded.
    if anchor and title>=0.62 and margin>=0.025: return True,'A',margin
    if title>=0.76 and margin>=0.04: return True,'A',margin
    if title>=0.68 and margin>=0.07: return True,'B',margin
    return (False,'C',margin) if score>=0.52 else (False,'E',margin)

def _build_result(page_no, region_name, region_text, scored, filename_codes, exact_code=''):
    by_code={clean_code(x['item'].get('code')):x for x in scored}
    best = by_code.get(clean_code(exact_code)) if exact_code else (scored[0] if scored else None)
    if best is None:
        return {
            'page':page_no,'page_label':page_no+1,'text':region_text[:220], 'code':'','title':'','score':0,
            'method':f'{region_name} · 판독 부족','needs_manual':True,'filename_codes':filename_codes,
            'suggestions':_suggestions_from_hybrid(scored,3),'margin':0,'grade':'E'
        }
    second=max((x['score'] for x in scored if clean_code(x['item'].get('code')) != clean_code(best['item'].get('code'))), default=0.0)
    exact=bool(exact_code and clean_code(best['item'].get('code'))==clean_code(exact_code))
    auto, grade, margin=_grade_candidate(best,second,exact_page_code=exact)
    item=best['item']; code=clean_code(item.get('code'))
    recommended=bool((auto or (best['score'] >= 0.60 and margin >= 0.06)) and not best.get('anchor_conflict') and not best.get('gender_conflict') and not best.get('breed_conflict'))
    signals=[]
    if exact: signals.append('페이지 내부 품번')
    if best['title_score']>=0.50: signals.append('상품명 OCR')
    if best.get('filename_candidate'): signals.append('파일명 품번 포함')
    if best.get('filename_title_score',0)>=0.55: signals.append('폴더/파일 상품명')
    if best.get('anchor_match'): signals.append('제품라인 일치')
    if best.get('page_order_candidate'): signals.append('페이지순서 보조')
    if best.get('gender_conflict'): signals.append('성별 충돌 차단')
    if best.get('breed_conflict'): signals.append('품종대 충돌 차단')
    elif best.get('page_breed',{}).get('large') and best.get('item_breed',{}).get('large'): signals.append('품종코드 일치')
    if best.get('anchor_conflict'): signals.append('제품라인 충돌 차단')
    method=f'{region_name} · ' + (' + '.join(signals) if signals else '유사도 후보') + f' · {grade}급'
    return {
        'page':page_no,'page_label':page_no+1,'text':region_text[:220],
        'code':code if recommended else '', 'title':str(item.get('title_ko') or '') if recommended else '',
        'score':round(best['score']*100),'method':method,'needs_manual':not auto,
        'filename_codes':filename_codes,'suggestions':_suggestions_from_hybrid(scored,3),
        'margin':round(margin*100),'grade':grade,
    }


def _expand_shared_title_group(result, scored, groups, region_text, region_name, filename_codes):
    """Expand one confident OCR decision to all filename codes sharing that same title.

    Example: a headquarters POP filename can list 3 style codes that all correspond to
    the same displayed product name.  Mapping only one of them is incomplete; mapping all
    of them is safe only when the visible title supports that shared title cluster.
    """
    if not result or result.get('needs_manual') or not result.get('code'):
        return [result] if result else []
    code = clean_code(result.get('code'))
    group = next((g for g in groups if any(clean_code(i.get('code')) == code for i in g.get('items', []))), None)
    if not group or len(group.get('items', [])) <= 1:
        return [result]
    # Require OCR evidence for the shared product title.  The filename list alone never expands.
    best_title = max((_title_match_score(region_text, i) for i in group['items']), default=0.0)
    if best_title < 0.50:
        return [result]
    out = []
    for item in group['items']:
        c = clean_code(item.get('code'))
        base = next((x for x in scored if clean_code(x['item'].get('code')) == c), None)
        if base is None:
            continue
        clone = dict(result)
        clone['code'] = c
        clone['title'] = str(item.get('title_ko') or '')
        clone['score'] = round(max(float(base.get('score') or 0), best_title) * 100)
        clone['needs_manual'] = False
        clone['grade'] = 'B'
        clone['method'] = f'{region_name} · 상품명 OCR + 파일명 공통상품 다중품번 · B급'
        clone['suggestions'] = _suggestions_from_hybrid(scored, 3)
        out.append(clone)
    return out or [result]


def _dedupe_page_results(results):
    """Keep the strongest row for each code while allowing multiple codes per page."""
    by_code={}
    blanks=[]
    for r in results:
        code=clean_code(r.get('code'))
        if not code:
            blanks.append(r); continue
        old=by_code.get(code)
        key=(not r.get('needs_manual'), int(r.get('score') or 0), int(r.get('margin') or 0))
        old_key=(not old.get('needs_manual'), int(old.get('score') or 0), int(old.get('margin') or 0)) if old else None
        if old is None or key>old_key:
            by_code[code]=r
    kept=list(by_code.values())
    kept.sort(key=lambda r:(int(r.get('page',0)), -int(r.get('score') or 0), clean_code(r.get('code'))))
    if kept:
        return kept
    return blanks[:1]


def match_pdf_pages(pdf_path, items, force_ocr=False):
    """V4.4.27 fast path-aware matcher.

    Key changes:
    - all filename codes are membership candidates; the first code is never privileged;
    - folder names are evidence (e.g. 쿨에어) and conflicting product lines are blocked;
    - cached OCR is read without launching Tesseract metadata checks;
    - PDFs without codes search only a RapidFuzz top-N shortlist, not the whole Excel;
    - when filename-code count equals page count, order is only a small tie-breaker;
    - single-page files with several codes can map all same-title style codes to that page.
    """
    results=[]; by_code=_item_by_code(items)
    filename_codes=extract_filename_codes(Path(pdf_path).name, items)
    source_desc=_source_description(pdf_path,filename_codes)
    filename_groups=_cluster_candidate_codes(items,filename_codes)
    doc=fitz.open(str(pdf_path))
    try:
        for page_no in range(doc.page_count):
            _raise_if_scan_cancelled()
            page=doc.load_page(page_no)
            embedded=re.sub(r'\s+',' ',page.get_text('text') or '').strip()
            # Only force split when one page really contains several different title groups.
            force_split=bool(doc.page_count==1 and len(filename_groups)>1)
            analysis=ocr_pdf_page_analysis(pdf_path,page_no,page=page,force=force_ocr,force_split=force_split)
            combined=re.sub(r'\s+',' ',f"{embedded} {analysis.get('combined','')}").strip()
            page_results=[]
            page_hint=(filename_codes[page_no] if len(filename_codes)>1 and len(filename_codes)==doc.page_count else '')

            exact_codes=_present_codes(combined,[i.get('code') for i in items])
            for exact in exact_codes:
                if exact not in by_code: continue
                scored=_score_items_hybrid(combined,items,filename_codes,source_desc,page_hint_code=page_hint)
                page_results.append(_build_result(page_no,'전체 페이지',combined,scored,filename_codes,exact_code=exact))

            split=bool(analysis.get('split')); used_groups=set()
            if split:
                region_rows=[]
                for label,key in (('좌측 상품영역','left'),('우측 상품영역','right')):
                    rtext=str(analysis.get(key) or '').strip()
                    if len(normalize_product_name(rtext))<3: continue
                    scored=_score_items_hybrid(rtext,items,filename_codes,source_desc,page_hint_code=page_hint)
                    if not scored: continue
                    top=float(scored[0].get('score') or 0); second=float(scored[1].get('score') or 0) if len(scored)>1 else 0.0
                    region_rows.append((top-second,top,label,rtext,scored))
                region_rows.sort(key=lambda x:(-x[0],-x[1]))
                for _,__,label,rtext,scored0 in region_rows:
                    scored=list(scored0)
                    if used_groups and filename_groups:
                        blocked=set()
                        for gi in used_groups:
                            blocked.update(clean_code(i.get('code')) for i in filename_groups[gi]['items'])
                        filtered=[x for x in scored if clean_code(x['item'].get('code')) not in blocked]
                        if filtered: scored=filtered
                    r=_build_result(page_no,label,rtext,scored,filename_codes)
                    if r.get('score',0)<42: continue
                    code=clean_code(r.get('code')); gi=None
                    if code and filename_groups:
                        gi=next((idx for idx,g in enumerate(filename_groups) if any(clean_code(i.get('code'))==code for i in g['items'])),None)
                    expanded=_expand_shared_title_group(r,scored,filename_groups,rtext,label,filename_codes)
                    # Never expand a group through a product-line conflict.
                    expanded=[x for x in expanded if x]
                    page_results.extend(expanded)
                    if gi is not None and any(not x.get('needs_manual') for x in expanded): used_groups.add(gi)

            base_text=' '.join(x for x in (embedded,analysis.get('full',''),analysis.get('lower','')) if x).strip()
            confident={clean_code(r.get('code')) for r in page_results if r.get('code') and not r.get('needs_manual')}
            if not confident or not split:
                scored=_score_items_hybrid(base_text,items,filename_codes,source_desc,page_hint_code=page_hint)
                exact=_unique_present_code(base_text,[i.get('code') for i in items])
                r=_build_result(page_no,'전체/하단 상품명',base_text,scored,filename_codes,exact_code=exact)
                page_results.extend(_expand_shared_title_group(r,scored,filename_groups,base_text,'전체/하단 상품명',filename_codes))

            # Important shared-POP rule: if a one-page filename explicitly lists several
            # style codes and they form the same title group, keep every style. This fixes
            # old "first code wins" behaviour without trusting unrelated codes.
            if doc.page_count==1 and filename_codes and filename_groups:
                for group in filename_groups:
                    if len(group.get('items',[]))<=1: continue
                    group_title=max((_title_match_score(base_text,i) for i in group['items']),default=0.0)
                    safe=[]
                    for item in group['items']:
                        anchor_match,conflict,_,_=_anchor_relation(source_desc,item)
                        src_title=_title_match_score(source_desc,item)
                        if not conflict and (group_title>=0.42 or src_title>=0.48 or anchor_match):
                            safe.append(item)
                    if len(safe)>=2:
                        for item in safe:
                            code=clean_code(item.get('code'))
                            page_results.append({
                                'page':page_no,'page_label':page_no+1,'text':base_text[:220],
                                'code':code,'title':str(item.get('title_ko') or ''),
                                'score':round(max(group_title,0.70)*100),
                                'method':'단일페이지 · 파일명 다중품번 멤버십 + 공통상품명 검증 · B급',
                                'needs_manual':False,'filename_codes':filename_codes,
                                'suggestions':[],'margin':100,'grade':'B'
                            })

            deduped=_dedupe_page_results(page_results)
            autos=[r for r in deduped if r.get('code') and not r.get('needs_manual')]
            if autos:
                results.extend(deduped)
            else:
                useful=[r for r in deduped if int(r.get('score') or 0)>=48]
                if useful:
                    useful.sort(key=lambda r:(-int(r.get('score') or 0),-int(r.get('margin') or 0)))
                    results.append(useful[0])
                elif deduped:
                    results.append(deduped[0])
    finally:
        doc.close()
    return results


# ---------------- V4.4.27 PaddleOCR-VL 1.6 page AI engine ----------------
_AI_CACHE = None
_AI_CACHE_DIRTY = False


def _ai_worker_env():
    env=os.environ.copy()
    env['TOPTEN_AI_SITE']=str(AI_SITE_DIR)
    env['PYTHONNOUSERSITE']='1'
    env.pop('PADDLE_PDX_MODEL_SOURCE',None)
    env.setdefault('HF_HUB_ETAG_TIMEOUT','8')
    env.setdefault('HF_HUB_DOWNLOAD_TIMEOUT','120')
    # Once the official model cache is complete, skip the remote source connectivity
    # check. This avoids the old 8-20 second status/import waits on every page load.
    try:
        model_dir=Path.home()/'.paddlex'/'official_models'/'PaddleOCR-VL-1.6'
        if model_dir.is_dir() and sum(p.stat().st_size for p in model_dir.rglob('*') if p.is_file()) > 500*1024*1024:
            env['PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK']='True'
    except Exception:
        pass
    return env


def _ai_installed_versions():
    """Read package metadata without importing Paddle/PaddleOCR.

    Importing Paddle just to paint the status line can take longer than the old
    subprocess timeout on CPU-only Windows PCs. Matching itself is the real runtime
    test; the status page must stay instant and non-blocking.
    """
    versions={}
    try:
        for dist in __import__('importlib.metadata',fromlist=['distributions']).distributions(path=[str(AI_SITE_DIR)]):
            name=str(dist.metadata.get('Name') or '').strip().lower().replace('_','-')
            if name in ('paddlepaddle','paddleocr'):
                versions[name]=str(dist.version)
    except Exception:
        pass
    return versions


def _ai_probe_light():
    if not AI_SITE_DIR.exists(): return False, 'AI 전용 런타임 미설치'
    versions=_ai_installed_versions()
    has_paddle=(AI_SITE_DIR/'paddle').is_dir() and bool(versions.get('paddlepaddle'))
    has_ocr=(AI_SITE_DIR/'paddleocr').is_dir() and bool(versions.get('paddleocr'))
    if not has_paddle or not has_ocr:
        missing=[]
        if not has_paddle: missing.append('PaddlePaddle')
        if not has_ocr: missing.append('PaddleOCR')
        return False, 'AI 런타임 구성 누락: '+', '.join(missing)
    return True, f"paddle={versions.get('paddlepaddle','?')}; paddleocr={versions.get('paddleocr','?')}"


def _ai_model_cache_info():
    candidates=[
        Path.home()/'.paddlex'/'official_models'/'PaddleOCR-VL-1.6',
        AI_RUNTIME_DIR/'models'/'PaddleOCR-VL-1.6',
    ]
    best=None; best_size=0
    for p in candidates:
        if not p.is_dir(): continue
        try: size=sum(x.stat().st_size for x in p.rglob('*') if x.is_file())
        except Exception: size=0
        if size>best_size: best,best_size=p,size
    return best,best_size


def ai_engine_status():
    ok,msg=_ai_probe_light()
    if not ok: return False,msg
    model_dir,model_bytes=_ai_model_cache_info()
    if model_dir and model_bytes>500*1024*1024:
        return True,'정상 · PP-OCRv5 Korean FAST + PaddleOCR-VL 1.6 정밀 fallback · '+msg+' · VL 모델 캐시 준비됨'
    return True,'런타임 정상 · PP-OCRv5 Korean FAST 우선 · PaddleOCR-VL 1.6은 애매한 페이지만 사용 · '+msg


def _pip_to_ai(args, log):
    log.parent.mkdir(parents=True,exist_ok=True)
    cmd=[sys.executable,'-m','pip','install','--disable-pip-version-check','--no-warn-script-location','--upgrade','--target',str(AI_SITE_DIR),'--retries','3','--timeout','120']+list(args)
    with log.open('a',encoding='utf-8',errors='replace') as f:
        f.write('\n$ '+' '.join(cmd)+'\n'); f.flush()
        return subprocess.call(cmd,stdout=f,stderr=subprocess.STDOUT,env=os.environ.copy())


def _ai_has_package_dir(name):
    return (AI_SITE_DIR/name).exists() or any(AI_SITE_DIR.glob(name.replace('-','_')+'-*.dist-info'))


def ensure_ai_runtime():
    _raise_if_scan_cancelled()
    AI_RUNTIME_DIR.mkdir(parents=True,exist_ok=True)
    AI_SITE_DIR.mkdir(parents=True,exist_ok=True)
    LOG_DIR.mkdir(parents=True,exist_ok=True)
    ok,msg=_ai_probe_light()
    if ok:
        AI_RUNTIME_MARKER.write_text(json.dumps({'version':'4.4.27','engine':'PP-OCRv5 Korean FAST + PaddleOCR-VL-1.6 fallback','ready_at':datetime.now().isoformat(),'probe':msg},ensure_ascii=False,indent=2),encoding='utf-8')
        return True,msg

    if not AI_LOG_FILE.exists():
        AI_LOG_FILE.write_text('TOPTEN POP V4.4.27 AI runtime install/repair log\n',encoding='utf-8')
    else:
        with AI_LOG_FILE.open('a',encoding='utf-8',errors='replace') as f:
            f.write('\n--- V4.4.27 runtime repair '+datetime.now().isoformat()+' ---\n')

    versions=_ai_installed_versions()
    if not _ai_has_package_dir('paddle') or versions.get('paddlepaddle')!='3.2.1':
        _set_scan_status(message='AI 엔진 1/2 · PaddlePaddle CPU 설치/복구 중')
        rc=_pip_to_ai(['paddlepaddle==3.2.1','-i','https://www.paddlepaddle.org.cn/packages/stable/cpu/'],AI_LOG_FILE)
        if rc!=0: return False,'PaddlePaddle 설치 실패 · data/logs/ai_engine.log 확인'
    else:
        _set_scan_status(message='AI 엔진 1/2 · 기존 PaddlePaddle 재사용')

    versions=_ai_installed_versions()
    if not _ai_has_package_dir('paddleocr') or versions.get('paddleocr')!='3.7.0':
        _set_scan_status(message='AI 엔진 2/2 · PaddleOCR 3.7.0 / VL 1.6 설치·복구 중')
        rc=_pip_to_ai(['paddleocr[doc-parser]==3.7.0'],AI_LOG_FILE)
        if rc!=0: return False,'PaddleOCR 설치 실패 · data/logs/ai_engine.log 확인'
    else:
        _set_scan_status(message='AI 엔진 2/2 · 기존 PaddleOCR 3.7.0 재사용')

    _raise_if_scan_cancelled()
    ok,msg=_ai_probe_light()
    if ok:
        AI_RUNTIME_MARKER.write_text(json.dumps({'version':'4.4.27','engine':'PP-OCRv5 Korean FAST + PaddleOCR-VL-1.6 fallback','ready_at':datetime.now().isoformat(),'probe':msg},ensure_ascii=False,indent=2),encoding='utf-8')
        return True,msg
    return False,'AI 런타임 구성 확인 실패 · '+str(msg).replace('\n',' ')[:350]+' · data/logs/ai_engine.log 확인'


def _load_ai_cache():
    global _AI_CACHE, _AI_CACHE_DIRTY
    if _AI_CACHE is not None: return _AI_CACHE
    raw={}
    if AI_PAGE_CACHE_FILE.exists():
        try: raw=json.loads(AI_PAGE_CACHE_FILE.read_text('utf-8'))
        except Exception: raw={}
    if not isinstance(raw,dict): raw={}
    pages=raw.get('pages') if isinstance(raw.get('pages'),dict) else {}
    # One-time consolidation of V4.4.15~18 versioned caches into one permanent cache.
    for source in LEGACY_AI_PAGE_CACHE_FILES:
        if not source.exists(): continue
        try: old=json.loads(source.read_text('utf-8'))
        except Exception: old={}
        if isinstance(old,dict) and isinstance(old.get('pages'),dict):
            for k,v in old['pages'].items():
                if k not in pages and isinstance(v,dict) and str(v.get('text') or '').strip(): pages[k]=v
    raw={'_version':AI_PAGE_CACHE_VERSION,'pages':pages}
    _AI_CACHE=raw; _AI_CACHE_DIRTY=True
    _save_ai_cache()
    for source in LEGACY_AI_PAGE_CACHE_FILES:
        try: source.unlink(missing_ok=True)
        except Exception: pass
    return raw


def _save_ai_cache():
    global _AI_CACHE_DIRTY
    if _AI_CACHE is None or not _AI_CACHE_DIRTY: return
    AI_PAGE_CACHE_FILE.write_text(json.dumps(_AI_CACHE,ensure_ascii=False,indent=2),encoding='utf-8')
    _AI_CACHE_DIRTY=False


def _ai_cache_key(pdf_path,page_no):
    p=Path(pdf_path); st=p.stat()
    try: rel=_sync_source_key(p)
    except Exception: rel=p.name
    raw=f'{AI_PAGE_CACHE_VERSION}|{rel}|{st.st_size}|{st.st_mtime_ns}|{int(page_no)}'
    return hashlib.sha1(raw.encode('utf-8',errors='ignore')).hexdigest()


def _render_ai_page(pdf_path,page_no):
    """Render a CPU-friendly page image for the VL model.

    TOPTEN POP pages are posters, not dense books. 1100px width preserves the
    gender/product-name text while cutting the visual-token workload versus the
    old 1500px render. Existing temporary renders are resized in place.
    """
    key=_ai_cache_key(pdf_path,page_no); out=CACHE_DIR/f'ai_page_{key}.jpg'
    if out.exists():
        try:
            im=Image.open(out).convert('RGB')
            if im.width>1100:
                h=max(1,round(im.height*1100/im.width)); im=im.resize((1100,h),Image.Resampling.LANCZOS)
                im.save(out,'JPEG',quality=88,optimize=True)
            return out
        except Exception:
            try: out.unlink(missing_ok=True)
            except Exception: pass
    with fitz.open(str(pdf_path)) as doc:
        page=doc.load_page(page_no)
        pix=page.get_pixmap(matrix=fitz.Matrix(1.6,1.6),alpha=False)
        im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples)
        if im.width>1100:
            h=max(1,round(im.height*1100/im.width)); im=im.resize((1100,h),Image.Resampling.LANCZOS)
        im.save(out,'JPEG',quality=88,optimize=True)
    return out


def _collect_fast_tasks(pdfs):
    """Only pages with no extracted text need the fast Korean OCR first pass."""
    cache=_load_ai_cache()['pages']; tasks=[]; meta={}; cached=0; total_pages=0
    for pdf in pdfs:
        try:
            with fitz.open(str(pdf)) as doc: pc=doc.page_count
            total_pages+=pc
            for pno in range(pc):
                key=_ai_cache_key(pdf,pno); meta[key]=(pdf,pno)
                rec=cache.get(key)
                if isinstance(rec,dict) and str(rec.get('text') or '').strip():
                    cached+=1; continue
                img=_render_ai_page(pdf,pno)
                tasks.append({'id':key,'image':str(img)})
        except Exception: continue
    return tasks,meta,cached,total_pages


def _collect_vl_fallback_tasks(pdfs,items,eligible_keys=None):
    """Use the 0.9B VL model only for newly analyzed ambiguous pages.

    On a repeated full re-match, unchanged pages that already have any cached AI/OCR
    text are *decision-cache only*: they are never sent back through OCR/VL just
    because the current Excel produced an ambiguous score. This is the critical
    V4.4.27 fix that makes repeated matching a fast re-decision instead of a second
    expensive inference pass. Changed/new PDF pages get new cache keys and are still
    analyzed normally.
    """
    tasks=[]; meta={}; vl_ready=0; fast_confident=0; total_pages=0
    eligible=None if eligible_keys is None else {str(x) for x in eligible_keys}
    for pdf in pdfs:
        try:
            with fitz.open(str(pdf)) as doc: pc=doc.page_count
            total_pages+=pc
            for pno in range(pc):
                key=_ai_cache_key(pdf,pno); meta[key]=(pdf,pno)
                eng=_ai_page_engine(pdf,pno)
                txt=_ai_page_text(pdf,pno)
                if eng.startswith('PaddleOCR-VL') and txt.strip():
                    vl_ready+=1; _cleanup_ai_render(pdf,pno); continue
                if txt.strip() and _fast_page_is_confident(pdf,pno,items):
                    fast_confident+=1; _cleanup_ai_render(pdf,pno); continue
                # Re-match mode may restrict VL to pages created by this run only.
                # Existing cached FAST text is reused as-is and only SKU/page scoring
                # is recomputed. This prevents the same 400 PDFs being inferred again.
                if eligible is not None and key not in eligible:
                    _cleanup_ai_render(pdf,pno); continue
                # Empty text or newly-produced ambiguous FAST OCR: escalate this page.
                img=_render_ai_page(pdf,pno)
                tasks.append({'id':key,'image':str(img)})
        except Exception: continue
    return tasks,meta,vl_ready,fast_confident,total_pages


def _ai_cache_coverage(pdfs):
    """Return (cached_pages, total_pages, current_keys) for unchanged-PDF reuse."""
    pages=_load_ai_cache().get('pages',{})
    cached=0; total=0; keys=set()
    for pdf in pdfs:
        try:
            with fitz.open(str(pdf)) as doc: pc=doc.page_count
            for pno in range(pc):
                total+=1; key=_ai_cache_key(pdf,pno); keys.add(key)
                rec=pages.get(key)
                if isinstance(rec,dict) and str(rec.get('text') or '').strip(): cached+=1
        except Exception:
            continue
    return cached,total,keys


def _cleanup_stale_ai_job_artifacts():
    """Remove only transient worker files from prior stopped/crashed AI jobs."""
    work=DATA_DIR/'ai_jobs'
    try:
        if work.is_dir(): shutil.rmtree(work)
    except Exception:
        pass
    try:
        for img in CACHE_DIR.glob('ai_page_*.jpg'):
            try: img.unlink()
            except Exception: pass
    except Exception:
        pass


def _prune_ai_cache_to_current(current_keys):
    """Drop cache records for deleted/changed PDFs after a successful full scan."""
    global _AI_CACHE_DIRTY
    try:
        cache=_load_ai_cache(); pages=cache.get('pages',{})
        keep={k:v for k,v in pages.items() if k in current_keys}
        if len(keep)!=len(pages):
            cache['pages']=keep; _AI_CACHE_DIRTY=True; _save_ai_cache()
    except Exception:
        pass



def _ingest_ai_worker_output(output_path, task_meta=None, items=None, default_engine='PaddleOCR-VL-1.6', preview_method='AI 후보 분석'):
    """Persist each completed page immediately and optionally publish a live candidate preview."""
    global _AI_CACHE_DIRTY
    if not output_path.exists(): return 0
    try: rows=json.loads(output_path.read_text('utf-8')).get('results') or []
    except Exception: return 0
    pages=_load_ai_cache()['pages']; added=0
    for row in rows:
        key=str(row.get('id') or ''); txt=' '.join(str(row.get('text') or '').split())
        if key and txt:
            engine=str(row.get('engine') or default_engine)
            prev=pages.get(key)
            if not isinstance(prev,dict) or str(prev.get('text') or '')!=txt or str(prev.get('engine') or '')!=engine:
                pages[key]={'text':txt,'engine':engine,'saved_at':datetime.now().isoformat(),'seconds':row.get('seconds')}
                _AI_CACHE_DIRTY=True; added+=1
            if task_meta and items and key in task_meta:
                pdf,pno=task_meta[key]
                # Save first, then use the exact same final scoring logic for preview.
                if _AI_CACHE_DIRTY: _save_ai_cache()
                _set_live_preview(pdf,pno,items,preview_method)
    if added: _save_ai_cache()
    return len(rows)



def _run_ai_worker(tasks, cached_base=0, page_total=None, task_meta=None, items=None):
    if not tasks: return True,''
    stamp=str(int(time.time()*1000)); work=DATA_DIR/'ai_jobs'; work.mkdir(parents=True,exist_ok=True)
    manifest=work/f'{stamp}_manifest.json'; output=work/f'{stamp}_out.json'; progress=work/f'{stamp}_progress.json'
    manifest.write_text(json.dumps({'tasks':tasks},ensure_ascii=False),encoding='utf-8')
    cmd=[sys.executable,'-S',str(AI_WORKER),'--manifest',str(manifest),'--output',str(output),'--progress',str(progress)]
    with AI_LOG_FILE.open('a',encoding='utf-8',errors='replace') as log:
        log.write('\nAI WORKER: '+' '.join(cmd)+'\n'); log.flush()
        global _ACTIVE_AI_PROC
        proc=subprocess.Popen(cmd,env=_ai_worker_env(),stdout=log,stderr=subprocess.STDOUT)
        with _ACTIVE_AI_PROC_LOCK: _ACTIVE_AI_PROC=proc
        last_output_count=0; rc=None
        try:
            while proc.poll() is None:
                # Save pages as soon as the worker writes them. A stop/restart therefore
                # resumes from the last completed page instead of starting over.
                try:
                    cnt=_ingest_ai_worker_output(output,task_meta,items,'PaddleOCR-VL-1.6','VL 정밀 후보')
                    if cnt>last_output_count: last_output_count=cnt
                except Exception: pass
                if _SCAN_CANCEL.is_set():
                    try: proc.terminate()
                    except Exception: pass
                    try: proc.wait(timeout=6)
                    except Exception:
                        try: proc.kill()
                        except Exception: pass
                    _ingest_ai_worker_output(output,task_meta,items,'PaddleOCR-VL-1.6','VL 정밀 후보')
                    raise ScanCancelled('AI 페이지 분석이 사용자 요청으로 중단되었습니다.')
                try:
                    pr=json.loads(progress.read_text('utf-8')) if progress.exists() else {}
                    msg=str(pr.get('message') or 'PaddleOCR-VL 1.6 모델/페이지 분석 중')
                    stage=str(pr.get('stage') or ''); source=str(pr.get('source') or '')
                    try: pct=float(pr.get('download_percent') or 0.0)
                    except Exception: pct=0.0
                    pct=max(0.0,min(100.0,pct))
                    worker_done=int(pr.get('done') or 0); total_display=int(page_total or (cached_base+len(tasks)))
                    _set_scan_status(message=msg,ai_stage=stage,ai_download_percent=pct,ai_download_source=source,
                        ai_downloaded_bytes=int(pr.get('downloaded_bytes') or 0),
                        ai_download_total_bytes=int(pr.get('total_bytes') or 0),
                        ai_download_speed_bps=float(pr.get('speed_bps') or 0.0),
                        ai_download_eta_seconds=int(pr.get('eta_seconds') if pr.get('eta_seconds') is not None else -1),
                        ai_page_done=min(total_display,cached_base+worker_done),ai_page_total=total_display,
                        ai_page_cached=cached_base,ai_page_new=len(tasks),
                        ai_current_page=int(pr.get('current_index') or 0),
                        ai_current_elapsed_seconds=int(pr.get('current_elapsed_seconds') or 0),
                        ai_elapsed_seconds=int(pr.get('elapsed_seconds') or 0),
                        ai_page_last_seconds=float(pr.get('last_page_seconds') or 0.0),
                        ai_page_eta_seconds=int(pr.get('page_eta_seconds') if pr.get('page_eta_seconds') is not None else -1),
                        ai_vl_done=worker_done,ai_vl_total=len(tasks))
                except Exception: pass
                time.sleep(1)
            rc=proc.returncode
        finally:
            _ingest_ai_worker_output(output,task_meta,items,'PaddleOCR-VL-1.6','VL 정밀 후보')
            with _ACTIVE_AI_PROC_LOCK:
                if _ACTIVE_AI_PROC is proc: _ACTIVE_AI_PROC=None
    if rc!=0:
        if rc==124: return False,'AI 페이지 CPU 추론이 10분 이상 응답하지 않아 자동 중단됨 · 완료 페이지는 캐시에 저장됨'
        return False,f'AI 페이지 분석 프로세스 실패(code={rc}) · 완료 페이지는 캐시에 저장됨 · data/logs/ai_engine.log 확인'
    _ingest_ai_worker_output(output,task_meta,items,'PaddleOCR-VL-1.6','VL 정밀 후보')
    for p in (manifest,output,progress):
        try: p.unlink(missing_ok=True)
        except Exception: pass
    try:
        if work.is_dir() and not any(work.iterdir()): work.rmdir()
    except Exception: pass
    return True,''


def _run_fast_worker(tasks, cached_base=0, page_total=None, task_meta=None, items=None):
    if not tasks: return True,''
    stamp='fast_'+str(int(time.time()*1000)); work=DATA_DIR/'ai_jobs'; work.mkdir(parents=True,exist_ok=True)
    manifest=work/f'{stamp}_manifest.json'; output=work/f'{stamp}_out.json'; progress=work/f'{stamp}_progress.json'
    manifest.write_text(json.dumps({'tasks':tasks},ensure_ascii=False),encoding='utf-8')
    cmd=[sys.executable,'-S',str(AI_FAST_WORKER),'--manifest',str(manifest),'--output',str(output),'--progress',str(progress)]
    with AI_LOG_FILE.open('a',encoding='utf-8',errors='replace') as log:
        log.write('\nFAST OCR WORKER: '+' '.join(cmd)+'\n'); log.flush()
        global _ACTIVE_AI_PROC
        proc=subprocess.Popen(cmd,env=_ai_worker_env(),stdout=log,stderr=subprocess.STDOUT)
        with _ACTIVE_AI_PROC_LOCK: _ACTIVE_AI_PROC=proc
        rc=None
        try:
            while proc.poll() is None:
                try: _ingest_ai_worker_output(output,task_meta,items,'PP-OCRv5 Korean FAST','빠른 OCR 1차 후보')
                except Exception: pass
                if _SCAN_CANCEL.is_set():
                    try: proc.terminate()
                    except Exception: pass
                    try: proc.wait(timeout=6)
                    except Exception:
                        try: proc.kill()
                        except Exception: pass
                    _ingest_ai_worker_output(output,task_meta,items,'PP-OCRv5 Korean FAST','빠른 OCR 1차 후보')
                    raise ScanCancelled('빠른 AI OCR이 사용자 요청으로 중단되었습니다.')
                try:
                    pr=json.loads(progress.read_text('utf-8')) if progress.exists() else {}
                    done=int(pr.get('done') or 0); total_display=int(page_total or (cached_base+len(tasks)))
                    _set_scan_status(message=str(pr.get('message') or 'PP-OCRv5 Korean FAST 분석 중'),ai_stage='fast_ocr',
                        ai_page_done=min(total_display,cached_base+done),ai_page_total=total_display,
                        ai_fast_done=done,ai_fast_total=len(tasks),ai_current_page=int(pr.get('current_index') or 0),
                        ai_current_elapsed_seconds=int(pr.get('current_elapsed_seconds') or 0),
                        ai_elapsed_seconds=int(pr.get('elapsed_seconds') or 0),
                        ai_page_last_seconds=float(pr.get('last_page_seconds') or 0.0),
                        ai_page_eta_seconds=int(pr.get('page_eta_seconds') if pr.get('page_eta_seconds') is not None else -1))
                except Exception: pass
                time.sleep(.6)
            rc=proc.returncode
        finally:
            _ingest_ai_worker_output(output,task_meta,items,'PP-OCRv5 Korean FAST','빠른 OCR 1차 후보')
            with _ACTIVE_AI_PROC_LOCK:
                if _ACTIVE_AI_PROC is proc: _ACTIVE_AI_PROC=None
    if rc!=0:
        return False,f'빠른 AI OCR 프로세스 실패(code={rc}) · data/logs/ai_engine.log 확인'
    for p in (manifest,output,progress):
        try: p.unlink(missing_ok=True)
        except Exception: pass
    return True,''


def _ai_page_text(pdf_path,page_no):
    rec=_load_ai_cache()['pages'].get(_ai_cache_key(pdf_path,page_no))
    return str(rec.get('text') or '') if isinstance(rec,dict) else ''


def _ai_page_engine(pdf_path,page_no):
    rec=_load_ai_cache()['pages'].get(_ai_cache_key(pdf_path,page_no))
    return str(rec.get('engine') or '') if isinstance(rec,dict) else ''


def _cleanup_ai_render(pdf_path,page_no):
    try:
        (CACHE_DIR/f'ai_page_{_ai_cache_key(pdf_path,page_no)}.jpg').unlink(missing_ok=True)
    except Exception:
        pass



def _load_ai_review():
    try:
        raw=json.loads(AI_REVIEW_FILE.read_text('utf-8')) if AI_REVIEW_FILE.exists() else {}
        if not isinstance(raw,dict): raw={}
    except Exception:
        raw={}
    raw.setdefault('rows',[])
    return raw


def _save_ai_review(data):
    AI_REVIEW_FILE.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    try:
        _set_scan_status(ai_review_count=len(data.get('rows') or []),ai_review_status=str(data.get('status') or ''))
    except Exception:
        pass


def _start_ai_review(total_pdfs=0,total_pages=0):
    data={
        'version':'4.4.27','session_id':datetime.now().strftime('%Y%m%d_%H%M%S'),
        'status':'running','started_at':datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'finished_at':'','message':'AI 전체 매칭 분석 중','total_pdfs':int(total_pdfs or 0),
        'total_pages':int(total_pages or 0),'rows':[],'scanned_files':[],'confirmed_at':'','confirmed_count':0
    }
    _save_ai_review(data)
    return data


def _review_row_id(source_id,page,code=''):
    raw=f'{_normalize_webhard_rel(source_id)}|{int(page)}|{clean_code(code)}'
    return hashlib.sha1(raw.encode('utf-8')).hexdigest()[:18]


def _stage_ai_review_preview(source_id,page,code,title,score,method,text):
    """Persist a provisional row while OCR/VL is running.

    It is intentionally marked provisional and is never committed by the
    'AI 자동 매칭 확정' button. Final PDF assignment replaces provisional rows.
    """
    try:
        data=_load_ai_review()
        if data.get('status')!='running': return
        source_id=_normalize_webhard_rel(source_id)
        if not source_id: return
        rows=list(data.get('rows') or [])
        # Do not overwrite a finalized row for this page.
        if any(r.get('file')==source_id and int(r.get('page',-1))==int(page) and r.get('final') for r in rows):
            return
        rows=[r for r in rows if not (r.get('file')==source_id and int(r.get('page',-1))==int(page) and not r.get('final'))]
        rows.append({
            'id':_review_row_id(source_id,page,'preview'),'file':source_id,'page':int(page),
            'page_label':int(page)+1,'proposed_code':clean_code(code),'selected_code':clean_code(code),
            'title':str(title or ''),'score':int(score or 0),'margin':0,'method':str(method or ''),
            'text':str(text or '')[:1200],'needs_manual':True,'status':'provisional',
            'final':False,'suggestions':[],'saved_at':datetime.now().isoformat(timespec='seconds')
        })
        data['rows']=rows
        _save_ai_review(data)
    except Exception:
        pass


def _stage_ai_review_results(source_id,results):
    """Replace provisional rows for one PDF with its final staged assignments."""
    data=_load_ai_review(); source_id=_normalize_webhard_rel(source_id)
    scanned=list(data.get('scanned_files') or [])
    if source_id and source_id not in scanned: scanned.append(source_id)
    data['scanned_files']=scanned
    rows=[r for r in (data.get('rows') or []) if r.get('file')!=source_id]
    for r in results or []:
        code=clean_code(r.get('code'))
        row={
            'id':_review_row_id(source_id,r.get('page',0),code or 'none'),
            'file':source_id,'page':int(r.get('page',0)),'page_label':int(r.get('page',0))+1,
            'proposed_code':code,'selected_code':code,'title':str(r.get('title') or ''),
            'score':int(r.get('score') or 0),'margin':int(r.get('margin') or 0),
            'method':str(r.get('method') or ''),'text':str(r.get('text') or '')[:1400],
            'needs_manual':bool(r.get('needs_manual') or not code),
            'status':'manual_required' if (r.get('needs_manual') or not code) else 'auto_proposed',
            'final':True,'suggestions':list(r.get('suggestions') or [])[:6],
            'saved_at':datetime.now().isoformat(timespec='seconds')
        }
        rows.append(row)
    data['rows']=rows; data['status']='running'
    _save_ai_review(data)


def _finalize_ai_review(status,message=''):
    try:
        data=_load_ai_review()
        if not data: return
        data['status']=str(status or 'completed')
        data['finished_at']=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        if message: data['message']=str(message)
        _save_ai_review(data)
    except Exception:
        pass


def _publish_ai_preview(source_id,page_one_based,code='',title='',score=0,method='',text='',stage_review=True):
    """Publish image + candidate as one atomic preview generation.

    The browser uses ai_preview_seq to preload the image and only then swaps both
    image and candidate text together. This prevents an old image being shown with
    a newly-polled SKU candidate.
    """
    seq=str(time.time_ns())
    page_cat=_breed_label(_page_breed_category(text,'')) if text else ''
    item_cat=''
    c=clean_code(code)
    if c:
        try:
            it=next((x for x in load_items() if clean_code(x.get('code'))==c),None)
            if it: item_cat=_breed_label(_item_breed_category(it))
        except Exception:
            item_cat=''
    _set_scan_status(ai_preview_file=_normalize_webhard_rel(source_id),ai_preview_page=int(page_one_based or 0),
        ai_preview_code=c,ai_preview_title=str(title or ''),ai_preview_score=int(score or 0),
        ai_preview_method=str(method or ''),ai_preview_text=str(text or '')[:650],
        ai_preview_page_category=page_cat,ai_preview_item_category=item_cat,ai_preview_seq=seq)
    if stage_review and int(page_one_based or 0)>0:
        _stage_ai_review_preview(source_id,int(page_one_based)-1,code,title,score,method,text)


def _fast_page_top_candidate(pdf_path,page_no,items):
    """Return a provisional candidate for live UI and fast/VL gating.

    This uses the same hard gender gate and title/context scoring as final assignment,
    but only for one page. It never treats filename style-code order as page order.
    """
    text=_ai_page_text(pdf_path,page_no)
    if not text.strip(): return None
    filename_codes=extract_filename_codes(Path(pdf_path).name,items)
    source_desc=_source_description(pdf_path,filename_codes)
    source_seasons=_source_season_tokens(pdf_path)
    source_types=_source_item_types(pdf_path)
    groups,_=_ai_group_candidates(pdf_path,items,[text])
    ranked=[]
    for g in groups:
        sc,it,exact,meta=_ai_group_page_score(text,g,source_desc,filename_codes,source_seasons,source_types)
        if it and sc>0:
            ranked.append((sc,it,exact,meta))
    ranked.sort(key=lambda x:-x[0])
    if not ranked: return None
    best=ranked[0]; second=ranked[1][0] if len(ranked)>1 else 0.0
    sc,it,exact,meta=best
    pg,ig,reason=(meta or ('','',''))
    return {
        'code':clean_code(it.get('code')),'title':str(it.get('title_ko') or ''),
        'score':round(sc*100),'margin':round((sc-second)*100),'exact':bool(exact),
        'page_gender':pg or '미확인','item_gender':ig or _ai_item_gender(it) or '미확인',
        'reason':reason or '', 'text':text[:650]
    }


def _fast_page_is_confident(pdf_path,page_no,items):
    """Conservative gate: only skip the heavy VL model when FAST OCR is clear."""
    rec=_fast_page_top_candidate(pdf_path,page_no,items)
    if not rec: return False
    if rec['exact']: return True
    # Strong title/context score + a real margin. Same-title shared style groups are
    # already grouped by gender, so this does not force one style code by filename order.
    if rec['score']>=93 and rec['margin']>=7: return True
    if rec['score']>=90 and rec['margin']>=10 and rec['page_gender']!='미확인': return True
    return False


def _set_live_preview(pdf_path,page_no,items,method):
    try:
        rec=_fast_page_top_candidate(pdf_path,page_no,items)
        sid=_sync_source_key(Path(pdf_path))
        if rec:
            _publish_ai_preview(sid,int(page_no)+1,rec['code'],rec['title'],rec['score'],method,rec.get('text',''),stage_review=True)
        else:
            _publish_ai_preview(sid,int(page_no)+1,'','후보 계산 중',0,method,_ai_page_text(pdf_path,page_no)[:650],stage_review=True)
    except Exception:
        pass


def _normalize_gender_value(value):
    raw=str(value or '').strip().upper().replace(' ', '')
    if raw in ('남성','남자','MEN','MENS','MALE','MAN'): return '남성'
    if raw in ('여성','여자','WOMEN','WOMENS','FEMALE','WOMAN'): return '여성'
    if raw in ('공용','남녀공용','UNISEX','UNI'): return '공용'
    return ''


def _ai_item_gender(item):
    # Store product-code rule is authoritative whenever the final-four digit rule applies.
    return _normalize_gender_value(infer_gender_from_code(clean_code(item.get('code')), item.get('gender')))


def _ai_page_gender(text):
    """Return explicit page gender from AI-extracted visible text/captions.

    Visible labels such as 남성/여성 or MEN/WOMEN are decisive.  A PaddleOCR-VL
    description such as '남성 모델' is accepted only as a secondary page cue.  If both
    male and female cues are present, the page is treated as mixed/unknown so no hard
    gender rejection is applied.
    """
    raw=' '.join(str(text or '').split())
    up=raw.upper()
    male_patterns=(r'(?<!여)남성',r'남자\s*모델',r'남성\s*모델',r'\bMEN(?:\'S)?\b',r'\bMALE\b',r'\bMAN\s+MODEL\b')
    female_patterns=(r'여성',r'여자\s*모델',r'여성\s*모델',r'\bWOMEN(?:\'S)?\b',r'\bFEMALE\b',r'\bWOMAN\s+MODEL\b')
    male=any(re.search(p,up,re.I) for p in male_patterns)
    female=any(re.search(p,up,re.I) for p in female_patterns)
    # TOPTEN page text sometimes uses 남류/여류 in captions or folder-derived AI text.
    male = male or ('남류' in raw)
    female = female or ('여류' in raw)
    if male and not female: return '남성','페이지 남성 표기/모델 단서'
    if female and not male: return '여성','페이지 여성 표기/모델 단서'
    if male and female: return '','남녀 혼합/복수 단서'
    if re.search(r'\bUNISEX\b|남녀\s*공용|공용',up,re.I): return '공용','페이지 공용 표기'
    return '','성별 표기 없음'


def _ai_gender_relation(page_text,item):
    pg,evidence=_ai_page_gender(page_text)
    ig=_ai_item_gender(item)
    # Explicit opposite genders are a hard reject. Unisex remains eligible but does
    # not outrank an exact gender-specific SKU merely because the title is identical.
    if pg in ('남성','여성') and ig in ('남성','여성') and pg!=ig:
        return pg,ig,-1.0,evidence+' · 품번성별 불일치'
    if pg in ('남성','여성') and ig==pg:
        return pg,ig,0.075,evidence+' · 품번성별 일치'
    if pg in ('남성','여성') and ig=='공용':
        return pg,ig,0.005,evidence+' · 공용 후보'
    if pg=='공용' and ig=='공용':
        return pg,ig,0.035,evidence+' · 공용 일치'
    return pg,ig,0.0,evidence


def _ai_context_score(page_text,item):
    """Small corroborating score from item type/zone/promotion descriptors.

    Product name remains the dominant signal.  This context only helps distinguish
    same/similar titles after gender gating; generic words cannot create an automatic
    match by themselves.
    """
    raw=' '.join(str(page_text or '').split())
    page_tokens=set(_semantic_tokens(raw))
    if not page_tokens: return 0.0
    item_tokens=[]
    for val in (item.get('zone'), item.get('promotion')):
        for tok in _semantic_tokens(val):
            if tok not in item_tokens: item_tokens.append(tok)
    if not item_tokens: return 0.0
    hits=sum(1 for t in item_tokens if t in page_tokens)
    return min(0.055, hits*0.018)


def _ai_item_page_score(page_text,item,source_desc='',filename_codes=None,source_seasons=None,source_types=None):
    pg,ig,gender_adj,gender_reason=_ai_gender_relation(page_text,item)
    if gender_adj < 0:
        return 0.0, False, pg, ig, gender_reason
    season_ok,season_adj,season_reason=_season_relation(source_seasons,item)
    if not season_ok:
        return 0.0, False, pg, ig, gender_reason+' · '+season_reason
    type_ok,type_adj,type_reason=_type_relation(source_types,item)
    if not type_ok:
        return 0.0, False, pg, ig, gender_reason+' · '+season_reason+' · '+type_reason
    breed_adj,breed_conflict,page_breed,item_breed,breed_reason=_manual_breed_relation(page_text,item,source_desc)
    if breed_conflict:
        return 0.0, False, pg, ig, gender_reason+' · '+season_reason+' · '+type_reason+' · '+breed_reason
    s=_ai_title_score(page_text,item)
    code=clean_code(item.get('code'))
    compact=re.sub(r'[^A-Z0-9]','',str(page_text).upper())
    exact=bool(code and code in compact)
    if exact: s=1.0
    allowed={clean_code(c) for c in (filename_codes or []) if clean_code(c)}
    if code in allowed: s=min(1.0,s+0.018)
    am,conf,_,_=_anchor_relation(source_desc,item)
    if am: s=min(1.0,s+0.03)
    s=min(1.0,s+gender_adj+season_adj+type_adj+breed_adj+_ai_context_score(page_text,item))
    if conf and s<0.92: s=min(s,0.57)
    if pg in ('남성','여성') and ig=='공용' and not exact:
        s=min(s,0.69)
    reason=' · '.join(x for x in (gender_reason,season_reason,type_reason,breed_reason) if x)
    return max(0.0,min(1.0,s)), exact, pg, ig, reason
def _ai_evidence_sections(text):
    """Split optional FAST OCR layout markers without breaking old AI cache rows.

    V4.4.27 FAST OCR can preserve the lower product-title area and English lines
    from the *same page image*. Old cached rows do not have these markers, so the
    full text remains a valid fallback and no expensive re-OCR is forced.
    """
    raw=' '.join(str(text or '').split())
    def part(tag,next_tags):
        marker='['+tag+']'
        if marker not in raw: return ''
        x=raw.split(marker,1)[1]
        stops=[x.find('['+t+']') for t in next_tags if ('['+t+']') in x]
        stops=[i for i in stops if i>=0]
        if stops: x=x[:min(stops)]
        return x.strip(' |')
    title=part('TITLE_ZONE',('ENGLISH_TEXT','GENDER_TEXT'))
    eng=part('ENGLISH_TEXT',('GENDER_TEXT',))
    gender=part('GENDER_TEXT',())
    full=raw.split('[TITLE_ZONE]',1)[0].replace('[FULL_TEXT]','').strip(' |') if '[TITLE_ZONE]' in raw else raw.replace('[FULL_TEXT]','').strip(' |')
    return full,title,eng,gender

def _ai_title_score(text,item):
    full,title_zone,english_zone,_=_ai_evidence_sections(text)
    full_n=normalize_product_name(full)
    title_n=normalize_product_name(title_zone)
    english_n=normalize_product_name(english_zone)
    ko=normalize_product_name(item.get('title_ko'))
    en=normalize_product_name(item.get('title_en'))

    def score_one(needle, hay, exact_cap, partial_w, wratio_w):
        if not needle or not hay: return 0.0
        out=0.0
        if needle in hay:
            out=max(out, exact_cap if len(needle)>=4 else min(exact_cap,0.94))
        out=max(out, fuzz.partial_ratio(needle,hay)/100.0*partial_w, fuzz.WRatio(needle,hay)/100.0*wratio_w)
        return out

    # Product-name area comes from OCR boxes on the actual rendered PDF page and is
    # stronger than generic bullet-copy text. Korean and English are scored separately
    # so a shared Korean name can be disambiguated by the English line when available.
    ko_zone=score_one(ko,title_n,1.0,0.985,0.975)
    en_zone=score_one(en,title_n or english_n,0.997,0.985,0.975)
    ko_full=score_one(ko,full_n,0.992,0.95,0.93)
    en_full=score_one(en,full_n,0.988,0.95,0.93)
    best=max(ko_zone,en_zone,ko_full,en_full)
    ko_best=max(ko_zone,ko_full); en_best=max(en_zone,en_full)
    if ko_best>=0.78 and en_best>=0.78:
        best=min(1.0,best+0.025)
    code=clean_code(item.get('code'))
    if code and code in re.sub(r'[^A-Z0-9]','',str(text).upper()): best=1.0
    return min(1.0,best)


def _ai_group_candidates(pdf_path,items,page_texts):
    filename_codes=extract_filename_codes(Path(pdf_path).name,items)
    source_seasons=_source_season_tokens(pdf_path)
    source_types=_source_item_types(pdf_path)
    # F2/G2/G3 etc. in the PDF filename is scope metadata, not a soft score.
    # Filter the candidate universe *before* fuzzy title retrieval so a G2/G3 SKU can
    # never win an F2 PDF just because the product title looks similar.
    scoped_items=[]
    for item in items:
        sok,_,_=_season_relation(source_seasons,item)
        tok,_,_=_type_relation(source_types,item)
        if sok and tok: scoped_items.append(item)
    candidate_universe=scoped_items if (source_seasons or source_types) else list(items)
    scoped=_filename_scope_items(candidate_universe,filename_codes)
    if scoped:
        base=scoped
    else:
        # No code list: take top fuzzy candidates from each AI page, then merge.
        idx=_match_search_index(candidate_universe); ids=[]
        for txt in page_texts:
            q=normalize_product_name(txt)
            if not q: continue
            try: hits=process.extract(q,idx['choices'],scorer=fuzz.WRatio,limit=min(40,len(idx['choices'])),score_cutoff=25)
            except Exception: hits=[]
            ids.extend(h[2] for h in hits)
        seen=set(); base=[]
        for ix in ids:
            if ix in seen: continue
            seen.add(ix); base.append(candidate_universe[ix])
        if not base: base=list(candidate_universe[:100])
    groups=[]
    for item in base:
        title=normalize_product_name(item.get('title_ko') or item.get('title_en') or '') or clean_code(item.get('code'))
        gender=_ai_item_gender(item)
        breed_large=tuple(_item_breed_category(item).get('large') or [])
        # Same title is still a different assignment group when gender or manual
        # 품종대 differs. This prevents same-name pants/sweater or male/female cross-linking.
        found=next((g for g in groups if gender==g['gender'] and breed_large==g.get('breed_large',()) and (title==g['title'] or (title and g['title'] and fuzz.ratio(title,g['title'])>=94))),None)
        if found: found['items'].append(item)
        else: groups.append({'title':title,'gender':gender,'breed_large':breed_large,'items':[item]})
    return groups,filename_codes


def _ai_group_page_score(page_text,group,source_desc,filename_codes,source_seasons=None,source_types=None):
    best=0.0; best_item=None; exact=False; meta=None
    for item in group['items']:
        s,is_exact,pg,ig,reason=_ai_item_page_score(page_text,item,source_desc,filename_codes,source_seasons,source_types)
        if s>best:
            best=s; best_item=item; exact=is_exact; meta=(pg,ig,reason)
    return best,best_item,exact,meta


def _hungarian_max(weights):
    # Rectangular max-weight assignment. Returns list of (row, col).
    if not weights or not weights[0]: return []
    n=len(weights); m=len(weights[0]); trans=False
    a=weights
    if n>m:
        trans=True; a=[list(x) for x in zip(*weights)]; n,m=m,n
    maxv=max(max(r) for r in a) if a else 0.0
    cost=[[maxv-v for v in row] for row in a]
    u=[0.0]*(n+1); v=[0.0]*(m+1); p=[0]*(m+1); way=[0]*(m+1)
    for i in range(1,n+1):
        p[0]=i; j0=0; minv=[float('inf')]*(m+1); used=[False]*(m+1)
        while True:
            used[j0]=True; i0=p[j0]; delta=float('inf'); j1=0
            for j in range(1,m+1):
                if used[j]: continue
                cur=cost[i0-1][j-1]-u[i0]-v[j]
                if cur<minv[j]: minv[j]=cur; way[j]=j0
                if minv[j]<delta: delta=minv[j]; j1=j
            for j in range(m+1):
                if used[j]: u[p[j]]+=delta; v[j]-=delta
                else: minv[j]-=delta
            j0=j1
            if p[j0]==0: break
        while True:
            j1=way[j0]; p[j0]=p[j1]; j0=j1
            if j0==0: break
    pairs=[]
    for j in range(1,m+1):
        if p[j]: pairs.append((p[j]-1,j-1))
    if trans: return [(c,r) for r,c in pairs]
    return pairs


def match_pdf_pages_ai(pdf_path,items):
    with fitz.open(str(pdf_path)) as doc: pc=doc.page_count
    page_texts=[_ai_page_text(pdf_path,p) for p in range(pc)]
    source_desc=_source_description(pdf_path,extract_filename_codes(Path(pdf_path).name,items))
    source_seasons=_source_season_tokens(pdf_path)
    source_types=_source_item_types(pdf_path)
    groups,filename_codes=_ai_group_candidates(pdf_path,items,page_texts)
    if not groups: return []
    matrix=[]; details=[]
    for g in groups:
        row=[]; drow=[]
        for txt in page_texts:
            sc,it,exact,meta=_ai_group_page_score(txt,g,source_desc,filename_codes,source_seasons,source_types)
            row.append(sc); drow.append((it,exact,meta))
        matrix.append(row); details.append(drow)
    assigned={}; strong=set()
    # First: independent strong evidence. Multiple real products can still share one
    # page, but opposite-gender groups have already been hard-rejected.
    for gi,row in enumerate(matrix):
        order=sorted(range(pc),key=lambda p:row[p],reverse=True)
        if not order: continue
        p=order[0]; best=row[p]; second=row[order[1]] if len(order)>1 else 0.0; margin=best-second
        it,exact,meta=details[gi][p]
        title_score=_ai_title_score(page_texts[p],it) if it else 0.0
        visible_title=bool(it and title_score>=0.94)
        if exact or (best>=0.87 and margin>=0.09) or (visible_title and best>=0.91):
            assigned[gi]=(p,best,margin,'AI 페이지 강한증거'); strong.add(gi)
    # Second: ambiguous groups use global page assignment, solving shuffled page order.
    rem=[i for i in range(len(groups)) if i not in strong]
    if rem and pc:
        pairs=_hungarian_max([matrix[i] for i in rem])
        for rr,p in pairs:
            gi=rem[rr]; best=matrix[gi][p]
            if best<0.50: continue
            others=[matrix[gi][x] for x in range(pc) if x!=p]
            margin=best-(max(others) if others else 0.0)
            assigned[gi]=(p,best,margin,'AI 전역 페이지 배정')
    results=[]
    for gi,g in enumerate(groups):
        if gi not in assigned: continue
        p,score,margin,method=assigned[gi]
        page_text=page_texts[p]
        ranked=[]
        for item in g['items']:
            s,exact,pg,ig,reason=_ai_item_page_score(page_text,item,source_desc,filename_codes,source_seasons,source_types)
            if s<=0: continue
            ranked.append((s,item,exact,pg,ig,reason))
        ranked.sort(key=lambda x:-x[0])
        top=ranked[0] if ranked else None
        top_item=top[1] if top else None
        exact=bool(top and top[2])
        pg=top[3] if top else _ai_page_gender(page_text)[0]
        auto=bool(top_item and (exact or score>=AI_AUTO_THRESHOLD))
        # Expand shared style codes only within the already gender-separated group.
        # This fixes the old bug where a male page could auto-connect a female style
        # simply because both had exactly the same title.
        selected_items=[]
        if auto and score>=0.87:
            for item in g['items']:
                rel=_ai_gender_relation(page_text,item)
                _,breed_conflict,_,_,_=_manual_breed_relation(page_text,item,source_desc)
                if rel[2]>=0 and not breed_conflict and (not pg or _ai_item_gender(item) in (pg,'공용','')):
                    selected_items.append(item)
        elif top_item:
            selected_items=[top_item]
        for item in selected_items:
            suggestions=[]
            for row in ranked[:4]:
                ss,it,_,spg,sig,sreason=row
                suggestions.append({'code':clean_code(it.get('code')),'title':it.get('title_ko',''),'score':round(ss*100),'gender':_ai_item_gender(it) or '-', 'season':'/'.join(_item_season_tokens(it)) or '-', 'category':_breed_label(_item_breed_category(it))})
            _,ig,_,gender_reason=_ai_gender_relation(page_text,item)
            gender_note=f' · 페이지성별 {pg or "미확인"} / 품번성별 {ig or "미확인"}'
            season_note=(f' · PDF시즌 {"/".join(source_seasons)} / 품번시즌 {"/".join(_item_season_tokens(item)) or "미확인"}' if source_seasons else '')
            type_note=(f' · PDF품종 {"/".join(source_types)}' if source_types else '')
            page_cat_label=_breed_label(_page_breed_category(page_text,source_desc))
            item_cat_label=_breed_label(_item_breed_category(item))
            breed_note=f' · 매뉴얼품종 {page_cat_label} → {item_cat_label}'
            results.append({
                'page':p,'page_label':p+1,'text':page_text[:900],
                'code':clean_code(item.get('code')),'title':str(item.get('title_ko') or ''),
                'score':round(score*100),'margin':round(margin*100),'grade':'AI-A' if auto else 'AI-C',
                'method':f'{(_ai_page_engine(pdf_path,p) or "AI")} · {method}{gender_note}{season_note}{type_note}{breed_note}', 'needs_manual':not auto,
                'filename_codes':filename_codes,'suggestions':suggestions,'page_gender':pg,'item_gender':ig,
            })
    # If a page has no confident assignment, expose one best gender-compatible manual candidate.
    represented={int(r['page']) for r in results}
    for p in range(pc):
        if p in represented: continue
        best=None
        for gi,g in enumerate(groups):
            s=matrix[gi][p]; it=details[gi][p][0]
            if it and s>0 and (best is None or s>best[0]): best=(s,it,gi)
        if best and best[0]>=0.35:
            sc,it,gi=best; pg,ig,_,_=_ai_gender_relation(page_texts[p],it)
            results.append({'page':p,'page_label':p+1,'text':page_texts[p][:900],'code':clean_code(it.get('code')),'title':it.get('title_ko',''),'score':round(sc*100),'margin':0,'grade':'AI-C','method':f'{(_ai_page_engine(pdf_path,p) or "AI")} · 수동확인 후보 · 페이지성별 {pg or "미확인"} / 품번성별 {ig or "미확인"}','needs_manual':True,'filename_codes':filename_codes,'page_gender':pg,'item_gender':ig,'suggestions':[{'code':clean_code(it.get('code')),'title':it.get('title_ko',''),'score':round(sc*100),'gender':ig or '-','category':_breed_label(_item_breed_category(it))}]})
    results.sort(key=lambda r:(int(r.get('page',0)), bool(r.get('needs_manual')), -int(r.get('score',0)), clean_code(r.get('code'))))
    return results


def _reserve_ai_job(mode,message):
    """Reserve UI state before the worker thread starts so the button never looks dead."""
    with _SCAN_STATUS_LOCK:
        if _SCAN_STATUS.get('running'):
            return False
        _SCAN_CANCEL.clear()
        _SCAN_STATUS.update({
            'running':True,'mode':mode,'started_at':datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'finished_at':'','message':message,'error':'','processed':0,'total':0,
            'cancel_requested':False,'ai_stage':'queued','ai_download_percent':0.0,
            'ai_download_source':'','ai_downloaded_bytes':0,'ai_download_total_bytes':0,
            'ai_download_speed_bps':0.0,'ai_download_eta_seconds':-1,
            'ai_page_done':0,'ai_page_total':0,'ai_page_cached':0,'ai_page_new':0,
            'ai_current_page':0,'ai_current_elapsed_seconds':0,'ai_elapsed_seconds':0,
            'ai_page_last_seconds':0.0,'ai_page_eta_seconds':-1,
            'ai_fast_done':0,'ai_fast_total':0,'ai_vl_done':0,'ai_vl_total':0,
            'ai_preview_file':'','ai_preview_page':0,'ai_preview_code':'','ai_preview_title':'',
            'ai_preview_score':0,'ai_preview_method':'','ai_preview_text':'','ai_preview_page_category':'','ai_preview_item_category':'','ai_preview_seq':'',
            'ai_review_count':0,'ai_review_status':'running',
        })
    return True


def _run_ai_full_rematch_job():
    if not _SCAN_LOCK.acquire(blocking=False):
        _set_scan_status(running=False,finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),message='AI 전체 매칭 시작 실패',error='다른 매칭 작업이 이미 실행 중입니다.')
        return False
    current_cache_keys=set()
    try:
        _cleanup_stale_ai_job_artifacts()
        _set_scan_status(running=True,mode='AI FAST 전체 재매칭 V4.4.27',message='기존 AI 분석 캐시 확인 중',error='',processed=0,total=0,cancel_requested=False,ai_stage='cache_check',ai_page_done=0,ai_page_total=0,ai_page_cached=0,ai_page_new=0,ai_current_page=0,ai_current_elapsed_seconds=0,ai_elapsed_seconds=0,ai_page_last_seconds=0.0,ai_page_eta_seconds=-1,ai_fast_done=0,ai_fast_total=0,ai_vl_done=0,ai_vl_total=0)
        items=load_items(force=False)[0]
        if not items: raise RuntimeError('프로모션 Excel 상품 데이터가 없습니다. 먼저 Excel을 적용하세요.')
        pdfs=sorted((p for p in WEBHARD_SYNC_DIR.rglob('*') if p.is_file() and p.suffix.lower()=='.pdf'),key=lambda p:_sync_source_key(p))
        if not pdfs: raise RuntimeError('webhard_sync에서 PDF를 찾지 못했습니다.')

        cached_before,total_review_pages,current_cache_keys=_ai_cache_coverage(pdfs)
        _set_scan_status(total=len(pdfs),ai_page_total=total_review_pages,ai_page_done=cached_before,ai_page_cached=cached_before,ai_page_new=max(0,total_review_pages-cached_before),message=f'AI 캐시 확인 · PDF {len(pdfs)}개 / 페이지 {total_review_pages}개 · 재사용 {cached_before} · 신규/변경 {max(0,total_review_pages-cached_before)}')

        # IMPORTANT V4.4.27: do NOT clear currently-applied AI mappings here.
        # Re-matching is staged in the review store while the old confirmed mapping
        # remains live. Cancel/error therefore never makes the image-match count drop.
        # Old auto links are replaced atomically only when the user presses
        # 'AI 자동 매칭 확정'. Manual links remain protected throughout.
        _start_ai_review(len(pdfs),total_review_pages)

        missing_pages=max(0,total_review_pages-cached_before)
        if missing_pages:
            _set_scan_status(message=f'신규/변경 페이지 {missing_pages}개 발견 · AI 런타임 확인 중',ai_stage='runtime')
            ok,msg=ensure_ai_runtime()
            if not ok: raise RuntimeError(msg)

            # Stage 1: OCR only pages with no current cache key/text.
            fast_tasks,fast_meta,cached_pages,total_pages=_collect_fast_tasks(pdfs)
            new_fast_keys={str(t.get('id') or '') for t in fast_tasks if str(t.get('id') or '')}
            _set_scan_status(total=len(pdfs),ai_page_total=total_pages,ai_page_done=cached_pages,ai_page_cached=cached_pages,ai_page_new=len(fast_tasks),ai_fast_total=len(fast_tasks),message=f'FAST 1차 분석 · 캐시 {cached_pages}페이지 재사용 · 신규/변경 {len(fast_tasks)}페이지')
            if fast_tasks:
                ok,msg=_run_fast_worker(fast_tasks,cached_base=cached_pages,page_total=total_pages,task_meta=fast_meta,items=items)
                if not ok: raise RuntimeError(msg)

            # Stage 2: heavy VL only for pages that were newly FAST-analyzed *this run*.
            # Existing ambiguous cache is reused on repeated matching instead of being
            # inferred again and again.
            vl_tasks,vl_meta,vl_ready,fast_confident,_=_collect_vl_fallback_tasks(pdfs,items,eligible_keys=new_fast_keys)
            _set_scan_status(ai_stage='vl_select',ai_vl_total=len(vl_tasks),ai_vl_done=0,ai_fast_done=len(fast_tasks),
                message=f'신규 페이지 FAST 판정 완료 · 빠른 확정 {fast_confident} · 기존 VL {vl_ready} · 신규 VL 정밀검증 {len(vl_tasks)}페이지')
            if vl_tasks:
                ok,msg=_run_ai_worker(vl_tasks,cached_base=max(0,total_pages-len(vl_tasks)),page_total=total_pages,task_meta=vl_meta,items=items)
                if not ok: raise RuntimeError(msg)
            else:
                _set_scan_status(message='신규 VL 정밀검증 0페이지 · 품번 재배정 시작',ai_stage='assign',ai_vl_done=0,ai_vl_total=0)
        else:
            # True repeat-rematch fast path: no package import, OCR, model load or VL.
            _set_scan_status(ai_stage='assign',ai_page_done=total_review_pages,ai_page_total=total_review_pages,ai_page_cached=total_review_pages,ai_page_new=0,ai_fast_total=0,ai_fast_done=0,ai_vl_total=0,ai_vl_done=0,
                message=f'기존 AI 분석 캐시 {total_review_pages}페이지 100% 재사용 · OCR/VL 재분석 0 · 현재 Excel 기준 품번 재배정만 실행')

        # Stage review results. Existing confirmed AI mappings remain live until confirm.
        state=load_sync_state(); total_auto=0; total_manual=0
        for idx,pdf in enumerate(pdfs,start=1):
            _raise_if_scan_cancelled(); sid=_sync_source_key(pdf)
            _set_scan_status(message=f'캐시 기반 최종 품번 재배정 {idx}/{len(pdfs)} · {sid[:70]}',processed=idx-1,total=len(pdfs),ai_stage='assign')
            try:
                results=match_pdf_pages_ai(pdf,items)
                _stage_ai_review_results(sid,results)
                if results:
                    r=sorted(results,key=lambda x:(bool(x.get('needs_manual')),-int(x.get('score',0))))[0]
                    _publish_ai_preview(sid,int(r.get('page',0))+1,r.get('code',''),r.get('title',''),int(r.get('score',0)),('수동확인 후보' if r.get('needs_manual') else '최종 자동매칭 후보'),str(r.get('text') or '')[:650],stage_review=False)
                auto=sum(1 for r in results if r.get('code') and not r.get('needs_manual'))
                manual=sum(1 for r in results if r.get('needs_manual') or not r.get('code'))
                total_auto+=auto; total_manual+=manual
                rec=state.setdefault(sid,{}); rec.update({'relative_path':sid,'source_file':sid,'status':'auto_matched' if results and manual==0 else 'manual_required','auto_count':auto,'manual_count':manual,'ai_engine':'PP-OCRv5 Korean FAST + PaddleOCR-VL 1.6 fallback','analysis_context':AI_PAGE_CACHE_VERSION,'detected_at':datetime.now().strftime('%Y-%m-%d %H:%M:%S')})
                try:
                    with fitz.open(str(pdf)) as d:
                        for pno in range(d.page_count): _cleanup_ai_render(pdf,pno)
                except Exception: pass
            except Exception as exc:
                rec=state.setdefault(sid,{}); rec.update({'relative_path':sid,'source_file':sid,'status':'error','error':f'{type(exc).__name__}: {exc}'[:300]})
        save_sync_state(state)
        _prune_ai_cache_to_current(current_cache_keys)
        reuse_note=(' · 기존 페이지 AI 재분석 0' if missing_pages==0 else f' · 신규/변경 {missing_pages}페이지만 분석')
        done_msg=f'AI 재매칭 계산 완료 · 자동확정 후보 {total_auto}개 · 수동확인 {total_manual}개{reuse_note} · 기존 적용 결과는 유지 중이며 검토 후 AI 자동 매칭 확정을 누르면 교체됩니다.'
        _finalize_ai_review('completed',done_msg)
        _set_scan_status(running=False,finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),message=done_msg,processed=len(pdfs),total=len(pdfs),error='',ai_stage='done',ai_download_percent=100.0)
    except ScanCancelled:
        _finalize_ai_review('stopped','AI 재매칭이 중단되었습니다. 기존에 확정·적용된 AI 번외 매칭은 그대로 유지됩니다. 중단 전 계산된 새 후보만 결과/검토 화면에 남습니다.')
        _set_scan_status(running=False,finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),message='AI 재매칭 중단 완료 · 기존 적용 결과 유지 · 새 후보는 결과/검토에서 확인 가능',error='',cancel_requested=False)
    except Exception as exc:
        _finalize_ai_review('error',f'{type(exc).__name__}: {exc}'[:300])
        _set_scan_status(running=False,finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),message='AI 재매칭 오류 · 기존 적용 결과는 유지됨',error=f'{type(exc).__name__}: {exc}'[:500],cancel_requested=False)
    finally:
        _SCAN_LOCK.release()
    return True

def _run_ai_single_job(source_id):
    if not _SCAN_LOCK.acquire(blocking=False):
        _set_scan_status(running=False,finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),message='AI 단일 PDF 테스트 시작 실패',error='다른 매칭 작업이 이미 실행 중입니다.')
        return False
    try:
        _set_scan_status(running=True,mode='AI FAST 단일 PDF 테스트',message='AI 런타임 확인 중',error='',processed=0,total=1,cancel_requested=False,ai_stage='runtime',ai_page_done=0,ai_page_total=0,ai_page_cached=0,ai_page_new=0,ai_current_page=0,ai_current_elapsed_seconds=0,ai_elapsed_seconds=0,ai_page_last_seconds=0.0,ai_page_eta_seconds=-1,ai_fast_done=0,ai_fast_total=0,ai_vl_done=0,ai_vl_total=0)
        ok,msg=ensure_ai_runtime()
        if not ok: raise RuntimeError(msg)
        pdf=_resolve_webhard_pdf(source_id)
        if not pdf: raise RuntimeError('선택한 PDF를 찾을 수 없습니다.')
        items=load_items(force=False)[0]
        if not items: raise RuntimeError('프로모션 Excel 상품 데이터가 없습니다. 먼저 Excel을 적용하세요.')
        fast_tasks,fast_meta,cached_pages,one_pages=_collect_fast_tasks([pdf])
        _set_scan_status(total=1,ai_page_total=one_pages,ai_page_done=cached_pages,ai_page_cached=cached_pages,ai_page_new=len(fast_tasks),ai_fast_total=len(fast_tasks),message=f'선택 PDF FAST 1차 분석 · 전체 {one_pages}페이지 · 캐시 {cached_pages} · 신규 {len(fast_tasks)}')
        if fast_tasks:
            ok,msg=_run_fast_worker(fast_tasks,cached_base=cached_pages,page_total=one_pages,task_meta=fast_meta,items=items)
            if not ok: raise RuntimeError(msg)
        vl_tasks,vl_meta,vl_ready,fast_confident,_=_collect_vl_fallback_tasks([pdf],items)
        _set_scan_status(ai_stage='vl_select',ai_vl_total=len(vl_tasks),message=f'FAST 판정 · 빠른 확정 {fast_confident} · 기존 VL {vl_ready} · VL 정밀검증 {len(vl_tasks)}페이지')
        if vl_tasks:
            ok,msg=_run_ai_worker(vl_tasks,cached_base=max(0,one_pages-len(vl_tasks)),page_total=one_pages,task_meta=vl_meta,items=items)
            if not ok: raise RuntimeError(msg)
        results=match_pdf_pages_ai(pdf,items)
        if results:
            r=sorted(results,key=lambda x:(bool(x.get('needs_manual')),-int(x.get('score',0))))[0]
            _publish_ai_preview(source_id,int(r.get('page',0))+1,r.get('code',''),r.get('title',''),int(r.get('score',0)),('수동확인 후보' if r.get('needs_manual') else '최종 자동매칭 후보'),str(r.get('text') or '')[:650],stage_review=False)
        AI_SINGLE_RESULT_FILE.write_text(json.dumps({'filename':source_id,'results':results,'saved_at':datetime.now().isoformat()},ensure_ascii=False,indent=2),encoding='utf-8')
        try:
            with fitz.open(str(pdf)) as d:
                for pno in range(d.page_count): _cleanup_ai_render(pdf,pno)
        except Exception: pass
        _set_scan_status(running=False,finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),message=f'단일 PDF AI FAST 테스트 완료 · 결과 {len(results)}개',processed=1,total=1,error='',ai_stage='done',ai_download_percent=100.0)
    except ScanCancelled:
        _set_scan_status(running=False,finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),message='단일 PDF AI 테스트 중단 완료',error='',cancel_requested=False)
    except Exception as exc:
        _set_scan_status(running=False,finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),message='단일 PDF AI 테스트 오류',error=f'{type(exc).__name__}: {exc}'[:500],cancel_requested=False)
    finally:
        _SCAN_LOCK.release()
    return True


def start_ai_single_job(source_id):
    if not _reserve_ai_job('AI 단일 PDF 테스트','AI 단일 테스트 시작 요청 접수 · 작업 준비 중'):
        return False
    try:
        threading.Thread(target=_run_ai_single_job,args=(source_id,),daemon=True).start()
        return True
    except Exception as exc:
        _set_scan_status(running=False,message='AI 단일 테스트 시작 실패',error=f'{type(exc).__name__}: {exc}'[:300])
        return False


def start_ai_full_rematch_job():
    if not _reserve_ai_job('AI FAST 전체 재매칭 V4.4.27','AI 전체 재매칭 시작 요청 접수 · 기존 적용 결과는 유지하고, 변경된 페이지만 분석하며 기존 페이지는 캐시로 재판정합니다.'):
        return False
    try:
        threading.Thread(target=_run_ai_full_rematch_job,daemon=True).start()
        return True
    except Exception as exc:
        _set_scan_status(running=False,message='AI 전체 매칭 시작 실패',error=f'{type(exc).__name__}: {exc}'[:300])
        return False

AI_MATCH_HTML=r"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AI 페이지 매칭 V4.4.27</title><style>body{font-family:Malgun Gothic,Arial;margin:0;background:#f3f5f7}.wrap{max-width:1200px;margin:auto;padding:24px}.panel{background:#fff;padding:18px;border-radius:12px;margin-bottom:16px}.btn{background:#102c73;color:#fff;border:0;border-radius:7px;padding:10px 15px;text-decoration:none;font-weight:700;cursor:pointer;display:inline-block}.green{background:#26734d}.gray{background:#555}.orange{background:#a85a00}.red{background:#c51f2c}.ok{color:#16753d;font-weight:700}.bad{color:#c00;font-weight:700}.muted{color:#666}.status{padding:12px;background:#eef3fb;border-radius:8px;line-height:1.7}.rule{background:#eef7f1;padding:13px;border-radius:8px;line-height:1.8}.progress-wrap{margin-top:12px;padding:10px;background:#fff;border-radius:8px;border:1px solid #d8dfeb}.progress-track{height:20px;background:#e4e8ef;border-radius:10px;overflow:hidden;margin-top:6px}.progress-bar{height:100%;width:0%;background:#26734d;transition:width .25s ease}.metrics{display:flex;gap:18px;flex-wrap:wrap;margin-top:8px}.metrics span{background:#f4f6f9;padding:5px 9px;border-radius:6px}.live{display:grid;grid-template-columns:230px 1fr;gap:16px;align-items:start}.live img{width:220px;max-height:310px;object-fit:contain;border:1px solid #ccd2da;background:#f5f5f5;border-radius:7px}.score{font-size:24px;font-weight:800;color:#126535}@media(max-width:700px){.live{grid-template-columns:1fr}.live img{width:100%;max-width:300px}}</style></head><body><div class="wrap"><div class="panel"><a class="btn gray" href="/bonus">← 기존 번외 매칭</a> <a class="btn" href="/sync">웹하드 상태</a><h2>AI 페이지 매칭 엔진 · V4.4.27 REVIEW TEST</h2><p><b>AI 엔진:</b> <span class="{{'ok' if ai_ok else 'bad'}}">{{ai_status}}</span></p><div class="rule"><b>V4.4.27 FAST + 품종코드 + 검토확정:</b> 모든 신규 페이지를 0.9B VL로 바로 돌리지 않습니다.<br>① <b>PP-OCRv5 Korean Mobile</b>로 한글/영문/남성·여성/상품명을 빠르게 읽음 → ② Excel 상품명·영문명·성별·부가설명과 즉시 비교 → ③ 확실한 페이지는 바로 캐시/매칭 → ④ <b>애매한 페이지만 PaddleOCR-VL 1.6</b> 정밀검증 → ⑤ 파일명 품번 순서는 후보군일 뿐 페이지 순서로 사용하지 않음 → <b>파일명에 F2/G2/G3 같은 시즌이 있으면 동일 시즌만 후보 허용</b> → 파일명 품종 + 매뉴얼 품종대/소(J/C/K/V/L/W/T/E/O/P/D/R/U/A)를 교차검증하고 명확한 품종대 불일치는 자동차단 → ⑥ <b>최종 점수 70% 이상(성별/시즌/품종대/제품라인 하드충돌 없음)은 자동확정 후보</b> → ⑦ 결과는 먼저 검토창에 저장 → ⑧ AI 자동 매칭 확정 버튼을 눌러야 실제 이미지 매칭에 반영 → ⑨ 수동고정 보호.</div><p class="muted">기존에 이미 PaddleOCR‑VL로 분석된 페이지는 그대로 재사용합니다. 새 페이지도 FAST 결과가 충분하면 VL 모델을 로딩하지 않으므로 CPU PC에서 준비/추론 시간을 크게 줄이는 구조입니다.</p><button id="aiStartBtn" class="btn green" type="button" onclick="startFullAi()" {{'disabled' if scan.running else ''}}>AI 전체 재매칭 시작</button> <button id="aiStopBtn" class="btn red" type="button" onclick="stopMatching()" {{'' if scan.running else 'disabled'}}>AI/OCR 매칭 중단</button><hr style="margin:18px 0"><h3>먼저 PDF 1개만 시험</h3><form method="post" action="/bonus-ai/test-one"><input id="aiPdfSearch" list="aipdfs" name="filename" style="padding:9px;min-width:520px" placeholder="webhard_sync PDF 검색/선택" autocomplete="off" required><datalist id="aipdfs">{% for f in all_pdfs %}<option value="{{f}}">{% endfor %}</datalist> <button class="btn orange">선택 PDF만 AI FAST 테스트</button></form><p><a id="reviewBtn" class="btn green" href="/bonus-ai/review" style="{{'' if review_ready else 'display:none'}}">AI 매칭 결과/검토 <span id="reviewCount">{{review_count}}</span>개</a> <span id="reviewHint" class="muted">{{'완료/중단 후 결과를 검토하고 자동매칭을 확정하세요.' if review_ready else ''}}</span></p><p id="singleResultWrap" style="{{'' if single_ready else 'display:none'}}"><a class="btn green" href="/bonus-ai/result">마지막 단일 PDF 결과 보기</a></p></div><div class="panel"><h3>작업 상태</h3><div class="status"><div style="margin-bottom:8px"><span id="aiRunBadge" style="font-weight:800;padding:5px 9px;border-radius:999px;background:#e7ebf1;color:#444">{{'● AI 매칭 실행 중' if scan.running else '대기'}}</span></div><b id="scanMode">{{scan.mode or '대기'}}</b><br><span id="scanMessage">{{scan.message}}</span><br><span id="scanError" class="bad">{{scan.error or ''}}</span><div id="scanTimes" class="muted"></div><div id="aiOverallBox" class="progress-wrap" style="display:none"><div><b id="aiOverallLabel">AI 작업 진행 중</b></div><div class="progress-track"><div id="aiOverallBar" class="progress-bar"></div></div><div class="metrics"><span>PDF: <b id="aiPdfProgress">0/0</b></span><span>전체 페이지: <b id="aiPageProgress">0/0</b></span><span>캐시: <b id="aiCachedProgress">0</b></span><span>FAST: <b id="aiFastProgress">0/0</b></span><span>VL 정밀: <b id="aiVlProgress">0/0</b></span></div><div class="metrics"><span>현재 페이지: <b id="aiCurrentPage">-</b></span><span>현재 경과: <b id="aiCurrentElapsed">-</b></span><span>최근 페이지: <b id="aiLastPageTime">-</b></span><span>남은 예상: <b id="aiPageEta">-</b></span><span>전체 경과: <b id="aiElapsed">-</b></span></div></div><div id="aiDownloadBox" class="progress-wrap" style="display:none"><div>VL 모델 소스: <b id="aiDownloadSource">-</b> · <b id="aiDownloadPercent">0.00%</b></div><div class="progress-track"><div id="aiDownloadBar" class="progress-bar"></div></div><div class="metrics"><span>받은 용량: <b id="aiDownloadBytes">-</b></span><span>속도: <b id="aiDownloadSpeed">-</b></span><span>남은 예상시간: <b id="aiDownloadEta">-</b></span></div></div></div></div><div class="panel" id="livePreviewBox"><h3>실시간 매칭 미리보기</h3><div class="live"><img id="livePreviewImg" style="display:none"><div><div><b>번외 PDF:</b> <span id="liveFile">대기 중</span> <span id="livePage"></span></div><div style="margin-top:8px"><b>현재 후보:</b> <span id="liveCode">-</span> · <span id="liveTitle">-</span></div><div class="score" id="liveScore">-</div><div><b>판정:</b> <span id="liveMethod">-</span></div><div><b>매뉴얼 품종:</b> <span id="livePageCategory">-</span> → <span id="liveItemCategory">-</span></div><div class="muted" id="liveText" style="margin-top:9px;max-height:110px;overflow:auto"></div></div></div></div><div class="panel"><h3>AI 페이지 캐시</h3><p>저장된 AI 분석 페이지: <b id="aiCacheCount">{{cache_count}}</b>개</p><p class="muted">페이지가 변경되지 않으면 FAST/VL 분석을 다시 하지 않습니다.</p></div></div><script>
function fmtBytes(n){n=Number(n||0);if(!n)return '-';const u=['B','KB','MB','GB'];let i=0;while(n>=1024&&i<u.length-1){n/=1024;i++;}return n.toFixed(i>=2?2:1)+' '+u[i];} function fmtSpeed(n){return Number(n||0)>0?fmtBytes(n)+'/s':'-';} function fmtEta(sec){sec=Number(sec);if(!Number.isFinite(sec)||sec<0)return '-';if(sec<=1)return '완료';let m=Math.ceil(sec/60);if(m<60)return '약 '+m+'분';return '약 '+Math.floor(m/60)+'시간 '+(m%60)+'분';} function fmtClock(sec){sec=Math.max(0,Math.floor(Number(sec||0)));let h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60),ss=sec%60;return (h?h+'시간 ':'')+(m?m+'분 ':'')+ss+'초';} function previewUrl(file,page,seq){if(!file||!page)return '';return '/bonus/page-preview/'+file.split('/').map(encodeURIComponent).join('/')+'/'+(Number(page)-1)+'?live='+(seq||'1');}
let requestedPreviewSeq=''; let shownPreviewSeq='';
function renderLiveAtomic(d){const f=d.ai_preview_file||'',pg=Number(d.ai_preview_page||0),seq=String(d.ai_preview_seq||[f,pg,d.ai_preview_code||'',d.ai_preview_method||''].join('|'));if(!f||!pg){return;}if(seq===requestedPreviewSeq||seq===shownPreviewSeq)return;requestedPreviewSeq=seq;const u=previewUrl(f,pg,seq),pre=new Image();const commit=()=>{if(requestedPreviewSeq!==seq)return;const im=document.getElementById('livePreviewImg');im.src=u;im.style.display='block';im.dataset.u=u;document.getElementById('liveFile').textContent=f;document.getElementById('livePage').textContent=' · '+pg+'페이지';document.getElementById('liveCode').textContent=d.ai_preview_code||'-';document.getElementById('liveTitle').textContent=d.ai_preview_title||'-';document.getElementById('liveScore').textContent=Number(d.ai_preview_score||0)?(d.ai_preview_score+'%'):'-';document.getElementById('liveMethod').textContent=d.ai_preview_method||'-';document.getElementById('livePageCategory').textContent=d.ai_preview_page_category||'-';document.getElementById('liveItemCategory').textContent=d.ai_preview_item_category||'-';document.getElementById('liveText').textContent=d.ai_preview_text||'';shownPreviewSeq=seq;};pre.onload=commit;pre.onerror=commit;pre.src=u;}
async function refreshStatus(){try{const r=await fetch('/api/scan-status',{cache:'no-store'});const d=await r.json(),running=!!d.running,stage=d.ai_stage||'';document.getElementById('scanMode').textContent=d.mode||'대기';document.getElementById('scanMessage').textContent=d.message||'';document.getElementById('scanError').textContent=d.error||'';document.getElementById('scanTimes').textContent=d.started_at?('시작 '+d.started_at+(d.finished_at?' · 완료 '+d.finished_at:'')+' · 처리 '+(d.processed||0)+(d.total?' / '+d.total:'')):'';document.getElementById('aiStopBtn').disabled=!running;document.getElementById('aiStartBtn').disabled=running;const badge=document.getElementById('aiRunBadge');badge.textContent=running?'● AI 매칭 실행 중':(d.error?'오류 발생':(d.finished_at?'완료':'대기'));badge.style.background=running?'#dff3e6':(d.error?'#ffe3e3':'#e7ebf1');badge.style.color=running?'#126535':(d.error?'#b00020':'#444');if(typeof d.ai_cache_count!=='undefined')document.getElementById('aiCacheCount').textContent=d.ai_cache_count;if(d.single_ready)document.getElementById('singleResultWrap').style.display='block';const pDone=Number(d.processed||0),pTotal=Number(d.total||0),aDone=Number(d.ai_page_done||0),aTotal=Number(d.ai_page_total||0);document.getElementById('aiOverallBox').style.display=(running||stage==='assign')?'block':'none';document.getElementById('aiPdfProgress').textContent=pDone+'/'+pTotal;document.getElementById('aiPageProgress').textContent=aDone+'/'+aTotal;document.getElementById('aiCachedProgress').textContent=Number(d.ai_page_cached||0);document.getElementById('aiFastProgress').textContent=Number(d.ai_fast_done||0)+'/'+Number(d.ai_fast_total||0);document.getElementById('aiVlProgress').textContent=Number(d.ai_vl_done||0)+'/'+Number(d.ai_vl_total||0);const cur=Number(d.ai_current_page||0);document.getElementById('aiCurrentPage').textContent=cur?String(cur):'-';document.getElementById('aiCurrentElapsed').textContent=cur?fmtClock(d.ai_current_elapsed_seconds):'-';document.getElementById('aiLastPageTime').textContent=Number(d.ai_page_last_seconds||0)>0?fmtClock(d.ai_page_last_seconds):'-';document.getElementById('aiPageEta').textContent=fmtEta(d.ai_page_eta_seconds);document.getElementById('aiElapsed').textContent=running?fmtClock(d.ai_elapsed_seconds):'-';let op=0;if(stage==='assign'&&pTotal)op=pDone*100/pTotal;else if(aTotal)op=aDone*100/aTotal;document.getElementById('aiOverallBar').style.width=Math.min(100,op)+'%';document.getElementById('aiOverallLabel').textContent=stage==='fast_ocr'?'PP-OCRv5 Korean FAST 분석 중':(stage==='vl_select'?'FAST 결과 판정 / VL 대상 선별':(stage==='assign'?'최종 품번 배정 중':(stage.startsWith('infer')?'PaddleOCR-VL 정밀검증 중':'AI 작업')));const pct=Math.max(0,Math.min(100,Number(d.ai_download_percent||0))),src=d.ai_download_source||'';const downloading=['source','download','model','engine_load'].includes(stage)&&running;document.getElementById('aiDownloadBox').style.display=downloading?'block':'none';document.getElementById('aiDownloadSource').textContent=src||'확인 중';document.getElementById('aiDownloadPercent').textContent=pct.toFixed(2)+'%';document.getElementById('aiDownloadBar').style.width=pct+'%';const got=Number(d.ai_downloaded_bytes||0),tot=Number(d.ai_download_total_bytes||0);document.getElementById('aiDownloadBytes').textContent=got?(fmtBytes(got)+(tot?' / '+fmtBytes(tot):'')):'-';document.getElementById('aiDownloadSpeed').textContent=fmtSpeed(d.ai_download_speed_bps);document.getElementById('aiDownloadEta').textContent=fmtEta(d.ai_download_eta_seconds);renderLiveAtomic(d);const rb=document.getElementById('reviewBtn'),rc=document.getElementById('reviewCount'),rh=document.getElementById('reviewHint');if(rb&&Number(d.ai_review_count||0)>0){rb.style.display='inline-block';if(rc)rc.textContent=Number(d.ai_review_count||0);if(rh)rh.textContent=(d.ai_review_status==='running'?'분석 중에도 현재 저장된 후보를 볼 수 있습니다.':'결과를 검토한 뒤 AI 자동 매칭 확정을 눌러주세요.');}}catch(e){}}
async function startFullAi(){if(!confirm('AI 전체 재매칭을 시작할까요? 현재 적용 중인 AI 매칭은 유지한 채 새 후보를 다시 계산합니다. 수동고정은 보호되고, 변경된 PDF 페이지만 AI 분석합니다. 기존 페이지는 캐시로 즉시 재판정합니다.'))return;document.getElementById('aiStartBtn').disabled=true;try{const r=await fetch('/bonus-ai/start',{method:'POST',headers:{'Accept':'application/json'}}),d=await r.json();if(!d.ok)alert(d.message||'시작 실패');await refreshStatus();}catch(e){alert('시작 요청 실패: '+e);}} async function stopMatching(){if(!confirm('현재 AI/OCR 매칭을 중단할까요? 완료된 페이지 캐시는 유지됩니다.'))return;try{await fetch('/api/scan-stop',{method:'POST'});refreshStatus();}catch(e){}} setInterval(refreshStatus,1000);refreshStatus();
</script></body></html>"""


AI_REVIEW_HTML=r"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AI 매칭 결과 검토 V4.4.27</title><style>body{font-family:Malgun Gothic,Arial;margin:0;background:#f3f5f7;color:#181818}.wrap{max-width:1540px;margin:auto;padding:22px}.panel{background:#fff;border-radius:12px;padding:17px;margin-bottom:15px;box-shadow:0 2px 10px #0000000d}.btn{display:inline-block;border:0;border-radius:7px;padding:9px 13px;background:#102c73;color:white;text-decoration:none;font-weight:700;cursor:pointer}.green{background:#26734d}.orange{background:#ad5b00}.red{background:#c51f2c}.gray{background:#555}.muted{color:#6b6b6b}.ok{color:#16753d;font-weight:800}.warn{color:#b45a00;font-weight:800}.bad{color:#c00;font-weight:800}.stats{display:flex;gap:9px;flex-wrap:wrap;margin-top:10px}.stat{background:#f2f5f8;padding:8px 11px;border-radius:7px}.tablebox{overflow:auto;max-height:720px;border:1px solid #ddd}table{width:100%;border-collapse:collapse;font-size:13px}th,td{padding:8px;border-bottom:1px solid #e2e2e2;vertical-align:top;text-align:left}th{position:sticky;top:0;background:#edf1f7;z-index:2}.thumb{width:150px;max-height:215px;object-fit:contain;border:1px solid #ccc;background:#eee}.suggest{margin:3px 0;padding-left:18px;line-height:1.5}.codeinput{padding:8px;min-width:275px;border:1px solid #bbb;border-radius:6px}.provisional{background:#fff9e9}.manualrow{background:#fff4f4}.applied{background:#eff9f2}.inline{display:inline-block;margin:2px}</style></head><body><div class="wrap"><div class="panel"><a class="btn gray" href="/bonus-ai">← AI 매칭</a> <a class="btn" href="/bonus">현재 번외 매칭</a><h2>AI 매칭 결과 / 검토 · V4.4.27</h2><p>상태: <b>{{review.status or '없음'}}</b> · 시작 {{review.started_at or '-'}} {% if review.finished_at %}· 종료 {{review.finished_at}}{% endif %}</p><p>{{review.message or ''}}</p><div class="stats"><span class="stat">검토 행 <b>{{rows|length}}</b></span><span class="stat">자동확정 후보 <b>{{auto_count}}</b></span><span class="stat">수동확인 <b>{{manual_count}}</b></span><span class="stat">분석중 후보 <b>{{provisional_count}}</b></span><span class="stat">AI 저장 매칭 <b>{{matches|length}}</b></span></div>{% if rows and review.status!='running' %}<form class="inline" method="post" action="/bonus-ai/review/confirm-auto" onsubmit="return confirm('검토된 자동확정 후보를 실제 이미지 매칭에 반영할까요? 수동고정은 보호됩니다.')"><button class="btn green">AI 자동 매칭 확정</button></form>{% endif %}<span class="muted">최종 점수 70% 이상이며 <b>성별·시즌·매뉴얼 품종대·제품라인 하드충돌이 없는 후보</b>만 자동확정 대상입니다. 이 버튼을 누르기 전까지 실제 이미지 매칭 숫자에는 반영되지 않습니다.</span></div><div class="panel"><div class="tablebox"><table><thead><tr><th>번외 페이지</th><th>AI 제안</th><th>근거/후보</th><th>상태</th><th>수동 변경</th></tr></thead><tbody>{% for r in rows %}<tr class="{{'provisional' if not r.final else ('manualrow' if r.needs_manual else ('applied' if r.status in ['manual_fixed','applied'] else ''))}}"><td><div><b>{{r.file}}</b> · {{r.page_label}}페이지</div><a target="_blank" href="{{url_for('bonus_page_preview',filename=r.file,page=r.page)}}"><img class="thumb" loading="lazy" src="{{url_for('bonus_page_preview',filename=r.file,page=r.page)}}"></a></td><td>{% if r.proposed_code %}<b>{{r.proposed_code}}</b><br>{{r.title or ''}}<br><span class="ok">{{r.score}}%</span>{% else %}<span class="bad">후보 없음</span>{% endif %}<div class="muted">{{r.method}}</div></td><td><div class="muted" style="max-width:410px;max-height:95px;overflow:auto">{{r.text or '-'}}</div>{% if r.suggestions %}<ol class="suggest">{% for s in r.suggestions %}<li><b>{{s.code}}</b> · {{s.title}} · {{s.score}}%{% if s.gender %} · {{s.gender}}{% endif %}{% if s.season %} · 시즌 {{s.season}}{% endif %}{% if s.category %} · 품종 {{s.category}}{% endif %}</li>{% endfor %}</ol>{% endif %}</td><td>{% if not r.final %}<span class="warn">분석중 후보</span>{% elif r.status=='manual_fixed' %}<span class="ok">수동고정 완료</span>{% elif r.status=='applied' %}<span class="ok">자동확정 반영됨</span>{% elif r.needs_manual %}<span class="bad">수동확인 필요</span>{% else %}<span class="ok">자동확정 후보</span>{% endif %}</td><td><form method="post" action="/bonus-ai/review/manual"><input type="hidden" name="row_id" value="{{r.id}}"><input class="codeinput" list="allcodes" name="code" value="{{r.selected_code or r.proposed_code or ''}}" placeholder="품번 입력/검색" required> <button class="btn orange">이 페이지로 수동고정</button></form>{% if r.final and r.status not in ['manual_fixed','applied'] %}<form class="inline" method="post" action="/bonus-ai/review/ignore"><input type="hidden" name="row_id" value="{{r.id}}"><button class="btn gray">이 후보 제외</button></form>{% endif %}</td></tr>{% else %}<tr><td colspan="5">아직 저장된 AI 매칭 결과가 없습니다.</td></tr>{% endfor %}</tbody></table></div><datalist id="allcodes">{% for i in items %}<option value="{{i.code}}">{{i.code}} | {{i.title_ko}} | {{i.gender}}</option>{% endfor %}</datalist></div></div></body></html>"""


@app.get('/bonus-ai/review')
def bonus_ai_review_page():
    review=_load_ai_review(); rows=list(review.get('rows') or [])
    rows.sort(key=lambda r:(str(r.get('file') or ''),int(r.get('page',0)),not bool(r.get('final')),clean_code(r.get('proposed_code'))))
    _,items,_,_=items_map(); matches=load_bonus_matches(mode='ai')
    auto_count=sum(1 for r in rows if r.get('final') and not r.get('needs_manual') and r.get('proposed_code') and r.get('status') not in ('ignored','manual_fixed'))
    manual_count=sum(1 for r in rows if r.get('final') and r.get('needs_manual'))
    provisional_count=sum(1 for r in rows if not r.get('final'))
    return render_template_string(AI_REVIEW_HTML,review=review,rows=rows,items=items,matches=matches,auto_count=auto_count,manual_count=manual_count,provisional_count=provisional_count)


@app.post('/bonus-ai/review/manual')
def bonus_ai_review_manual():
    row_id=str(request.form.get('row_id') or '').strip(); code=clean_code(request.form.get('code'))
    review=_load_ai_review(); rows=review.get('rows') or []
    row=next((r for r in rows if str(r.get('id'))==row_id),None)
    _,items,_,_=items_map(); valid={clean_code(i.get('code')) for i in items}
    if row and code in valid:
        source_id=_normalize_webhard_rel(row.get('file')); page=int(row.get('page',0))
        if source_id and _resolve_webhard_pdf(source_id):
            data=dict(load_bonus_matches(mode='ai')); data[code]={'file':source_id,'source':source_id,'page':page,'source_type':'manual'}
            save_bonus_matches(data,mode='ai'); _set_manual_override(code,source_id,page,mode='ai'); load_items(force=True)
            row['selected_code']=code; row['status']='manual_fixed'; row['needs_manual']=False; row['manual_fixed_at']=datetime.now().isoformat(timespec='seconds')
            _save_ai_review(review)
    return redirect('/bonus-ai/review')


@app.post('/bonus-ai/review/ignore')
def bonus_ai_review_ignore():
    row_id=str(request.form.get('row_id') or '').strip(); review=_load_ai_review()
    row=next((r for r in (review.get('rows') or []) if str(r.get('id'))==row_id),None)
    if row:
        row['status']='ignored'; row['selected_code']=''; _save_ai_review(review)
    return redirect('/bonus-ai/review')


@app.post('/bonus-ai/review/confirm-auto')
def bonus_ai_review_confirm_auto():
    review=_load_ai_review(); rows=[r for r in (review.get('rows') or []) if r.get('final')]
    manual_overrides=_load_manual_overrides(mode='ai'); data=dict(load_bonus_matches(mode='ai'))
    # For PDFs that reached final assignment, replace old non-manual auto links from
    # those PDFs. Stopped jobs therefore never erase unrelated/unfinished mappings.
    final_files={_normalize_webhard_rel(r.get('file')) for r in rows if _normalize_webhard_rel(r.get('file'))}
    final_files.update(_normalize_webhard_rel(x) for x in (review.get('scanned_files') or []) if _normalize_webhard_rel(x))
    data={c:rec for c,rec in data.items() if not (_bonus_source_id(rec) in final_files and str(rec.get('source_type') or 'auto')!='manual' and clean_code(c) not in manual_overrides)}
    candidates=[]
    for r in rows:
        if r.get('status') in ('ignored','manual_fixed') or r.get('needs_manual'): continue
        code=clean_code(r.get('selected_code') or r.get('proposed_code'))
        source_id=_normalize_webhard_rel(r.get('file'))
        if not code or code in manual_overrides or not source_id: continue
        candidates.append((int(r.get('score') or 0),code,source_id,int(r.get('page',0)),r))
    # One SKU can point to only one PDF/page: highest score wins deterministically.
    best={}
    for tup in sorted(candidates,key=lambda x:(-x[0],x[2],x[3])):
        best.setdefault(tup[1],tup)
    applied=0
    for score,code,source_id,page,row in best.values():
        data[code]={'file':source_id,'source':source_id,'page':page,'source_type':'auto'}
        row['status']='applied'; row['applied_at']=datetime.now().isoformat(timespec='seconds'); applied+=1
    save_bonus_matches(data,mode='ai'); load_items(force=True)
    review['confirmed_at']=datetime.now().strftime('%Y-%m-%d %H:%M:%S'); review['confirmed_count']=applied
    review['message']=f'AI 자동 매칭 {applied}개를 AI 번외 결과에 저장했습니다. 메인 화면에서 AI 번외 적용을 선택하면 실제 POP/이미지 매칭에 사용됩니다. 수동고정은 보호됩니다.'
    _save_ai_review(review)
    return redirect('/bonus-ai/review')


@app.get('/bonus-ai')
def bonus_ai_page():
    ok,status=ai_engine_status(); cache=_load_ai_cache().get('pages',{})
    all_pdfs=sorted(_sync_source_key(p) for p in WEBHARD_SYNC_DIR.rglob('*.pdf') if p.is_file())
    review=_load_ai_review(); review_rows=review.get('rows') or []
    return render_template_string(AI_MATCH_HTML,ai_ok=ok,ai_status=status,scan=get_scan_status(),cache_count=len(cache),all_pdfs=all_pdfs,single_ready=AI_SINGLE_RESULT_FILE.exists(),review_ready=bool(review_rows),review_count=len(review_rows),review_status=review.get('status',''))

@app.post('/bonus-ai/start')
def bonus_ai_start():
    ok=start_ai_full_rematch_job()
    return jsonify({'ok':ok,'message':'AI 전체 매칭 시작됨' if ok else '이미 다른 AI/OCR 매칭 작업이 실행 중입니다.','status':get_scan_status()})

@app.get('/bonus-ai/start')
def bonus_ai_start_compat():
    start_ai_full_rematch_job()
    return redirect('/bonus-ai')

@app.post('/bonus-ai/test-one')
def bonus_ai_test_one():
    sid=_normalize_webhard_rel(request.form.get('filename',''))
    if sid and _resolve_webhard_pdf(sid):
        if not start_ai_single_job(sid):
            _set_scan_status(message='단일 PDF 테스트 시작 보류',error='이미 다른 AI/OCR 매칭 작업이 실행 중입니다.')
    else:
        _set_scan_status(message='단일 PDF 테스트 시작 실패',error='선택한 PDF를 찾을 수 없습니다.')
    return redirect('/bonus-ai')

@app.get('/bonus-ai/result')
def bonus_ai_result():
    try: rec=json.loads(AI_SINGLE_RESULT_FILE.read_text('utf-8'))
    except Exception: return redirect('/bonus-ai')
    sid=_normalize_webhard_rel(rec.get('filename','')); _,items,_,_=items_map()
    return render_template_string(BONUS_HTML,results=rec.get('results') or [],filename=sid,items=items,matches=load_bonus_matches(mode='ai'),ocr_status='AI: PP-OCRv5 Korean FAST + PaddleOCR-VL 1.6 fallback',ocr_threshold=round(AI_AUTO_THRESHOLD*100),ocr_margin=round(AI_MARGIN_THRESHOLD*100))

@app.get('/bonus-ai/analyze/<path:filename>')
def bonus_ai_analyze(filename):
    sid=_normalize_webhard_rel(filename); path=_resolve_webhard_pdf(sid)
    if not path: return redirect('/bonus-ai')
    _,items,_,_=items_map()
    # Single-file debug uses existing AI cache. If missing, ask the full test job to build it.
    with fitz.open(str(path)) as doc:
        missing=any(not _ai_page_text(path,p) for p in range(doc.page_count))
    if missing: return redirect('/bonus-ai')
    results=match_pdf_pages_ai(path,items)
    return render_template_string(BONUS_HTML,results=results,filename=sid,items=items,matches=load_bonus_matches(mode='ai'),ocr_status='AI: PP-OCRv5 Korean FAST + PaddleOCR-VL 1.6 fallback',ocr_threshold=round(AI_AUTO_THRESHOLD*100),ocr_margin=round(AI_MARGIN_THRESHOLD*100))
# ---------------- end AI engine ----------------

def calculate_discount_percent(normal, sale):
    """Return markdown percentage from normal price to sale price.

    Example: 39,900 -> 11,900 = 70.18%, therefore the V4.4 special-price rule applies.
    """
    try:
        normal = float(normal or 0)
        sale = float(sale or 0)
    except Exception:
        return 0.0
    if normal <= 0 or sale <= 0 or sale >= normal:
        return 0.0
    return max(0.0, min(100.0, (normal - sale) / normal * 100.0))


def load_items(force=False):
    global _ITEMS_CACHE, _CACHE_MTIME, _PRODUCT_INDEX
    if not CURRENT_XLSX.exists():
        return [], '', '엑셀 미등록'
    # Visual mappings and engine selection can change without touching the Excel file.
    bonus_mode=get_bonus_match_mode()
    active_bonus_file=_bonus_map_file(bonus_mode)
    bonus_mtime = active_bonus_file.stat().st_mtime_ns if active_bonus_file.exists() else -1
    mode_mtime = BONUS_MODE_FILE.stat().st_mtime_ns if BONUS_MODE_FILE.exists() else -1
    choice_mtime = VISUAL_CHOICE_FILE.stat().st_mtime_ns if VISUAL_CHOICE_FILE.exists() else -1
    template_sig = tuple(
        p.stat().st_mtime_ns if p.exists() else -1
        for p in (TEMPLATE_DIR / 'NEW_ARRIVAL.pdf', ADULT_SMALL_TEMPLATE, CLEARANCE_TEMPLATE)
    )
    mtime = (CURRENT_XLSX.stat().st_mtime_ns, bonus_mode, bonus_mtime, mode_mtime, choice_mtime, template_sig)
    if not force and _ITEMS_CACHE is not None and _CACHE_MTIME == mtime:
        return _ITEMS_CACHE

    _PRODUCT_INDEX = None
    build_product_index()
    wb = load_workbook(CURRENT_XLSX, data_only=True, read_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    header_idx = None
    header_values = []
    for idx, row in enumerate(rows[:40]):
        vals = [str(v or '').strip() for v in row]
        if any(x in vals for x in ('스타일', '품번')) and '정상가' in vals:
            header_idx = idx
            header_values = vals
            break
    if header_idx is None:
        wb.close()
        raise ValueError('헤더 행을 찾지 못했습니다. 품번/스타일과 정상가 열이 필요합니다.')

    def col(*names):
        for name in names:
            if name in header_values:
                return header_values.index(name)
        return None

    cols = {
        'code': col('스타일', '품번'), 'title_ko': col('상품명'),
        'title_en': col('상품명(영문)', '영문명'), 'gender': col('성별'),
        'zone': col('조닝', '종류'), 'color': col('컬러'),
        'normal': col('정상가'), 'sale': col('조정가', '할인가'),
        'promotion': col('프로모션 내용'), 'season': col('시즌')
    }

    date_range = ''
    for row in rows[:20]:
        for value in row[:20]:
            text_value = str(value or '').strip()
            candidate = normalize_date_range(value)
            has_two_dates = len(re.findall(r'\d{1,2}[./-]\d{1,2}|\d{1,2}\s*월\s*\d{1,2}', text_value)) >= 2
            if '기간' in text_value or has_two_dates:
                date_range = candidate
                break
        if date_range:
            break

    items = []
    for row in rows[header_idx + 1:]:
        def get(key):
            c = cols.get(key)
            return row[c] if c is not None and c < len(row) else None
        code = clean_code(get('code'))
        if not code:
            continue
        normal = n(get('normal'))
        sale = n(get('sale'))
        promo = str(get('promotion') or '').strip()
        multi = []
        for c, label in ((11, '2장'), (12, '3장'), (13, '4장')):
            if c < len(row):
                value = n(row[c])
                if value > 0:
                    multi.append(f'{label} {value:,}원')
        if not promo and multi:
            promo = ' / '.join(multi)
        is_disc = sale > 0 and (normal == 0 or sale < normal)
        discount_percent = calculate_discount_percent(normal, sale)
        gender = infer_gender_from_code(code, get('gender'))
        route = resolve_item_visual(code, gender, is_disc, discount_percent)
        item = {
            'code': code, 'title_ko': str(get('title_ko') or '').strip(),
            'title_en': str(get('title_en') or '').strip(),
            'gender': gender, 'zone': str(get('zone') or '').strip(),
            'color': str(get('color') or '').strip(), 'normal': normal, 'sale': sale,
            'normal_fmt': f'{normal:,}원' if normal else '-',
            'sale_fmt': f'{sale:,}원' if sale else '-', 'promotion': promo,
            'season': str(get('season') or '').strip(),
            'date_range': date_range, 'is_discount': is_disc,
            'discount_percent': round(discount_percent, 1),
            'discount_percent_fmt': (f'{discount_percent:.1f}%'.replace('.0%', '%') if is_disc else '-'),
        }
        item.update(route)
        items.append(item)
    wb.close()
    loaded = LAST_NAME.read_text('utf-8').strip() if LAST_NAME.exists() else CURRENT_XLSX.name
    _ITEMS_CACHE = (items, date_range, loaded)
    _CACHE_MTIME = mtime
    return _ITEMS_CACHE

def _row_metrics(im):
    """Return lightweight row statistics used for source-bar detection."""
    probe_w = 360
    scale = probe_w / max(1, im.width)
    probe_h = max(1, round(im.height * scale))
    probe = im.convert('RGB').resize((probe_w, probe_h), Image.Resampling.BILINEAR)
    rows = []
    for y in range(probe_h):
        colors = list(probe.crop((0, y, probe_w, y + 1)).getdata())
        n = max(1, len(colors))
        mr = sum(c[0] for c in colors) / n
        mg = sum(c[1] for c in colors) / n
        mb = sum(c[2] for c in colors) / n
        # Mean distance from the row mean: low values indicate a flat label band.
        dev = sum((abs(c[0]-mr)+abs(c[1]-mg)+abs(c[2]-mb))/3 for c in colors) / n
        rows.append((mr, mg, mb, dev))
    return rows, probe_h, probe


def _detect_bonus_visual_bottom(im):
    """Detect the beginning of a source PDF's own lower information strip.

    The lower strip may be white, gray, or tinted. We look only in the final
    quarter of the page, score full-width horizontal transitions, and prefer a
    boundary followed by a comparatively flat region. This avoids mistaking
    internal product photos or text panels for the source information bar.
    """
    rows, ph, probe = _row_metrics(im)
    if ph < 40:
        return im.height

    start = int(ph * 0.73)
    end = int(ph * 0.88)
    candidates = []
    for y in range(start, end):
        r0 = rows[max(0, y-2)]
        r1 = rows[y]
        transition = (abs(r1[0]-r0[0]) + abs(r1[1]-r0[1]) + abs(r1[2]-r0[2])) / 3
        row_a = list(probe.crop((0, max(0, y-2), probe.width, max(0, y-2)+1)).getdata())
        row_b = list(probe.crop((0, y, probe.width, y+1)).getdata())
        change_coverage = sum(
            1 for a, b in zip(row_a, row_b)
            if (abs(a[0]-b[0])+abs(a[1]-b[1])+abs(a[2]-b[2]))/3 >= 18
        ) / max(1, probe.width)

        below = rows[y:max(y+1, int(ph * 0.94))]
        flat_ratio = sum(1 for r in below if r[3] <= 24) / max(1, len(below))
        avg_dev = sum(r[3] for r in below) / max(1, len(below))

        if transition < 8 or change_coverage < 0.22 or flat_ratio < 0.55:
            continue
        score = (
            transition * 1.2
            + change_coverage * 55
            + flat_ratio * 35
            - (y / ph) * 30
            - avg_dev * 0.15
        )
        candidates.append((score, y))

    if not candidates:
        return im.height

    _, y_probe = max(candidates, key=lambda v: v[0])
    y_full = round(y_probe * im.height / ph)
    # Remove a small safety band above the detected source-bar boundary;
    # headquarters files often place the outlined gender box immediately above
    # the rest of their information strip.
    margin = max(2, round(im.height * 0.04))
    return max(1, min(im.height, y_full - margin))


def _edge_background_color(im):
    """Estimate a neutral fill colour from the artwork edges."""
    rgb = im.convert('RGB')
    w, h = rgb.size
    sw = max(1, w // 80)
    sh = max(1, h // 80)
    samples = []
    for box in ((0, 0, w, sh), (0, h-sh, w, h), (0, 0, sw, h), (w-sw, 0, w, h)):
        samples.extend(list(rgb.crop(box).resize((40, 4), Image.Resampling.BILINEAR).getdata()))
    if not samples:
        return (255, 255, 255)
    samples.sort(key=lambda c: c[0] + c[1] + c[2])
    mid = samples[len(samples)//2]
    return tuple(int(v) for v in mid)


def _fit_bonus_artwork(art, target_w, target_h):
    """Fit complete artwork into a fixed frame without cutting text or models."""
    art = art.convert('RGB')
    if art.width <= 0 or art.height <= 0:
        return Image.new('RGB', (target_w, target_h), 'white')
    bg = _edge_background_color(art)
    frame = Image.new('RGB', (target_w, target_h), bg)

    # Small safety inset prevents artwork typography from visually colliding
    # with the standard bottom bar while preserving the complete composition.
    inset_x = max(0, round(target_w * 0.006))
    inset_y = max(0, round(target_h * 0.006))
    avail_w = max(1, target_w - inset_x * 2)
    avail_h = max(1, target_h - inset_y * 2)
    scale = min(avail_w / art.width, avail_h / art.height)
    nw = max(1, round(art.width * scale))
    nh = max(1, round(art.height * scale))
    fitted = art.resize((nw, nh), Image.Resampling.LANCZOS)
    x = (target_w - nw) // 2
    y = (target_h - nh) // 2
    frame.paste(fitted, (x, y))
    return frame


def load_generation_queue():
    if not QUEUE_FILE.exists():
        return []
    try:
        raw = json.loads(QUEUE_FILE.read_text('utf-8'))
        return [clean_code(x) for x in raw if clean_code(x)]
    except Exception:
        return []


def save_generation_queue(codes):
    unique=[]; seen=set()
    for code in codes:
        code=clean_code(code)
        if code and code not in seen:
            unique.append(code); seen.add(code)
    QUEUE_FILE.write_text(json.dumps(unique, ensure_ascii=False, indent=2), encoding='utf-8')
    return unique


def visual_signature(pathstr):
    raw=str(pathstr or '')
    page=0
    if '::page=' in raw:
        raw,p=raw.rsplit('::page=',1)
        try: page=int(p)
        except Exception: page=0
    p=Path(raw) if raw else TEMPLATE_DIR/'NEW_ARRIVAL.pdf'
    try:
        st=p.stat(); base=f'{p.resolve()}|{page}|{st.st_size}|{st.st_mtime_ns}'
    except OSError:
        base=f'{p}|{page}|missing'
    return hashlib.sha1(base.encode('utf-8',errors='ignore')).hexdigest()[:16]


def item_preview_version(item):
    payload='|'.join(str(item.get(k,'')) for k in ('code','gender','title_ko','title_en','normal','sale','discount_percent','date_range','visual','visual_mode','bonus_choice','requires_bonus_choice'))
    payload += '|'+visual_signature(item.get('visual'))
    return hashlib.sha1(payload.encode('utf-8',errors='ignore')).hexdigest()[:16]


def _render_cache_key(pathstr):
    return f'{str(pathstr)}|{visual_signature(pathstr)}'

def render_visual_a4(pathstr):
    cache_key = _render_cache_key(pathstr)
    cached = _RENDER_CACHE.get(cache_key)
    if cached is not None:
        _RENDER_CACHE.move_to_end(cache_key)
        return cached.copy()
    """Render the complete source page at true A4 size.

    NEW ARRIVAL and every bonus PDF follow one identical rule: preserve the
    source page without automatic trimming, then generate_one() covers the
    final 210 x 50 mm of the finished 210 x 240 mm POP with the standard bar.
    This fixed physical overlay hides headquarters' original lower gender and
    product-information area without unreliable image-content detection.
    """
    page_index = 0
    raw_path = str(pathstr or '')
    if '::page=' in raw_path:
        raw_path, page_text = raw_path.rsplit('::page=', 1)
        try:
            page_index = max(0, int(page_text))
        except Exception:
            page_index = 0
    p = Path(raw_path) if raw_path else TEMPLATE_DIR / 'NEW_ARRIVAL.pdf'
    if not p.exists():
        p = TEMPLATE_DIR / 'NEW_ARRIVAL.pdf'
    canvas = Image.new('RGB', (A4_W_PX, A4_H_PX), 'white')
    try:
        if p.suffix.lower() == '.pdf':
            doc = fitz.open(str(p))
            page = doc.load_page(min(page_index, max(0, doc.page_count - 1)))
            scale = DPI / 72.0
            pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False)
            im = Image.frombytes('RGB', [pix.width, pix.height], pix.samples)
            doc.close()
        else:
            im = Image.open(p).convert('RGB')

        # Full-page actual-size normalization only; no bonus-specific cropping.
        if im.size != canvas.size:
            im = im.resize(canvas.size, Image.Resampling.LANCZOS)
        canvas.paste(im, (0, 0))
        _RENDER_CACHE[cache_key] = canvas.copy()
        _RENDER_CACHE.move_to_end(cache_key)
        while len(_RENDER_CACHE) > _RENDER_CACHE_MAX:
            _RENDER_CACHE.popitem(last=False)
        return canvas
    except Exception as exc:
        print(f'Visual load error: {exc}', flush=True)
        return canvas

def draw_right(draw, xy_right, text, font_obj, fill):
    box = draw.textbbox((0,0), text, font=font_obj)
    draw.text((xy_right[0]-(box[2]-box[0]), xy_right[1]), text, font=font_obj, fill=fill)

def clip_text_to_width(draw, text, font_obj, max_width):
    """Keep the fixed font size and shorten only the text when it exceeds the PPT box."""
    text = str(text or '').strip()
    if not text:
        return ''
    if draw.textbbox((0,0), text, font=font_obj)[2] <= max_width:
        return text
    ellipsis = '…'
    lo, hi = 0, len(text)
    while lo < hi:
        mid = (lo + hi + 1) // 2
        candidate = text[:mid].rstrip() + ellipsis
        if draw.textbbox((0,0), candidate, font=font_obj)[2] <= max_width:
            lo = mid
        else:
            hi = mid - 1
    return text[:lo].rstrip() + ellipsis

def _tag(draw, x, y, text, fnt, bg, fg='white', pad_x_mm=1.0, pad_y_mm=0.25):
    box = draw.textbbox((0,0), text, font=fnt)
    w, h = box[2]-box[0], box[3]-box[1]
    px = round(pad_x_mm * MM_TO_PX)
    py = round(pad_y_mm * MM_TO_PX)
    draw.rectangle((x, y, x+w+px*2, y+h+py*2), fill=bg)
    draw.text((x+px, y+py-box[1]), text, font=fnt, fill=fg)
    return x+w+px*2

def _fit_text_fixed_box(draw, text, font_obj, left, top, right, fill, align='left'):
    """Draw inside a fixed PPT text box. Both box edges stay immovable."""
    text = str(text or '').strip()
    if not text:
        return
    max_width = max(1, right - left)
    text = clip_text_to_width(draw, text, font_obj, max_width)
    box = draw.textbbox((0, 0), text, font=font_obj)
    width = box[2] - box[0]
    x = right - width if align == 'right' else left
    draw.text((x, top), text, font=font_obj, fill=fill)


def _fit_text_shrink_box(draw, text, font_path, start_pt, min_pt, left, top, right, fill, align='left'):
    """Keep both box edges fixed and reduce font size until the complete text fits."""
    text = str(text or '').strip()
    if not text:
        return
    max_width = max(1, right-left)
    chosen = None
    chosen_size = start_pt
    for pt in range(int(start_pt), int(min_pt)-1, -1):
        fnt = font(font_path, pt_px(pt))
        box = draw.textbbox((0,0), text, font=fnt)
        if box[2]-box[0] <= max_width:
            chosen = fnt
            chosen_size = pt
            break
    if chosen is None:
        chosen_size = min_pt
        chosen = font(font_path, pt_px(min_pt))
        # Last resort only for extraordinarily long names: preserve all characters by horizontal compression.
        box = draw.textbbox((0,0), text, font=chosen)
        tw, th = max(1, box[2]-box[0]), max(1, box[3]-box[1])
        layer = Image.new('RGBA', (tw+8, th+8), (255,255,255,0))
        ld = ImageDraw.Draw(layer)
        ld.text((4-box[0],4-box[1]), text, font=chosen, fill=fill)
        target_w = max_width
        layer = layer.resize((target_w, layer.height), Image.Resampling.LANCZOS)
        x = right-target_w if align=='right' else left
        draw._image.alpha_composite(layer, (x, top)) if draw._image.mode=='RGBA' else draw._image.paste(layer.convert('RGB'), (x,top), layer)
        return
    box = draw.textbbox((0,0), text, font=chosen)
    width = box[2]-box[0]
    x = right-width if align=='right' else left
    draw.text((x,top), text, font=chosen, fill=fill)


def _fixed_tag(draw, box_mm, text, font_obj, bg, fg='white'):
    """Draw a tag in an immovable rectangle; text is clipped within the fixed rectangle."""
    l, t, r, b = [round(v * MM_TO_PX) for v in box_mm]
    draw.rectangle((l, t, r, b), fill=bg)
    text = clip_text_to_width(draw, text, font_obj, max(1, r-l-round(1.4*MM_TO_PX)))
    tb = draw.textbbox((0,0), text, font=font_obj)
    th = tb[3]-tb[1]
    tw = tb[2]-tb[0]
    # Exact horizontal and vertical centering inside the fixed tag rectangle.
    x = l + max(0, ((r-l)-tw)//2) - tb[0]
    y = t + max(0, ((b-t)-th)//2) - tb[1]
    draw.text((x, y), text, font=font_obj, fill=fg)


def _pt_px_for_dpi(pt, dpi):
    return max(1, round(float(pt) * float(dpi) / 72.0))


def _font_for_dpi(path, pt, dpi, bold=False):
    return font(path, _pt_px_for_dpi(pt, dpi), fallback_bold=bold)


def _box_px(box_mm, dpi):
    scale = dpi / 25.4
    return tuple(round(v * scale) for v in box_mm)


def _fit_one_line(draw, text, font_path, start_pt, min_pt, box_mm, fill, dpi, align='left', bold=False):
    text = str(text or '').strip()
    if not text:
        return
    left, top, right, bottom = _box_px(box_mm, dpi)
    max_w = max(1, right-left)
    chosen = _font_for_dpi(font_path, min_pt, dpi, bold)
    for pt in range(int(start_pt), int(min_pt)-1, -1):
        candidate = _font_for_dpi(font_path, pt, dpi, bold)
        bbox = draw.textbbox((0,0), text, font=candidate)
        if bbox[2]-bbox[0] <= max_w:
            chosen = candidate
            break
    bbox = draw.textbbox((0,0), text, font=chosen)
    tw, th = bbox[2]-bbox[0], bbox[3]-bbox[1]
    x = right-tw-bbox[0] if align == 'right' else left-bbox[0]
    y = top-bbox[1] + max(0, ((bottom-top)-th)//2)
    draw.text((x,y), text, font=chosen, fill=fill)


def _title_char_count(text):
    """Count visible product-name characters; spaces are ignored for the 11-character store rule."""
    return len(re.sub(r'\s+', '', str(text or '').strip()))


def _smart_title_lines(text, max_chars=11):
    """Return one or exactly two clean lines using the store's 11-character rule.

    Important example:
      [분노의 질주] 가먼트다잉 그래픽 T (반팔)
    becomes
      [분노의 질주]
      가먼트다잉 그래픽 T (반팔)

    Bracketed collaboration/collection names are treated as a semantic prefix, so we do
    not create the awkward '[분노의 질주] 가먼트다잉 / 그래픽 T (반팔)' split.
    """
    text = re.sub(r'\s+', ' ', str(text or '').strip())
    if not text or _title_char_count(text) <= max_chars:
        return [text]

    # Prefer a leading [collection / collaboration] block as line 1.
    m = re.match(r'^(\[[^\]]+\])\s+(.+)$', text)
    if m and m.group(2).strip():
        return [m.group(1).strip(), m.group(2).strip()]

    words = text.split(' ')
    if len(words) >= 2:
        best_cut = None
        best_score = None
        for cut in range(1, len(words)):
            left = ' '.join(words[:cut]).strip()
            right = ' '.join(words[cut:]).strip()
            if not right:
                continue
            n = _title_char_count(left)
            # Strongly prefer line 1 at or below 11 chars; among them use the fullest line.
            over = max(0, n - max_chars)
            under = max(0, max_chars - n)
            score = (over * 1000 + under, abs(_title_char_count(right) - n))
            if best_score is None or score < best_score:
                best_score = score
                best_cut = cut
        if best_cut:
            return [' '.join(words[:best_cut]).strip(), ' '.join(words[best_cut:]).strip()]

    # No word boundary exists. Split at the 11th visible character without dropping spaces.
    visible = 0
    cut = 0
    for i, ch in enumerate(text):
        if not ch.isspace():
            visible += 1
        if visible >= max_chars:
            cut = i + 1
            break
    if cut <= 0 or cut >= len(text):
        cut = max(1, len(text)//2)
    return [text[:cut].rstrip(), text[cut:].lstrip()]


def _fit_smart_title(draw, text, font_path, start_pt, min_pt, box_mm, fill, dpi, bold=False):
    """Draw a product name in one line, or exactly two lines when it exceeds 11 chars."""
    text = str(text or '').strip()
    if not text:
        return 1
    lines = _smart_title_lines(text, 11)
    left, top, right, bottom = _box_px(box_mm, dpi)
    max_w, max_h = max(1, right-left), max(1, bottom-top)
    chosen = _font_for_dpi(font_path, min_pt, dpi, bold)
    for pt in range(int(start_pt), int(min_pt)-1, -1):
        candidate = _font_for_dpi(font_path, pt, dpi, bold)
        boxes = [draw.textbbox((0,0), line, font=candidate) for line in lines]
        widths = [b[2]-b[0] for b in boxes]
        heights = [b[3]-b[1] for b in boxes]
        line_gap = max(1, round(pt * dpi / 72 * 0.10)) if len(lines) == 2 else 0
        if max(widths or [0]) <= max_w and sum(heights) + line_gap <= max_h:
            chosen = candidate
            break
    boxes = [draw.textbbox((0,0), line, font=chosen) for line in lines]
    heights = [b[3]-b[1] for b in boxes]
    # Top-anchored layout keeps the first row exactly aligned with the template field.
    gap = max(1, round((bottom-top-sum(heights)) * 0.18)) if len(lines) == 2 else 0
    y = top
    for line, b in zip(lines, boxes):
        draw.text((left-b[0], y-b[1]), line, font=chosen, fill=fill)
        y += (b[3]-b[1]) + gap
    return len(lines)


def _split_two_lines(text, draw, fnt, max_w):
    text = str(text or '').strip()
    if not text:
        return ['']
    if draw.textbbox((0,0), text, font=fnt)[2] <= max_w:
        return [text]
    words = text.split()
    candidates = []
    if len(words) > 1:
        for cut in range(1, len(words)):
            a=' '.join(words[:cut]); b=' '.join(words[cut:])
            width=max(draw.textbbox((0,0),a,font=fnt)[2],draw.textbbox((0,0),b,font=fnt)[2])
            candidates.append((width,abs(len(a)-len(b)),a,b))
    else:
        for cut in range(1, len(text)):
            a=text[:cut]; b=text[cut:]
            width=max(draw.textbbox((0,0),a,font=fnt)[2],draw.textbbox((0,0),b,font=fnt)[2])
            candidates.append((width,abs(len(a)-len(b)),a,b))
    if not candidates:
        return [text]
    _,__,a,b=min(candidates)
    return [a,b]


def _fit_two_lines(draw, text, font_path, start_pt, min_pt, box_mm, fill, dpi, bold=False):
    text = str(text or '').strip()
    if not text:
        return
    left, top, right, bottom = _box_px(box_mm, dpi)
    max_w, max_h = max(1,right-left), max(1,bottom-top)
    lines=[text]; chosen=_font_for_dpi(font_path,min_pt,dpi,bold)
    for pt in range(int(start_pt), int(min_pt)-1, -1):
        candidate=_font_for_dpi(font_path,pt,dpi,bold)
        proposed=_split_two_lines(text,draw,candidate,max_w)
        line_heights=[]; widths=[]
        for line in proposed:
            bb=draw.textbbox((0,0),line,font=candidate)
            widths.append(bb[2]-bb[0]); line_heights.append(bb[3]-bb[1])
        gap=round(pt*dpi/72*0.06) if len(proposed)>1 else 0
        if max(widths or [0])<=max_w and sum(line_heights)+gap<=max_h:
            chosen=candidate; lines=proposed; break
    metrics=[draw.textbbox((0,0),line,font=chosen) for line in lines]
    heights=[b[3]-b[1] for b in metrics]
    gap=max(0,round((bottom-top-sum(heights))/max(1,len(lines)+1)))
    y=top+gap
    for line,b in zip(lines,metrics):
        draw.text((left-b[0],y-b[1]),line,font=chosen,fill=fill)
        y += (b[3]-b[1])+gap


def _draw_adult_small_fields(a4, item, dpi):
    d=ImageDraw.Draw(a4)
    black=(20,20,20); red=(230,0,18); gray=(45,45,45)
    _fit_one_line(d, f"{item.get('sale',0):,}" if item.get('sale') else '', FONT_DIN_BOLD, 152, 82,
                  (23.77,51.06,209.03,118.26), red, dpi, 'left', True)
    _fit_one_line(d, f"{item.get('normal',0):,}" if item.get('normal') else '', FONT_DIN_MEDIUM, 44, 28,
                  (29.12,114.87,140.97,132.88), black, dpi, 'left')
    _fit_one_line(d, item.get('date_range',''), FONT_DIN_MEDIUM, 25, 18,
                  (82.56,182.41,152.57,196.41), red, dpi, 'left')

    # Exact left alignment rule: gender tag edge, Korean title and English title share one X line.
    # The fixed gender tag on the adult-small template starts at about 30.1 mm.
    FIELD_LEFT = 30.10
    SAFE_RIGHT = 132.00  # never enter the colored lower-right triangle
    line_count = _fit_smart_title(d, item.get('title_ko',''), FONT_KO, 31, 18,
                                  (FIELD_LEFT,193.80,SAFE_RIGHT,214.60), black, dpi, True)
    en_top = 214.70 if line_count == 2 else 211.80
    _fit_one_line(d, str(item.get('title_en') or '').upper(), FONT_DIN_MEDIUM, 21, 11,
                  (FIELD_LEFT,en_top,SAFE_RIGHT,223.30), gray, dpi, 'left')

def _draw_clearance_fields(a4, item, dpi):
    d=ImageDraw.Draw(a4)
    black=(20,20,20); red=(230,0,18); gray=(45,45,45)
    _fit_one_line(d, f"{item.get('normal',0):,}" if item.get('normal') else '', FONT_DIN_MEDIUM, 24, 17,
                  (163.14,222.76,195.03,234.30), black, dpi, 'right')
    _fit_one_line(d, f"{item.get('sale',0):,}" if item.get('sale') else '', FONT_DIN_BOLD, 65, 40,
                  (127.75,228.53,195.03,256.20), red, dpi, 'right', True)

    # Exact left alignment rule for SPECIAL PRICE: gender tag, Korean title and English title.
    FIELD_LEFT = 19.30
    SAFE_RIGHT = 127.02
    line_count = _fit_smart_title(d, item.get('title_ko',''), FONT_KO, 27, 17,
                                  (FIELD_LEFT,230.40,SAFE_RIGHT,253.30), black, dpi, True)
    en_top = 254.00 if line_count == 2 else 246.50
    _fit_one_line(d, str(item.get('title_en') or '').upper(), FONT_DIN_MEDIUM, 12.7, 8,
                  (FIELD_LEFT,en_top,SAFE_RIGHT,264.00), gray, dpi, 'left')

def render_custom_template_a4(item, dpi):
    if dpi == DPI:
        a4 = render_visual_a4(item.get('visual'))
    else:
        a4 = _render_visual_preview(item.get('visual'))
    if item.get('visual_mode') == 'clearance':
        _draw_clearance_fields(a4, item, dpi)
    else:
        _draw_adult_small_fields(a4, item, dpi)
    return a4


def generate_bottom_bar(item):
    """Render the adult-small TOPTEN bottom bar with locked PPT text boxes.

    Font mapping:
      - gender / Korean title / English title / old normal price: NanumBarunGothic
      - event date: DINPro-Medium
      - normal main price / discount main price: DINPro-Bold

    Every field uses a fixed left and right boundary derived from the sample/PPT.
    Product names longer than 11 visible characters are rendered as exactly two clean lines; all left edges remain locked.
    """
    bar = Image.new('RGB', (A4_W_PX, BAR_H_PX), 'white')
    d = ImageDraw.Draw(bar)

    black = (20, 20, 20)
    gray = (45, 45, 45)
    red = (230, 0, 18)
    gender_bg = (32, 32, 32)
    period_bg = (196, 0, 18)

    # Fixed point sizes supplied by the store.
    f_gender = font(FONT_KO, pt_px(11))
    f_period = font(FONT_KO, pt_px(11))
    f_date = font(FONT_DIN_MEDIUM, pt_px(17))
    f_title = font(FONT_KO, pt_px(27))
    f_en = font(FONT_KO, pt_px(13))
    f_main = font(FONT_DIN_BOLD, pt_px(59), fallback_bold=True)
    f_old = font(FONT_KO, pt_px(23))

    # LOCKED BOUNDARIES (millimetres within the measured 210 x 50 mm bottom bar).
    # Both the start and end of every text box remain fixed.
    # Original PPT geometry is vertically centered with 5 mm margins.
    GENDER_BOX = (17.4, 6.8, 29.6, 12.2)
    PERIOD_BOX = (30.4, 6.8, 48.7, 12.2)
    DATE_LEFT, DATE_RIGHT, DATE_TOP = 50.4, 93.0, 5.55
    TITLE_LEFT, TITLE_RIGHT, TITLE_TOP = 17.4, 124.0, 13.2
    EN_LEFT, EN_RIGHT, EN_TOP = 17.4, 124.0, 28.0
    PRICE_LEFT, PRICE_RIGHT, PRICE_TOP = 126.0, 193.45, 11.3
    OLD_LEFT, OLD_RIGHT, OLD_TOP = 158.0, 193.45, 5.1

    gender = (item.get('gender') or '공용').strip()
    _fixed_tag(d, GENDER_BOX, gender, f_gender, gender_bg)

    if item.get('is_discount'):
        _fixed_tag(d, PERIOD_BOX, '기간한정', f_period, period_bg)
        _fit_text_fixed_box(
            d, item.get('date_range',''), f_date,
            round(DATE_LEFT*MM_TO_PX), round(DATE_TOP*MM_TO_PX), round(DATE_RIGHT*MM_TO_PX), red, 'left'
        )

    # Gender tag, Korean product name and English product name all start on the same X line.
    title_lines = _fit_smart_title(
        d, item.get('title_ko',''), FONT_KO, 27, 15,
        (TITLE_LEFT, TITLE_TOP, TITLE_RIGHT, 30.8), black, DPI, True
    )
    en_top_mm = 31.0 if title_lines == 2 else EN_TOP
    _fit_one_line(
        d, str(item.get('title_en') or '').upper(), FONT_KO, 13, 9,
        (EN_LEFT, en_top_mm, EN_RIGHT, 38.8), gray, DPI, 'left'
    )

    if item.get('is_discount'):
        old = f"{item.get('normal',0):,}" if item.get('normal') else ''
        sale = f"{item.get('sale',0):,}" if item.get('sale') else ''
        _fit_text_fixed_box(
            d, old, f_old,
            round(OLD_LEFT*MM_TO_PX), round(OLD_TOP*MM_TO_PX), round(OLD_RIGHT*MM_TO_PX), black, 'right'
        )
        if old:
            # Straight horizontal red cancellation arrow, pointing from right to left.
            ob = d.textbbox((0,0), old, font=f_old)
            ow = ob[2]-ob[0]
            old_right_px = round(OLD_RIGHT*MM_TO_PX)
            text_left_px = old_right_px - ow
            left_x = max(round(OLD_LEFT*MM_TO_PX), text_left_px - round(4.0*MM_TO_PX))
            right_x = old_right_px
            y = round(8.55*MM_TO_PX)
            width = max(2, round(.28*MM_TO_PX))
            d.line((right_x, y, left_x, y), fill=red, width=width)
            # Arrowhead at the left end: direction is right -> left.
            head = round(2.0*MM_TO_PX)
            d.line((left_x, y, left_x+head, y-head), fill=red, width=width)
            d.line((left_x, y, left_x+head, y+head), fill=red, width=width)
        _fit_text_fixed_box(
            d, sale, f_main,
            round(PRICE_LEFT*MM_TO_PX), round(PRICE_TOP*MM_TO_PX), round(PRICE_RIGHT*MM_TO_PX), red, 'right'
        )
    else:
        price = f"{item.get('normal',0):,}" if item.get('normal') else ''
        _fit_text_fixed_box(
            d, price, f_main,
            round(PRICE_LEFT*MM_TO_PX), round(PRICE_TOP*MM_TO_PX), round(PRICE_RIGHT*MM_TO_PX), black, 'right'
        )
    return bar

def save_a4_pdf(a4_image, pdf_path):
    """Save a true A4 page. Print at Actual size / 100%."""
    tmp = CACHE_DIR / '_a4_page.png'
    a4_image.save(tmp, 'PNG', dpi=(DPI,DPI))
    a4 = fitz.paper_rect('a4')
    doc = fitz.open()
    page = doc.new_page(width=a4.width, height=a4.height)
    page.insert_image(page.rect, filename=str(tmp))
    # Clear full-width cut guides. Cut exactly on both dashed lines to obtain 210 x 240 mm.
    for idx, mm in enumerate((CUT_TOP_MM, CUT_BOTTOM_MM)):
        y = mm / 25.4 * 72
        dash = 8.0
        gap = 5.0
        x = 0.0
        while x < a4.width:
            page.draw_line(fitz.Point(x,y), fitz.Point(min(a4.width,x+dash),y), color=(.55,.55,.55), width=.45)
            x += dash+gap
        label_y = y-9 if idx == 0 else y+3
        page.insert_text(fitz.Point(8,label_y), 'CUT HERE - 210 x 240 mm', fontsize=7, color=(.45,.45,.45), fontname='helv')
    doc.save(str(pdf_path), deflate=True)
    doc.close()

def generate_one(item,out_path=None):
    if item.get('visual_mode') in {'adult_small', 'clearance'}:
        a4_page = render_custom_template_a4(item, DPI)
    else:
        a4_page = render_visual_a4(item.get('visual'))
        bar = generate_bottom_bar(item)
        a4_page.paste(bar, (0, BAR_TOP_PX))
    pop = a4_page.crop((0, CUT_TOP_PX, A4_W_PX, CUT_TOP_PX + POP_H_PX))
    if out_path:
        out_path = Path(out_path)
        pop.save(out_path, 'PNG', dpi=(DPI,DPI))
        save_a4_pdf(a4_page, out_path.with_suffix('.pdf'))
    return pop

def items_map():
    its,dr,ln=load_items(); return {i['code']:i for i in its},its,dr,ln



def load_sync_state():
    if not SYNC_STATE_FILE.exists():
        return {}
    try:
        return json.loads(SYNC_STATE_FILE.read_text('utf-8'))
    except Exception:
        return {}


def save_sync_state(data):
    SYNC_STATE_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


def safe_filename(name):
    return re.sub(r'[^0-9A-Za-z가-힣._-]+', '_', Path(name).name)


def _sync_source_key(src):
    """Return a stable POSIX-style path relative to webhard_sync."""
    try:
        return src.resolve().relative_to(WEBHARD_SYNC_DIR.resolve()).as_posix()
    except Exception:
        return src.name


def _apply_automatic_bonus_matches(source_id, results, refresh_items=True):
    """Persist direct webhard_sync source paths; no duplicate PDF copy is created."""
    source_id = _normalize_webhard_rel(source_id)
    if not source_id:
        return 0
    automatic = [r for r in results if r.get('code') and not r.get('needs_manual')]
    if not automatic:
        return 0
    data = load_bonus_matches(mode='ocr')
    manual_overrides = _load_manual_overrides(mode='ocr')
    saved = 0
    for r in automatic:
        code = clean_code(r['code'])
        if not code or code in manual_overrides:
            continue
        data[code] = {'file': source_id, 'source': source_id, 'page': int(r['page']), 'source_type':'auto'}
        saved += 1
    if saved:
        save_bonus_matches(data,mode='ocr')
        if refresh_items:
            load_items(force=True)
    return saved


def _set_scan_status(**kwargs):
    with _SCAN_STATUS_LOCK:
        _SCAN_STATUS.update(kwargs)


def get_scan_status():
    with _SCAN_STATUS_LOCK:
        return dict(_SCAN_STATUS)


def _run_scan_job(force=False, retry_manual=False, source='자동'):
    """Run one complete Webhard scan outside Flask request threads."""
    if not _SCAN_LOCK.acquire(blocking=False):
        return False
    try:
        _SCAN_CANCEL.clear()
        _set_scan_status(
            running=True, mode=('미매칭 OCR 재분석' if retry_manual else source),
            started_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            finished_at='', message='PDF 확인 및 매칭 중', error='', processed=0, cancel_requested=False
        )
        state = scan_webhard_folder(force=force, retry_manual=retry_manual)
        _raise_if_scan_cancelled()
        _set_scan_status(
            running=False, finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            message='분석 완료', processed=len(state), error='', cancel_requested=False
        )
    except ScanCancelled:
        _set_scan_status(running=False, finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'), message='OCR 매칭 중단 완료', error='', cancel_requested=False)
    except Exception as exc:
        _set_scan_status(
            running=False, finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            message='분석 오류', error=f'{type(exc).__name__}: {exc}'[:300]
        )
    finally:
        _SCAN_LOCK.release()
    return True


def start_scan_job(force=False, retry_manual=False, source='자동'):
    if get_scan_status().get('running'):
        return False
    threading.Thread(
        target=_run_scan_job,
        kwargs={'force': force, 'retry_manual': retry_manual, 'source': source},
        daemon=True
    ).start()
    return True


def scan_webhard_folder(force=False, retry_manual=False):
    """Analyze PDFs in webhard_sync in place; no bonus_pdfs duplicate is made."""
    state = load_sync_state()
    changed = False
    now = time.time()
    items = load_items(force=False)[0]
    ocr_ok, ocr_message = ocr_engine_status()
    excel_sig = str(CURRENT_XLSX.stat().st_mtime_ns) if CURRENT_XLSX.exists() else 'no-excel'
    analysis_context = f'{OCR_CACHE_VERSION}|{MATCH_ALGORITHM_VERSION}|ocr={int(ocr_ok)}|excel={excel_sig}'
    try:
        pdfs = sorted(
            (p for p in WEBHARD_SYNC_DIR.rglob('*') if p.is_file() and p.suffix.lower() == '.pdf'),
            key=lambda p: (p.stat().st_mtime_ns, _sync_source_key(p))
        )
    except OSError:
        pdfs = []

    current_keys = set()
    for src in pdfs:
        _raise_if_scan_cancelled()
        try:
            st = src.stat()
        except OSError:
            continue
        key = _sync_source_key(src)
        current_keys.add(key)
        rec = state.get(key, {})
        sig = f'{st.st_size}:{st.st_mtime_ns}'
        if rec.get('sig') != sig:
            rec = {
                'sig': sig, 'first_seen': now, 'status': 'waiting', 'size': st.st_size,
                'relative_path': key, 'source_file': key
            }
            state[key] = rec
            changed = True
            if not force:
                continue

        if not force and now - float(rec.get('first_seen', now)) < 3:
            continue

        unresolved = rec.get('status') in ('manual_required', 'error', 'ready', 'waiting')
        context_changed = rec.get('analysis_context') != analysis_context
        should_analyze = (
            force or rec.get('analyzed_sig') != sig
            or (unresolved and (retry_manual or context_changed))
        )
        if should_analyze:
            try:
                _raise_if_scan_cancelled()
                force_page_ocr = bool(unresolved and retry_manual)
                results = match_pdf_pages(src, items, force_ocr=force_page_ocr)
                auto_count = _apply_automatic_bonus_matches(key, results)
                manual_count = sum(1 for r in results if r.get('needs_manual') or not r.get('code'))
                status = 'auto_matched' if results and manual_count == 0 and auto_count == len(results) else 'manual_required'
                rec.update({
                    'status': status, 'source_file': key,
                    'detected_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'analyzed_sig': sig, 'auto_count': auto_count,
                    'manual_count': manual_count,
                    'page_count': len({int(r.get('page', 0)) for r in results}) if results else 0,
                    'relative_path': key, 'analysis_context': analysis_context,
                    'ocr_status': ocr_message, 'error': ''
                })
                rec.pop('bonus_file', None)
            except ScanCancelled:
                raise
            except Exception as e:
                rec.update({
                    'status': 'error', 'source_file': key,
                    'detected_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'relative_path': key, 'analysis_context': analysis_context,
                    'ocr_status': ocr_message, 'error': str(e)[:300]
                })
                rec.pop('bonus_file', None)
        elif rec.get('status') == 'waiting':
            rec['status'] = 'ready'
        state[key] = rec
        changed = True

    for key in list(state):
        if key not in current_keys:
            state[key]['source_missing'] = True
        else:
            state[key].pop('source_missing', None)

    if changed:
        save_sync_state(state)
    return state


def _reset_sync_records(target_files=None):
    reset_all = target_files is None
    targets = {_normalize_webhard_rel(x) for x in (target_files or []) if _normalize_webhard_rel(x)}
    state = load_sync_state()
    changed = False
    for key, rec in state.items():
        source_id = _normalize_webhard_rel(rec.get('relative_path') or rec.get('source_file') or key)
        if not reset_all and source_id not in targets:
            continue
        rec['status'] = 'ready'
        rec['auto_count'] = 0
        rec['manual_count'] = 0
        rec.pop('analysis_context', None)
        rec.pop('analyzed_sig', None)
        changed = True
    if changed:
        save_sync_state(state)


def reset_bonus_mappings(code=None, filename=None, reset_sync=True, preserve_manual=False, mode='ocr'):
    mode=_normalize_bonus_mode(mode)
    data = dict(load_bonus_matches(mode=mode))
    code = clean_code(code) if code else ''
    filename = _normalize_webhard_rel(filename) if filename else ''
    removed_files = set()
    removed_codes = set()
    next_data = {}
    removed = 0
    for saved_code, rec in data.items():
        source_id = _bonus_source_id(rec)
        should_remove = bool(
            (code and clean_code(saved_code) == code) or
            (filename and source_id == filename) or
            (not code and not filename)
        )
        if should_remove:
            removed += 1
            removed_codes.add(clean_code(saved_code))
            if source_id:
                removed_files.add(source_id)
        else:
            next_data[saved_code] = rec
    if preserve_manual:
        manual=_load_manual_overrides(mode=mode)
        for mcode,mrec in manual.items():
            if isinstance(mrec,dict) and _bonus_source_id(mrec):
                rec=dict(mrec); rec['source_type']='manual'; next_data[clean_code(mcode)]=rec
    save_bonus_matches(next_data,mode=mode)
    if preserve_manual:
        # Keep manual learning/overrides during an automatic re-match.
        pass
    else:
        _remove_ocr_learning(removed_codes, clear_all=(not code and not filename))
        _remove_manual_overrides(removed_codes, filename=filename, clear_all=(not code and not filename), mode=mode)
    load_items(force=True)
    if reset_sync:
        if code or filename:
            if removed_files:
                _reset_sync_records(removed_files)
        else:
            _reset_sync_records(None)
    return removed


def _run_full_rematch_job():
    """Clear mappings and re-evaluate every PDF directly under webhard_sync."""
    if not _SCAN_LOCK.acquire(blocking=False):
        return False
    try:
        _SCAN_CANCEL.clear()
        _set_scan_status(
            running=True, mode='전 품번 재매칭',
            started_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            finished_at='', message='기존 매칭 초기화 중', error='', processed=0, cancel_requested=False
        )
        reset_bonus_mappings(reset_sync=True, preserve_manual=True)
        items = load_items(force=False)[0]
        state = load_sync_state()
        ocr_ok, _ = ocr_engine_status()
        excel_sig = str(CURRENT_XLSX.stat().st_mtime_ns) if CURRENT_XLSX.exists() else 'no-excel'
        analysis_context = f'{OCR_CACHE_VERSION}|{MATCH_ALGORITHM_VERSION}|ocr={int(ocr_ok)}|excel={excel_sig}'
        pdfs = sorted(
            (p for p in WEBHARD_SYNC_DIR.rglob('*') if p.is_file() and p.suffix.lower() == '.pdf'),
            key=lambda p: (p.stat().st_mtime_ns, _sync_source_key(p))
        )
        total_auto = 0
        total_manual = 0
        for idx, pdf in enumerate(pdfs, start=1):
            _raise_if_scan_cancelled()
            source_id = _sync_source_key(pdf)
            _set_scan_status(message=f'{idx}/{len(pdfs)} 분석 중: {source_id[:80]}', processed=idx-1)
            rec = state.setdefault(source_id, {'relative_path': source_id, 'source_file': source_id})
            try:
                results = match_pdf_pages(pdf, items, force_ocr=False)
                auto_count = _apply_automatic_bonus_matches(source_id, results, refresh_items=False)
                manual_count = sum(1 for r in results if r.get('needs_manual') or not r.get('code'))
                total_auto += auto_count
                total_manual += manual_count
                rec.update({
                    'status': 'auto_matched' if results and manual_count == 0 else 'manual_required',
                    'auto_count': auto_count, 'manual_count': manual_count,
                    'page_count': len({int(r.get('page', 0)) for r in results}) if results else 0,
                    'analysis_context': analysis_context,
                    'detected_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'relative_path': source_id, 'source_file': source_id,
                })
                rec.pop('bonus_file', None)
            except ScanCancelled:
                raise
            except Exception as exc:
                rec.update({
                    'status': 'error', 'error': f'{type(exc).__name__}: {exc}'[:300],
                    'relative_path': source_id, 'source_file': source_id
                })
            state[source_id] = rec
        save_sync_state(state)
        load_items(force=True)
        _set_scan_status(
            running=False, finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            message=f'전 품번 재매칭 완료 · 자동 {total_auto}개 · 수동확인 {total_manual}개',
            processed=len(pdfs), error=''
        )
    except ScanCancelled:
        _set_scan_status(running=False, finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'), message='OCR 전 품번 재매칭 중단 완료', error='', cancel_requested=False)
    except Exception as exc:
        _set_scan_status(
            running=False, finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            message='전 품번 재매칭 오류', error=f'{type(exc).__name__}: {exc}'[:300], cancel_requested=False
        )
    finally:
        _SCAN_LOCK.release()
    return True


def start_full_rematch_job():
    if get_scan_status().get('running'):
        return False
    threading.Thread(target=_run_full_rematch_job, daemon=True).start()
    return True

def webhard_watch_loop():
    # Legacy scheduler retained for compatibility but not started in V4.4.27.
    # A longer interval prevents 7 GB folder rescans from competing with previews.
    time.sleep(3)
    while True:
        try:
            start_scan_job(source='자동 새 파일 확인')
        except Exception as e:
            print('WEBHARD WATCH ERROR:', e, flush=True)
        time.sleep(30)


SYNC_HTML = r"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>웹하드 다운로드 폴더</title><style>body{font-family:Malgun Gothic,Arial;margin:0;background:#f3f5f7}.wrap{max-width:1200px;margin:auto;padding:24px}.panel{background:#fff;padding:18px;border-radius:12px;margin-bottom:16px}.btn{background:#102c73;color:#fff;border:0;border-radius:7px;padding:10px 15px;text-decoration:none;font-weight:700;cursor:pointer;display:inline-block}.green{background:#26734d}.gray{background:#555}.red{background:#c51f2c}.muted{color:#666}code{background:#f0f2f5;padding:3px 7px;border-radius:5px}table{width:100%;border-collapse:collapse}th,td{padding:10px;border-bottom:1px solid #ddd;text-align:left}th{background:#edf1f7}.ready{color:#15733a;font-weight:700}.wait{color:#b66a00;font-weight:700}.status{padding:12px;border-radius:8px;background:#eef3fb}.spin{display:inline-block;width:14px;height:14px;border:2px solid #aaa;border-top-color:#102c73;border-radius:50%;animation:r 1s linear infinite}@keyframes r{to{transform:rotate(360deg)}}</style></head><body><div class="wrap"><div class="panel"><a class="btn gray" href="/">← 메인 화면</a> <a class="btn green" href="/sync/open-folder">다운로드 폴더 열기</a> <a class="btn" href="/sync/start?mode=new">신규 파일 OCR 분석</a> <a class="btn green" href="/sync/start?mode=retry">기존 미매칭 OCR 재분석</a> <button id="ocrStopBtn" class="btn red" type="button" onclick="stopMatching()" {{'' if scan.running else 'disabled'}}>OCR/AI 매칭 중단</button><h2>웹하드 반자동 다운로드 폴더</h2><p><b>V4.4.27부터 기존 OCR 자동 스캔/자동 새로고침은 꺼져 있습니다.</b> 필요한 경우 위 분석 버튼을 직접 눌러 실행합니다. 작업 상태만 아래에서 갱신되며 페이지 전체는 새로고침하지 않습니다.</p><p><code>{{folder}}</code></p><div class="status"><span id="spin" class="spin" style="{{'' if scan.running else 'display:none'}}"></span> <b id="scanMode">{{scan.mode or '대기'}}</b> · <span id="scanMessage">{{scan.message}}</span><br><span id="scanError" style="color:#c00">{{scan.error or ''}}</span><div id="scanTimes" class="muted">{% if scan.started_at %}시작: {{scan.started_at}}{% if scan.finished_at %} · 완료: {{scan.finished_at}}{% endif %} · 처리: {{scan.processed}}{% endif %}</div></div></div><div class="panel"><h3>감지된 PDF</h3><table><thead><tr><th>폴더/파일명</th><th>상태</th><th>자동 연결</th><th>감지 시각</th><th>작업</th></tr></thead><tbody>{% for name,rec in rows %}<tr><td>{{rec.relative_path or name}}</td><td class="{{'ready' if rec.status=='auto_matched' else 'wait'}}">{% if rec.status=='auto_matched' %}자동 매칭·대체 완료{% elif rec.status=='manual_required' %}불일치 - 수동 확인 필요{% elif rec.status=='error' %}분석 오류{% elif rec.status=='ready' %}분석 대기{% else %}다운로드 완료 확인 중{% endif %}</td><td>{{rec.auto_count or 0}}개</td><td>{{rec.detected_at or '-'}}</td><td>{% if rec.status in ['manual_required','error','ready'] and rec.relative_path %}<a class="btn green" href="/sync/analyze/{{rec.relative_path}}">수동 확인</a>{% elif rec.status=='auto_matched' and rec.relative_path %}<a class="btn green" href="/sync/analyze/{{rec.relative_path}}">확인/수정</a>{% endif %}</td></tr>{% else %}<tr><td colspan="5">아직 PDF가 없습니다.</td></tr>{% endfor %}</tbody></table></div></div><script>
async function refreshStatus(){try{const r=await fetch('/api/scan-status',{cache:'no-store'});const d=await r.json();document.getElementById('scanMode').textContent=d.mode||'대기';document.getElementById('scanMessage').textContent=d.message||'';document.getElementById('scanError').textContent=d.error||'';document.getElementById('ocrStopBtn').disabled=!d.running;document.getElementById('spin').style.display=d.running?'inline-block':'none';let t='';if(d.started_at){t='시작: '+d.started_at+(d.finished_at?' · 완료: '+d.finished_at:'')+' · 처리: '+(d.processed||0);}document.getElementById('scanTimes').textContent=t;}catch(e){}}
async function stopMatching(){if(!confirm('현재 진행 중인 OCR/AI 매칭을 중단할까요?'))return;try{await fetch('/api/scan-stop',{method:'POST'});refreshStatus();}catch(e){}}
setInterval(refreshStatus,1500);refreshStatus();
</script></body></html>"""

@app.get('/sync')
def sync_page():
    state = load_sync_state()
    rows = sorted(state.items(), key=lambda kv: kv[1].get('detected_at',''), reverse=True)
    return render_template_string(
        SYNC_HTML, folder=str(WEBHARD_SYNC_DIR), rows=rows, scan=get_scan_status()
    )

@app.get('/sync/start')
def sync_start():
    mode = request.args.get('mode', 'new')
    start_scan_job(force=True, retry_manual=(mode == 'retry'), source='신규 파일 분석')
    return redirect('/sync')

@app.get('/sync/open-folder')
def sync_open_folder():
    try:
        if os.name == 'nt':
            os.startfile(str(WEBHARD_SYNC_DIR))
        else:
            subprocess.Popen(['xdg-open', str(WEBHARD_SYNC_DIR)])
    except Exception:
        pass
    return redirect('/sync')

@app.get('/sync/analyze/<path:filename>')
def sync_analyze(filename):
    source_id = _normalize_webhard_rel(filename)
    path = _resolve_webhard_pdf(source_id)
    if not path:
        return redirect('/sync')
    _,items,_,_=items_map()
    results = match_pdf_pages(path, items, force_ocr=False)
    return render_template_string(BONUS_HTML, results=results, filename=source_id, items=items, matches=load_bonus_matches(mode='ocr'), ocr_status=ocr_engine_status()[1], ocr_threshold=round(OCR_AUTO_THRESHOLD*100), ocr_margin=round(OCR_MARGIN_THRESHOLD*100))

BONUS_HTML = r"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>번외 PDF 자동매칭</title><style>body{font-family:Malgun Gothic,Arial;margin:0;background:#f3f5f7}.wrap{max-width:1480px;margin:auto;padding:24px}.panel{background:white;padding:18px;border-radius:12px;margin-bottom:16px}.btn{background:#102c73;color:white;border:0;border-radius:7px;padding:10px 15px;text-decoration:none;font-weight:700;cursor:pointer;display:inline-block}.green{background:#26734d}.red{background:#d10b18}.gray{background:#555}.orange{background:#a85a00}.inline{display:inline-block;margin:3px}table{width:100%;border-collapse:collapse;font-size:13px}th,td{border-bottom:1px solid #ddd;padding:9px;text-align:left;vertical-align:top}th{background:#edf1f7}select{width:100%;min-width:300px;padding:7px}.score-high{color:#16753d;font-weight:700}.score-low{color:#c00;font-weight:700}.muted{color:#777}.auto{color:#16753d;font-weight:700}.manual{color:#c00;font-weight:700}.rule{background:#eef7f1;padding:12px;border-radius:8px;line-height:1.7}.danger{background:#fff1f1;border:1px solid #f0b7b7;padding:12px;border-radius:8px;margin-top:12px}.suggest{line-height:1.65;margin:4px 0;padding-left:20px}.small{font-size:12px}.page-thumb{display:block;width:180px;max-height:255px;object-fit:contain;background:#eee;border:1px solid #ccc;border-radius:5px}</style></head><body><div class="wrap"><div class="panel"><a class="btn" href="/">← 메인 화면</a> <a class="btn gray" href="/sync">웹하드 상태</a> <a class="btn orange" href="/bonus-ai">AI 페이지 매칭 TEST</a><h2>일반 OCR 번외 PDF 매칭 · V4.4.27</h2><p><b>OCR 상태:</b> {{ocr_status}} · <b>자동확정:</b> 고속 후보검색 + 폴더/제품라인 충돌차단 + 다중품번 멤버십</p><div class="rule"><b>V4.4.27 고속 하이브리드 + 매뉴얼 품종코드 매칭</b><br>① 파일명 품번은 전부 멤버십 후보로 사용하고 첫 품번 자동선택 금지 → ② 품번 없는 PDF는 RapidFuzz 상위 후보만 비교해 속도 개선 → ③ 성별 하드게이트 + 품번의 매뉴얼 품종대 코드(J/C/K/V/L/W/T/E/O/P/D/R/U/A) + 페이지의 품종소 문구를 교차검증하여 다른 품종대는 자동차단 → ④ webhard_sync의 폴더명까지 제품라인 증거로 사용(쿨에어↔핫스터프 같은 충돌은 자동차단) → ⑤ OCR 캐시는 Tesseract 상태확인보다 먼저 읽어 재매칭 속도 개선 → ⑥ 한 페이지 다중상품/다중품번 유지 → ⑦ 자동매칭도 '수동 수정'으로 고정 가능하며 다음 재매칭에서 덮어쓰지 않음</div><p class="muted">파일명에 품번이 여러 개 있어도 첫 품번이나 파일명 순서로 자동확정하지 않습니다. ‘전 품번 재매칭’은 기존 품번 연결만 다시 판정하며 PDF/OCR 캐시는 유지합니다.</p><form action="/bonus/analyze" method="post" enctype="multipart/form-data"><input type="file" name="pdf" accept=".pdf" required> <button class="btn green">PDF 분석</button></form><div class="danger"><form class="inline" action="/bonus/reset-all" method="post" onsubmit="return confirm('저장된 모든 번외 품번 연결을 초기화할까요? PDF와 OCR 글자 캐시는 유지되고 수동학습 연결은 함께 초기화됩니다.')"><button class="btn red">전체 매칭 초기화</button></form><form class="inline" action="/bonus/rematch-all" method="post" onsubmit="return confirm('기존 연결을 모두 풀고 모든 번외 PDF를 다시 매칭할까요? 작업은 백그라운드에서 실행됩니다.')"><button class="btn orange">전 품번 재매칭</button></form>{% if filename %}<form class="inline" action="/bonus/reset-file" method="post" onsubmit="return confirm('현재 PDF에 저장된 연결만 초기화할까요?')"><input type="hidden" name="filename" value="{{filename}}"><button class="btn gray">현재 PDF 매칭 초기화</button></form>{% endif %}</div></div>{% if results %}<div class="panel"><form action="/bonus/save" method="post"><input type="hidden" name="filename" value="{{filename}}"><table><thead><tr><th>페이지</th><th>페이지 미리보기</th><th>인식 내용</th><th>판정 방식</th><th>추천 후보</th><th>상태</th><th>최종 연결</th></tr></thead><tbody>{% for r in results %}<tr><td><b>{{r.page_label}}</b></td><td><a href="{{url_for('bonus_page_preview', filename=filename, page=r.page)}}" target="_blank"><img class="page-thumb" loading="lazy" src="{{url_for('bonus_page_preview', filename=filename, page=r.page)}}"></a></td><td>{{r.text or 'PDF/OCR 인식 내용 없음'}}</td><td>{{r.method}}<br><span class="small muted">선택 점수 {{r.score}}% · 후보 차이 {{r.margin or 0}}%p</span></td><td>{% if r.suggestions %}<ol class="suggest">{% for s in r.suggestions %}<li><b>{{s.code}}</b> · {{s.title}}{% if s.gender %} · {{s.gender}}{% endif %}{% if s.category %} · 품종 {{s.category}}{% endif %} <span class="{{'score-high' if s.score>=ocr_threshold else 'score-low'}}">{{s.score}}%</span></li>{% endfor %}</ol>{% else %}-{% endif %}</td><td class="{{'manual' if r.needs_manual else 'auto'}}">{{'수동 확인 필요' if r.needs_manual else '자동배정 완료'}}</td><td><input type="hidden" name="page" value="{{r.page}}"><input type="hidden" name="ocr_text" value="{{r.text|e}}"><select name="code"><option value="">연결하지 않음</option>{% for i in items %}<option value="{{i.code}}" {{'selected' if i.code==r.code else ''}}>{{i.code}} | {{i.title_ko}}</option>{% endfor %}</select></td></tr>{% endfor %}</tbody></table><p><button class="btn red">확인한 매칭 저장</button></p></form></div>{% endif %}<div class="panel"><h3>현재 저장된 번외 매칭 · {{matches|length}}개</h3><table><tr><th>품번</th><th>PDF</th><th>페이지</th><th>페이지 미리보기</th><th>상태/변경</th></tr>{% for code,rec in matches.items() %}<tr><td><b>{{code}}</b></td><td>{{rec.file}}</td><td>{{rec.page+1}}</td><td><a href="{{url_for('bonus_page_preview', filename=rec.file, page=rec.page)}}" target="_blank"><img class="page-thumb" loading="lazy" src="{{url_for('bonus_page_preview', filename=rec.file, page=rec.page)}}"></a></td><td><div style="margin-bottom:7px"><b>{{'수동고정' if rec.source_type=='manual' else '자동매칭'}}</b></div><a class="btn green" href="/bonus/edit-code/{{code}}">수동 수정</a> <form class="inline" action="/bonus/reset-code" method="post" onsubmit="return confirm('{{code}} 연결을 해제할까요?')"><input type="hidden" name="code" value="{{code}}"><button class="btn gray">초기화</button></form></td></tr>{% else %}<tr><td colspan="5">저장된 번외 매칭이 없습니다.</td></tr>{% endfor %}</table></div></div></body></html>"""

@app.get('/bonus/page-preview/<path:filename>/<int:page>')
def bonus_page_preview(filename, page):
    source_id = _normalize_webhard_rel(filename)
    pdf_path = _resolve_webhard_pdf(source_id or filename)
    if not pdf_path:
        return ('not found', 404)
    try:
        st = pdf_path.stat()
        key = hashlib.sha1(f'{pdf_path.resolve()}|{st.st_size}|{st.st_mtime_ns}|{page}|thumb-v4.4.27'.encode('utf-8')).hexdigest()[:24]
        cache_path = CACHE_DIR / f'bonus_page_{key}.jpg'
        if not cache_path.exists():
            with fitz.open(str(pdf_path)) as doc:
                if page < 0 or page >= doc.page_count:
                    return ('page not found', 404)
                p = doc.load_page(page)
                pix = p.get_pixmap(matrix=fitz.Matrix(1.15, 1.15), alpha=False)
                im = Image.frombytes('RGB', (pix.width, pix.height), pix.samples)
                if im.width > 420:
                    nh = round(im.height * 420 / im.width)
                    im = im.resize((420, nh), Image.Resampling.LANCZOS)
                im.save(cache_path, 'JPEG', quality=82, optimize=True, progressive=True)
        response = send_from_directory(CACHE_DIR, cache_path.name, mimetype='image/jpeg')
        response.headers['Cache-Control'] = 'public, max-age=31536000, immutable'
        return response
    except Exception as exc:
        return (f'preview error: {exc}', 500)


@app.get('/bonus')
def bonus_page():
    _,items,_,_=items_map()
    return render_template_string(BONUS_HTML, results=None, items=items, matches=load_bonus_matches(mode='ocr'), ocr_status=ocr_engine_status()[1], ocr_threshold=round(OCR_AUTO_THRESHOLD*100), ocr_margin=round(OCR_MARGIN_THRESHOLD*100))

@app.post('/bonus/analyze')
def bonus_analyze():
    f = request.files.get('pdf')
    if not f or not f.filename:
        return redirect('/bonus')
    safe = safe_filename(f.filename)
    upload_dir = WEBHARD_SYNC_DIR / '_manual_uploads'
    upload_dir.mkdir(parents=True, exist_ok=True)
    path = upload_dir / safe
    if path.exists():
        path = upload_dir / f'{path.stem}_{int(time.time())}{path.suffix}'
    f.save(path)
    source_id = _sync_source_key(path)
    _,items,_,_=items_map()
    results = match_pdf_pages(path,items)
    return render_template_string(BONUS_HTML,results=results,filename=source_id,items=items,matches=load_bonus_matches(mode='ocr'),ocr_status=ocr_engine_status()[1], ocr_threshold=round(OCR_AUTO_THRESHOLD*100), ocr_margin=round(OCR_MARGIN_THRESHOLD*100))

@app.post('/bonus/save')
def bonus_save():
    filename = _normalize_webhard_rel(request.form.get('filename',''))
    pages = request.form.getlist('page')
    codes = request.form.getlist('code')
    ocr_texts = request.form.getlist('ocr_text')
    data = {k:v for k,v in load_bonus_matches(mode='ocr').items() if _bonus_source_id(v) != filename}
    for idx,(page,code) in enumerate(zip(pages,codes)):
        code=clean_code(code)
        if code and filename:
            data[code]={'file':filename,'source':filename,'page':int(page),'source_type':'manual'}
            _set_manual_override(code, filename, int(page), mode='ocr')
            if idx < len(ocr_texts):
                _learn_ocr_mapping(ocr_texts[idx], code)
    save_bonus_matches(data,mode='ocr')
    load_items(force=True)
    return redirect('/bonus')


def _manual_pdf_candidates(code, items, limit=18):
    code=clean_code(code); item=next((i for i in items if clean_code(i.get('code'))==code),None)
    if not item: return []
    rows=[]; cache=_load_ocr_cache()
    for pdf in WEBHARD_SYNC_DIR.rglob('*.pdf'):
        try:
            source_id=_sync_source_key(pdf); filename_codes=extract_filename_codes(pdf.name,items)
            source_desc=_source_description(pdf,filename_codes)
            exact=code in {clean_code(x) for x in filename_codes}
            best_page=0; best=max(_title_match_score(source_desc,item),0.0)
            with fitz.open(str(pdf)) as doc:
                for pno in range(doc.page_count):
                    key=_ocr_cache_key(pdf,pno); rec=cache.get(key) if isinstance(cache,dict) else None
                    txt=''
                    if isinstance(rec,dict):
                        txt=str(rec.get('text') or '')
                        if not txt and isinstance(rec.get('regions'),dict): txt=' '.join(str(v or '') for v in rec['regions'].values())
                    s=_title_match_score(txt,item) if txt else 0.0
                    if s>best: best=s; best_page=pno
                anchor,conflict,_,_=_anchor_relation(source_desc,item)
                score=best + (0.60 if exact else 0) + (0.15 if anchor else 0) - (0.35 if conflict and not exact else 0)
                if exact or score>=0.38:
                    rows.append({'file':source_id,'page':best_page,'page_label':best_page+1,'score':round(max(0,min(1.5,score))*100),'exact':exact,'anchor':anchor,'conflict':conflict})
        except Exception:
            continue
    rows.sort(key=lambda r:(-bool(r['exact']),bool(r['conflict']),-r['score'],r['file']))
    return rows[:limit]


EDIT_MATCH_HTML=r"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>번외 매칭 수동 수정</title><style>body{font-family:Malgun Gothic,Arial;margin:0;background:#f3f5f7}.wrap{max-width:1200px;margin:auto;padding:24px}.panel{background:#fff;padding:18px;border-radius:12px;margin-bottom:16px}.btn{background:#102c73;color:#fff;border:0;border-radius:7px;padding:9px 13px;text-decoration:none;font-weight:700;cursor:pointer}.green{background:#26734d}.gray{background:#555}table{width:100%;border-collapse:collapse}th,td{padding:9px;border-bottom:1px solid #ddd;text-align:left;vertical-align:middle}th{background:#edf1f7}.thumb{width:120px;max-height:170px;object-fit:contain;border:1px solid #ccc;background:#eee}.muted{color:#666}.bad{color:#c00;font-weight:700}input{padding:9px;min-width:420px}</style></head><body><div class="wrap"><div class="panel"><a class="btn gray" href="/bonus">← 번외 매칭</a><h2>{{code}} · {{item.title_ko}} 수동 수정</h2>{% if current %}<p>현재: <b>{{current.file}}</b> / {{current.page+1}}페이지 · {{'수동고정' if current.source_type=='manual' else '자동매칭'}}</p><img class="thumb" src="{{url_for('bonus_page_preview',filename=current.file,page=current.page)}}">{% else %}<p class="muted">현재 연결 없음</p>{% endif %}</div><div class="panel"><h3>PDF 직접 선택</h3><p class="muted">추천에 원하는 PDF가 없어도 webhard_sync 안의 모든 PDF를 직접 지정할 수 있습니다. 페이지는 1부터 입력합니다.</p><form method="post" action="/bonus/edit-code-save"><input type="hidden" name="code" value="{{code}}"><input list="allpdfs" name="filename" placeholder="PDF 파일/폴더명 검색" required><datalist id="allpdfs">{% for f in all_pdfs %}<option value="{{f}}">{% endfor %}</datalist> <input style="min-width:70px;width:70px" type="number" name="page_display" min="1" value="1"> <button class="btn green">직접 고정</button></form></div><div class="panel"><h3>추천 PDF</h3><p class="muted">파일명 품번, 폴더/파일 제품라인, 저장된 OCR 상품명을 함께 사용한 추천입니다. 빨간 '라인충돌'은 자동으로 선택하지 않습니다.</p><table><tr><th>미리보기</th><th>PDF / 페이지</th><th>근거</th><th>변경</th></tr>{% for r in candidates %}<tr><td><img class="thumb" loading="lazy" src="{{url_for('bonus_page_preview',filename=r.file,page=r.page)}}"></td><td>{{r.file}}<br>{{r.page_label}}페이지</td><td>{{r.score}}점 {% if r.exact %}· 파일명 품번{% endif %}{% if r.anchor %} · 제품라인 일치{% endif %}{% if r.conflict %}<span class="bad"> · 라인충돌</span>{% endif %}</td><td><form method="post" action="/bonus/edit-code-save"><input type="hidden" name="code" value="{{code}}"><input type="hidden" name="filename" value="{{r.file}}"><input type="hidden" name="page" value="{{r.page}}"><button class="btn green">이 PDF로 고정</button></form></td></tr>{% else %}<tr><td colspan="4">추천 후보 없음</td></tr>{% endfor %}</table></div></div></body></html>"""


@app.get('/bonus/edit-code/<code>')
def bonus_edit_code(code):
    code=clean_code(code); _,items,_,_=items_map(); item=next((i for i in items if clean_code(i.get('code'))==code),None)
    if not item: return redirect('/bonus')
    current=load_bonus_matches(mode='ocr').get(code)
    candidates=_manual_pdf_candidates(code,items)
    all_pdfs=sorted(_sync_source_key(p) for p in WEBHARD_SYNC_DIR.rglob('*.pdf') if p.is_file())
    return render_template_string(EDIT_MATCH_HTML,code=code,item=item,current=current,candidates=candidates,all_pdfs=all_pdfs)


@app.post('/bonus/edit-code-save')
def bonus_edit_code_save():
    code=clean_code(request.form.get('code','')); filename=_normalize_webhard_rel(request.form.get('filename',''))
    try:
        if request.form.get('page_display'):
            page=max(0,int(request.form.get('page_display','1'))-1)
        else:
            page=max(0,int(request.form.get('page','0')))
    except Exception: page=0
    if code and filename and _resolve_webhard_pdf(filename):
        data=dict(load_bonus_matches(mode='ocr')); data[code]={'file':filename,'source':filename,'page':page,'source_type':'manual'}
        save_bonus_matches(data,mode='ocr'); _set_manual_override(code,filename,page,mode='ocr'); load_items(force=True)
    return redirect('/bonus')


@app.post('/bonus/reset-code')
def bonus_reset_code():
    reset_bonus_mappings(code=request.form.get('code', ''),mode='ocr')
    return redirect('/bonus')


@app.post('/bonus/reset-file')
def bonus_reset_file():
    reset_bonus_mappings(filename=request.form.get('filename', ''),mode='ocr')
    return redirect('/bonus')


@app.post('/bonus/reset-all')
def bonus_reset_all():
    reset_bonus_mappings(mode='ocr')
    return redirect('/bonus')


@app.post('/bonus/rematch-all')
def bonus_rematch_all():
    start_full_rematch_job()
    return redirect('/sync')

@app.get('/api/scan-status')
def api_scan_status():
    st=get_scan_status()
    try: st['ai_cache_count']=len(_load_ai_cache().get('pages',{}))
    except Exception: st['ai_cache_count']=0
    st['single_ready']=AI_SINGLE_RESULT_FILE.exists()
    try:
        review=_load_ai_review(); st['ai_review_count']=len(review.get('rows') or []); st['ai_review_status']=str(review.get('status') or '')
    except Exception:
        st['ai_review_count']=0; st['ai_review_status']=''
    return jsonify(st)

@app.post('/api/scan-stop')
def api_scan_stop():
    request_scan_stop()
    return jsonify({'ok':True,'status':get_scan_status()})

@app.get('/health')
def health():
    return {'status': 'ok'}

@app.route('/')
def index():
    mp,all_items,date_range,loaded=items_map(); q=request.args.get('q','').strip().upper()
    items=all_items
    if q: items=[i for i in items if q in i['code'] or q in i['title_ko'].upper()]
    queue_codes=load_generation_queue()
    queue_items=[mp[c] for c in queue_codes if c in mp]
    if len(queue_items)!=len(queue_codes): save_generation_queue([i['code'] for i in queue_items])
    generated=[p.name for p in sorted(OUTPUT_DIR.glob('*.pdf'),key=lambda p:p.stat().st_mtime,reverse=True)[:20]]
    init=''
    return render_template_string(HTML,items=items,queue_items=queue_items,date_range=date_range,loaded_name=loaded,q=q,normal_count=sum(not i['is_discount'] for i in items),sale_count=sum(i['is_discount'] for i in items),matched_count=sum(bool(i.get('bonus_available')) for i in items),missing_count=sum(not bool(i.get('bonus_available')) for i in items),generated=generated,initial_preview=init,missing_fonts=missing_required_fonts(),bonus_mode=get_bonus_match_mode(),ocr_match_count=len(load_bonus_matches(mode='ocr')),ai_match_count=len(load_bonus_matches(mode='ai')))

@app.post('/bonus/mode')
def bonus_mode_select():
    mode=set_bonus_match_mode(request.form.get('mode','ocr'))
    _set_scan_status(message=('AI 번외 매칭을 POP 생성에 적용합니다.' if mode=='ai' else '일반 OCR 번외 매칭을 POP 생성에 적용합니다.'))
    return redirect('/')


@app.post('/bonus-ai/rematch-main')
def bonus_ai_rematch_main():
    if not start_ai_full_rematch_job():
        _set_scan_status(message='AI 전체 재매칭 시작 보류',error='이미 다른 AI/OCR 매칭 작업이 실행 중입니다.')
    return redirect('/bonus-ai')


@app.post('/upload')
def upload():
    f=request.files.get('excel')
    if f and f.filename:
        f.save(CURRENT_XLSX); LAST_NAME.write_text(f.filename,encoding='utf-8'); load_items(force=True)
    return redirect('/')

@app.get('/api/item/<code>')
def api_item(code):
    mp,_,_,_=items_map(); i=mp.get(clean_code(code))
    if not i: return jsonify({})
    result=dict(i); result['preview_version']=item_preview_version(i)
    return jsonify(result)

@app.get('/api/visual-choice-required')
def visual_choice_required():
    # Backward-compatible endpoint. V4.4 has no E/F choice popup.
    return jsonify({'items': []})


@app.post('/api/visual-choice')
def visual_choice_save():
    code = clean_code(request.form.get('code',''))
    choice = request.form.get('choice','')
    if not set_carryover_visual_choice(code, choice):
        return jsonify({'ok': False, 'error': '선택을 저장할 수 없습니다.'}), 400
    return jsonify({'ok': True, 'code': code, 'choice': choice})

def _render_visual_preview(pathstr):
    """Render only a screen-sized A4 image; never create a print PDF for preview."""
    page_index = 0
    raw_path = str(pathstr or '')
    if '::page=' in raw_path:
        raw_path, page_text = raw_path.rsplit('::page=', 1)
        try: page_index = max(0, int(page_text))
        except Exception: page_index = 0
    p = Path(raw_path) if raw_path else TEMPLATE_DIR / 'NEW_ARRIVAL.pdf'
    if not p.exists(): p = TEMPLATE_DIR / 'NEW_ARRIVAL.pdf'
    w = round(A4_W_MM * PREVIEW_DPI / 25.4)
    h = round(A4_H_MM * PREVIEW_DPI / 25.4)
    canvas = Image.new('RGB', (w, h), 'white')
    try:
        if p.suffix.lower() == '.pdf':
            with fitz.open(str(p)) as doc:
                page = doc.load_page(min(page_index, max(0, doc.page_count - 1)))
                pix = page.get_pixmap(matrix=fitz.Matrix(PREVIEW_DPI/72, PREVIEW_DPI/72), alpha=False)
                im = Image.frombytes('RGB', (pix.width, pix.height), pix.samples)
        else:
            im = Image.open(p).convert('RGB')
        if im.size != canvas.size:
            im = im.resize(canvas.size, Image.Resampling.LANCZOS)
        canvas.paste(im, (0, 0))
    except Exception as exc:
        print('Preview visual error:', exc, flush=True)
    return canvas


def generate_fast_preview(item, path):
    scale = PREVIEW_DPI / DPI
    if item.get('visual_mode') in {'adult_small', 'clearance'}:
        a4 = render_custom_template_a4(item, PREVIEW_DPI)
    else:
        a4 = _render_visual_preview(item.get('visual'))
        bar = generate_bottom_bar(item)
        bar = bar.resize((a4.width, round(BAR_H_PX * scale)), Image.Resampling.LANCZOS)
        a4.paste(bar, (0, round(BAR_TOP_PX * scale)))
    top = round(CUT_TOP_PX * scale)
    pop_h = round(POP_H_PX * scale)
    pop = a4.crop((0, top, a4.width, min(a4.height, top + pop_h)))
    if pop.width > PREVIEW_MAX_WIDTH:
        nh = round(pop.height * PREVIEW_MAX_WIDTH / pop.width)
        pop = pop.resize((PREVIEW_MAX_WIDTH, nh), Image.Resampling.LANCZOS)
    pop.save(path, 'JPEG', quality=88, optimize=True, progressive=True)


@app.get('/preview/<code>')
def preview(code):
    mp,_,_,_=items_map(); i=mp.get(clean_code(code))
    if not i:return ('not found',404)
    version=item_preview_version(i)
    path=CACHE_DIR/f'preview_fast_{i["code"]}_{version}.jpg'
    if not path.exists():
        generate_fast_preview(i,path)
        for old in CACHE_DIR.glob(f'preview_fast_{i["code"]}_*.jpg'):
            if old != path:
                try: old.unlink()
                except OSError: pass
    response=send_from_directory(CACHE_DIR,path.name,mimetype='image/jpeg')
    response.headers['Cache-Control']='public, max-age=31536000, immutable'
    return response

def queue_payload():
    mp,_,_,_=items_map()
    codes=load_generation_queue()
    return [{'code':c,'title_ko':mp[c].get('title_ko','')} for c in codes if c in mp]

@app.post('/queue/add')
def queue_add():
    old=load_generation_queue(); incoming=request.form.getlist('codes')
    new=save_generation_queue(old+incoming)
    return jsonify({'added':len(new)-len(old),'items':queue_payload()})

@app.post('/queue/remove')
def queue_remove():
    remove={clean_code(x) for x in request.form.getlist('codes')}
    save_generation_queue([c for c in load_generation_queue() if c not in remove])
    return jsonify({'items':queue_payload()})

@app.post('/queue/clear')
def queue_clear():
    save_generation_queue([])
    return jsonify({'items':[]})

@app.post('/queue/generate')
def queue_generate():
    mp,_,_,_=items_map(); codes=load_generation_queue(); generated=[]; failed=[]
    for code in codes:
        item=mp.get(code)
        if not item:
            failed.append(code); continue
        try:
            generate_one(item,OUTPUT_DIR/f'POP_{item["code"]}.png'); generated.append(code)
        except Exception:
            failed.append(code)
    save_generation_queue(failed)
    return jsonify({'generated':len(generated),'failed':failed,'items':queue_payload()})

@app.post('/generate')
def generate():
    mp,items,_,_=items_map(); mode=request.form.get('mode'); codes=request.form.getlist('codes')
    targets=items if mode=='all' else [mp[c] for c in codes if c in mp]
    for i in targets: generate_one(i,OUTPUT_DIR/f'POP_{i["code"]}.png')
    return redirect('/')

@app.get('/output/<name>')
def output(name): return send_from_directory(OUTPUT_DIR,name,as_attachment=False)

def configured_port():
    try:
        return int(os.environ.get('TOPTEN_POP_PORT', '8080'))
    except Exception:
        return 8080

if __name__=='__main__':
    p = configured_port()
    PID_FILE.write_text(str(os.getpid()), encoding='ascii')
    # V4.4.27: legacy OCR auto watcher disabled. OCR runs only when the user starts it.
    print(f'READY http://127.0.0.1:{p}', flush=True)
    try:
        app.run('127.0.0.1', p, debug=False, threaded=True, use_reloader=False)
    finally:
        try:
            if PID_FILE.exists() and PID_FILE.read_text('ascii').strip() == str(os.getpid()):
                PID_FILE.unlink()
        except Exception:
            pass
