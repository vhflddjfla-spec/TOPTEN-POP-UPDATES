# -*- coding: utf-8 -*-
from pathlib import Path
from datetime import datetime
import json, os, shutil

ROOT=Path(__file__).resolve().parent
FONT_DIR=ROOT/'fonts'
DATA_DIR=ROOT/'data'
FONT_SPECS={
    'NanumBarunGothic':['NanumBarunGothic.otf','NanumBarunGothic.ttf'],
    'DINPro-Regular':['DINPro-Regular.otf','DINPro-Regular.ttf'],
    'DINPro-Medium':['DINPro-Medium.otf','DINPro-Medium.ttf'],
    'DINPro-Bold':['DINPro-Bold.otf','DINPro-Bold.ttf'],
}

def roots():
    out=[FONT_DIR,ROOT,Path('C:/Windows/Fonts'),Path.home()/'AppData/Local/Microsoft/Windows/Fonts',Path.home()/'Downloads',Path.home()/'Desktop']
    env=str(os.environ.get('TOPTEN_FONT_SOURCE') or '').strip()
    if env: out.insert(0,Path(env))
    try:
        for sib in sorted(ROOT.parent.glob('TOPTEN_POP_V*'),reverse=True):
            if sib.resolve()!=ROOT.resolve(): out.append(sib/'fonts')
    except Exception: pass
    return out

def find(names):
    wanted={n.lower() for n in names}
    for base in roots():
        for n in names:
            p=base/n
            if p.is_file(): return p
        if base in (Path.home()/'Downloads',Path.home()/'Desktop') and base.exists():
            try:
                for p in base.glob('*'):
                    if p.is_file() and p.name.lower() in wanted: return p
                    if p.is_dir():
                        for q in p.glob('*'):
                            if q.is_file() and q.name.lower() in wanted: return q
            except Exception: pass
    return None

def localize(label,names):
    FONT_DIR.mkdir(parents=True,exist_ok=True)
    src=find(names)
    if not src: return {'status':'MISSING','source':''}
    try:
        if src.parent.resolve()==FONT_DIR.resolve():
            return {'status':'OK_LOCAL','source':str(src)}
    except Exception: pass
    suffix=src.suffix.lower() if src.suffix.lower() in ('.otf','.ttf') else '.otf'
    dst=FONT_DIR/(label+suffix)
    try:
        if not dst.exists(): shutil.copy2(src,dst)
        return {'status':'COPIED' if dst.exists() else 'FOUND','source':str(src),'target':str(dst)}
    except Exception as exc:
        return {'status':'FOUND_COPY_FAILED','source':str(src),'error':str(exc)}

def main():
    result={k:localize(k,v) for k,v in FONT_SPECS.items()}
    result['updated_at']=datetime.now().isoformat(timespec='seconds')
    DATA_DIR.mkdir(parents=True,exist_ok=True)
    (DATA_DIR/'font_check_report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print('=== TOPTEN POP FONT CHECK ===')
    for k in FONT_SPECS:
        print(f'{k}: {result[k]["status"]}')
    if result['DINPro-Regular']['status']=='MISSING':
        print('\nDINPro-Regular가 PC에서 발견되지 않았습니다.')
        print('DINPro-Regular.otf 또는 .ttf를 Downloads/Desktop/fonts 중 한 곳에 둔 뒤 RUN.cmd를 다시 실행하면 자동 복사됩니다.')
    else:
        print('\nDINPro-Regular 자동 연결 확인 완료.')

if __name__=='__main__': main()
