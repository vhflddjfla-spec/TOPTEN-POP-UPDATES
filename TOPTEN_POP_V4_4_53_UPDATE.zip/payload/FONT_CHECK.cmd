@echo off
chcp 65001 >nul
cd /d "%~dp0"
if exist "runtime\python.exe" (
  "runtime\python.exe" font_check.py
) else (
  python font_check.py
)
echo.
pause
