@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title TOPTEN POP V4.2 UPDATE

echo ==================================================
echo TOPTEN POP V4.2 SAFE REMATCH UPDATE
echo ==================================================
echo.
echo Close TOPTEN POP and RUN.cmd before continuing.
echo Existing PDFs, Excel, mappings, OCR text cache and outputs are preserved.
echo.

set "TARGET=%~1"
if not defined TARGET set /p "TARGET=TOPTEN POP folder path: "
set "TARGET=%TARGET:"=%"
if not defined TARGET goto :badtarget
if not exist "%TARGET%" goto :badtarget

call :resolve_root
if not defined ROOTDIR goto :badtarget
call :find_python
if not defined PYEXE goto :pythonfail

set "BACKUP=%ROOTDIR%\update_backup_V4_2_%RANDOM%_%RANDOM%"
mkdir "%BACKUP%\app" >nul 2>&1
if exist "%ROOTDIR%\app\app.py" copy /y "%ROOTDIR%\app\app.py" "%BACKUP%\app\app.py" >nul
if exist "%ROOTDIR%\app.py" copy /y "%ROOTDIR%\app.py" "%BACKUP%\app.py" >nul
if exist "%ROOTDIR%\RUN.cmd" copy /y "%ROOTDIR%\RUN.cmd" "%BACKUP%\RUN.cmd" >nul
if exist "%ROOTDIR%\version.json" copy /y "%ROOTDIR%\version.json" "%BACKUP%\version.json" >nul

if not exist "%ROOTDIR%\app" mkdir "%ROOTDIR%\app" >nul 2>&1
copy /y "%~dp0payload\app\app.py" "%ROOTDIR%\app\app.py" >nul
if errorlevel 1 goto :copyfail
copy /y "%~dp0payload\RUN.cmd" "%ROOTDIR%\RUN.cmd" >nul
if errorlevel 1 goto :copyfail
copy /y "%~dp0payload\version.json" "%ROOTDIR%\version.json" >nul
if errorlevel 1 goto :copyfail

"%PYEXE%" -m py_compile "%ROOTDIR%\app\app.py" >nul 2>&1
if errorlevel 1 goto :syntaxfail

>"%ROOTDIR%\V4_2_UPDATE_COMPLETE.txt" echo TOPTEN POP V4.2.0 update completed.
>>"%ROOTDIR%\V4_2_UPDATE_COMPLETE.txt" echo Backup: %BACKUP%

echo.
echo ==================================================
echo V4.2 UPDATE COMPLETE
echo ==================================================
echo Target: %ROOTDIR%
echo Backup: %BACKUP%
echo.
echo Start the program with RUN.cmd in the target folder.
pause
exit /b 0

:resolve_root
set "ROOTDIR="
if exist "%TARGET%\app\app.py" set "ROOTDIR=%TARGET%"
if not defined ROOTDIR if exist "%TARGET%\app.py" set "ROOTDIR=%TARGET%"
if not defined ROOTDIR if exist "%TARGET%\RUN.cmd" set "ROOTDIR=%TARGET%"
if defined ROOTDIR exit /b 0
for /d %%D in ("%TARGET%\*") do (
  if not defined ROOTDIR if exist "%%~fD\app\app.py" set "ROOTDIR=%%~fD"
  if not defined ROOTDIR if exist "%%~fD\app.py" set "ROOTDIR=%%~fD"
  if not defined ROOTDIR if exist "%%~fD\RUN.cmd" set "ROOTDIR=%%~fD"
)
exit /b 0

:find_python
set "PYEXE="
for /f "delims=" %%P in ('where python 2^>nul') do if not defined PYEXE if exist "%%P" set "PYEXE=%%P"
if defined PYEXE exit /b 0
for %%P in (
 "%LocalAppData%\Programs\Python\Python313\python.exe"
 "%LocalAppData%\Programs\Python\Python312\python.exe"
 "%LocalAppData%\Programs\Python\Python311\python.exe"
 "C:\Program Files\Python313\python.exe"
 "C:\Program Files\Python312\python.exe"
 "C:\Program Files\Python311\python.exe"
) do if exist "%%~P" if not defined PYEXE set "PYEXE=%%~P"
exit /b 0

:badtarget
echo ERROR: TOPTEN POP program folder was not found.
echo Select the exact program folder or its parent folder.
goto :fail
:pythonfail
echo ERROR: Python was not found. Use the V4.2 unified installer instead.
goto :fail
:copyfail
echo ERROR: A file could not be copied. Close TOPTEN POP and RUN.cmd and retry.
echo Backup: %BACKUP%
goto :fail
:syntaxfail
echo ERROR: Python syntax verification failed. Restoring the previous app.py.
if exist "%BACKUP%\app\app.py" copy /y "%BACKUP%\app\app.py" "%ROOTDIR%\app\app.py" >nul
if exist "%BACKUP%\RUN.cmd" copy /y "%BACKUP%\RUN.cmd" "%ROOTDIR%\RUN.cmd" >nul
if exist "%BACKUP%\version.json" copy /y "%BACKUP%\version.json" "%ROOTDIR%\version.json" >nul
goto :fail
:fail
echo.
echo Update was not completed.
pause
exit /b 1
