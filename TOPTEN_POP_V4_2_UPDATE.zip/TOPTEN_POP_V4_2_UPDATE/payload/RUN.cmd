@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title TOPTEN POP V4.2 - KEEP THIS WINDOW OPEN
set "LOG=%CD%\run_log.txt"
set "PIDFILE=%CD%\data\server.pid"
>"%LOG%" echo TOPTEN POP V4.2 RUN LOG

call :find_python
if not defined PYEXE (
  echo Python was not found.
  echo Run INSTALL_OR_UPGRADE_TO_V4_2.cmd from the V4 patch folder.
  pause
  exit /b 1
)
if not exist "%CD%\app\app.py" (
  echo app\app.py is missing.
  pause
  exit /b 2
)

if exist "%PIDFILE%" (
  set /p OLDPID=<"%PIDFILE%"
  if defined OLDPID taskkill /F /PID !OLDPID! >nul 2>&1
  del /q "%PIDFILE%" >nul 2>&1
)

echo Python: %PYEXE%>>"%LOG%"
"%PYEXE%" -c "import sys; print(sys.executable); print(sys.version)" >>"%LOG%" 2>&1

for %%M in (flask openpyxl PIL fitz pytesseract) do (
  "%PYEXE%" -c "import %%M" >nul 2>&1
  if errorlevel 1 set "NEEDPKG=1"
)
if defined NEEDPKG (
  echo Installing missing Python packages...
  "%PYEXE%" -m pip install --disable-pip-version-check flask openpyxl pillow pymupdf pytesseract packaging >>"%LOG%" 2>&1
)

if exist "%CD%\ocr_tessdata\kor.traineddata" set "TESSDATA_PREFIX=%CD%\ocr_tessdata"
if exist "C:\Program Files\Tesseract-OCR\tesseract.exe" set "TESSERACT_CMD=C:\Program Files\Tesseract-OCR\tesseract.exe"
if exist "C:\Program Files (x86)\Tesseract-OCR\tesseract.exe" if not defined TESSERACT_CMD set "TESSERACT_CMD=C:\Program Files (x86)\Tesseract-OCR\tesseract.exe"
if defined TESSERACT_CMD echo Tesseract: %TESSERACT_CMD%>>"%LOG%"
if defined TESSDATA_PREFIX echo Tessdata: %TESSDATA_PREFIX%>>"%LOG%"

set "TOPTEN_POP_PORT=8080"
echo Starting TOPTEN POP V4.2...
start "TOPTEN POP V4.2 SERVER" /b "%PYEXE%" "%CD%\app\app.py" >>"%LOG%" 2>&1

set /a COUNT=0
:wait_health
powershell -NoProfile -Command "try { $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 http://127.0.0.1:8080/health; if($r.StatusCode -eq 200){exit 0}else{exit 1} } catch { exit 1 }"
if not errorlevel 1 goto ready
set /a COUNT+=1
if %COUNT% GEQ 45 goto failed
timeout /t 1 /nobreak >nul
goto wait_health

:ready
echo Server ready. Opening browser...
start "" http://127.0.0.1:8080
echo.
echo TOPTEN POP V4.2 is running at http://127.0.0.1:8080
echo Keep this window open. Press any key to stop this server.
pause >nul
call :stop_server
exit /b 0

:failed
echo.
echo START FAILED. See run_log.txt.
type "%LOG%"
call :stop_server
pause
exit /b 3

:stop_server
if exist "%PIDFILE%" (
  set /p SERVERPID=<"%PIDFILE%"
  if defined SERVERPID taskkill /F /PID !SERVERPID! >nul 2>&1
  del /q "%PIDFILE%" >nul 2>&1
)
exit /b 0

:find_python
set "PYEXE="
for /f "delims=" %%P in ('where python 2^>nul') do if not defined PYEXE if exist "%%P" set "PYEXE=%%P"
if defined PYEXE exit /b 0
for %%P in (
  "%LocalAppData%\Programs\Python\Python313\python.exe"
  "%LocalAppData%\Programs\Python\Python312\python.exe"
  "%LocalAppData%\Programs\Python\Python311\python.exe"
  "C:\Program Files\Python313\python.exe"
  "C:\Program Files\Python312\python.exe"
  "C:\Program Files\Python311\python.exe"
) do if exist "%%~P" if not defined PYEXE set "PYEXE=%%~P"
exit /b 0
