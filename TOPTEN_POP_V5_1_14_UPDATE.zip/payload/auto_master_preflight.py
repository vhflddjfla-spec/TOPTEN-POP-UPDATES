# -*- coding: utf-8 -*-
"""TOPTEN POP V5.1.14 central-price preflight.

Called by RUN.cmd BEFORE starting Flask. No business XLSX is changed unless
we validate the official central SHA256, validate XLSX structure, and create
an intact local backup. Preserves locally-consumed workflows for the same
central release by tracking installed release identity across launches.
"""
from __future__ import annotations
import datetime as dt
import hashlib
import json
import os
import re
import shutil
import socket
import stat
import sys
import tempfile
import time
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data'
CACHE=ROOT/'cache'
MASTER=DATA/'TOPTEN_가격정책_마스터.xlsx'
STATUS=DATA/'central_price_master_status.json'
PREFLIGHT_STATE=DATA/'price_master_preflight_state.json'
BACKUPS=DATA/'backups'/'central_price_master'
LOG=DATA/'logs'/'price_master_preflight.log'
MANIFEST_URL='https://raw.githubusercontent.com/vhflddjfla-spec/TOPTEN-POP-UPDATES/refs/heads/main/price_master.json'
MAX_BYTES=30*1024*1024


def note(msg):
    line=f"[{dt.datetime.now().isoformat(timespec='seconds')}] {msg}"
    print(line, flush=True)
    try:
        LOG.parent.mkdir(parents=True,exist_ok=True)
        with LOG.open('a',encoding='utf-8') as f:f.write(line+'\n')
    except OSError:pass


def read_json(path):
    try:
        v=json.loads(path.read_text('utf-8-sig'))
        return v if isinstance(v,dict) else {}
    except Exception:return {}


def write_json_atomic(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    candidate=path.with_suffix(path.suffix+'.new')
    candidate.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
    os.replace(candidate,path)


def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest().lower()


def online_get(url,limit,timeout=6):
    u=urllib.parse.urlparse(url)
    if u.scheme!='https' or u.hostname!='raw.githubusercontent.com' or not u.path.startswith('/vhflddjfla-spec/TOPTEN-POP-UPDATES/'):
        raise RuntimeError('Unexpected central repository URL; refusing download')
    req=urllib.request.Request(url,headers={'User-Agent':'TOPTEN-POP-preflight/5.1.14'})
    with urllib.request.urlopen(req,timeout=timeout) as response:data=response.read(limit+1)
    if len(data)>limit:raise RuntimeError('Central download size limit exceeded')
    return data


def xlsx_ok(path):
    with zipfile.ZipFile(path,'r') as z:
        names=set(z.namelist())
        if 'xl/workbook.xml' not in names or not any(x.startswith('xl/worksheets/sheet') and x.endswith('.xml') for x in names):
            raise RuntimeError('Central file is not a valid workbook structure')
        if z.testzip() is not None:raise RuntimeError('Central workbook failed CRC check')


def app_running():
    with socket.socket() as s:
        s.settimeout(0.25)
        return s.connect_ex(('127.0.0.1',8080))==0


def safe_existing_live():
    if not MASTER.is_file():return False
    try:
        xlsx_ok(MASTER)
        return True
    except Exception:return False


def status_success(central,local_hash):
    # Never infer "installed" from remote_version or a failed attempt.
    state=read_json(PREFLIGHT_STATE)
    if state.get('installed_sha256')==central and state.get('ok') is True and safe_existing_live():
        return True
    installed=read_json(STATUS)
    if installed.get('installed_sha256')==central and (installed.get('verified_local_sha256')==local_hash or local_hash==central):
        if safe_existing_live():return True
    return bool(local_hash==central and safe_existing_live())


def replace_verified(pending,expected):
    if not MASTER.exists():
        # Never bootstrap a missing live master from the cloud without admin review.
        raise RuntimeError('Operational master missing: protected, manual recovery required')
    original_sha=sha(MASTER)
    writable=bool(MASTER.stat().st_mode & stat.S_IWRITE)
    if original_sha==expected:return 'unchanged',original_sha
    BACKUPS.mkdir(parents=True,exist_ok=True)
    stamp=dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    backup=BACKUPS/('TOPTEN_가격정책_마스터_preflight_'+stamp+'.xlsx')
    shutil.copy2(MASTER,backup)
    if sha(backup)!=original_sha:
        raise RuntimeError('Backup did not match original; no replacement attempted')
    staging=DATA/('.topten_v514_'+expected[:16]+'.tmp.xlsx')
    try:
        shutil.copyfile(pending,staging)
        if sha(staging)!=expected:
            raise RuntimeError('Staging hash mismatch, keeping existing master')
        if not writable:
            # This was the essential successful offline-recovery step. Only
            # remove read-only after the central file & backup were verified.
            os.chmod(MASTER,MASTER.stat().st_mode|stat.S_IWRITE)
            note('Existing master read-only flag cleared after backup validation')
        try:
            last=None
            for attempt in range(4):
                try:
                    os.replace(staging,MASTER)
                    last=None
                    break
                except PermissionError as e:
                    last=e
                    time.sleep([0.12,0.30,0.60,0.0][attempt])
            if last is not None:raise last
        except Exception:
            # Restore original read-only state if original remains in place.
            if not writable and MASTER.exists():
                try:
                    if sha(MASTER)==original_sha:os.chmod(MASTER,MASTER.stat().st_mode & ~stat.S_IWRITE)
                except OSError:pass
            raise
        if sha(MASTER)!=expected:
            raise RuntimeError('Post-install SHA mismatch. STOP using this store and restore '+str(backup))
        note('Master replaced; verified backup='+str(backup))
        return 'installed',original_sha
    finally:
        try:staging.unlink(missing_ok=True)
        except OSError:pass


def run():
    note('V5.1.14 PRELAUNCH: verify price master while web server is stopped')
    if app_running():
        note('SKIP: existing web server still running; not touching workbook')
        return 2
    if not MASTER.exists():
        note('STOP: no operational master; never install bundled initial file here')
        return 3
    try:
        manifest=json.loads(online_get(MANIFEST_URL,128*1024).decode('utf-8-sig'))
        expected=str(manifest.get('sha256') or '').lower().strip()
        version=str(manifest.get('master_version') or '').strip()
        url=str(manifest.get('download_url') or '')
        if not re.fullmatch(r'[0-9a-f]{64}',expected) or not version or not url:
            raise RuntimeError('Invalid central manifest')
        # Validate URL even on a no-op path.
        u=urllib.parse.urlparse(url)
        if u.scheme!='https' or u.hostname!='raw.githubusercontent.com' or not u.path.startswith('/vhflddjfla-spec/TOPTEN-POP-UPDATES/'):
            raise RuntimeError('Invalid central XLSX origin')
        local_hash=sha(MASTER)
        if status_success(expected,local_hash):
            note('[OK] Central release already installed, preserving local applied changes: '+version)
            write_json_atomic(PREFLIGHT_STATE,{'ok':True,'installed_sha256':expected,'master_version':version,
                                            'confirmed_at':dt.datetime.now().isoformat(timespec='seconds')})
            # Don't rewrite STATUS: app may hold locally processed SHA fingerprint.
            return 0
        CACHE.mkdir(parents=True,exist_ok=True)
        pending=CACHE/('central_price_master_pending_'+expected[:16]+'.xlsx')
        if not (pending.is_file() and sha(pending)==expected):
            fd,name=tempfile.mkstemp(prefix='.central_incoming_',suffix='.xlsx',dir=str(CACHE))
            os.close(fd);tmp=Path(name)
            try:
                tmp.write_bytes(online_get(url,MAX_BYTES,timeout=15))
                if sha(tmp)!=expected:raise RuntimeError('Downloaded central SHA256 mismatch')
                xlsx_ok(tmp)
                os.replace(tmp,pending)
            finally:
                try:tmp.unlink(missing_ok=True)
                except OSError:pass
        xlsx_ok(pending)
        if sha(pending)!=expected:raise RuntimeError('Cached candidate SHA256 mismatch')
        result,_=replace_verified(pending,expected)
        installed_hash=sha(MASTER)
        now=dt.datetime.now().isoformat(timespec='seconds')
        # Preserve unknown status fields and write only after successful SHA validation.
        state=read_json(STATUS)
        state.update({'ok':True,'deferred':False,'changed':result=='installed',
                      'message':'RUN 실행 전 중앙 가격정책 적용 완료' if result=='installed' else '중앙 가격정책 이미 최신',
                      'remote_version':version,'sha256':expected,'installed_version':version,
                      'installed_sha256':expected,'verified_local_sha256':installed_hash,
                      'last_checked':now,'last_updated':now,'source':'V5.1.14 prelaunch'})
        write_json_atomic(STATUS,state)
        write_json_atomic(PREFLIGHT_STATE,{'ok':True,'installed_sha256':expected,'master_version':version,'confirmed_at':now})
        note('[OK] Central master '+result+', '+version)
        return 0
    except Exception as e:
        note('[DEFER] '+type(e).__name__+': '+str(e))
        note('Existing operational master kept when replacement was rejected; inspect log if store looks stale')
        try:
            state=read_json(STATUS)
            state.update({'ok':False,'deferred':True,
                          'message':'RUN 시작 전 중앙 정책 적용 보류: '+type(e).__name__+': '+str(e),
                          'last_checked':dt.datetime.now().isoformat(timespec='seconds'),
                          'source':'V5.1.14 prelaunch'})
            write_json_atomic(STATUS,state)
        except Exception:pass
        return 4


if __name__=='__main__':sys.exit(run())
