@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "ROOT=%~dp0"
cd /d "%ROOT%"
title TOPTEN POP V4.4.1 - KEEP THIS WINDOW OPEN
set "LOG=%ROOT%run_log.txt"
set "PIDFILE=%ROOT%data\server.pid"
set "PENDING=%ROOT%data\pending_finalize.json"
set "SPAWNED=%ROOT%data\finalizer_spawned.json"
>"%LOG%" echo TOPTEN POP V4.4.1 RUN LOG

call :find_python
if not defined PYEXE (
  echo Python was not found.
  echo Install Python 3.11-3.13 first.
  pause
  exit /b 1
)
set "PYWEXE=%PYEXE%"
for %%I in ("%PYEXE%") do if exist "%%~dpIpythonw.exe" set "PYWEXE=%%~dpIpythonw.exe"

if exist "%ROOT%update_client.py" (
  echo Checking TOPTEN POP updates...
  "%PYEXE%" "%ROOT%update_client.py"
  echo.
)

rem ------------------------------------------------------------
rem Deferred folder cleanup/rename.  Only ONE finalizer may spawn.
rem This prevents RUN -> finalizer -> RUN infinite CMD loops.
rem ------------------------------------------------------------
if exist "%PENDING%" if exist "%ROOT%finalize_update.py" (
  if exist "%SPAWNED%" (
    echo Update finalization is already running. Waiting...
    timeout /t 7 /nobreak >nul
    if not exist "%PENDING%" exit /b 0
    echo Previous finalizer did not finish. Repeated launch is blocked.
    del /q "%PENDING%" >nul 2>&1
    del /q "%SPAWNED%" >nul 2>&1
    "%PYEXE%" -c "import json,pathlib; r=pathlib.Path(r'%ROOT:~0,-1%'); p=r/'data'/'folder_rename_state.json'; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps({'status':'failed','version':json.loads((r/'version.json').read_text(encoding='utf-8-sig')).get('version','0.0.0'),'root':str(r),'reason':'finalizer launch timeout - loop blocked'},ensure_ascii=False,indent=2),encoding='utf-8')" >nul 2>&1
    goto start_app
  )

  >"%SPAWNED%" echo {"status":"spawned"}
  set "TEMP_FINAL=%TEMP%\TOPTEN_POP_finalize_%RANDOM%_%RANDOM%.py"
  copy /y "%ROOT%finalize_update.py" "!TEMP_FINAL!" >nul 2>&1
  if errorlevel 1 (
    del /q "%SPAWNED%" >nul 2>&1
    echo Finalizer copy failed. Program will start without folder rename.
    goto start_app
  )
  set "OLDROOT=%ROOT:~0,-1%"
  echo Finalizing update. TOPTEN POP will reopen automatically...
  cd /d "%TEMP%"
  start "" "!PYWEXE!" "!TEMP_FINAL!" "!OLDROOT!" --delay 3.0
  exit /b 0
)

:start_app
cd /d "%ROOT%"
if not exist "%ROOT%app\app.py" (
  echo app\app.py is missing.
  pause
  exit /b 2
)

if exist "%PIDFILE%" (
  set /p OLDPID=<"%PIDFILE%"
  if defined OLDPID taskkill /F /PID !OLDPID! >nul 2>&1
  del /q "%PIDFILE%" >nul 2>&1
)

echo Python: %PYEXE%>>"%LOG%"
"%PYEXE%" -c "import sys; print(sys.executable); print(sys.version)" >>"%LOG%" 2>&1

set "NEEDPKG="
for %%M in (flask openpyxl PIL fitz pytesseract) do (
  "%PYEXE%" -c "import %%M" >nul 2>&1
  if errorlevel 1 set "NEEDPKG=1"
)
if defined NEEDPKG (
  echo Installing missing Python packages...
  "%PYEXE%" -m pip install --disable-pip-version-check flask openpyxl pillow pymupdf pytesseract packaging >>"%LOG%" 2>&1
)

if exist "%ROOT%ocr_tessdata\kor.traineddata" set "TESSDATA_PREFIX=%ROOT%ocr_tessdata"
if exist "C:\Program Files\Tesseract-OCR\tesseract.exe" set "TESSERACT_CMD=C:\Program Files\Tesseract-OCR\tesseract.exe"
if exist "C:\Program Files (x86)\Tesseract-OCR\tesseract.exe" if not defined TESSERACT_CMD set "TESSERACT_CMD=C:\Program Files (x86)\Tesseract-OCR\tesseract.exe"
if defined TESSERACT_CMD echo Tesseract: %TESSERACT_CMD%>>"%LOG%"
if defined TESSDATA_PREFIX echo Tessdata: %TESSDATA_PREFIX%>>"%LOG%"

set "TOPTEN_POP_PORT=8080"
echo Starting TOPTEN POP V4.4.1...
start "TOPTEN POP V4.4.1 SERVER" /b "%PYEXE%" "%ROOT%app\app.py" >>"%LOG%" 2>&1

set /a COUNT=0
:wait_health
powershell -NoProfile -Command "try { $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 http://127.0.0.1:8080/health; if($r.StatusCode -eq 200){exit 0}else{exit 1} } catch { exit 1 }"
if not errorlevel 1 goto ready
set /a COUNT+=1
if %COUNT% GEQ 45 goto failed
timeout /t 1 /nobreak >nul
goto wait_health

:ready
echo Server ready. Opening browser...
start "" http://127.0.0.1:8080
echo.
echo TOPTEN POP V4.4.1 is running at http://127.0.0.1:8080
echo Keep this window open. Press any key to stop this server.
pause >nul
call :stop_server
exit /b 0

:failed
echo.
echo START FAILED. See run_log.txt.
type "%LOG%"
call :stop_server
pause
exit /b 3

:stop_server
if exist "%PIDFILE%" (
  set /p SERVERPID=<"%PIDFILE%"
  if defined SERVERPID taskkill /F /PID !SERVERPID! >nul 2>&1
  del /q "%PIDFILE%" >nul 2>&1
)
exit /b 0

:find_python
set "PYEXE="
for /f "delims=" %%P in ('where python 2^>nul') do if not defined PYEXE (
  "%%P" -c "import sys; print(sys.executable)" >nul 2>&1
  if not errorlevel 1 set "PYEXE=%%P"
)
if defined PYEXE exit /b 0
for %%P in (
  "%LocalAppData%\Programs\Python\Python313\python.exe"
  "%LocalAppData%\Programs\Python\Python312\python.exe"
  "%LocalAppData%\Programs\Python\Python311\python.exe"
  "C:\Program Files\Python313\python.exe"
  "C:\Program Files\Python312\python.exe"
  "C:\Program Files\Python311\python.exe"
) do if exist "%%~P" if not defined PYEXE set "PYEXE=%%~P"
exit /b 0
