@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "ROOT=%~dp0"
cd /d "%ROOT%"
title TOPTEN POP V4.4.31 - KEEP THIS WINDOW OPEN
if not exist "%ROOT%data\logs" mkdir "%ROOT%data\logs" >nul 2>&1
set "LOG=%ROOT%data\logs\run.log"
set "SETUPLOG=%ROOT%data\logs\setup.log"
set "PIDFILE=%ROOT%data\server.pid"
set "PENDING=%ROOT%data\pending_finalize.json"
set "SPAWNED=%ROOT%data\finalizer_spawned.json"
>"%LOG%" echo TOPTEN POP V4.4.31 RUN LOG

echo ==========================================================
echo TOPTEN POP V4.4.31
echo SUPPORTED OS: Windows 10 / 11 64-bit x64
echo NOT SUPPORTED: Windows 32-bit x86 or ARM64 native
echo First run prepares Python/modules. Tesseract remains available as fallback OCR.
echo PowerShell is NOT required.
echo ==========================================================
echo.

set "NATIVE_ARCH=%PROCESSOR_ARCHITECTURE%"
if defined PROCESSOR_ARCHITEW6432 set "NATIVE_ARCH=%PROCESSOR_ARCHITEW6432%"
echo Detected architecture: %NATIVE_ARCH%
if /I "%NATIVE_ARCH%"=="ARM64" goto blocked_arm
if /I "%NATIVE_ARCH%"=="AMD64" goto arch_ok
goto blocked_32

:blocked_32
echo.
echo INSTALLATION BLOCKED: 32-bit Windows is not supported.
echo No Python, Tesseract, or module setup was attempted.
pause
exit /b 32

:blocked_arm
echo.
echo INSTALLATION BLOCKED: ARM64 native Windows is not supported.
echo No Python, Tesseract, or module setup was attempted.
pause
exit /b 33

:arch_ok
echo OS check: PASS
echo.
if not exist "%ROOT%bootstrap_env.cmd" goto bootstrap_missing
if not exist "%ROOT%bootstrap_unzip.vbs" goto bootstrap_missing

echo [1/4] Preparing Python and required modules...
call "%ROOT%bootstrap_env.cmd" "%ROOT%" core
if errorlevel 1 goto setup_failed

set "PYEXE="
if exist "%ROOT%data\python_path.txt" set /p PYEXE=<"%ROOT%data\python_path.txt"
if not defined PYEXE goto python_missing
if not exist "%PYEXE%" goto python_missing
"%PYEXE%" -c "import sys,struct;raise SystemExit(0 if struct.calcsize('P')*8==64 else 1)" >nul 2>&1
if errorlevel 1 goto python_missing
set "PYWEXE=%PYEXE%"
for %%I in ("%PYEXE%") do if exist "%%~dpIpythonw.exe" set "PYWEXE=%%~dpIpythonw.exe"

echo [2/4] Checking TOPTEN POP updates...
if exist "%ROOT%update_client.py" "%PYEXE%" "%ROOT%update_client.py"
echo.
if exist "%PENDING%" if exist "%ROOT%finalize_update.py" goto finalize_update

echo [3/4] Preparing Tesseract and OCR language data...
call "%ROOT%bootstrap_env.cmd" "%ROOT%" full
if errorlevel 1 goto setup_failed
rem V4.4.31: OCR is fallback/manual; automatic webhard OCR watcher is disabled.
goto start_app

:finalize_update
if exist "%SPAWNED%" goto finalizer_stale
>"%SPAWNED%" echo {"status":"spawned"}
set "TEMP_FINAL=%TEMP%\TOPTEN_POP_finalize_%RANDOM%_%RANDOM%.py"
copy /y "%ROOT%finalize_update.py" "!TEMP_FINAL!" >nul 2>&1
if errorlevel 1 goto finalizer_copy_failed
set "OLDROOT=%ROOT:~0,-1%"
echo [3/4] Finalizing update. Program will reopen automatically...
cd /d "%TEMP%"
start "" "!PYWEXE!" "!TEMP_FINAL!" "!OLDROOT!" --delay 3.0
exit /b 0

:finalizer_stale
echo Update finalizer marker found. Waiting once...
timeout /t 7 /nobreak >nul
if not exist "%PENDING%" exit /b 0
del /q "%PENDING%" >nul 2>&1
del /q "%SPAWNED%" >nul 2>&1
goto start_app

:finalizer_copy_failed
del /q "%SPAWNED%" >nul 2>&1
goto start_app

:start_app
cd /d "%ROOT%"
if not exist "%ROOT%app\app.py" goto app_missing
if exist "%PIDFILE%" goto stop_old_pid
goto verify_packages

:stop_old_pid
set "OLDPID="
set /p OLDPID=<"%PIDFILE%"
if defined OLDPID taskkill /F /PID !OLDPID! >nul 2>&1
del /q "%PIDFILE%" >nul 2>&1

:verify_packages
"%PYEXE%" -c "import flask,openpyxl,PIL,fitz,pytesseract,packaging" >>"%LOG%" 2>&1
if errorlevel 1 goto packages_retry
goto launch

:packages_retry
echo Python package verification failed. Repairing...
call "%ROOT%bootstrap_env.cmd" "%ROOT%" core
if errorlevel 1 goto setup_failed

:launch
set "TOPTEN_POP_PORT=8080"
echo [4/4] Starting TOPTEN POP V4.4.31...
start "TOPTEN POP V4.4.31 SERVER" /b "%PYEXE%" "%ROOT%app\app.py" >>"%LOG%" 2>&1
set /a COUNT=0

:wait_health
"%PYEXE%" -c "import urllib.request; r=urllib.request.urlopen('http://127.0.0.1:8080/health',timeout=2); raise SystemExit(0 if r.status==200 else 1)" >nul 2>&1
if not errorlevel 1 goto ready
set /a COUNT+=1
if !COUNT! GEQ 45 goto failed
timeout /t 1 /nobreak >nul
goto wait_health

:ready
echo Server ready. Opening browser...
start "" "http://127.0.0.1:8080"
echo.
echo TOPTEN POP V4.4.31 is running at http://127.0.0.1:8080
echo Keep this window open. Press any key to stop the server.
pause >nul
if not exist "%PIDFILE%" exit /b 0
set "SERVERPID="
set /p SERVERPID=<"%PIDFILE%"
if defined SERVERPID taskkill /F /PID !SERVERPID! >nul 2>&1
del /q "%PIDFILE%" >nul 2>&1
exit /b 0

:bootstrap_missing
echo ERROR: bootstrap_env.cmd or bootstrap_unzip.vbs is missing.
pause
exit /b 10

:setup_failed
echo.
echo AUTO SETUP FAILED.
echo See: %SETUPLOG%
echo.
if exist "%SETUPLOG%" type "%SETUPLOG%"
pause
exit /b 11

:python_missing
echo ERROR: Portable 64-bit Python is not ready.
echo See data\logs\setup.log
pause
exit /b 12

:tess_missing
echo ERROR: Tesseract is not ready.
echo See data\logs\setup.log
pause
exit /b 13

:tessdata_missing
echo ERROR: OCR language data path is not ready.
echo See data\logs\setup.log
pause
exit /b 15

:app_missing
echo ERROR: app\app.py is missing.
pause
exit /b 14

:failed
echo START FAILED. See data\logs\run.log and data\logs\setup.log.
if exist "%LOG%" type "%LOG%"
pause
exit /b 16
