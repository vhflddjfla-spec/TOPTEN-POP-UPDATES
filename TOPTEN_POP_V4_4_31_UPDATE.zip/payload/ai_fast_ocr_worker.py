# -*- coding: utf-8 -*-
from __future__ import annotations
import argparse,json,os,site,sys,time,re
from pathlib import Path
AI_SITE=os.environ.get('TOPTEN_AI_SITE','').strip()
if AI_SITE: site.addsitedir(AI_SITE)

def write_progress(path,**kw):
    p=Path(path); base={'stage':'fast_ocr','done':0,'total':0,'message':'PP-OCRv5 Korean FAST 준비 중','current_index':0,'current_elapsed_seconds':0,'elapsed_seconds':0,'last_page_seconds':0.0,'page_eta_seconds':-1}
    try:
        if p.exists():
            old=json.loads(p.read_text('utf-8')); base.update(old if isinstance(old,dict) else {})
    except Exception: pass
    base.update(kw); tmp=p.with_suffix(p.suffix+'.tmp'); tmp.write_text(json.dumps(base,ensure_ascii=False),encoding='utf-8'); tmp.replace(p)

def walk_text(obj,key=''):
    out=[]; k=str(key).lower()
    if isinstance(obj,str):
        t=' '.join(obj.split())
        if t and not t.startswith('data:image/') and (any(x in k for x in ('text','rec','label','content','title')) or len(t)<500): out.append(t)
    elif isinstance(obj,dict):
        for kk,v in obj.items(): out.extend(walk_text(v,kk))
    elif isinstance(obj,(list,tuple)):
        for v in obj: out.extend(walk_text(v,key))
    return out

def _result_json(res):
    try:
        j=getattr(res,'json',None)
        if callable(j): j=j()
        return j if isinstance(j,dict) else {}
    except Exception:
        return {}

def _ascii_ratio(s):
    a=sum(1 for ch in s if ('A'<=ch.upper()<='Z'))
    letters=sum(1 for ch in s if ch.isalpha())
    return a/max(1,letters)

def result_text(res):
    # Prefer the official OCR line list + boxes when available. This lets the matcher
    # preserve the lower product-name area from the *same* page image without doing
    # a second OCR pass (important for store-PC speed).
    j=_result_json(res); base=j.get('res',j) if isinstance(j,dict) else {}
    texts=list(base.get('rec_texts') or []) if isinstance(base,dict) else []
    boxes=list(base.get('rec_boxes') or []) if isinstance(base,dict) else []
    clean_texts=[' '.join(str(x).split()) for x in texts if str(x).strip()]
    if clean_texts:
        title=[]; english=[]; gender=[]
        max_y=0.0
        for b in boxes:
            try: max_y=max(max_y,float(b[3]))
            except Exception: pass
        for ix,t in enumerate(clean_texts):
            if re.search(r'남성|여성|남류|여류|\bMEN(?:\'S)?\b|\bWOMEN(?:\'S)?\b|\bUNISEX\b',t,re.I): gender.append(t)
            if _ascii_ratio(t)>=0.72 and len(t)>=3: english.append(t)
            try:
                b=boxes[ix]; cy=(float(b[1])+float(b[3]))/2.0
                if max_y and cy>=max_y*0.56: title.append(t)
            except Exception: pass
        full=' | '.join(clean_texts)
        return ('[FULL_TEXT] '+full+' [TITLE_ZONE] '+' | '.join(title)+' [ENGLISH_TEXT] '+' | '.join(english)+' [GENDER_TEXT] '+' | '.join(gender))[:30000]
    vals=[]
    for objname in ('json','res','data'):
        try: vals.extend(walk_text(getattr(res,objname,None),objname))
        except Exception: pass
    seen=set(); out=[]
    for x in vals:
        x=' '.join(str(x).split())
        if x and x not in seen: seen.add(x); out.append(x)
    return ' | '.join(out)[:30000]

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--manifest',required=True); ap.add_argument('--output',required=True); ap.add_argument('--progress',required=True); a=ap.parse_args()
    tasks=list(json.loads(Path(a.manifest).read_text('utf-8')).get('tasks') or [])
    Path(a.output).parent.mkdir(parents=True,exist_ok=True); Path(a.progress).parent.mkdir(parents=True,exist_ok=True)
    write_progress(a.progress,total=len(tasks),message='PP-OCRv5 Korean FAST 소형 모델 로딩 중')
    from paddleocr import PaddleOCR
    threads=max(2,min(10,int(os.cpu_count() or 4)))
    # Official PP-OCRv5 Korean mobile recognition + mobile detection. This is tens of MB,
    # not a 0.9B VLM, and is the default first pass for TOPTEN posters.
    ocr=PaddleOCR(ocr_version='PP-OCRv5',lang='korean',text_detection_model_name='PP-OCRv5_mobile_det',text_recognition_model_name='korean_PP-OCRv5_mobile_rec',use_doc_orientation_classify=False,use_doc_unwarping=False,use_textline_orientation=False,device='cpu',enable_mkldnn=True,cpu_threads=threads)
    results=[]; durations=[]; t0=time.monotonic()
    write_progress(a.progress,total=len(tasks),message=f'PP-OCRv5 Korean FAST 시작 · 신규 {len(tasks)}페이지')
    for idx,t in enumerate(tasks,start=1):
        st=time.monotonic(); write_progress(a.progress,done=idx-1,total=len(tasks),current_index=idx,current_elapsed_seconds=0,elapsed_seconds=int(st-t0),last_page_seconds=(durations[-1] if durations else 0),page_eta_seconds=(int(sum(durations)/len(durations)*(len(tasks)-idx+1)) if durations else -1),message=f'FAST 페이지 {idx}/{len(tasks)} 읽는 중')
        parts=[]
        for res in ocr.predict(str(Path(t['image']).resolve())):
            txt=result_text(res)
            if txt: parts.append(txt)
        sec=max(.05,time.monotonic()-st); durations.append(sec); txt=' | '.join(parts)[:30000]
        results.append({'id':t['id'],'image':t['image'],'text':txt,'seconds':round(sec,2),'engine':'PP-OCRv5 Korean FAST'})
        Path(a.output).write_text(json.dumps({'results':results},ensure_ascii=False),encoding='utf-8')
        avg=sum(durations)/len(durations); eta=int(avg*(len(tasks)-idx))
        write_progress(a.progress,done=idx,total=len(tasks),current_index=(idx+1 if idx<len(tasks) else 0),current_elapsed_seconds=0,elapsed_seconds=int(time.monotonic()-t0),last_page_seconds=round(sec,2),page_eta_seconds=eta,message=f'FAST 페이지 {idx}/{len(tasks)} 완료 · {sec:.1f}초 · 남은 예상 {eta//60}분 {eta%60}초')
    write_progress(a.progress,stage='fast_done',done=len(tasks),total=len(tasks),current_index=0,elapsed_seconds=int(time.monotonic()-t0),page_eta_seconds=0,message='PP-OCRv5 Korean FAST 완료')
if __name__=='__main__': main()
