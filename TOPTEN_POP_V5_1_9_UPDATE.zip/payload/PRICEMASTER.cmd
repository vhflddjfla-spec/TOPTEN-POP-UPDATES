@echo off
setlocal EnableExtensions
chcp 65001 >nul
set "ROOT=%~dp0"
cd /d "%ROOT%"
title TOPTEN PRICE MASTER V5.1.9

echo ============================================================
echo TOPTEN PRICE MASTER V5.1.9
echo - 실사용 data\TOPTEN_가격정책_마스터.xlsx만 사용
echo - 초기본 재생성/대체 금지
echo - 오늘 도래 예약 + 기간종료 복귀 후 중앙배포 파일 생성
echo ============================================================
echo.

if not exist "%ROOT%data\TOPTEN_가격정책_마스터.xlsx" (
  echo [ERROR] 실사용 가격정책 마스터가 없습니다.
  echo         %ROOT%data\TOPTEN_가격정책_마스터.xlsx
  echo.
  echo 초기본으로 대신 만들지 않습니다. RUN.cmd를 먼저 1회 실행하세요.
  pause
  exit /b 2
)

set "PYEXE="
if exist "%ROOT%data\python_path.txt" set /p PYEXE=<"%ROOT%data\python_path.txt"
if defined PYEXE if exist "%PYEXE%" goto run_path
set "PYEXE="
where py >nul 2>&1 && set "PYEXE=py -3"
if defined PYEXE goto run_command
where python >nul 2>&1 && set "PYEXE=python"
if defined PYEXE goto run_command

echo [ERROR] Python을 찾지 못했습니다. RUN.cmd를 먼저 1회 실행하세요.
pause
exit /b 1

:run_path
echo [INFO] SOURCE = %ROOT%data\TOPTEN_가격정책_마스터.xlsx
"%PYEXE%" "%ROOT%publish_price_master.py"
set "RC=%ERRORLEVEL%"
goto after_run

:run_command
echo [INFO] SOURCE = %ROOT%data\TOPTEN_가격정책_마스터.xlsx
%PYEXE% "%ROOT%publish_price_master.py"
set "RC=%ERRORLEVEL%"

:after_run
if not "%RC%"=="0" (
  echo.
  echo [ERROR] PRICEMASTER 생성 실패. 오류코드=%RC%
  echo 로그: %ROOT%data\logs\pricemaster.log
  if exist "%ROOT%data\logs\pricemaster.log" (
    echo ---------------- LOG ----------------
    type "%ROOT%data\logs\pricemaster.log"
    echo -------------------------------------
  )
  pause
  exit /b %RC%
)

if not exist "%ROOT%github_price_master_release\TOPTEN_PRICE_POLICY_MASTER.xlsx" goto output_missing
if not exist "%ROOT%github_price_master_release\price_master.json" goto output_missing

echo.
echo [OK] 생성 완료
echo      %ROOT%github_price_master_release\TOPTEN_PRICE_POLICY_MASTER.xlsx
echo      %ROOT%github_price_master_release\price_master.json
start "" explorer "%ROOT%github_price_master_release"
pause
exit /b 0

:output_missing
echo.
echo [ERROR] Python은 성공 종료했지만 출력파일 검증에 실패했습니다.
echo 로그: %ROOT%data\logs\pricemaster.log
pause
exit /b 9
