# -*- coding: utf-8 -*-
"""TOPTEN POP V4.4.11 OCR bootstrap.

Goals
- Reuse any working Tesseract already installed on Windows, regardless of install folder.
- Reuse its native tessdata directly when kor/eng/osd are complete and verified.
- If language data are incomplete, fill only the missing files from the bundled assets,
  then from the official tessdata_fast repository only as a last resort.
- If Tesseract itself is missing, install it automatically (winget first, verified
  UB-Mannheim installer fallback), then discover it again.
- Pass Windows paths to Tesseract through subprocess argument arrays, never shell strings,
  so spaces/OneDrive/Korean paths are handled by Python/Win32 Unicode APIs.
"""
from __future__ import annotations

import hashlib
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

VERSION = "4.4.11"
REQUIRED = {
    "eng": (1_000_000, "https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/eng.traineddata"),
    "kor": (500_000, "https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/kor.traineddata"),
    "osd": (1_000_000, "https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/osd.traineddata"),
}
TESS_INSTALL_URL = "https://github.com/UB-Mannheim/tesseract/releases/download/v5.4.0.20240606/tesseract-ocr-w64-setup-5.4.0.20240606.exe"
TESS_INSTALL_SHA256 = "c885fff6998e0608ba4bb8ab51436e1c6775c2bafc2559a19b423e18678b60c9"


def log(msg: str) -> None:
    print(msg, flush=True)


def read_saved(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="ignore").strip().strip('"')
    except OSError:
        return ""


def executable_ok(path: Path) -> bool:
    if not path.is_file():
        return False
    try:
        p = subprocess.run([str(path), "--version"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           text=True, encoding="utf-8", errors="replace", timeout=15, check=False)
        return p.returncode == 0 and "tesseract" in (p.stdout or "").lower()
    except Exception:
        return False


def registry_candidates() -> list[Path]:
    if os.name != "nt":
        return []
    out: list[Path] = []
    try:
        import winreg
    except Exception:
        return out
    keys = [
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Tesseract-OCR"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Tesseract-OCR"),
        (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Tesseract-OCR"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\tesseract.exe"),
        (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\tesseract.exe"),
    ]
    for hive, keyname in keys:
        try:
            with winreg.OpenKey(hive, keyname) as key:
                for valuename in ("InstallDir", "Path", ""):
                    try:
                        value, _ = winreg.QueryValueEx(key, valuename)
                    except OSError:
                        continue
                    if not value:
                        continue
                    p = Path(str(value).strip().strip('"'))
                    if p.suffix.lower() == ".exe":
                        out.append(p)
                    else:
                        out.append(p / "tesseract.exe")
        except OSError:
            continue
    return out


def limited_glob_candidates() -> list[Path]:
    roots = []
    for env in ("ProgramFiles", "ProgramFiles(x86)", "LOCALAPPDATA", "ProgramData"):
        value = os.environ.get(env)
        if value:
            roots.append(Path(value))
    patterns = [
        "Tesseract-OCR/tesseract.exe",
        "Programs/Tesseract-OCR/tesseract.exe",
        "Tesseract*/tesseract.exe",
        "Programs/Tesseract*/tesseract.exe",
    ]
    out: list[Path] = []
    for root in roots:
        for pattern in patterns:
            try:
                out.extend(root.glob(pattern))
            except OSError:
                pass
    return out


def discover_tesseract(root: Path) -> Path | None:
    data = root / "data"
    candidates: list[Path] = []
    saved = read_saved(data / "tesseract_path.txt")
    if saved:
        candidates.append(Path(saved))
    env_cmd = os.environ.get("TESSERACT_CMD", "").strip().strip('"')
    if env_cmd:
        candidates.append(Path(env_cmd))
    which = shutil.which("tesseract") or shutil.which("tesseract.exe")
    if which:
        candidates.append(Path(which))
    candidates.extend([
        Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Tesseract-OCR" / "tesseract.exe",
        Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "Tesseract-OCR" / "tesseract.exe",
        Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Tesseract-OCR" / "tesseract.exe" if os.environ.get("LOCALAPPDATA") else Path("__none__"),
    ])
    candidates.extend(registry_candidates())
    candidates.extend(limited_glob_candidates())
    seen = set()
    for candidate in candidates:
        try:
            key = os.path.normcase(os.path.abspath(str(candidate)))
        except Exception:
            key = str(candidate)
        if key in seen:
            continue
        seen.add(key)
        if executable_ok(candidate):
            return candidate.resolve()
    return None


def hash_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def download(url: str, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".part")
    tmp.unlink(missing_ok=True)
    req = urllib.request.Request(url, headers={"User-Agent": f"TOPTEN-POP/{VERSION}"})
    with urllib.request.urlopen(req, timeout=90) as r, tmp.open("wb") as f:
        shutil.copyfileobj(r, f)
    os.replace(tmp, dest)


def install_tesseract(root: Path) -> Path | None:
    winget = shutil.which("winget") or shutil.which("winget.exe")
    if winget:
        log("Tesseract not found. Trying Windows Package Manager first.")
        try:
            proc = subprocess.run([
                winget, "install", "--id", "UB-Mannheim.TesseractOCR", "--exact", "--silent",
                "--accept-package-agreements", "--accept-source-agreements", "--disable-interactivity",
            ], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8",
               errors="replace", timeout=600, check=False)
            log(f"winget result: {proc.returncode}")
        except Exception as exc:
            log(f"winget install was unavailable: {type(exc).__name__}: {exc}")
        for _ in range(5):
            found = discover_tesseract(root)
            if found:
                return found
            time.sleep(1)

    log("Tesseract still not found. Downloading verified UB-Mannheim x64 installer.")
    temp_root = Path(os.environ.get("TEMP") or tempfile.gettempdir()) / "TOPTEN_POP_V4411_SETUP"
    temp_root.mkdir(parents=True, exist_ok=True)
    installer = temp_root / "tesseract-ocr-w64-setup-5.4.0.20240606.exe"
    try:
        if not installer.is_file() or hash_file(installer).lower() != TESS_INSTALL_SHA256:
            download(TESS_INSTALL_URL, installer)
        if installer.stat().st_size < 40_000_000:
            raise RuntimeError("Tesseract installer download is unexpectedly small")
        if hash_file(installer).lower() != TESS_INSTALL_SHA256:
            raise RuntimeError("Tesseract installer SHA256 mismatch")
        with installer.open("rb") as f:
            if f.read(2) != b"MZ":
                raise RuntimeError("Tesseract installer is not a Windows executable")
        log("Installing Tesseract silently. Windows may request UAC approval.")
        proc = subprocess.run([str(installer), "/S"], cwd=str(temp_root), check=False, timeout=600)
        log(f"installer result: {proc.returncode}")
    except Exception as exc:
        log(f"Tesseract direct install failed: {type(exc).__name__}: {exc}")
        return None
    for _ in range(10):
        found = discover_tesseract(root)
        if found:
            return found
        time.sleep(1)
    return None


def valid_file(path: Path, lang: str) -> bool:
    min_size = REQUIRED[lang][0]
    try:
        return path.is_file() and path.stat().st_size >= min_size
    except OSError:
        return False


def complete_dir(folder: Path) -> bool:
    return folder.is_dir() and all(valid_file(folder / f"{lang}.traineddata", lang) for lang in REQUIRED)


def list_languages(tesseract: Path, tessdata: Path) -> tuple[bool, set[str], str]:
    try:
        proc = subprocess.run(
            [str(tesseract), "--tessdata-dir", str(tessdata), "--list-langs"],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
            encoding="utf-8", errors="replace", timeout=30, check=False,
        )
    except Exception as exc:
        return False, set(), f"{type(exc).__name__}: {exc}"
    output = proc.stdout or ""
    found = {line.strip() for line in output.splitlines() if line.strip() in REQUIRED}
    ok = proc.returncode == 0 and all(lang in found for lang in REQUIRED)
    return ok, found, output


def default_tessdata_from_tesseract(tesseract: Path) -> Path | None:
    """Ask Tesseract itself which default tessdata directory it is using."""
    try:
        proc = subprocess.run(
            [str(tesseract), "--list-langs"],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
            encoding="utf-8", errors="replace", timeout=30, check=False,
        )
    except Exception:
        return None
    output = proc.stdout or ""
    # Typical first line: List of available languages in "C:\\...\\tessdata/" (3):
    for line in output.splitlines():
        if "List of available languages in" not in line:
            continue
        if '"' in line:
            parts = line.split('"')
            if len(parts) >= 3 and parts[1].strip():
                return Path(parts[1].strip())
    return None


def tessdata_candidates(root: Path, tesseract: Path) -> list[Path]:
    data = root / "data"
    candidates: list[Path] = []
    saved = read_saved(data / "tessdata_path.txt")
    if saved:
        candidates.append(Path(saved))
    for env in ("TOPTEN_TESSDATA_DIR", "TESSDATA_PREFIX"):
        value = os.environ.get(env, "").strip().strip('"')
        if value:
            p = Path(value)
            candidates.append(p)
            candidates.append(p / "tessdata")
    detected_default = default_tessdata_from_tesseract(tesseract)
    if detected_default is not None:
        candidates.append(detected_default)
    candidates.extend([
        tesseract.parent / "tessdata",
        tesseract.parent.parent / "share" / "tessdata",
        root / "ocr_tessdata",
        root / "bootstrap_assets" / "tessdata",
        data / "downloaded_tessdata",
    ])
    program_data = os.environ.get("ProgramData")
    local = os.environ.get("LOCALAPPDATA")
    if program_data:
        candidates.append(Path(program_data) / "TOPTEN_POP" / "tessdata")
    if local:
        candidates.append(Path(local) / "TOPTEN_POP" / "tessdata")
    out: list[Path] = []
    seen = set()
    for p in candidates:
        key = os.path.normcase(os.path.abspath(str(p)))
        if key not in seen:
            seen.add(key)
            out.append(p)
    return out


def choose_existing_tessdata(root: Path, tesseract: Path, check_file: Path) -> Path | None:
    for folder in tessdata_candidates(root, tesseract):
        if not complete_dir(folder):
            continue
        ok, found, output = list_languages(tesseract, folder)
        if ok:
            check_file.write_text(output, encoding="utf-8")
            log(f"Existing OCR language data detected and verified: {folder}")
            return folder.resolve()
    return None


def writable_stable_dir(root: Path) -> Path:
    candidates: list[Path] = []
    program_data = os.environ.get("ProgramData")
    local = os.environ.get("LOCALAPPDATA")
    if program_data:
        candidates.append(Path(program_data) / "TOPTEN_POP" / "tessdata")
    if local:
        candidates.append(Path(local) / "TOPTEN_POP" / "tessdata")
    candidates.append(root / "data" / "stable_tessdata")
    for folder in candidates:
        try:
            folder.mkdir(parents=True, exist_ok=True)
            probe = folder / ".topten_write_test"
            probe.write_bytes(b"ok")
            probe.unlink(missing_ok=True)
            return folder
        except OSError:
            continue
    raise RuntimeError("No writable OCR tessdata directory")


def fill_missing(root: Path, tesseract: Path, dest: Path) -> None:
    sources = tessdata_candidates(root, tesseract)
    dest.mkdir(parents=True, exist_ok=True)
    for lang, (min_size, url) in REQUIRED.items():
        target = dest / f"{lang}.traineddata"
        if valid_file(target, lang):
            continue
        source = next((p / f"{lang}.traineddata" for p in sources if valid_file(p / f"{lang}.traineddata", lang)), None)
        if source is not None:
            log(f"OCR {lang}: reusing local file from {source.parent}")
            tmp = target.with_suffix(target.suffix + ".tmp")
            shutil.copy2(source, tmp)
            os.replace(tmp, target)
            continue
        log(f"OCR {lang}: no local copy found; downloading fallback language file.")
        download(url, target)
        if not valid_file(target, lang):
            raise RuntimeError(f"Downloaded OCR language file is invalid: {lang}")


def main() -> int:
    if len(sys.argv) < 2:
        print("usage: ocr_bootstrap.py ROOT", flush=True)
        return 2
    root = Path(sys.argv[1]).resolve()
    data = root / "data"
    data.mkdir(parents=True, exist_ok=True)
    check_file = data / "ocr_languages_check.txt"

    log("Scanning Windows for an existing Tesseract installation.")
    tesseract = discover_tesseract(root)
    if tesseract:
        log(f"Existing Tesseract detected: {tesseract}")
    else:
        tesseract = install_tesseract(root)
        if not tesseract:
            raise RuntimeError("Tesseract could not be found or installed")
        log(f"Tesseract installed/detected: {tesseract}")

    # First preference: use the installation's or another already-complete tessdata directly.
    tessdata = choose_existing_tessdata(root, tesseract, check_file)
    if tessdata is None:
        log("No complete verified OCR language set was found. Preparing only the missing files.")
        tessdata = writable_stable_dir(root)
        fill_missing(root, tesseract, tessdata)
        ok, found, output = list_languages(tesseract, tessdata)
        check_file.write_text(output, encoding="utf-8")
        if not ok:
            raise RuntimeError("OCR language verification failed after repair; detected=" + ",".join(sorted(found)))
        tessdata = tessdata.resolve()
        log(f"Repaired OCR language data verified: {tessdata}")

    (data / "tesseract_path.txt").write_text(str(tesseract), encoding="utf-8")
    (data / "tessdata_path.txt").write_text(str(tessdata), encoding="utf-8")
    log("OCR languages READY: kor, eng, osd.")
    log("Tesseract/OCR environment READY.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"OCR BOOTSTRAP ERROR: {type(exc).__name__}: {exc}", flush=True)
        raise SystemExit(55)
