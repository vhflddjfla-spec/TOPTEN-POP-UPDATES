﻿@echo off
setlocal EnableExtensions
chcp 65001 >nul
set "ROOT=%~dp0"
cd /d "%ROOT%"
title TOPTEN PRICE MASTER V5.1.18

echo ============================================================
echo TOPTEN PRICE MASTER V5.1.18
echo - 실사용 data\TOPTEN_가격정책_마스터.xlsx만 사용
echo - 초기본 재생성/대체 금지
echo - 예약 적용 + 기간종료 복귀 + 신상 등록 + 완료/대체 행 자동정리 + 중앙배포
echo ============================================================
echo.

if not exist "%ROOT%data\TOPTEN_가격정책_마스터.xlsx" (
  echo [ERROR] 실사용 가격정책 마스터가 없습니다.
  echo         %ROOT%data\TOPTEN_가격정책_마스터.xlsx
  echo.
  echo 초기본으로 대신 만들지 않습니다. RUN.cmd를 먼저 1회 실행하세요.
  pause
  exit /b 2
)

set "PYEXE="
if exist "%ROOT%data\python_path.txt" set /p PYEXE=<"%ROOT%data\python_path.txt"
if defined PYEXE if exist "%PYEXE%" goto run_path
set "PYEXE="
where py >nul 2>&1 && set "PYEXE=py -3"
if defined PYEXE goto run_command
where python >nul 2>&1 && set "PYEXE=python"
if defined PYEXE goto run_command

echo [ERROR] Python을 찾지 못했습니다. RUN.cmd를 먼저 1회 실행하세요.
pause
exit /b 1

:run_path
set "PYMODE=path"
echo [INFO] SOURCE = %ROOT%data\TOPTEN_가격정책_마스터.xlsx
"%PYEXE%" "%ROOT%publish_price_master.py"
set "RC=%ERRORLEVEL%"
goto after_run

:run_command
set "PYMODE=command"
echo [INFO] SOURCE = %ROOT%data\TOPTEN_가격정책_마스터.xlsx
%PYEXE% "%ROOT%publish_price_master.py"
set "RC=%ERRORLEVEL%"

:after_run
if not "%RC%"=="0" (
  echo.
  echo [ERROR] PRICEMASTER 생성 실패. 오류코드=%RC%
  echo 로그: %ROOT%data\logs\pricemaster.log
  if exist "%ROOT%data\logs\pricemaster.log" (
    echo ---------------- LOG ----------------
    type "%ROOT%data\logs\pricemaster.log"
    echo -------------------------------------
  )
  pause
  exit /b %RC%
)

if not exist "%ROOT%github_price_master_release\TOPTEN_PRICE_POLICY_MASTER.xlsx" goto output_missing
if not exist "%ROOT%github_price_master_release\price_master.json" goto output_missing

rem [HQ 2장 기간한정] Price master publication stays authoritative.
rem Generate HQ PPTX as an additional local output; don't block XLSX/JSON publication.
if exist "%ROOT%TOPTEN_기간한정_2장_POP_출력.py" if exist "%ROOT%본사_POP_원본.pptx" (
  echo [HQ] 기간한정 2장 상품 본사 하단바 POP 확인...
  if /I "%PYMODE%"=="path" (
    "%PYEXE%" "%ROOT%TOPTEN_기간한정_2장_POP_출력.py" --master "%ROOT%data\TOPTEN_가격정책_마스터.xlsx" --template "%ROOT%본사_POP_원본.pptx" --output "%ROOT%TOPTEN_기간한정_2장POP_출력.pptx"
  ) else (
    %PYEXE% "%ROOT%TOPTEN_기간한정_2장_POP_출력.py" --master "%ROOT%data\TOPTEN_가격정책_마스터.xlsx" --template "%ROOT%본사_POP_원본.pptx" --output "%ROOT%TOPTEN_기간한정_2장POP_출력.pptx"
  )
  if errorlevel 1 echo [WARNING] HQ PPTX 생성 실패. 가격정책 XLSX/JSON 배포는 정상 완료; python-pptx/원본 확인 필요.
)

echo.
echo [OK] 생성 완료
echo      %ROOT%github_price_master_release\TOPTEN_PRICE_POLICY_MASTER.xlsx
echo      %ROOT%github_price_master_release\price_master.json
start "" explorer "%ROOT%github_price_master_release"
pause
exit /b 0

:output_missing
echo.
echo [ERROR] Python은 성공 종료했지만 출력파일 검증에 실패했습니다.
echo 로그: %ROOT%data\logs\pricemaster.log
pause
exit /b 9
