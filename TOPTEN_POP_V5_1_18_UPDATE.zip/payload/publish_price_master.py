# -*- coding: utf-8 -*-
from __future__ import annotations
import copy
import hashlib
import json
import os
import re
import shutil
import sys
import urllib.request
import urllib.error
from datetime import datetime, date, timedelta
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font, Alignment
from openpyxl.utils import get_column_letter
from openpyxl.utils.datetime import from_excel
from arrival_intake_v517 import sync_arrival_file, compact_arrival, new_review

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
LIVE_MASTER = DATA / 'TOPTEN_가격정책_마스터.xlsx'
OUT = ROOT / 'github_price_master_release'
REMOTE_NAME = 'TOPTEN_PRICE_POLICY_MASTER.xlsx'
REMOTE_URL = 'https://raw.githubusercontent.com/vhflddjfla-spec/TOPTEN-POP-UPDATES/refs/heads/main/' + REMOTE_NAME
LOG_DIR = DATA / 'logs'
LOG_FILE = LOG_DIR / 'pricemaster.log'
BACKUP_DIR = ROOT / 'backups' / 'price_master_publish'

MASTER_SHEET = '가격정책마스터'
CHANGE_SHEET = '변경리스트_입력'
PERIOD_EDIT_SHEET = '행사기간_수정'
HISTORY_SHEET = '변경이력'
ARRIVAL_SHEET = '신상등록_입력'
ARRIVAL_REVIEW = '신상등록_품번별검토'
ARCHIVE_SHEET = '변경리스트_자동보관'

# V5.1.17 safe extension: two-piece display is a rendering variant of 기간한정.
# Never create a new '묶음할인' price policy or overwrite the one-item price.
TWO_PIECE_FORMAT = '본사 원본 2장 하단바'
TWO_PIECE_MASTER_FIELDS = (
    '차기기간한정 POP양식', 'POP표시수량(장)', 'POP표시가격(원)', '차기 1장판매가(원)',
    '차기행사시작일', '차기행사종료일', 'POP교체작업일(D-1)', '출력상태(날짜판정)'
)
TWO_PIECE_INPUT_FIELDS = ('기간한정 POP양식', 'POP표시수량(장)', '2장 표시가격(원)')

ARRIVAL_FILE = DATA / '신상리스트.xlsx'

# 매장 POP는 행사 종료일의 하루 전날 준비하므로,
# 행사 종료복귀는 종료일 D-1(행사종료일 - 1일)에 실행한다.
# 주의: 변경리스트_입력의 '적용일'은 원래부터 D-1 POP 작업일이므로 조정하지 않는다.
PERIOD_END_POP_LEAD_DAYS = 1


def is_period_return_due(event_end: date | None, today: date) -> bool:
    return event_end is not None and (event_end - timedelta(days=PERIOD_END_POP_LEAD_DAYS)) <= today

HISTORY_HEADERS = [
    '처리일시','적용일','작업유형','구분','품번','상품명','이전정책','이전가격','새정책','새가격',
    '행사시작일','행사종료일','기간종료후정책','기간종료후가격','원본내용','원본파일','처리메모'
]


def log(message: str):
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    line = f"[{datetime.now().isoformat(timespec='seconds')}] {message}"
    print(line, flush=True)
    with LOG_FILE.open('a', encoding='utf-8') as f:
        f.write(line + '\n')


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest().lower()


def n(value) -> int:
    try:
        if value in (None, ''):
            return 0
        return int(float(str(value).replace(',', '')))
    except Exception:
        return 0


def clean_code(value) -> str:
    return re.sub(r'[^A-Z0-9_-]', '', str(value or '').strip().upper())


def to_date(value):
    if value in (None, ''):
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, (int, float)) and 30000 <= float(value) <= 90000:
        return from_excel(value).date() if isinstance(from_excel(value), datetime) else from_excel(value)
    if isinstance(value, date):
        return value
    if hasattr(value, 'year') and hasattr(value, 'month') and hasattr(value, 'day'):
        try:
            return date(int(value.year), int(value.month), int(value.day))
        except Exception:
            pass
    text = str(value).strip()
    for fmt in ('%Y-%m-%d', '%Y/%m/%d', '%Y.%m.%d', '%m/%d', '%m-%d'):
        try:
            d = datetime.strptime(text[:10], fmt)
            if fmt.startswith('%m'):
                d = d.replace(year=datetime.now().year)
            return d.date()
        except Exception:
            pass
    return None


def normalize_policy(value) -> str:
    raw = str(value or '').strip()
    if not raw:
        return ''
    compact = re.sub(r'\s+', '', raw).replace('期間限定', '기간한정')
    if '기간한정' in compact or '기간한정할인' in compact:
        return '기간한정'
    if '가격인하' in compact or '가격하향' in compact or '가격유지' in compact:
        return '가격인하'
    if '정상가' in compact or '정상가격' in compact:
        return '정상가'
    return ''


def is_auto_policy(value) -> bool:
    raw = re.sub(r'\s+', '', str(value or '').strip())
    return raw in ('', '자동', '자동판정', '자동판단', '자동분류')


def infer_policy(normal_price, sale_price) -> str:
    normal, sale = n(normal_price), n(sale_price)
    if normal <= 0 or sale <= 0:
        return ''
    return '가격인하' if sale < normal else '정상가'


def infer_reduction_transition(existing_policy, existing_price, normal_price, new_price, has_existing=True) -> str:
    existing_policy = normalize_policy(existing_policy)
    old, normal, new = n(existing_price), n(normal_price), n(new_price)
    if not has_existing or existing_policy != '가격인하' or old <= 0:
        return '신규 가격인하'
    if new <= 0:
        return '가격 유지'
    if new < old:
        return '추가 가격인하'
    if new == old:
        return '가격 유지'
    if normal > 0 and new < normal:
        return '가격인하 가격조정'
    return '가격인하'


def money(value) -> str:
    v = n(value)
    return '-' if v <= 0 else f'{v:,}'


def header_map(ws, header_row=1):
    return {
        str(ws.cell(header_row, c).value or '').strip(): c
        for c in range(1, (ws.max_column or 40) + 1)
        if str(ws.cell(header_row, c).value or '').strip()
    }


def find_master_sheet(wb):
    candidates = []
    if MASTER_SHEET in wb.sheetnames:
        candidates.append(wb[MASTER_SHEET])
    candidates.extend(ws for ws in wb.worksheets if ws not in candidates)
    for ws in candidates:
        for r in range(1, min(ws.max_row or 25, 25) + 1):
            vals = [str(ws.cell(r, c).value or '').strip() for c in range(1, (ws.max_column or 40) + 1)]
            if '품번' in vals and '정상가' in vals and '가격정책' in vals and ('조정가' in vals or '할인가' in vals):
                return ws, r, {v: i + 1 for i, v in enumerate(vals) if v}
    raise RuntimeError('가격정책 마스터 헤더(품번/정상가/조정가/가격정책)를 찾지 못했습니다.')


def ensure_master_columns(ws, header_row, h):
    required = [
        '구분','품번','상품명','상품영문','정상가','조정가','프로모션 내용','가격정책','적용일',
        '행사시작일','행사종료일','기간종료후정책','기간종료후가격','원본정책문구','최종동기화일','원본파일'
    ]
    for name in required + list(TWO_PIECE_MASTER_FIELDS):
        if name not in h:
            col = (ws.max_column or 0) + 1
            ws.cell(header_row, col).value = name
            h[name] = col
    return h


def ensure_input_pop_columns(ws):
    h = header_map(ws)
    for key in TWO_PIECE_INPUT_FIELDS:
        if key not in h:
            col = ws.max_column + 1
            ws.cell(1, col).value = key
            h[key] = col
    return h


def clear_two_piece_meta(ws, row, h):
    for key in TWO_PIECE_MASTER_FIELDS:
        if key in h:
            ws.cell(row, h[key]).value = None


def apply_two_piece_meta(ws, row, h, rec):
    fmt = str(rec.get('pop_template') or '').strip()
    quantity = n(rec.get('pop_quantity'))
    price = n(rec.get('pop_price'))
    if not fmt:
        # Ordinary period-limited promotions must use the original POP logic.
        clear_two_piece_meta(ws, row, h)
        return
    if fmt != TWO_PIECE_FORMAT or quantity != 2 or price <= 0:
        raise ValueError('2장 기간한정: POP양식/표시수량/표시가격을 확인하세요.')
    start = rec.get('event_start')
    end = rec.get('event_end')
    if not isinstance(start, date) or not isinstance(end, date) or start > end:
        raise ValueError('2장 기간한정: 행사시작일/종료일이 유효하지 않습니다.')
    workday = start - timedelta(days=1)
    attrs = (fmt, quantity, price, n(rec.get('sale')),
             start, end, workday)
    for key, value in zip(TWO_PIECE_MASTER_FIELDS, attrs):
        ws.cell(row, h[key]).value = value
    current = row
    q, w, v = (get_column_letter(h[k]) for k in (
        '차기기간한정 POP양식', 'POP교체작업일(D-1)', '차기행사종료일'))
    ws.cell(current, h['출력상태(날짜판정)']).value = (
        f'=IF(OR({q}{current}="",{w}{current}="",{v}{current}=""),"",'
        f'IF(TODAY()<{w}{current},"예약(기존 POP)",'
        f'IF(TODAY()<{v}{current},"본사 2장 하단바 POP","종료/복귀 POP")))'
    )


def pending_two_piece_due(path: Path, today: date):
    # Older Flask /apply-live code cannot read new O:Q columns safely.
    wb = load_workbook(path, read_only=True, data_only=False)
    try:
        if CHANGE_SHEET not in wb.sheetnames:
            return False
        ws = wb[CHANGE_SHEET]
        h = header_map(ws)
        for row in ws.iter_rows(min_row=2, values_only=True):
            def val(name):
                i = h.get(name, 0) - 1
                return row[i] if 0 <= i < len(row) else None
            if str(val('기간한정 POP양식') or '').strip() != TWO_PIECE_FORMAT:
                continue
            if str(val('처리상태') or '').startswith('처리완료'):
                continue
            when = to_date(val('적용일'))
            if when is None or when <= today:
                return True
        return False
    finally:
        wb.close()


def ensure_history_sheet(wb):
    if HISTORY_SHEET not in wb.sheetnames:
        ws = wb.create_sheet(HISTORY_SHEET)
        for c, name in enumerate(HISTORY_HEADERS, 1):
            ws.cell(1, c).value = name
    return wb[HISTORY_SHEET]


def history_append(ws, values):
    row = ws.max_row or 1
    check_cols = max(1, min(ws.max_column or len(values), len(values)))
    while row > 1 and not any(ws.cell(row, c).value not in (None, '') for c in range(1, check_cols + 1)):
        row -= 1
    row += 1
    for c, value in enumerate(values, 1):
        ws.cell(row, c).value = value
    return row


def build_code_rows(ws, h, header_row):
    out = {}
    for r in range(header_row + 1, (ws.max_row or 0) + 1):
        code = clean_code(ws.cell(r, h['품번']).value)
        if code:
            out[code] = r
    return out


def copy_previous_style(ws, row, header_row):
    if row - 1 <= header_row:
        return
    for c in range(1, (ws.max_column or 0) + 1):
        src, dst = ws.cell(row - 1, c), ws.cell(row, c)
        if src.has_style:
            dst._style = copy.copy(src._style)
        if src.number_format:
            dst.number_format = src.number_format
        if src.alignment:
            dst.alignment = copy.copy(src.alignment)
        if src.protection:
            dst.protection = copy.copy(src.protection)


def master_baseline(ws, row, h):
    old_policy = normalize_policy(ws.cell(row, h['가격정책']).value)
    old_normal = n(ws.cell(row, h['정상가']).value)
    old_sale = n(ws.cell(row, h['조정가']).value)
    old_base_policy = normalize_policy(ws.cell(row, h['기간종료후정책']).value)
    old_base_price = n(ws.cell(row, h['기간종료후가격']).value)
    if old_policy == '기간한정':
        base_policy = old_base_policy or ('정상가' if old_sale >= old_normal and old_normal > 0 else '가격인하')
        base_price = old_base_price or (old_normal if base_policy == '정상가' else old_sale)
    else:
        base_policy = old_policy or ('정상가' if old_sale >= old_normal and old_normal > 0 else '가격인하')
        base_price = old_normal if base_policy == '정상가' else old_sale
    return old_policy, old_normal, old_sale, base_policy, base_price


def apply_policy_change(ws, row, h, rec):
    old_policy, old_normal, old_sale, base_policy, base_price = master_baseline(ws, row, h)
    old_start = to_date(ws.cell(row, h['행사시작일']).value)
    old_end = to_date(ws.cell(row, h['행사종료일']).value)
    old_return_policy = normalize_policy(ws.cell(row, h['기간종료후정책']).value)
    old_return_price = n(ws.cell(row, h['기간종료후가격']).value)

    incoming_policy = normalize_policy(rec.get('policy'))
    incoming_normal = n(rec.get('normal')) or old_normal
    incoming_sale = n(rec.get('sale'))
    ref = rec.get('apply_date') or datetime.now().date()
    if isinstance(ref, datetime):
        ref = ref.date()
    if not isinstance(ref, date):
        ref = datetime.now().date()

    had_existing = bool(old_policy or old_normal > 0 or old_sale > 0 or old_return_policy or old_return_price > 0)
    decision = incoming_policy or ''
    if incoming_policy == '가격인하':
        decision = infer_reduction_transition(base_policy, base_price, incoming_normal, incoming_sale or base_price, had_existing)

    # R5: a valid dated reduction supersedes an active period, not merely its return baseline.
    preserve_period = (old_policy == '기간한정' and old_end is not None and ref <= old_end
                       and (incoming_policy == '정상가' or (incoming_policy == '가격인하' and incoming_sale <= 0)))

    if rec.get('season'):
        ws.cell(row, h['구분']).value = rec['season']
    if rec.get('title_ko'):
        ws.cell(row, h['상품명']).value = rec['title_ko']
    if rec.get('title_en'):
        ws.cell(row, h['상품영문']).value = rec['title_en']
    if rec.get('normal_raw') not in (None, '') or rec.get('normal'):
        ws.cell(row, h['정상가']).value = rec.get('normal_raw') if rec.get('normal_raw') not in (None, '') else incoming_normal
    if rec.get('promo') not in (None, ''):
        ws.cell(row, h['프로모션 내용']).value = rec.get('promo')

    raw_label = str(rec.get('raw_policy') or '').strip()
    typed_mismatch = incoming_policy == '가격인하' and raw_label and raw_label not in ('가격인하', '자동판정') and decision not in raw_label
    typed_note = f" · 입력 '{raw_label}' → 마스터 기준 재판정" if typed_mismatch else ''

    if incoming_policy == '기간한정':
        if old_policy == '기간한정':
            return_policy = old_return_policy or base_policy
            return_price = old_return_price or base_price
        else:
            return_policy = base_policy
            return_price = base_price
        if not return_policy:
            candidate = incoming_sale or incoming_normal
            return_policy = '정상가' if incoming_normal > 0 and candidate >= incoming_normal else '가격인하'
            return_price = incoming_normal if return_policy == '정상가' else candidate
        ws.cell(row, h['가격정책']).value = '기간한정'
        if incoming_sale > 0:
            ws.cell(row, h['조정가']).value = rec.get('sale_raw') if rec.get('sale_raw') not in (None, '') else incoming_sale
        if rec.get('event_start') is not None:
            ws.cell(row, h['행사시작일']).value = rec['event_start']
        if rec.get('event_end') is not None:
            ws.cell(row, h['행사종료일']).value = rec['event_end']
        ws.cell(row, h['기간종료후정책']).value = return_policy
        ws.cell(row, h['기간종료후가격']).value = return_price
        apply_two_piece_meta(ws, row, h, rec)
        decision = '기간한정'
        note = f'기간한정 적용 · 종료후 {return_policy} {money(return_price)}'
    elif preserve_period:
        if incoming_policy == '정상가':
            new_base_price = incoming_normal
            decision = '정상가'
        else:
            new_base_price = incoming_sale or base_price or old_sale
        ws.cell(row, h['기간종료후정책']).value = incoming_policy
        ws.cell(row, h['기간종료후가격']).value = new_base_price
        if incoming_policy == '가격인하':
            note = f'자동판정: {decision}{typed_note} · 기간한정 유지 · 종료후 기준 {money(base_price)} → {money(new_base_price)}'
        else:
            note = f'기간한정 유지 · 종료후 정상가 {money(new_base_price)}로 갱신'
    else:
        ws.cell(row, h['가격정책']).value = incoming_policy
        if incoming_policy == '정상가':
            ws.cell(row, h['조정가']).value = incoming_normal
            decision = '정상가'
            note = f'정상가 기준정책 반영 · {money(incoming_normal)}'
        elif incoming_policy == '가격인하':
            new_sale = incoming_sale or base_price or old_sale
            if new_sale > 0:
                ws.cell(row, h['조정가']).value = rec.get('sale_raw') if rec.get('sale_raw') not in (None, '') else new_sale
            if decision == '가격 유지':
                note = f'자동판정: 가격 유지{typed_note} · {money(new_sale)} 유지'
            else:
                before_price = base_price if base_price > 0 else (old_sale if old_sale > 0 else incoming_normal)
                note = f'자동판정: {decision}{typed_note} · {money(before_price)} → {money(new_sale)}'
        else:
            raise RuntimeError(f'지원하지 않는 가격정책: {incoming_policy or rec.get("raw_policy")}')
        if old_policy == '기간한정' and incoming_policy == '가격인하':
            note += f' · 기존 기간한정 종료, 적용일 {ref.isoformat()}부터 가격인하 우선'
        ws.cell(row, h['행사시작일']).value = None
        ws.cell(row, h['행사종료일']).value = None
        ws.cell(row, h['기간종료후정책']).value = None
        ws.cell(row, h['기간종료후가격']).value = None
        clear_two_piece_meta(ws, row, h)

    if rec.get('apply_date') is not None:
        ws.cell(row, h['적용일']).value = rec.get('apply_date')
    ws.cell(row, h['원본정책문구']).value = rec.get('raw_policy') or decision or incoming_policy
    ws.cell(row, h['최종동기화일']).value = datetime.now()
    ws.cell(row, h['원본파일']).value = rec.get('source_name') or 'PRICEMASTER.cmd'
    return {
        'old_policy': old_policy,
        'old_price': old_sale,
        'new_policy': normalize_policy(ws.cell(row, h['가격정책']).value),
        'new_price': n(ws.cell(row, h['조정가']).value),
        'event_start': to_date(ws.cell(row, h['행사시작일']).value),
        'event_end': to_date(ws.cell(row, h['행사종료일']).value),
        'return_policy': normalize_policy(ws.cell(row, h['기간종료후정책']).value),
        'return_price': n(ws.cell(row, h['기간종료후가격']).value),
        'decision': decision,
        'note': note,
    }


def settle_workbook(path: Path, today: date | None = None):
    """Apply due input rows, and period expirations on D-1 POP preparation day.

    Future 예약대기 rows are preserved. The live workbook is replaced atomically only
    after a complete save/validation succeeds.
    """
    today = today or datetime.now().date()
    tmp = DATA / 'pricemaster_publish_settle.tmp.xlsx'
    shutil.copy2(path, tmp)
    wb = load_workbook(tmp)
    try:
        ws, header_row, h = find_master_sheet(wb)
        h = ensure_master_columns(ws, header_row, h)
        hist = ensure_history_sheet(wb)
        code_rows = build_code_rows(ws, h, header_row)
        now = datetime.now()
        expired = 0
        processed = 0
        duplicates = 0
        added = 0
        errors = 0
        scheduled = 0

        # 1) 기간한정 종료일 D-1에 다음 날 POP를 위한 종료복귀를 처리한다.
        for r in range(header_row + 1, (ws.max_row or 0) + 1):
            if normalize_policy(ws.cell(r, h['가격정책']).value) != '기간한정':
                continue
            end = to_date(ws.cell(r, h['행사종료일']).value)
            if not is_period_return_due(end, today):
                continue
            code = clean_code(ws.cell(r, h['품번']).value)
            old_price = n(ws.cell(r, h['조정가']).value)
            old_start = to_date(ws.cell(r, h['행사시작일']).value)
            return_policy = normalize_policy(ws.cell(r, h['기간종료후정책']).value)
            return_price = n(ws.cell(r, h['기간종료후가격']).value)
            normal = n(ws.cell(r, h['정상가']).value)
            if return_policy not in ('정상가', '가격인하'):
                return_policy = '정상가' if normal > 0 and (return_price <= 0 or return_price >= normal) else '가격인하'
            new_price = (normal if normal > 0 else (return_price or old_price)) if return_policy == '정상가' else (return_price or old_price)
            if return_policy == '가격인하' and return_price <= 0:
                log(f'[주의] {code}: 가격인하 복귀가격 미입력(0원). 기존 기간한정 가격 '
                    f'{money(old_price)}을 임시 유지합니다. 원본 공지의 실제 복귀가격을 확인하세요.')
            ws.cell(r, h['가격정책']).value = return_policy
            if new_price > 0:
                ws.cell(r, h['조정가']).value = new_price
            ws.cell(r, h['적용일']).value = today
            ws.cell(r, h['행사시작일']).value = None
            ws.cell(r, h['행사종료일']).value = None
            ws.cell(r, h['기간종료후정책']).value = None
            ws.cell(r, h['기간종료후가격']).value = None
            clear_two_piece_meta(ws, r, h)
            ws.cell(r, h['원본정책문구']).value = f'기간한정 종료복귀 → {return_policy}'
            ws.cell(r, h['최종동기화일']).value = now
            ws.cell(r, h['원본파일']).value = 'PRICEMASTER.cmd 중앙배포 전 자동복귀'
            note = (f'행사종료 {end.isoformat()} · D-1 POP 작업일 {today.isoformat()}에 '
                    f'{return_policy} {money(new_price)} 복귀')
            if return_policy == '가격인하' and return_price <= 0:
                note += ' · [확인필요] 원래 복귀가격이 0원이라 직전 기간한정가를 임시 유지'
            history_append(hist, [
                now, today, '기간한정 종료복귀', ws.cell(r, h['구분']).value, code, ws.cell(r, h['상품명']).value,
                '기간한정', old_price, return_policy, new_price, old_start, end, return_policy, new_price,
                '기간한정 자동종료', 'PRICEMASTER.cmd', note
            ])
            expired += 1

        # 2) 변경리스트의 오늘/과거 적용일 행만 처리한다. 미래행은 예약대기 유지.
        if CHANGE_SHEET in wb.sheetnames:
            cws = wb[CHANGE_SHEET]
            ch = ensure_input_pop_columns(cws)
            seen = {}
            due_row_order = sorted(range(2, (cws.max_row or 0) + 1), key=lambda rr: (
                to_date(cws.cell(rr, ch.get('적용일', 1)).value) or date.min, rr))
            for r in due_row_order:
                vals = [cws.cell(r, c).value for c in range(1, min(cws.max_column or 0, 14) + 1)]
                if not any(v not in (None, '') for v in vals):
                    continue
                code = clean_code(cws.cell(r, ch.get('품번', 3)).value)
                if not code:
                    continue
                status = str(cws.cell(r, ch.get('처리상태', 12)).value or '').strip()
                if status.startswith('처리완료'):
                    continue
                apply_date = to_date(cws.cell(r, ch.get('적용일', 1)).value)
                if apply_date and apply_date > today:
                    cws.cell(r, ch.get('처리상태', 12)).value = '예약대기'
                    cws.cell(r, ch.get('처리일', 13)).value = None
                    cws.cell(r, ch.get('처리메모', 14)).value = f'{apply_date.isoformat()} 00:00부터 자동판정/반영 예정'
                    scheduled += 1
                    continue

                row = code_rows.get(code)
                existing_normal = n(ws.cell(row, h['정상가']).value) if row else 0
                normal_raw = cws.cell(r, ch.get('정상가', 6)).value
                sale_raw = cws.cell(r, ch.get('조정가', 7)).value
                effective_normal = n(normal_raw) or existing_normal
                input_sale = n(sale_raw)
                raw = str(cws.cell(r, ch.get('정책/변경내용', 9)).value or '').strip()
                event_start = to_date(cws.cell(r, ch.get('행사시작일', 10)).value)
                event_end = to_date(cws.cell(r, ch.get('행사종료일', 11)).value)
                policy = normalize_policy(raw)
                if is_auto_policy(raw):
                    if event_start and event_end:
                        policy = '기간한정'; raw = '자동판정(행사기간)'
                    elif event_start or event_end:
                        cws.cell(r, ch.get('처리상태', 12)).value = '오류'
                        cws.cell(r, ch.get('처리메모', 14)).value = '기간한정은 행사시작일/종료일을 모두 입력해 주세요.'
                        errors += 1; continue
                    else:
                        policy = infer_policy(effective_normal, input_sale)
                        raw = '자동판정'
                if not policy:
                    cws.cell(r, ch.get('처리상태', 12)).value = '오류'
                    cws.cell(r, ch.get('처리메모', 14)).value = '정책/변경내용 확인 필요'
                    errors += 1; continue
                if policy == '기간한정' and (not event_start or not event_end):
                    cws.cell(r, ch.get('처리상태', 12)).value = '오류'
                    cws.cell(r, ch.get('처리메모', 14)).value = '기간한정은 시작일/종료일 필수'
                    errors += 1; continue
                if event_start and event_end and event_start > event_end:
                    cws.cell(r, ch.get('처리상태', 12)).value = '오류'
                    cws.cell(r, ch.get('처리메모', 14)).value = '행사 시작일이 종료일보다 늦음'
                    errors += 1; continue

                promo = str(cws.cell(r, ch.get('프로모션 내용', 8)).value or '').strip()
                pop_fmt = str(cws.cell(r, ch['기간한정 POP양식']).value or '').strip()
                pop_quantity = n(cws.cell(r, ch['POP표시수량(장)']).value)
                pop_price = n(cws.cell(r, ch['2장 표시가격(원)']).value)
                if pop_fmt and (policy != '기간한정' or pop_fmt != TWO_PIECE_FORMAT or pop_quantity != 2 or pop_price <= 0):
                    cws.cell(r, ch.get('처리상태', 12)).value = '오류'
                    cws.cell(r, ch.get('처리메모', 14)).value = '본사 2장 하단바: 기간한정/수량2/표시가격을 확인하세요.'
                    errors += 1; continue
                if (pop_quantity or pop_price) and not pop_fmt:
                    cws.cell(r, ch.get('처리상태', 12)).value = '오류'
                    cws.cell(r, ch.get('처리메모', 14)).value = '2장 표시정보가 있으나 기간한정 POP양식이 비어 있습니다.'
                    errors += 1; continue
                key = (code, apply_date, policy, effective_normal, input_sale, event_start, event_end, promo,
                       pop_fmt, pop_quantity, pop_price)
                if key in seen:
                    cws.cell(r, ch.get('처리상태', 12)).value = '처리완료(중복)'
                    cws.cell(r, ch.get('처리일', 13)).value = now
                    cws.cell(r, ch.get('처리메모', 14)).value = f'동일 입력 중복 · {seen[key]}행 적용값 사용'
                    duplicates += 1; continue
                seen[key] = r

                if row is None:
                    row = (ws.max_row or header_row) + 1
                    copy_previous_style(ws, row, header_row)
                    ws.cell(row, h['품번']).value = code
                    code_rows[code] = row
                    added += 1

                rec = {
                    'season': str(cws.cell(r, ch.get('구분', 2)).value or '').strip(),
                    'code': code,
                    'title_ko': str(cws.cell(r, ch.get('상품명', 4)).value or '').strip(),
                    'title_en': str(cws.cell(r, ch.get('상품영문', 5)).value or '').strip(),
                    'normal_raw': normal_raw,
                    'sale_raw': sale_raw,
                    'normal': effective_normal,
                    'sale': input_sale,
                    'promo': promo,
                    'policy': policy,
                    'raw_policy': raw,
                    'event_start': event_start,
                    'event_end': event_end,
                    'apply_date': apply_date,
                    'source_name': 'PRICEMASTER.cmd 중앙배포 전 자동반영',
                    'pop_template': pop_fmt,
                    'pop_quantity': pop_quantity,
                    'pop_price': pop_price,
                }
                result = apply_policy_change(ws, row, h, rec)
                history_append(hist, [
                    now, apply_date, result.get('decision') or raw or policy, ws.cell(row, h['구분']).value, code, ws.cell(row, h['상품명']).value,
                    result['old_policy'], result['old_price'], result['new_policy'], result['new_price'],
                    result['event_start'], result['event_end'], result['return_policy'], result['return_price'],
                    raw, 'PRICEMASTER.cmd', result['note']
                ])
                cws.cell(r, ch.get('처리상태', 12)).value = '처리완료'
                cws.cell(r, ch.get('처리일', 13)).value = now
                cws.cell(r, ch.get('처리메모', 14)).value = result['note']
                processed += 1

        # 3) 행사기간_수정의 미처리행은 즉시 반영한다.
        if PERIOD_EDIT_SHEET in wb.sheetnames:
            pws = wb[PERIOD_EDIT_SHEET]
            ph = header_map(pws, 1)
            seen_period = {}
            for r in range(2, (pws.max_row or 0) + 1):
                vals = [pws.cell(r, c).value for c in range(1, min(pws.max_column or 0, 7) + 1)]
                if not any(v not in (None, '') for v in vals):
                    continue
                status = str(pws.cell(r, ph.get('처리상태', 5)).value or '').strip()
                if status.startswith('처리완료'):
                    continue
                code = clean_code(pws.cell(r, ph.get('품번', 1)).value)
                mr = code_rows.get(code)
                if not code or mr is None:
                    pws.cell(r, ph.get('처리상태', 5)).value = '오류'
                    pws.cell(r, ph.get('처리메모', 7)).value = '마스터에서 품번을 찾지 못함'
                    errors += 1; continue
                if normalize_policy(ws.cell(mr, h['가격정책']).value) != '기간한정':
                    pws.cell(r, ph.get('처리상태', 5)).value = '오류'
                    pws.cell(r, ph.get('처리메모', 7)).value = '현재 기간한정 품번이 아님'
                    errors += 1; continue
                old_s, old_e = to_date(ws.cell(mr, h['행사시작일']).value), to_date(ws.cell(mr, h['행사종료일']).value)
                new_s = to_date(pws.cell(r, ph.get('새 행사시작일', 2)).value) or old_s
                new_e = to_date(pws.cell(r, ph.get('새 행사종료일', 3)).value) or old_e
                if not new_s or not new_e or new_s > new_e:
                    pws.cell(r, ph.get('처리상태', 5)).value = '오류'
                    pws.cell(r, ph.get('처리메모', 7)).value = '행사기간 확인 필요'
                    errors += 1; continue
                reason = str(pws.cell(r, ph.get('변경사유', 4)).value or '').strip()
                key = (code, new_s, new_e, reason)
                if key in seen_period:
                    pws.cell(r, ph.get('처리상태', 5)).value = '처리완료(중복)'
                    pws.cell(r, ph.get('처리일', 6)).value = now
                    pws.cell(r, ph.get('처리메모', 7)).value = f'동일 기간수정 중복 · {seen_period[key]}행 적용값 사용'
                    duplicates += 1; continue
                seen_period[key] = r
                ws.cell(mr, h['행사시작일']).value = new_s
                ws.cell(mr, h['행사종료일']).value = new_e
                ws.cell(mr, h['최종동기화일']).value = now
                ws.cell(mr, h['원본파일']).value = 'PRICEMASTER.cmd 중앙배포 전 기간수정'
                note = f'행사기간 {old_s or "-"}~{old_e or "-"} → {new_s}~{new_e}'
                history_append(hist, [
                    now, None, '행사기간 수정', ws.cell(mr, h['구분']).value, code, ws.cell(mr, h['상품명']).value,
                    '기간한정', n(ws.cell(mr, h['조정가']).value), '기간한정', n(ws.cell(mr, h['조정가']).value),
                    new_s, new_e, normalize_policy(ws.cell(mr, h['기간종료후정책']).value), n(ws.cell(mr, h['기간종료후가격']).value),
                    reason, 'PRICEMASTER.cmd', note
                ])
                pws.cell(r, ph.get('처리상태', 5)).value = '처리완료'
                pws.cell(r, ph.get('처리일', 6)).value = now
                pws.cell(r, ph.get('처리메모', 7)).value = note
                processed += 1

        try:
            for table in ws.tables.values():
                table.ref = f'A{header_row}:{get_column_letter(ws.max_column)}{ws.max_row}'
                break
        except Exception:
            pass

        wb.save(tmp)
    finally:
        wb.close()

    # Validate the saved temp before replacing the live source.
    test = load_workbook(tmp, read_only=True, data_only=False)
    try:
        tws, tr, th = find_master_sheet(test)
        for req in ('품번','정상가','조정가','가격정책'):
            if req not in th:
                raise RuntimeError('저장 후 필수열 검증 실패: ' + req)
        if (tws.max_row or 0) <= tr:
            raise RuntimeError('저장 후 마스터 데이터가 비어 있습니다.')
    finally:
        test.close()

    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup = BACKUP_DIR / f'TOPTEN_가격정책_마스터_before_publish_{stamp}.xlsx'
    shutil.copy2(path, backup)
    os.replace(tmp, path)
    return {
        'processed': processed,
        'expired': expired,
        'duplicates': duplicates,
        'added': added,
        'errors': errors,
        'scheduled': scheduled,
        'backup': str(backup),
    }


def due_summary(path: Path, today: date | None = None):
    """Return unprocessed input rows due, plus D-1 POP period expirations."""
    today = today or datetime.now().date()
    wb = load_workbook(path, read_only=True, data_only=False)
    due, expired, scheduled = 0, 0, 0
    try:
        ws, header_row, h = find_master_sheet(wb)
        for row in ws.iter_rows(min_row=header_row + 1, values_only=True):
            idx_policy = h.get('가격정책', 0) - 1
            idx_end = h.get('행사종료일', 0) - 1
            if idx_policy >= 0 and idx_end >= 0 and idx_policy < len(row) and idx_end < len(row):
                if normalize_policy(row[idx_policy]) == '기간한정':
                    end = to_date(row[idx_end])
                    if is_period_return_due(end, today):
                        expired += 1
        if CHANGE_SHEET in wb.sheetnames:
            cws = wb[CHANGE_SHEET]
            header = next(cws.iter_rows(min_row=1, max_row=1, values_only=True), ())
            ch = {str(v or '').strip(): i for i, v in enumerate(header)}
            for row in cws.iter_rows(min_row=2, values_only=True):
                if not any(v not in (None, '') for v in row[:14]):
                    continue
                status = str(row[ch.get('처리상태', 11)] if ch.get('처리상태', 11) < len(row) else '' or '').strip()
                if status.startswith('처리완료'):
                    continue
                ad = to_date(row[ch.get('적용일', 0)] if ch.get('적용일', 0) < len(row) else None)
                if ad and ad > today:
                    scheduled += 1
                else:
                    due += 1
        if PERIOD_EDIT_SHEET in wb.sheetnames:
            pws = wb[PERIOD_EDIT_SHEET]
            header = next(pws.iter_rows(min_row=1, max_row=1, values_only=True), ())
            ph = {str(v or '').strip(): i for i, v in enumerate(header)}
            for row in pws.iter_rows(min_row=2, values_only=True):
                if not any(v not in (None, '') for v in row[:7]):
                    continue
                status = str(row[ph.get('처리상태', 4)] if ph.get('처리상태', 4) < len(row) else '' or '').strip()
                if not status.startswith('처리완료'):
                    due += 1
        return {'due': due, 'expired': expired, 'scheduled': scheduled}
    finally:
        wb.close()


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def try_running_app_apply():
    """If the app is running, let its own route settle the master first."""
    port = os.environ.get('TOPTEN_POP_PORT', '8080')
    url = f'http://127.0.0.1:{port}/price-master/apply-live'
    req = urllib.request.Request(url, data=b'', method='POST')
    opener = urllib.request.build_opener(NoRedirect)
    try:
        with opener.open(req, timeout=8) as r:
            return 200 <= int(getattr(r, 'status', 200)) < 400
    except urllib.error.HTTPError as exc:
        # Flask route returns 302 after synchronous processing. With redirects blocked,
        # that 302 is success and guarantees the route already finished its workbook work.
        return exc.code in (301, 302, 303, 307, 308)
    except Exception:
        return False



# --- V5.1.10 extension: arrival intake + safe input-row archiving ---
ARRIVAL_HEADERS = [
    '제품코드','칼라','상품명','상품명(영문)','소비자가','판매기준가','적용 시작일','적용구분',
    '마스터 등록','예약대기 여부','자료/등록 판정','품번 중복 안내','POP 작업 참고일(D-1)'
]
ARCHIVE_HEADERS = [
    '적용일','구분','품번','상품명','상품영문','정상가','조정가','프로모션 내용',
    '정책/변경내용','행사시작일','행사종료일','처리상태','처리일','처리메모',
    '보관일시','보관사유'
]


def _set_if_different(ws, row, col, value):
    cell = ws.cell(row, col)
    if isinstance(value, date) and isinstance(cell.value, (date, datetime)) and to_date(cell.value) == to_date(value):
        return False
    if cell.value != value:
        cell.value = value
        return True
    return False


def _ensure_arrival_sheet(wb):
    '''Create an editable, independent item-intake sheet; import data\신상리스트.xlsx once if supplied.'''
    if ARRIVAL_SHEET in wb.sheetnames:
        return wb[ARRIVAL_SHEET], False, 0
    ws = wb.create_sheet(ARRIVAL_SHEET)
    for i, title in enumerate(ARRIVAL_HEADERS, 1):
        c = ws.cell(1, i, title)
        c.fill = PatternFill('solid', fgColor='243B53')
        c.font = Font(color='FFFFFF', bold=True)
        c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    ws.row_dimensions[1].height = 32
    for col, width in {'A':18,'B':10,'C':38,'D':39,'E':14,'F':15,'G':18,'H':17,'I':15,'J':18,'K':25,'L':20,'M':22}.items():
        ws.column_dimensions[col].width = width
    ws.freeze_panes = 'C2'
    ws.auto_filter.ref = 'A1:M1'
    count = 0
    if ARRIVAL_FILE.is_file():
        source = load_workbook(ARRIVAL_FILE, read_only=True, data_only=True)
        try:
            match = None
            for s in source.worksheets:
                first = [str(s.cell(1,c).value or '').strip() for c in range(1,9)]
                if first[:2] == ['제품코드', '칼라'] and '판매기준가' in first:
                    match = s
                    break
            if match is None:
                raise RuntimeError('신상리스트.xlsx A:H 헤더가 예상 형식(제품코드/칼라/.../판매기준가)이 아닙니다.')
            for vals in match.iter_rows(min_row=2, max_col=8, values_only=True):
                if not any(v not in ('',None) for v in vals):
                    continue
                ws.append(list(vals))
                count += 1
        finally:
            source.close()
    for row in range(2,ws.max_row+1):
        ws.cell(row,5).number_format = '#,##0'
        ws.cell(row,6).number_format = '#,##0'
        ws.cell(row,7).number_format = 'yyyy-mm-dd'
        ws.cell(row,13).number_format = 'yyyy-mm-dd'
    ws.auto_filter.ref = f'A1:M{max(ws.max_row,2)}'
    return ws, True, count


def _ensure_input_archive(wb):
    if ARCHIVE_SHEET in wb.sheetnames:
        ws = wb[ARCHIVE_SHEET]
        # Retain original legacy O/P columns (archived-at, reason); add Q:S.
        for c, title in enumerate(TWO_PIECE_INPUT_FIELDS, 17):
            if not ws.cell(1, c).value:
                ws.cell(1, c).value = title
        return ws, False
    ws = wb.create_sheet(ARCHIVE_SHEET)
    for col,title in enumerate(ARCHIVE_HEADERS,1):
        c=ws.cell(1,col,title)
        c.fill = PatternFill('solid', fgColor='394961')
        c.font = Font(color='FFFFFF', bold=True)
        c.alignment = Alignment(wrap_text=True)
    ws.freeze_panes = 'D2'
    for name,width in {'A':17,'B':11,'C':17,'D':35,'E':34,'F':14,'G':14,'H':27,'I':22,'J':17,'K':17,'L':23,'M':20,'N':49,'O':23,'P':23}.items():
        ws.column_dimensions[name].width=width
    ws.auto_filter.ref='A1:S2'
    for c, title in enumerate(TWO_PIECE_INPUT_FIELDS, 17):
        ws.cell(1, c).value = title
    return ws, True


def _archive_and_compact_input(wb, now, today):
    '''Show currently valid policy rows AND distinct future bookings, archive only expired/replaced ones.'''
    if CHANGE_SHEET not in wb.sheetnames:
        return 0,0,False
    src=wb[CHANGE_SHEET]
    headers=ensure_input_pop_columns(src)
    limit=max(14, *(headers.get(k, 14) for k in TWO_PIECE_INPUT_FIELDS))
    code_col=headers.get('품번',3)-1
    status_col=headers.get('처리상태',12)-1
    dates_col=headers.get('적용일',1)-1
    master,hrow,h=find_master_sheet(wb)
    mr=build_code_rows(master,h,hrow)
    active=[]; archived=[]; seen={}
    # A completed record is useful on screen while it STILL describes an effective policy.
    # Keep it with a status beginning 처리완료 so the main app does not re-apply it.
    for row_idx in range(2,src.max_row+1):
        values=tuple(src.cell(row_idx,c).value for c in range(1,limit+1))
        if not any(v not in (None,'') for v in values):
            continue
        code=clean_code(values[code_col])
        status=str(values[status_col] or '').strip()
        is_completed=status.startswith('처리완료')
        if is_completed:
            if '중복' in status or not code or code not in mr:
                archived.append((values,'중복/상품정보 없음'))
                continue
            row=mr[code]
            master_policy=normalize_policy(master.cell(row,h['가격정책']).value)
            master_price=n(master.cell(row,h['조정가']).value)
            master_return=normalize_policy(master.cell(row,h['기간종료후정책']).value)
            return_price=n(master.cell(row,h['기간종료후가격']).value)
            target_price=n(values[6])
            raw=str(values[8] or '')
            input_policy=normalize_policy(raw)
            event_start=to_date(values[9])
            event_end=to_date(values[10])
            if not input_policy and event_start and event_end:
                input_policy='기간한정'
            if not input_policy:
                input_policy=infer_policy(values[5],values[6])
            keep=False
            if input_policy=='기간한정':
                master_start=to_date(master.cell(row,h['행사시작일']).value)
                master_end=to_date(master.cell(row,h['행사종료일']).value)
                price_matches=(master_price==target_price) if target_price>0 else bool(values[7])
                keep=(event_end is not None and event_end>today and master_policy=='기간한정' and
                      master_end is not None and master_end>today and master_start==event_start and price_matches)
                # The master period edit can legitimately extend the end date. Display the live value.
                if keep and master_end and master_end!=event_end:
                    v=list(values);v[10]=master_end; values=tuple(v)
                active_label='처리완료(기간한정 진행)'
            elif input_policy in ('가격인하','정상가'):
                current_match=(master_policy==input_policy and master_price==target_price)
                baseline_match=(master_policy=='기간한정' and master_return==input_policy and return_price==target_price)
                keep=(target_price>0 and (current_match or baseline_match))
                active_label='처리완료(' + ('가격인하 유지' if input_policy=='가격인하' else '정상가 유지') + ')'
            else:
                keep=False
                active_label=status
            if not keep:
                archived.append((values,'기간종료 또는 최신 가격정책으로 대체됨'))
                continue
            if status!=active_label:
                v=list(values);v[status_col]=active_label;values=tuple(v)
        # The signature includes *all* source fields defining one price event, including its date.
        # Do not collapse separately dated price reductions or different sale prices.
        dedup_key=tuple(
            to_date(values[i]) if i in (0,9,10) else n(values[i]) if i in (5,6) else str(values[i] or '').strip()
            for i in range(11)
        ) + tuple(str(values[headers[k]-1] or '').strip() for k in TWO_PIECE_INPUT_FIELDS)
        if code and status!='오류' and dedup_key in seen:
            v=list(values);v[status_col]='처리완료(중복예약)'
            archived.append((tuple(v),f'동일 예약/유지 중복 · 원본 {seen[dedup_key]}행 유지'))
            continue
        if code and status!='오류':
            seen[dedup_key]=row_idx
        active.append((row_idx,values))
    # Current effective policies first; then future reservations (earlier dates first).
    active.sort(key=lambda pair:(
        0 if str(pair[1][status_col] or '').startswith('처리완료') else 1,
        to_date(pair[1][dates_col]) or date.min,
        pair[0]
    ))
    packed=[row for _,row in active]
    existing=[tuple(src.cell(r,c).value for c in range(1,limit+1)) for r in range(2,src.max_row+1)]
    result=packed+[(None,)*limit]*(len(existing)-len(packed))
    changed=existing!=result
    if archived:
        dest,_=_ensure_input_archive(wb)
        for vals,reason in archived:
            # Keep existing archive layout: A:N policy data, O timestamp, P reason.
            # Additional Q:S now retain the original O:Q 2-piece input values.
            dest.append([*vals[:14], now, reason, *(vals[headers[k]-1] for k in TWO_PIECE_INPUT_FIELDS)])
        dest.auto_filter.ref=f'A1:S{dest.max_row}'
        changed=True
    if changed:
        for r,vals in enumerate(result,2):
            for c,value in enumerate(vals,1):
                _set_if_different(src,r,c,value)
    return len(archived),len(packed),changed


def _refresh_arrival_review(wb, summary):
    if ARRIVAL_REVIEW not in wb.sheetnames:
        return False
    review=wb[ARRIVAL_REVIEW]
    changed=False
    for r in range(2,review.max_row+1):
        code=clean_code(review.cell(r,1).value)
        if code not in summary:
            continue
        item=summary[code]
        for col,value in ((9,item['policy']),(10,item['price']),(11,item['reserved']),(12,item['reservation_date']),
                          (13,item['status']),(14,item['note'])):
            changed |= _set_if_different(review,r,col,value)
    return changed


def _register_new_arrivals(wb, now, today):
    """Register only truly new codes. Blank sale price/date do not block normal-price SKU entry.

    A missing official sale date is NOT inferred. Undated discount prices are
    NEVER activated: the known consumer price is registered as normal price.
    Conflicting colors or unknown prices are sent for review without a zero-won POP.
    """
    arrival, created, imported = _ensure_arrival_sheet(wb)
    master, header, h = find_master_sheet(wb)
    h = ensure_master_columns(master, header, h)
    code_rows = build_code_rows(master, h, header)
    history = ensure_history_sheet(wb)
    pending = {}
    if CHANGE_SHEET in wb.sheetnames:
        cws = wb[CHANGE_SHEET]
        ch = header_map(cws, 1)
        for r in range(2, cws.max_row+1):
            sku = clean_code(cws.cell(r, ch.get('품번',3)).value)
            state = str(cws.cell(r, ch.get('처리상태',12)).value or '').strip()
            if sku and not state.startswith('처리완료'):
                ad = to_date(cws.cell(r, ch.get('적용일',1)).value)
                if sku not in pending or (ad and (pending[sku][0] is None or ad < pending[sku][0])):
                    pending[sku] = (ad, str(cws.cell(r, ch.get('정책/변경내용',9)).value or ''))
    groups = {}
    for r in range(2, arrival.max_row+1):
        sku = clean_code(arrival.cell(r,1).value)
        if sku:
            groups.setdefault(sku,[]).append(r)
    additions = 0
    changed = created
    summary = {}
    for sku, rows in groups.items():
        normals = {n(arrival.cell(r,5).value) for r in rows if n(arrival.cell(r,5).value)>0}
        sales = {n(arrival.cell(r,6).value) for r in rows if n(arrival.cell(r,6).value)>0}
        starts = {to_date(arrival.cell(r,7).value) for r in rows if to_date(arrival.cell(r,7).value)}
        representative = next((r for r in rows if arrival.cell(r,3).value), rows[0])
        normal = next(iter(normals),0)
        sale = next(iter(sales),0)
        start = next(iter(starts),None)
        conflicts = len(normals)>1 or len(sales)>1 or len(starts)>1
        if normal<=0 and sale>0:normal=sale
        if sale<=0 and normal>0:sale=normal
        if sku in code_rows:
            state='기존등록'
            note='기존 가격정책·예약·원본 가격 보호'
        elif conflicts:
            state='자료불일치'
            note='동일 품번의 색상별 가격/시작일 충돌 · 확인 전 자동등록 보류'
        elif normal<=0:
            state='자료확인'
            note='소비자가/판매기준가 모두 누락 · 0원 등록 방지, 검토필요 시트로 이동'
        elif start and today < (start-timedelta(days=1)):
            state='신상등록대기'
            note=f'판매 {start.isoformat()} · POP 작업 예정 {(start-timedelta(days=1)).isoformat()}'
        else:
            # If an official sale date is missing, register product details at
            # undiscounted normal price. Do NOT claim an undocumented reduction.
            safe_sale = normal if (not start and sale < normal) else sale
            if not start and sale < normal:
                new_review(wb, [*(arrival.cell(representative,c).value for c in range(1,9)),
                                None,None,None,None,None],
                           '시작일 없는 인하가격은 적용 불가 · 정상가로 상품정보만 등록됨')
            initial = '가격인하' if safe_sale < normal else '정상가'
            nr = master.max_row+1
            copy_previous_style(master,nr,header)
            master.cell(nr,h['품번']).value=sku
            master.cell(nr,h['상품명']).value=arrival.cell(representative,3).value
            master.cell(nr,h['상품영문']).value=arrival.cell(representative,4).value
            master.cell(nr,h['정상가']).value=normal
            master.cell(nr,h['조정가']).value=safe_sale
            master.cell(nr,h['가격정책']).value=initial
            master.cell(nr,h['적용일']).value=start-timedelta(days=1) if start else None
            master.cell(nr,h['프로모션 내용']).value=(
                '신상품 정보등록 · 공식 판매시작일 미기재' if not start else '신상품 최초 등록')
            master.cell(nr,h['원본정책문구']).value='신상리스트.xlsx 신규품번 자동등록'
            master.cell(nr,h['최종동기화일']).value=now
            master.cell(nr,h['원본파일']).value='신상리스트.xlsx'
            code_rows[sku]=nr
            note = ('공식 판매일 미기재 · 정상가 상품정보만 등록 · 인하가격 미적용'
                    if not start else f'판매 {start.isoformat()} · 가격정책과 예약은 별도 유지')
            history_append(history,[
                now,start-timedelta(days=1) if start else None,
                '신상 최초등록' if start else '신상 신규상품정보 등록',None,
                sku,arrival.cell(representative,3).value,None,None,initial,safe_sale,
                None,None,None,None,'신상리스트.xlsx','PRICEMASTER.cmd',note
            ])
            additions+=1
            changed=True
            state='등록완료'
        mr=code_rows.get(sku)
        policy=normalize_policy(master.cell(mr,h['가격정책']).value) if mr else '미등록'
        effective_price=n(master.cell(mr,h['조정가']).value) if mr else None
        queued=pending.get(sku)
        for r in rows:
            rd=to_date(arrival.cell(r,7).value)
            fields=[
                '기존등록' if mr else '미등록',
                '예약있음' if queued else '예약없음',
                state,
                '색상별 동일품번' if r!=rows[0] else '최초 등장',
                rd-timedelta(days=1) if rd else None,
            ]
            for c,val in enumerate(fields,9):
                changed |= _set_if_different(arrival,r,c,val)
        summary[sku]={'policy':policy,'price':effective_price,
                      'reserved':queued[1] if queued else '',
                      'reservation_date':queued[0] if queued else None,
                      'status':state,'note':note}
    changed |= _refresh_arrival_review(wb,summary)
    if additions:
        try:
            for table in master.tables.values():
                table.ref=f'A{header}:{get_column_letter(master.max_column)}{master.max_row}'
                break
        except Exception:
            pass
    arrival.auto_filter.ref=f'A1:M{max(2,arrival.max_row)}'
    return additions, imported, len(groups), changed


def maintain_intake_and_queue(path: Path, as_of: date | None = None):
    '''Run after normal V5.1.10 apply-live/standalone settle. Never overwrite existing prices.'''
    now=datetime.now()
    today=as_of or now.date()
    tmp=DATA / 'pricemaster_intake_maintain.tmp.xlsx'
    shutil.copy2(path,tmp)
    workbook=load_workbook(tmp)
    changed=False
    try:
        log('[ARRIVAL V5.1.17 R3] New-arrival source reconciliation enabled; existing D-1 price policy retained')
        # R3: read the current HQ arrivals on EVERY changed-file publication.
        # This runs even when there are no due price changes, and keeps existing POP policy intact.
        source_arrivals=sync_arrival_file(workbook,DATA)
        additions,imported,codes,a_changed=_register_new_arrivals(workbook,now,today)
        compact_arrivals=compact_arrival(workbook)
        archived,remaining,q_changed=_archive_and_compact_input(workbook,now,today)
        changed=bool(source_arrivals.get('changed') or a_changed or compact_arrivals.get('changed') or q_changed)
        if changed:
            workbook.save(tmp)
    finally:
        workbook.close()
    result={'new_items':additions,'imported_rows':imported,'distinct_arrivals':codes,
            'source_arrivals':source_arrivals,'arrival_compact':compact_arrivals,
            'archived_queue_rows':archived,'remaining_queue_rows':remaining,'changed':changed}
    if not changed:
        tmp.unlink(missing_ok=True)
        return result
    verify=load_workbook(tmp,read_only=True)
    try:
        v,_,_=find_master_sheet(verify)
        if v.max_row < 2 or ARRIVAL_SHEET not in verify.sheetnames or CHANGE_SHEET not in verify.sheetnames:
            raise RuntimeError('자동정리 검증 실패: 주요 시트가 없습니다.')
    finally:
        verify.close()
    BACKUP_DIR.mkdir(parents=True,exist_ok=True)
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    backup=BACKUP_DIR / f'TOPTEN_가격정책_마스터_before_intake_{stamp}.xlsx'
    shutil.copy2(path,backup)
    os.replace(tmp,path)
    result['backup']=str(backup)
    return result


def build_release():
    if not LIVE_MASTER.exists():
        raise RuntimeError('실사용 마스터가 없습니다: ' + str(LIVE_MASTER) + '\n초기본으로 대체 생성하지 않습니다. RUN.cmd를 1회 실행하세요.')

    log('SOURCE=' + str(LIVE_MASTER))
    before_sha = sha256(LIVE_MASTER)
    log('LIVE BEFORE SHA256=' + before_sha)
    before = due_summary(LIVE_MASTER)
    log('BEFORE due={due} expired={expired} future={scheduled}'.format(**before))

    # Running app route first; otherwise standalone processor uses the exact same rules.
    app_applied = False
    if before['due'] or before['expired']:
        # Mandatory: prefer the patched settlement code for new HQ two-piece rows.
        # Older app/app.py routes can mark O:Q metadata processed without copying it.
        has_two_piece_due = pending_two_piece_due(LIVE_MASTER, datetime.now().date())
        app_applied = False if has_two_piece_due else try_running_app_apply()
        if has_two_piece_due:
            log('HQ 2장 기간한정 예약행: 구버전 app/app.py 우회, 패치된 독립 처리 사용')
        if app_applied:
            log('Running app /price-master/apply-live completed')
        after_route = due_summary(LIVE_MASTER)
        if after_route['due'] or after_route['expired']:
            log('Standalone settle required after route/unavailable app')
            result = settle_workbook(LIVE_MASTER)
            log('SETTLE=' + json.dumps(result, ensure_ascii=False))
        else:
            log('No standalone settle needed')
    else:
        log('No due/expired rows; live master will be published as-is')

    # Always check intake/archiving even when no reservation falls due today.
    intake_result = maintain_intake_and_queue(LIVE_MASTER)
    log('INTAKE=' + json.dumps(intake_result, ensure_ascii=False))

    final_summary = due_summary(LIVE_MASTER)
    if final_summary['due'] or final_summary['expired']:
        raise RuntimeError(
            f'자동반영 후에도 미처리 대상이 남아 있습니다. due={final_summary["due"]}, expired={final_summary["expired"]}. '
            f'Excel에서 마스터가 열려 있으면 닫고 다시 실행하세요. 로그: {LOG_FILE}'
        )
    log('AFTER due=0 expired=0 future={}'.format(final_summary['scheduled']))

    # Never source or compare against the bundled initial workbook. Only live data master.
    OUT.mkdir(parents=True, exist_ok=True)
    dest = OUT / REMOTE_NAME
    shutil.copy2(LIVE_MASTER, dest)
    digest = sha256(dest)
    master_version = 'pm-' + digest[:16]
    manifest = {
        'schema_version': 2,
        'master_version': master_version,
        'file_name': REMOTE_NAME,
        'download_url': REMOTE_URL,
        'sha256': digest,
        'minimum_app_version': '5.1.18',
        'published_at': datetime.now().isoformat(timespec='seconds'),
        'message': 'TOPTEN V5.1.18 가격정책·신상등록·입력정리 ' + master_version,
    }
    (OUT / 'price_master.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    (OUT / 'README_UPLOAD.txt').write_text(
        'GitHub TOPTEN-POP-UPDATES 저장소 main 루트에 아래 2개 파일을 업로드/덮어쓰기 하세요.\n'
        '1) TOPTEN_PRICE_POLICY_MASTER.xlsx\n2) price_master.json\n\n'
        '반드시 XLSX를 먼저 올리고 price_master.json을 마지막에 올리세요.\n'
        'V5.1.18 PRICEMASTER는 data\\TOPTEN_가격정책_마스터.xlsx 실사용본만 사용하며 초기본을 절대 재생성/배포하지 않습니다.\n'
        '실행 시 적용일 도래 변경리스트와 행사종료일 D-1 자동복귀를 먼저 처리한 뒤 생성합니다.\n'
        '신상등록_입력은 없으면 자동 생성됩니다. data\\신상리스트.xlsx가 있으면 1회 가져옵니다.\n'
        '처리완료 행은 변경리스트_자동보관으로 이동하고 미래 예약행은 상단에 유지합니다.\n',
        encoding='utf-8'
    )
    result = {
        'ok': True,
        'source': str(LIVE_MASTER),
        'source_sha256': sha256(LIVE_MASTER),
        'output': str(dest),
        'sha256': digest,
        'master_version': master_version,
        'future_reservations': final_summary['scheduled'],
        'intake': intake_result,
        'generated_at': datetime.now().isoformat(timespec='seconds'),
    }
    (OUT / 'publish_result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    log('OUTPUT=' + str(dest))
    log('MASTER_VERSION=' + master_version)
    log('OUTPUT SHA256=' + digest)
    return result


def main():
    try:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        log('===== PRICEMASTER D-1 PERIOD RETURN + INTAKE/COMPACTION START =====')
        result = build_release()
        print('\n[OK] 현재 실사용 가격정책 기준 중앙배포 파일 생성 완료')
        print('SOURCE :', result['source'])
        print('OUTPUT :', result['output'])
        print('VERSION:', result['master_version'])
        print('SHA256 :', result['sha256'])
        print('미래 예약대기:', result['future_reservations'], '행 (정상 보존)')
        print('LOG    :', LOG_FILE)
        return 0
    except PermissionError as exc:
        log('ERROR PermissionError: ' + str(exc))
        print('\n[ERROR] 가격정책 마스터가 Excel에서 열려 있거나 파일 교체가 차단되었습니다.')
        print('Excel에서 TOPTEN_가격정책_마스터.xlsx를 완전히 닫고 다시 실행하세요.')
        print('상세:', exc)
        print('로그:', LOG_FILE)
        return 5
    except Exception as exc:
        log('ERROR ' + type(exc).__name__ + ': ' + str(exc))
        print('\n[ERROR]', exc)
        print('로그:', LOG_FILE)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
