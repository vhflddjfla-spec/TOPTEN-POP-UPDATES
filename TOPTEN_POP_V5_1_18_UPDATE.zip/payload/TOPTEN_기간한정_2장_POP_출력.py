#!/usr/bin/env python3
"""TOPTEN 기간한정 2장가격: original HQ A4 bottom-bar POP renderer.

Integrated with PRICEMASTER.cmd for safe standalone HQ bottom-bar PPTX generation.
The Flask app POP button still needs app/app.py to route 2-piece items.
Requires `python-pptx` in the local Python environment.

Usage:
  python TOPTEN_기간한정_2장_POP_출력.py --force
  python TOPTEN_기간한정_2장_POP_출력.py --date 2026-11-26
  python TOPTEN_기간한정_2장_POP_출력.py --date 2026-12-10

Read-only access to the price master. Does not change its prices or policy status.
"""
from __future__ import annotations
import argparse
import datetime as dt
import math
import re
import zipfile
import xml.etree.ElementTree as ET
from copy import deepcopy
from pathlib import Path

from pptx import Presentation
from pptx.enum.text import MSO_AUTO_SIZE
from pptx.util import Pt
from pptx.dml.color import RGBColor

BASE=Path(__file__).resolve().parent
MASTER=BASE/'data'/'TOPTEN_가격정책_마스터.xlsx'
TEMPLATE=BASE/'본사_POP_원본.pptx'
OUTPUT=BASE/'TOPTEN_기간한정_2장POP_출력.pptx'
_NS='{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'


def _xlsx_master_rows(path):
    """Use only stdlib zip XML for READ; preserve the original workbook entirely."""
    with zipfile.ZipFile(path) as z:
        allnames=z.namelist()
        shared=[]
        if 'xl/sharedStrings.xml' in allnames:
            strings=ET.fromstring(z.read('xl/sharedStrings.xml'))
            shared=[''.join(t.text or '' for t in si.iter(_NS+'t')) for si in strings.findall(_NS+'si')]
        # The current TOPTEN master has the price master as second worksheet.
        root=ET.fromstring(z.read('xl/worksheets/sheet2.xml'))
        rows=root.findall(_NS+'sheetData/'+_NS+'row')
        for row in rows:
            cells={}
            for c in row.findall(_NS+'c'):
                name=re.match(r'([A-Z]+)',c.get('r')).group(1)
                val=c.find(_NS+'v')
                if val is None and c.get('t')!='inlineStr':continue
                raw=val.text if val is not None else ''
                if c.get('t')=='s' and raw is not None: raw=shared[int(raw)]
                if c.get('t')=='inlineStr':raw=''.join(t.text or '' for t in c.iter(_NS+'t'))
                cells[name]=raw
            if cells.get('B'):
                yield cells


def _date_serial(d):return (d-dt.date(1899,12,30)).days

def _items_for_print(master_path, day, force=False):
    items=[]
    for row in _xlsx_master_rows(master_path):
        if row.get('Q')!='본사 원본 2장 하단바':continue
        if row.get('R')!='2':raise ValueError('Unexpected count for '+row['B'])
        start=int(float(row['U'])); end=int(float(row['V'])); work=int(float(row['W']))
        if not force and not (work<=_date_serial(day)<end):continue
        gender_name=row.get('C','')
        match=re.match(r'^\s*(남성|여성|키즈|공용)\)\s*(.+)',gender_name)
        gender,kr=(match.group(1),match.group(2)) if match else ('공용',gender_name)
        items.append(dict(style_code=row['B'],gender=gender,
          product_name_ko=kr,product_name_en=' '.join(row.get('D','').split()),
          single_price=int(float(row['T'])),bundle_quantity=2,
          bundle_price=int(float(row['S'])),source_policy='기간한정',
          event_period=(dt.date(1899,12,30)+dt.timedelta(days=start)).strftime('%m/%d').lstrip('0').replace('/0','/') +
            ' ~ ' + (dt.date(1899,12,30)+dt.timedelta(days=end)).strftime('%m/%d').lstrip('0').replace('/0','/')))
    return sorted(items,key=lambda p:(p['bundle_price'],p['gender'],p['style_code']))


def _change_text_keep_format(shape, content, fontsize=None):
    tf=shape.text_frame;paras=tf.paragraphs;lines=content.split('\n')
    while len(paras)<len(lines):paras.append(tf.add_paragraph())
    for ix,par in enumerate(tf.paragraphs):
        value=lines[ix] if ix<len(lines) else ''
        if par.runs:
            par.runs[0].text=value
            for run in par.runs[1:]:run.text=''
            if fontsize:par.runs[0].font.size=Pt(fontsize)
        else:
            run=par.add_run();run.text=value
            if fontsize:run.font.size=Pt(fontsize)
        if fontsize:
            for run in par.runs:run.font.size=Pt(fontsize)
    tf.auto_size=MSO_AUTO_SIZE.TEXT_TO_FIT_SHAPE


def _line_split_ko(s):
    if len(s)<15:return s
    toks=s.split(' '); maxw=17 if len(s)<28 else 15
    if len(toks)<2:return s
    lines=[];line=''
    for t in toks:
        joined=(line+' '+t).strip()
        if line and len(joined)>maxw:
            lines.append(line);line=t
        else:line=joined
    if line:lines.append(line)
    if len(lines)>3:lines=[lines[0],lines[1],' '.join(lines[2:])]
    return '\n'.join(lines)


def _all_shapes(slide):
    shapes=[s for s in slide.shapes if s.has_text_frame]
    names=sorted([s for s in shapes if '쿨에어코튼' in s.text],key=lambda s:s.top)
    ens=sorted([s for s in shapes if s.text.startswith('COOL AIR COTTON')],key=lambda s:s.top)
    prices=sorted([s for s in shapes if s.text=='399,900'],key=lambda s:s.top)
    gender=sorted([s for s in shapes if s.text=='남성'],key=lambda s:s.top)
    qty=sorted([s for s in shapes if s.text=='2'],key=lambda s:s.top)
    if not all(len(a)==6 for a in (names,ens,prices,gender,qty)):
        raise ValueError('Not the expected unmodified HQ two-piece POP template')
    return names,ens,prices,gender,qty


def _duplicate(prs,src):
    slide=prs.slides.add_slide(src.slide_layout)
    tree=slide.shapes._spTree
    for sh in list(slide.shapes):tree.remove(sh._element)
    for sh in src.shapes:tree.insert_element_before(deepcopy(sh.element),'p:extLst')
    for rel in src.part.rels.values():
        if rel.reltype.endswith('/slideLayout'):continue
        if rel.is_external:slide.part.relate_to(rel.target_ref,rel.reltype,is_external=True)
        else:slide.part.relate_to(rel.target_part,rel.reltype)
    return slide


def _blank_tail(slide,n_used):
    from pptx.enum.shapes import MSO_SHAPE
    from pptx.util import Inches
    if n_used==6:return
    top=Inches(0.64+n_used*1.73)
    rect=slide.shapes.add_shape(MSO_SHAPE.RECTANGLE,0,top,Inches(8.26),Inches(11.69)-top)
    rect.fill.solid();rect.fill.fore_color.rgb=RGBColor(255,255,255)
    rect.line.fill.background()


def _populate(slide,items):
    from pptx.util import Inches
    names,ens,prices,genders,qty=_all_shapes(slide)
    policy_tags=sorted([s for s in slide.shapes if s.has_text_frame and s.text.strip()=='기간한정'],key=lambda s:s.top)
    if len(policy_tags)!=6:
        raise ValueError('본사 기간한정 표기 원본이 아닙니다. 수정된 본사_POP_원본.pptx를 사용하세요.')
    for ix,p in enumerate(items):
        kr=_line_split_ko(p['product_name_ko']);maxline=max(map(len,kr.split('\n')))
        size=16 if len(kr.split('\n'))>2 else (20 if maxline<=17 else 18)
        en=p['product_name_en']
        _change_text_keep_format(names[ix],kr,size)
        _change_text_keep_format(ens[ix],en,10 if len(en)<=42 else 9)
        _change_text_keep_format(prices[ix],f"{p['bundle_price']:,}")
        _change_text_keep_format(genders[ix],p['gender'])
        _change_text_keep_format(qty[ix],'2')
        # HQ_2PCS_DATE_V1: Preserve HQ tags/price; add period on their top row.
        tag=policy_tags[ix]
        date_box=slide.shapes.add_textbox(Inches(1.98),tag.top-Inches(.015), Inches(2.18),Inches(.30))
        frame=date_box.text_frame
        frame.clear()
        frame.word_wrap=False
        frame.margin_left=frame.margin_right=0
        frame.margin_top=frame.margin_bottom=0
        para=frame.paragraphs[0]
        run=para.add_run(); run.text=p['event_period']
        run.font.name='DINPro-Medium'; run.font.size=Pt(15)
        run.font.color.rgb=RGBColor(210,39,33)
    for ix in range(len(items),6):
        for shape in (names[ix],ens[ix],prices[ix],genders[ix],qty[ix]):
            _change_text_keep_format(shape,'')
    _blank_tail(slide,len(items))


def render(items,template,out):
    prs=Presentation(str(template))
    if len(prs.slides)!=2:raise ValueError('HQ template must have 2 slides')
    source=prs.slides[1]
    sheets=[source]
    for _ in range(math.ceil(len(items)/6)-1):sheets.append(_duplicate(prs,source))
    first_id=prs.slides._sldIdLst[0];prs.part.drop_rel(first_id.rId);prs.slides._sldIdLst.remove(first_id)
    for page,slide in enumerate(sheets):_populate(slide,items[6*page:6*(page+1)])
    prs.save(str(out))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--master',type=Path,default=MASTER)
    p.add_argument('--template',type=Path,default=TEMPLATE)
    p.add_argument('--output',type=Path,default=OUTPUT)
    p.add_argument('--date',type=dt.date.fromisoformat,default=dt.date.today())
    p.add_argument('--force',action='store_true',help='Preview/prepare all registered 2-piece POPs regardless of date')
    args=p.parse_args()
    items=_items_for_print(args.master,args.date,args.force)
    if not items:
        if args.output.is_file():
            args.output.unlink()  # Remove only the generator-owned stale HQ promotion file.
        print(f'{args.date}: no scheduled HQ 2-piece period POP; the previously generated HQ PPTX (if any) was cleared.')
        return
    render(items,args.template,args.output)
    print('가격정책=기간한정 / 본사 원본 하단바 POP')
    print(f'{args.date}: printed {len(items)} styles, {math.ceil(len(items)/6)} A4 slides: {args.output}')

if __name__=='__main__':main()
