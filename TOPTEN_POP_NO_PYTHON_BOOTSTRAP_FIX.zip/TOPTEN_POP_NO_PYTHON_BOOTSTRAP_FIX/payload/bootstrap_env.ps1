param(
    [Parameter(Mandatory=$true)][string]$Root
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$Root = [IO.Path]::GetFullPath($Root.TrimEnd('\'))
$Log = Join-Path $Root 'run_setup_log.txt'
$TessDataDir = Join-Path $Root 'ocr_tessdata'
$TempDir = Join-Path $env:TEMP 'TOPTEN_POP_BOOTSTRAP'

# Hard safety gate: never download or run an installer on unsupported systems.
$nativeArch = if ($env:PROCESSOR_ARCHITEW6432) { $env:PROCESSOR_ARCHITEW6432 } else { $env:PROCESSOR_ARCHITECTURE }
if (-not [Environment]::Is64BitOperatingSystem) {
    Set-Content -LiteralPath $Log -Value 'TOPTEN POP V4.4.3 AUTO SETUP LOG' -Encoding UTF8
    Add-Content -LiteralPath $Log -Value '[BLOCKED] Windows 32-bit (x86) is not supported. No installation attempted.' -Encoding UTF8
    Write-Host 'INSTALLATION BLOCKED: Windows 32-bit (x86) is not supported.'
    Write-Host 'Supported OS: Windows 10 / 11 64-bit (x64)'
    exit 32
}
if ($nativeArch -eq 'ARM64') {
    Set-Content -LiteralPath $Log -Value 'TOPTEN POP V4.4.3 AUTO SETUP LOG' -Encoding UTF8
    Add-Content -LiteralPath $Log -Value '[BLOCKED] ARM64 native Windows is not supported by this x64 package. No installation attempted.' -Encoding UTF8
    Write-Host 'INSTALLATION BLOCKED: ARM64 native Windows is not supported by this x64 package.'
    Write-Host 'Supported OS: Windows 10 / 11 64-bit (x64)'
    exit 33
}
if ([Environment]::OSVersion.Version.Major -lt 10) {
    Set-Content -LiteralPath $Log -Value 'TOPTEN POP V4.4.3 AUTO SETUP LOG' -Encoding UTF8
    Add-Content -LiteralPath $Log -Value '[BLOCKED] Windows version below 10 is unsupported. No installation attempted.' -Encoding UTF8
    Write-Host 'INSTALLATION BLOCKED: Supported OS is Windows 10 / 11 64-bit (x64).'
    exit 34
}

New-Item -ItemType Directory -Force -Path $TempDir | Out-Null
New-Item -ItemType Directory -Force -Path $TessDataDir | Out-Null

function Write-SetupLog([string]$Message) {
    $line = "[{0}] {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message
    Write-Host $Message
    Add-Content -LiteralPath $Log -Value $line -Encoding UTF8
}

function Refresh-Path {
    $machine = [Environment]::GetEnvironmentVariable('Path','Machine')
    $user = [Environment]::GetEnvironmentVariable('Path','User')
    $env:Path = "$machine;$user"
}

function Test-PythonExe([string]$Exe) {
    if ([string]::IsNullOrWhiteSpace($Exe) -or -not (Test-Path -LiteralPath $Exe)) { return $false }
    try {
        & $Exe -c "import sys,struct; raise SystemExit(0 if (3,11) <= sys.version_info[:2] <= (3,14) and struct.calcsize('P')*8==64 else 1)" *> $null
        return ($LASTEXITCODE -eq 0)
    } catch { return $false }
}

function Find-Python {
    $candidates = New-Object System.Collections.Generic.List[string]
    foreach ($v in @('313','312','311','314')) {
        $candidates.Add((Join-Path $env:LOCALAPPDATA "Programs\Python\Python$v\python.exe"))
        $candidates.Add("C:\Program Files\Python$v\python.exe")
    }
    try {
        $cmd = Get-Command python.exe -ErrorAction SilentlyContinue
        if ($cmd -and $cmd.Source) { $candidates.Add($cmd.Source) }
    } catch {}
    try {
        $pyLauncher = Get-Command py.exe -ErrorAction SilentlyContinue
        if ($pyLauncher) {
            $resolved = (& $pyLauncher.Source -3.13 -c "import sys; print(sys.executable)" 2>$null | Select-Object -First 1)
            if ($resolved) { $candidates.Add($resolved.Trim()) }
            $resolved = (& $pyLauncher.Source -3 -c "import sys; print(sys.executable)" 2>$null | Select-Object -First 1)
            if ($resolved) { $candidates.Add($resolved.Trim()) }
        }
    } catch {}
    foreach ($candidate in ($candidates | Select-Object -Unique)) {
        if (Test-PythonExe $candidate) { return [IO.Path]::GetFullPath($candidate) }
    }
    return $null
}

function Download-File([string]$Url, [string]$Dest) {
    Write-SetupLog "다운로드: $Url"
    if (Test-Path -LiteralPath $Dest) { Remove-Item -Force -LiteralPath $Dest }
    try {
        Invoke-WebRequest -UseBasicParsing -Uri $Url -OutFile $Dest -TimeoutSec 120
    } catch {
        Write-SetupLog "Invoke-WebRequest 실패, WebClient로 재시도: $($_.Exception.Message)"
        $wc = New-Object System.Net.WebClient
        $wc.Headers['User-Agent'] = 'TOPTEN-POP-Bootstrap/4.4.3'
        $wc.DownloadFile($Url, $Dest)
    }
    if (-not (Test-Path -LiteralPath $Dest)) { throw "다운로드 파일이 생성되지 않았습니다: $Url" }
}

function Download-Verified([string]$Url, [string]$Dest, [string]$Sha256) {
    Download-File $Url $Dest
    $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $Dest).Hash.ToLowerInvariant()
    if ($actual -ne $Sha256.ToLowerInvariant()) {
        Remove-Item -Force -LiteralPath $Dest -ErrorAction SilentlyContinue
        throw "SHA256 불일치: $Url`nexpected=$Sha256`nactual=$actual"
    }
}

function Ensure-Python {
    $python = Find-Python
    if ($python) {
        Write-SetupLog "Python 확인 완료: $python"
        return $python
    }

    Write-SetupLog 'Python 3.11~3.14를 찾지 못했습니다. Python 3.13.14를 자동 설치합니다.'
    $installer = Join-Path $TempDir 'python-3.13.14-amd64.exe'
    $url = 'https://www.python.org/ftp/python/3.13.14/python-3.13.14-amd64.exe'
    $sha = 'c54d9b9bbb8a36e6489363ddd01139707fd781d72f1f9e90c7ec65d0061368e0'
    try {
        Download-Verified $url $installer $sha
        $installArgs = '/quiet InstallAllUsers=0 PrependPath=1 Include_pip=1 Include_launcher=1 Include_test=0 SimpleInstall=1'
        $p = Start-Process -FilePath $installer -ArgumentList $installArgs -Wait -PassThru
        Write-SetupLog "Python 설치 종료코드: $($p.ExitCode)"
        if ($p.ExitCode -notin @(0,3010)) { throw "Python 설치 프로그램 종료코드 $($p.ExitCode)" }
    } catch {
        Write-SetupLog "Python 직접 설치 실패: $($_.Exception.Message)"
        $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
        if ($winget) {
            Write-SetupLog 'winget Python 설치로 재시도합니다.'
            $wa = @('install','--id','Python.Python.3.13','-e','--scope','user','--silent','--accept-package-agreements','--accept-source-agreements','--disable-interactivity')
            $p = Start-Process -FilePath $winget.Source -ArgumentList $wa -Wait -PassThru
            Write-SetupLog "winget Python 설치 종료코드: $($p.ExitCode)"
        } else { throw }
    }
    Refresh-Path
    Start-Sleep -Seconds 2
    $python = Find-Python
    if (-not $python) { throw 'Python 자동 설치 후 python.exe를 찾지 못했습니다.' }
    Write-SetupLog "Python 자동 설치 완료: $python"
    return $python
}

function Ensure-PythonPackages([string]$Python) {
    Write-SetupLog 'Python 필수 모듈을 확인합니다.'
    & $Python -m ensurepip --upgrade *> $null
    $modules = @('flask','openpyxl','PIL','fitz','pytesseract','packaging')
    $missing = @()
    foreach ($m in $modules) {
        & $Python -c "import $m" *> $null
        if ($LASTEXITCODE -ne 0) { $missing += $m }
    }
    if ($missing.Count -gt 0) {
        Write-SetupLog ('필수 모듈 자동 설치: ' + ($missing -join ', '))
        & $Python -m pip install --disable-pip-version-check --upgrade pip
        if ($LASTEXITCODE -ne 0) { throw 'pip 업그레이드 실패' }
        & $Python -m pip install --disable-pip-version-check flask openpyxl pillow pymupdf pytesseract packaging
        if ($LASTEXITCODE -ne 0) { throw 'Python 필수 모듈 설치 실패' }
    }
    foreach ($m in $modules) {
        & $Python -c "import $m" *> $null
        if ($LASTEXITCODE -ne 0) { throw "Python 모듈 확인 실패: $m" }
    }
    Write-SetupLog 'Python 필수 모듈 정상.'
}

function Find-Tesseract {
    $candidates = @(
        $env:TESSERACT_CMD,
        'C:\Program Files\Tesseract-OCR\tesseract.exe',
        'C:\Program Files (x86)\Tesseract-OCR\tesseract.exe',
        (Join-Path $env:LOCALAPPDATA 'Programs\Tesseract-OCR\tesseract.exe')
    )
    try {
        $cmd = Get-Command tesseract.exe -ErrorAction SilentlyContinue
        if ($cmd -and $cmd.Source) { $candidates += $cmd.Source }
    } catch {}
    foreach ($candidate in ($candidates | Where-Object { $_ } | Select-Object -Unique)) {
        if (Test-Path -LiteralPath $candidate) { return [IO.Path]::GetFullPath($candidate) }
    }
    return $null
}

function Ensure-Tesseract {
    $tess = Find-Tesseract
    if ($tess) {
        Write-SetupLog "Tesseract 확인 완료: $tess"
        return $tess
    }

    Write-SetupLog 'Tesseract가 없어 5.5.0을 자동 설치합니다. Windows UAC가 뜨면 예를 눌러주세요.'
    $installer = Join-Path $TempDir 'tesseract-ocr-w64-setup-5.5.0.20241111.exe'
    $url = 'https://github.com/tesseract-ocr/tesseract/releases/download/5.5.0/tesseract-ocr-w64-setup-5.5.0.20241111.exe'
    $sha = 'f3fc4236425b690c8be756f35793f77394ee004be0a6460a440c754d892f68bc'
    try {
        Download-Verified $url $installer $sha
        try {
            $p = Start-Process -FilePath $installer -ArgumentList '/S' -Wait -PassThru
        } catch {
            Write-SetupLog '일반 설치 권한이 없어 관리자 권한으로 재시도합니다.'
            $p = Start-Process -FilePath $installer -ArgumentList '/S' -Verb RunAs -Wait -PassThru
        }
        Write-SetupLog "Tesseract 설치 종료코드: $($p.ExitCode)"
        if ($p.ExitCode -notin @(0,3010)) { throw "Tesseract 설치 프로그램 종료코드 $($p.ExitCode)" }
    } catch {
        Write-SetupLog "Tesseract 직접 설치 실패: $($_.Exception.Message)"
        $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
        if (-not $winget) { throw }
        foreach ($package in @('tesseract-ocr.tesseract','UB-Mannheim.TesseractOCR')) {
            try {
                Write-SetupLog "winget Tesseract 재시도: $package"
                $wa = @('install','--id',$package,'-e','--silent','--accept-package-agreements','--accept-source-agreements','--disable-interactivity')
                $p = Start-Process -FilePath $winget.Source -ArgumentList $wa -Wait -PassThru
                Write-SetupLog "winget 종료코드: $($p.ExitCode)"
                Start-Sleep -Seconds 2
                $tess = Find-Tesseract
                if ($tess) { return $tess }
            } catch { Write-SetupLog "winget $package 실패: $($_.Exception.Message)" }
        }
    }
    Refresh-Path
    Start-Sleep -Seconds 2
    $tess = Find-Tesseract
    if (-not $tess) { throw 'Tesseract 자동 설치 후 tesseract.exe를 찾지 못했습니다.' }
    Write-SetupLog "Tesseract 자동 설치 완료: $tess"
    return $tess
}

function Ensure-TessData([string]$Tesseract) {
    $files = @{
        'eng.traineddata' = 'https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/eng.traineddata'
        'kor.traineddata' = 'https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/kor.traineddata'
        'osd.traineddata' = 'https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/osd.traineddata'
    }
    foreach ($name in $files.Keys) {
        $dest = Join-Path $TessDataDir $name
        $need = (-not (Test-Path -LiteralPath $dest))
        if (-not $need) {
            try { $need = ((Get-Item -LiteralPath $dest).Length -lt 100000) } catch { $need = $true }
        }
        if ($need) {
            Write-SetupLog "OCR 언어 데이터 설치: $name"
            Download-File $files[$name] $dest
            if ((Get-Item -LiteralPath $dest).Length -lt 100000) { throw "OCR 언어 데이터가 비정상적으로 작습니다: $name" }
        }
    }
    $env:TESSDATA_PREFIX = $TessDataDir
    $langs = (& $Tesseract --list-langs 2>&1 | Out-String)
    if ($langs -notmatch '(?m)^kor\s*$' -or $langs -notmatch '(?m)^eng\s*$') {
        throw "Tesseract 언어 확인 실패. 감지 내용: $langs"
    }
    Write-SetupLog 'OCR 언어 데이터 정상: kor + eng + osd.'
}

try {
    Set-Content -LiteralPath $Log -Value 'TOPTEN POP V4.4.3 AUTO SETUP LOG' -Encoding UTF8
    Write-SetupLog "설치환경 자동점검 시작: $Root"
    $python = Ensure-Python
    Ensure-PythonPackages $python
    $tesseract = Ensure-Tesseract
    Ensure-TessData $tesseract

    $state = @{
        version = '4.4.3'
        status = 'ready'
        python = $python
        tesseract = $tesseract
        tessdata = $TessDataDir
        checked_at = (Get-Date).ToString('s')
    }
    $statePath = Join-Path $Root 'data\environment_state.json'
    New-Item -ItemType Directory -Force -Path (Split-Path $statePath -Parent) | Out-Null
    $state | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath $statePath -Encoding UTF8
    Write-SetupLog '모든 필수 설치환경이 정상입니다.'
    Write-Output "PYTHON=$python"
    Write-Output "TESSERACT=$tesseract"
    exit 0
} catch {
    Write-SetupLog ("자동 설치/점검 실패: " + $_.Exception.Message)
    try {
        $state = @{ version='4.4.3'; status='failed'; error=$_.Exception.Message; checked_at=(Get-Date).ToString('s') }
        $statePath = Join-Path $Root 'data\environment_state.json'
        New-Item -ItemType Directory -Force -Path (Split-Path $statePath -Parent) | Out-Null
        $state | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath $statePath -Encoding UTF8
    } catch {}
    exit 20
}
