@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "ROOT=%~dp0"
cd /d "%ROOT%"
title TOPTEN POP V4.4.3 - KEEP THIS WINDOW OPEN
set "LOG=%ROOT%run_log.txt"
set "SETUPLOG=%ROOT%run_setup_log.txt"
set "PIDFILE=%ROOT%data\server.pid"
set "PENDING=%ROOT%data\pending_finalize.json"
set "SPAWNED=%ROOT%data\finalizer_spawned.json"
>"%LOG%" echo TOPTEN POP V4.4.3 RUN LOG

echo ==========================================================
echo TOPTEN POP V4.4.3
echo [SUPPORTED OS] Windows 10 / 11 64-bit (x64)
echo [NOT SUPPORTED] Windows 32-bit (x86) / ARM64 native
echo First run automatically installs required components.
echo ==========================================================
echo.

rem ------------------------------------------------------------
rem 0) OS / architecture gate. This MUST run before any installer.
rem    32-bit Windows and unsupported ARM64 native systems stop here.
rem ------------------------------------------------------------
set "OS64="
set "NATIVE_ARCH=%PROCESSOR_ARCHITECTURE%"
if defined PROCESSOR_ARCHITEW6432 set "NATIVE_ARCH=%PROCESSOR_ARCHITEW6432%"
if /I "%NATIVE_ARCH%"=="AMD64" set "OS64=True"
if /I "%NATIVE_ARCH%"=="ARM64" set "OS64=True"
if not defined OS64 (
  for /f "delims=" %%A in ('powershell.exe -NoLogo -NoProfile -Command "[Environment]::Is64BitOperatingSystem" 2^>nul') do set "OS64=%%A"
)

echo Detected architecture: %NATIVE_ARCH%
if /I not "%OS64%"=="True" (
  echo.
  echo ==========================================================
  echo INSTALLATION BLOCKED
  echo Windows 32-bit (x86) is not supported.
  echo Supported OS: Windows 10 / 11 64-bit (x64)
  echo No Python, Tesseract, or module installation was attempted.
  echo ==========================================================
  echo OS BLOCK: 32-bit Windows - setup not attempted.>>"%SETUPLOG%"
  pause
  exit /b 32
)
if /I "%NATIVE_ARCH%"=="ARM64" (
  echo.
  echo ==========================================================
  echo INSTALLATION BLOCKED
  echo ARM64 native Windows is not supported by this x64 package.
  echo Supported OS: Windows 10 / 11 64-bit (x64)
  echo No Python, Tesseract, or module installation was attempted.
  echo ==========================================================
  echo OS BLOCK: ARM64 native - x64 package not attempted.>>"%SETUPLOG%"
  pause
  exit /b 33
)

rem Windows 10 and Windows 11 both report NT major version 10.
set "WINMAJOR="
for /f "delims=" %%V in ('powershell.exe -NoLogo -NoProfile -Command "[Environment]::OSVersion.Version.Major" 2^>nul') do set "WINMAJOR=%%V"
if defined WINMAJOR (
  if !WINMAJOR! LSS 10 (
    echo.
    echo ==========================================================
    echo INSTALLATION BLOCKED
    echo This Windows version is not supported.
    echo Supported OS: Windows 10 / 11 64-bit (x64)
    echo No Python, Tesseract, or module installation was attempted.
    echo ==========================================================
    echo OS BLOCK: Windows version below 10 - setup not attempted.>>"%SETUPLOG%"
    pause
    exit /b 34
  )
)

echo OS check: PASS - Windows 10/11 64-bit x64
echo.

rem ------------------------------------------------------------
rem 1) Full environment bootstrap using built-in Windows PowerShell.
rem    This runs BEFORE Python is needed, so a brand-new PC works.
rem ------------------------------------------------------------
if not exist "%ROOT%bootstrap_env.ps1" (
  echo ERROR: bootstrap_env.ps1 is missing.
  pause
  exit /b 10
)

echo [1/4] Checking required environment...
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%ROOT%bootstrap_env.ps1" -Root "%ROOT%"
if errorlevel 1 (
  echo.
  echo AUTO SETUP FAILED.
  echo See: %SETUPLOG%
  echo.
  if exist "%SETUPLOG%" type "%SETUPLOG%"
  pause
  exit /b 11
)

call :find_python
if not defined PYEXE (
  echo ERROR: Python was installed/checked but could not be found.
  echo See: %SETUPLOG%
  pause
  exit /b 12
)
set "PYWEXE=%PYEXE%"
for %%I in ("%PYEXE%") do if exist "%%~dpIpythonw.exe" set "PYWEXE=%%~dpIpythonw.exe"

rem Use the local OCR language store installed by bootstrap_env.ps1.
if exist "%ROOT%ocr_tessdata\kor.traineddata" set "TESSDATA_PREFIX=%ROOT%ocr_tessdata"
call :find_tesseract
if not defined TESSERACT_CMD (
  echo ERROR: Tesseract was installed/checked but could not be found.
  echo See: %SETUPLOG%
  pause
  exit /b 13
)

echo Python: %PYEXE%>>"%LOG%"
echo Tesseract: %TESSERACT_CMD%>>"%LOG%"
echo Tessdata: %TESSDATA_PREFIX%>>"%LOG%"

rem ------------------------------------------------------------
rem 2) GitHub automatic update.
rem ------------------------------------------------------------
echo [2/4] Checking TOPTEN POP updates...
if exist "%ROOT%update_client.py" (
  "%PYEXE%" "%ROOT%update_client.py"
  echo.
)

rem ------------------------------------------------------------
rem 3) Deferred cleanup / version folder rename.
rem ------------------------------------------------------------
if exist "%PENDING%" if exist "%ROOT%finalize_update.py" (
  if exist "%SPAWNED%" (
    echo Update finalization is already running. Waiting...
    timeout /t 7 /nobreak >nul
    if not exist "%PENDING%" exit /b 0
    echo Previous finalizer did not finish. Repeated launch is blocked.
    del /q "%PENDING%" >nul 2>&1
    del /q "%SPAWNED%" >nul 2>&1
    goto start_app
  )

  >"%SPAWNED%" echo {"status":"spawned"}
  set "TEMP_FINAL=%TEMP%\TOPTEN_POP_finalize_%RANDOM%_%RANDOM%.py"
  copy /y "%ROOT%finalize_update.py" "!TEMP_FINAL!" >nul 2>&1
  if errorlevel 1 (
    del /q "%SPAWNED%" >nul 2>&1
    echo Finalizer copy failed. Program will start without folder rename.
    goto start_app
  )
  set "OLDROOT=%ROOT:~0,-1%"
  echo [3/4] Finalizing update. TOPTEN POP will reopen automatically...
  cd /d "%TEMP%"
  start "" "!PYWEXE!" "!TEMP_FINAL!" "!OLDROOT!" --delay 3.0
  exit /b 0
)

:start_app
cd /d "%ROOT%"
if not exist "%ROOT%app\app.py" (
  echo ERROR: app\app.py is missing.
  pause
  exit /b 14
)

if exist "%PIDFILE%" (
  set /p OLDPID=<"%PIDFILE%"
  if defined OLDPID taskkill /F /PID !OLDPID! >nul 2>&1
  del /q "%PIDFILE%" >nul 2>&1
)

rem Final import verification. Bootstrap normally made this unnecessary,
rem but it protects against antivirus/package corruption between runs.
"%PYEXE%" -c "import flask,openpyxl,PIL,fitz,pytesseract,packaging" >>"%LOG%" 2>&1
if errorlevel 1 (
  echo Python package verification failed. Retrying automatic setup...
  powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%ROOT%bootstrap_env.ps1" -Root "%ROOT%"
  if errorlevel 1 (
    echo ERROR: Required Python packages could not be prepared.
    pause
    exit /b 15
  )
)

set "TOPTEN_POP_PORT=8080"
echo [4/4] Starting TOPTEN POP V4.4.3...
start "TOPTEN POP V4.4.3 SERVER" /b "%PYEXE%" "%ROOT%app\app.py" >>"%LOG%" 2>&1

set /a COUNT=0
:wait_health
powershell -NoProfile -Command "try { $r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 http://127.0.0.1:8080/health; if($r.StatusCode -eq 200){exit 0}else{exit 1} } catch { exit 1 }"
if not errorlevel 1 goto ready
set /a COUNT+=1
if %COUNT% GEQ 45 goto failed
timeout /t 1 /nobreak >nul
goto wait_health

:ready
echo Server ready. Opening browser...
start "" http://127.0.0.1:8080
echo.
echo TOPTEN POP V4.4.3 is running at http://127.0.0.1:8080
echo Keep this window open. Press any key to stop this server.
pause >nul
call :stop_server
exit /b 0

:failed
echo.
echo START FAILED. See run_log.txt and run_setup_log.txt.
type "%LOG%"
call :stop_server
pause
exit /b 16

:stop_server
if exist "%PIDFILE%" (
  set /p SERVERPID=<"%PIDFILE%"
  if defined SERVERPID taskkill /F /PID !SERVERPID! >nul 2>&1
  del /q "%PIDFILE%" >nul 2>&1
)
exit /b 0

:find_python
set "PYEXE="
for %%P in (
  "%LocalAppData%\Programs\Python\Python313\python.exe"
  "%LocalAppData%\Programs\Python\Python312\python.exe"
  "%LocalAppData%\Programs\Python\Python311\python.exe"
  "%LocalAppData%\Programs\Python\Python314\python.exe"
  "C:\Program Files\Python313\python.exe"
  "C:\Program Files\Python312\python.exe"
  "C:\Program Files\Python311\python.exe"
  "C:\Program Files\Python314\python.exe"
) do if exist "%%~P" if not defined PYEXE (
  "%%~P" -c "import sys,struct; raise SystemExit(0 if (3,11) <= sys.version_info[:2] <= (3,14) and struct.calcsize('P')*8==64 else 1)" >nul 2>&1
  if not errorlevel 1 set "PYEXE=%%~P"
)
if defined PYEXE exit /b 0
for /f "delims=" %%P in ('where python 2^>nul') do if not defined PYEXE (
  "%%P" -c "import sys,struct; raise SystemExit(0 if (3,11) <= sys.version_info[:2] <= (3,14) and struct.calcsize('P')*8==64 else 1)" >nul 2>&1
  if not errorlevel 1 set "PYEXE=%%P"
)
exit /b 0

:find_tesseract
set "TESSERACT_CMD="
if exist "C:\Program Files\Tesseract-OCR\tesseract.exe" set "TESSERACT_CMD=C:\Program Files\Tesseract-OCR\tesseract.exe"
if not defined TESSERACT_CMD if exist "C:\Program Files (x86)\Tesseract-OCR\tesseract.exe" set "TESSERACT_CMD=C:\Program Files (x86)\Tesseract-OCR\tesseract.exe"
if not defined TESSERACT_CMD if exist "%LocalAppData%\Programs\Tesseract-OCR\tesseract.exe" set "TESSERACT_CMD=%LocalAppData%\Programs\Tesseract-OCR\tesseract.exe"
if not defined TESSERACT_CMD for /f "delims=" %%T in ('where tesseract 2^>nul') do if not defined TESSERACT_CMD set "TESSERACT_CMD=%%T"
exit /b 0
