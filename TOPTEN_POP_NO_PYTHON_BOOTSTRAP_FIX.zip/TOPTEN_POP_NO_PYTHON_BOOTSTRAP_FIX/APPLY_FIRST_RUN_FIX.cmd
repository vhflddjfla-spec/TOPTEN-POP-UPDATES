﻿@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul 2>&1
title TOPTEN POP - FIRST RUN BOOTSTRAP FIX

echo ==========================================================
echo TOPTEN POP FIRST RUN BOOTSTRAP FIX
echo [SUPPORTED OS] Windows 10 / 11 64-bit (x64)
echo [NOT SUPPORTED] Windows 32-bit (x86) / ARM64 native
echo ==========================================================
echo.

rem ------------------------------------------------------------
rem Safety gate BEFORE any file replacement or installer attempt.
rem ------------------------------------------------------------
set "NATIVE_ARCH=%PROCESSOR_ARCHITECTURE%"
if defined PROCESSOR_ARCHITEW6432 set "NATIVE_ARCH=%PROCESSOR_ARCHITEW6432%"
set "OS64="
if /I "%NATIVE_ARCH%"=="AMD64" set "OS64=True"
if /I "%NATIVE_ARCH%"=="ARM64" set "OS64=True"
if not defined OS64 (
  for /f "delims=" %%A in ('powershell.exe -NoLogo -NoProfile -Command "[Environment]::Is64BitOperatingSystem" 2^>nul') do set "OS64=%%A"
)

if /I not "%OS64%"=="True" (
  echo INSTALLATION BLOCKED: Windows 32-bit ^(x86^) is not supported.
  echo No files or installers were changed.
  pause
  exit /b 32
)
if /I "%NATIVE_ARCH%"=="ARM64" (
  echo INSTALLATION BLOCKED: ARM64 native Windows is not supported.
  echo No files or installers were changed.
  pause
  exit /b 33
)

echo Detected architecture: %NATIVE_ARCH%
echo.
echo TOPTEN POP 프로그램 폴더를 선택하세요.
echo 예: TOPTEN_POP_V4.4.1 또는 TOPTEN_POP_V4.4.0.1
echo.

set "TARGET="
for /f "usebackq delims=" %%D in (`powershell.exe -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -Command "Add-Type -AssemblyName System.Windows.Forms; $d=New-Object System.Windows.Forms.FolderBrowserDialog; $d.Description='TOPTEN POP 프로그램 폴더를 선택하세요'; $d.ShowNewFolderButton=$false; if($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK){[Console]::Write($d.SelectedPath)}"`) do set "TARGET=%%D"

if not defined TARGET (
  echo 폴더 선택이 취소되었습니다.
  pause
  exit /b 2
)

if not exist "%TARGET%\RUN.cmd" (
  echo ERROR: 선택한 폴더에 RUN.cmd가 없습니다.
  pause
  exit /b 3
)
if not exist "%TARGET%\app\app.py" (
  echo ERROR: 선택한 폴더에 app\app.py가 없습니다.
  pause
  exit /b 4
)
if not exist "%TARGET%\update_client.py" (
  echo ERROR: 선택한 폴더에 update_client.py가 없습니다.
  pause
  exit /b 5
)

if not exist "%~dp0payload\RUN.cmd" (
  echo ERROR: payload\RUN.cmd가 없습니다.
  pause
  exit /b 6
)
if not exist "%~dp0payload\bootstrap_env.ps1" (
  echo ERROR: payload\bootstrap_env.ps1이 없습니다.
  pause
  exit /b 7
)

echo.
echo Target: %TARGET%
echo 기존 RUN.cmd를 백업하고 최초실행 자동설치 런처를 적용합니다...
copy /y "%TARGET%\RUN.cmd" "%TARGET%\RUN_before_first_run_fix.cmd" >nul
copy /y "%~dp0payload\RUN.cmd" "%TARGET%\RUN.cmd" >nul
if errorlevel 1 goto copyfail
copy /y "%~dp0payload\bootstrap_env.ps1" "%TARGET%\bootstrap_env.ps1" >nul
if errorlevel 1 goto copyfail

echo.
echo FIX APPLIED.
echo 이제 새 RUN.cmd가 Python/Tesseract/필수 모듈을 먼저 준비한 뒤
echo GitHub 자동 업데이트를 실행합니다.
echo.
echo RUN.cmd를 지금 실행합니다...
timeout /t 2 /nobreak >nul
start "" /D "%TARGET%" "%TARGET%\RUN.cmd"
exit /b 0

:copyfail
echo ERROR: 파일 교체에 실패했습니다.
echo 프로그램이 실행 중이면 모두 종료한 뒤 다시 시도하세요.
pause
exit /b 8
