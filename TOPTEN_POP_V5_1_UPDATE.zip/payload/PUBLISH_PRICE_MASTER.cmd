@echo off
setlocal EnableExtensions
set "ROOT=%~dp0"
cd /d "%ROOT%"
set "PYEXE="
if exist "%ROOT%data\python_path.txt" set /p PYEXE=<"%ROOT%data\python_path.txt"
if not defined PYEXE where py >nul 2>&1 && set "PYEXE=py -3"
if not defined PYEXE where python >nul 2>&1 && set "PYEXE=python"
if not defined PYEXE (
  echo [ERROR] Python not ready. Run RUN.cmd once first.
  pause
  exit /b 1
)
%PYEXE% "%ROOT%publish_price_master.py"
if errorlevel 1 (
  echo [ERROR] Price master release generation failed.
  pause
  exit /b 1
)
echo.
echo Upload the files inside github_price_master_release to GitHub main root.
explorer "%ROOT%github_price_master_release"
pause
