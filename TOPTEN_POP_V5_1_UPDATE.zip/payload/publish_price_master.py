# -*- coding: utf-8 -*-
from __future__ import annotations
import hashlib, json, shutil, sys
from datetime import datetime
from pathlib import Path
from openpyxl import load_workbook

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'data'/'TOPTEN_가격정책_마스터.xlsx'
OUT=ROOT/'github_price_master_release'
REMOTE_NAME='TOPTEN_PRICE_POLICY_MASTER.xlsx'
REMOTE_URL='https://raw.githubusercontent.com/vhflddjfla-spec/TOPTEN-POP-UPDATES/refs/heads/main/'+REMOTE_NAME

def sha256(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest().lower()

def validate(path):
    wb=load_workbook(path,data_only=False,read_only=False)
    try:
        candidates=[]
        if '가격정책마스터' in wb.sheetnames: candidates.append(wb['가격정책마스터'])
        candidates += [ws for ws in wb.worksheets if ws not in candidates]
        for ws in candidates:
            for r in range(1,min(int(ws.max_row or 0),25)+1):
                vals=[str(ws.cell(r,c).value or '').strip() for c in range(1,ws.max_column+1)]
                if '품번' in vals and '정상가' in vals and '가격정책' in vals and ('조정가' in vals or '할인가' in vals):
                    return True
    finally: wb.close()
    raise RuntimeError('가격정책 마스터 필수 헤더를 찾지 못했습니다.')

def main():
    if not SOURCE.exists():
        print('[ERROR] 실사용 마스터가 없습니다:',SOURCE); return 2
    validate(SOURCE)
    OUT.mkdir(parents=True,exist_ok=True)
    dest=OUT/REMOTE_NAME
    shutil.copy2(SOURCE,dest)
    digest=sha256(dest)
    ver=datetime.now().strftime('%Y-%m-%d-%H%M%S')
    manifest={
      'schema_version':1,
      'master_version':ver,
      'file_name':REMOTE_NAME,
      'download_url':REMOTE_URL,
      'sha256':digest,
      'minimum_app_version':'5.1',
      'message':'TOPTEN 중앙 가격정책 마스터 '+ver,
    }
    (OUT/'price_master.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    (OUT/'README_UPLOAD.txt').write_text(
      'GitHub TOPTEN-POP-UPDATES 저장소 main 루트에 아래 2개 파일을 업로드/덮어쓰기 하세요.\n'
      '1) TOPTEN_PRICE_POLICY_MASTER.xlsx\n2) price_master.json\n\n'
      '항상 XLSX를 먼저 올리고 price_master.json을 마지막에 올리세요.\n'
      '다른 매장 V5.1은 시작 시/30분 간격/수동버튼에서 manifest SHA256을 확인해 변경된 경우에만 교체합니다.\n',encoding='utf-8')
    print('[OK] GitHub 업로드용 가격정책 생성 완료')
    print('Folder:',OUT)
    print('Version:',ver)
    print('SHA256:',digest)
    return 0
if __name__=='__main__': raise SystemExit(main())
