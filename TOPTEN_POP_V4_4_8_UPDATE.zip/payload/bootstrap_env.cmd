@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "ROOT=%~1"
if not defined ROOT set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"
set "MODE=%~2"
if not defined MODE set "MODE=full"
set "DATA=%ROOT%\data"
set "RUNTIME=%ROOT%\runtime"
set "PYDIR=%RUNTIME%\Python313"
set "PYEXE=%PYDIR%\python.exe"
set "BUNDLED_TESSDATA=%ROOT%\bootstrap_assets\tessdata"
set "LOCAL_TESSDATA=%ROOT%\ocr_tessdata"
set "DOWNLOADED_TESSDATA=%DATA%\downloaded_tessdata"
set "LOG=%ROOT%\run_setup_log.txt"
set "TMPDIR=%TEMP%\TOPTEN_POP_V448_SETUP"
set "PYZIP=%TMPDIR%\python-3.13.14-embed-amd64.zip"
set "GETPIP=%TMPDIR%\get-pip.py"
set "TESSSETUP=%TMPDIR%\tesseract-ocr-w64-setup-5.4.0.20240606.exe"
set "PYURL=https://www.python.org/ftp/python/3.13.14/python-3.13.14-embed-amd64.zip"
set "PYHASH=90b4e5b9898b72d744650524bff92377c367f44bd5fbd09e3148656c080ad907"
set "PIPURL=https://bootstrap.pypa.io/get-pip.py"
set "TESSURL=https://github.com/UB-Mannheim/tesseract/releases/download/v5.4.0.20240606/tesseract-ocr-w64-setup-5.4.0.20240606.exe"
set "TESSHASH=c885fff6998e0608ba4bb8ab51436e1c6775c2bafc2559a19b423e18678b60c9"

if not exist "%DATA%" mkdir "%DATA%" >nul 2>&1
if not exist "%RUNTIME%" mkdir "%RUNTIME%" >nul 2>&1
if not exist "%TMPDIR%" mkdir "%TMPDIR%" >nul 2>&1
if not exist "%DATA%" exit /b 60
if not exist "%RUNTIME%" exit /b 60
>"%LOG%" echo TOPTEN POP V4.4.8 AUTO SETUP LOG
call :log "Setup start - PowerShell-free bootstrap / mode=%MODE%"

set "NATIVE_ARCH=%PROCESSOR_ARCHITECTURE%"
if defined PROCESSOR_ARCHITEW6432 set "NATIVE_ARCH=%PROCESSOR_ARCHITEW6432%"
if /I not "%NATIVE_ARCH%"=="AMD64" goto fail_arch

:python_check
if not exist "%PYEXE%" goto python_prepare
"%PYEXE%" -c "import struct,sys;raise SystemExit(0 if struct.calcsize('P')*8==64 and sys.version_info[:2]==(3,13) else 1)" >nul 2>&1
if errorlevel 1 goto python_rebuild
call :log "Portable Python OK: %PYEXE%"
goto python_pip_check

:python_rebuild
call :log "Portable Python exists but failed verification. Rebuilding runtime."
rmdir /s /q "%PYDIR%" >nul 2>&1

:python_prepare
call :log "Downloading official Python 3.13.14 embeddable x64 package."
if exist "%PYZIP%" del /q "%PYZIP%" >nul 2>&1
call :download "%PYURL%" "%PYZIP%"
if errorlevel 1 goto fail_python_download
for %%I in ("%PYZIP%") do set "PYSIZE=%%~zI"
if not defined PYSIZE goto fail_python_download
if !PYSIZE! LSS 9000000 goto fail_python_download
call :hashcheck "%PYZIP%" "%PYHASH%"
if errorlevel 1 goto fail_python_hash
if exist "%PYDIR%" rmdir /s /q "%PYDIR%" >nul 2>&1
mkdir "%PYDIR%" >nul 2>&1
where tar.exe >nul 2>&1
if errorlevel 1 goto python_unzip_vbs
call :log "Extracting Python with Windows tar.exe."
tar.exe -xf "%PYZIP%" -C "%PYDIR%" >>"%LOG%" 2>&1
if exist "%PYEXE%" goto python_unzip_done

:python_unzip_vbs
call :log "Extracting Python with Windows Shell ZIP fallback."
cscript.exe //nologo "%ROOT%\bootstrap_unzip.vbs" "%PYZIP%" "%PYDIR%" >>"%LOG%" 2>&1
set /a WAITZIP=0
:python_zip_wait
if exist "%PYEXE%" goto python_unzip_done
set /a WAITZIP+=1
if !WAITZIP! GEQ 30 goto fail_python_extract
timeout /t 1 /nobreak >nul
goto python_zip_wait

:python_unzip_done
if not exist "%PYEXE%" goto fail_python_extract
set "PTH=%PYDIR%\python313._pth"
if not exist "%PYDIR%\Lib\site-packages" mkdir "%PYDIR%\Lib\site-packages" >nul 2>&1
findstr /x /c:"Lib\site-packages" "%PTH%" >nul 2>&1
if errorlevel 1 >>"%PTH%" echo Lib\site-packages
findstr /x /c:"import site" "%PTH%" >nul 2>&1
if errorlevel 1 >>"%PTH%" echo import site
"%PYEXE%" -c "import struct;raise SystemExit(0 if struct.calcsize('P')*8==64 else 1)" >>"%LOG%" 2>&1
if errorlevel 1 goto fail_python_verify
call :log "Portable Python runtime ready."

:python_pip_check
"%PYEXE%" -m pip --version >nul 2>&1
if not errorlevel 1 goto python_packages
call :log "pip not found. Downloading official get-pip.py."
if exist "%GETPIP%" del /q "%GETPIP%" >nul 2>&1
call :download "%PIPURL%" "%GETPIP%"
if errorlevel 1 goto fail_pip_download
for %%I in ("%GETPIP%") do set "PIPSIZE=%%~zI"
if not defined PIPSIZE goto fail_pip_download
if !PIPSIZE! LSS 1000000 goto fail_pip_download
"%PYEXE%" "%GETPIP%" --disable-pip-version-check >>"%LOG%" 2>&1
if errorlevel 1 goto fail_pip_install

:python_packages
call :log "Checking Python modules."
"%PYEXE%" -c "import flask,openpyxl,PIL,fitz,pytesseract,packaging" >nul 2>&1
if not errorlevel 1 goto python_done
call :log "Installing required Python modules from PyPI."
"%PYEXE%" -m pip install --disable-pip-version-check --no-warn-script-location --retries 3 --timeout 45 flask openpyxl pillow pymupdf pytesseract packaging >>"%LOG%" 2>&1
if errorlevel 1 goto fail_packages
"%PYEXE%" -c "import flask,openpyxl,PIL,fitz,pytesseract,packaging" >>"%LOG%" 2>&1
if errorlevel 1 goto fail_packages

:python_done
>"%DATA%\python_path.txt" echo %PYEXE%
call :log "Python and required modules READY."
if /I "%MODE%"=="core" goto core_ready
goto tesseract_check

:core_ready
call :log "Core environment READY for update check."
exit /b 0

:tesseract_check
set "TESSERACT="
if exist "%DATA%\tesseract_path.txt" set /p TESSERACT=<"%DATA%\tesseract_path.txt"
if defined TESSERACT if exist "%TESSERACT%" goto tesseract_ready
if exist "C:\Program Files\Tesseract-OCR\tesseract.exe" set "TESSERACT=C:\Program Files\Tesseract-OCR\tesseract.exe"
if defined TESSERACT goto tesseract_ready
if exist "%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe" set "TESSERACT=%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe"
if defined TESSERACT goto tesseract_ready
for /f "delims=" %%T in ('where tesseract.exe 2^>nul') do if not defined TESSERACT set "TESSERACT=%%T"
if defined TESSERACT goto tesseract_ready
goto tesseract_install

:tesseract_install
call :log "Tesseract not found. Trying winget first."
where winget.exe >nul 2>&1
if errorlevel 1 goto tesseract_direct
winget.exe install --id UB-Mannheim.TesseractOCR -e --silent --accept-package-agreements --accept-source-agreements --disable-interactivity >>"%LOG%" 2>&1
if exist "C:\Program Files\Tesseract-OCR\tesseract.exe" set "TESSERACT=C:\Program Files\Tesseract-OCR\tesseract.exe"
if defined TESSERACT goto tesseract_ready

:tesseract_direct
call :log "Downloading verified UB-Mannheim Tesseract 5.4.0 installer."
if exist "%TESSSETUP%" del /q "%TESSSETUP%" >nul 2>&1
call :download "%TESSURL%" "%TESSSETUP%"
if errorlevel 1 goto fail_tess_download
for %%I in ("%TESSSETUP%") do set "TESSSIZE=%%~zI"
if not defined TESSSIZE goto fail_tess_download
if !TESSSIZE! LSS 40000000 goto fail_tess_download
call :hashcheck "%TESSSETUP%" "%TESSHASH%"
if errorlevel 1 goto fail_tess_hash
call :log "Installing Tesseract silently. A Windows UAC approval may appear."
start /wait "" "%TESSSETUP%" /S >>"%LOG%" 2>&1
if exist "C:\Program Files\Tesseract-OCR\tesseract.exe" set "TESSERACT=C:\Program Files\Tesseract-OCR\tesseract.exe"
if exist "%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe" set "TESSERACT=%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe"
if not defined TESSERACT goto fail_tess_install

:tesseract_ready
>"%DATA%\tesseract_path.txt" echo %TESSERACT%
call :log "Tesseract READY: %TESSERACT%"
for %%I in ("%TESSERACT%") do set "TESSDIR=%%~dpI"
set "TESSDATA_SELECTED="

rem 1) Existing local OCR folder is accepted if all 3 files are valid.
call :check_langset "%LOCAL_TESSDATA%"
if not errorlevel 1 set "TESSDATA_SELECTED=%LOCAL_TESSDATA%"

rem 2) V4.4.8 ships the language files. Use them in-place; no copy step.
if not defined TESSDATA_SELECTED call :check_langset "%BUNDLED_TESSDATA%"
if not defined TESSDATA_SELECTED if not errorlevel 1 set "TESSDATA_SELECTED=%BUNDLED_TESSDATA%"

rem 3) Existing Tesseract installation may already have all languages.
if not defined TESSDATA_SELECTED call :check_langset "%TESSDIR%tessdata"
if not defined TESSDATA_SELECTED if not errorlevel 1 set "TESSDATA_SELECTED=%TESSDIR%tessdata"

rem 4) Last fallback: download into data folder, which is always preserved.
if not defined TESSDATA_SELECTED goto tessdata_download_fallback
goto tessdata_verify

:tessdata_download_fallback
call :log "Bundled/local OCR data unavailable. Downloading fallback language files."
if not exist "%DOWNLOADED_TESSDATA%" mkdir "%DOWNLOADED_TESSDATA%" >nul 2>&1
if not exist "%DOWNLOADED_TESSDATA%" goto fail_tessdata
call :ensure_lang "eng" "1000000"
if errorlevel 1 goto fail_tessdata
call :ensure_lang "kor" "500000"
if errorlevel 1 goto fail_tessdata
call :ensure_lang "osd" "1000000"
if errorlevel 1 goto fail_tessdata
set "TESSDATA_SELECTED=%DOWNLOADED_TESSDATA%"

:tessdata_verify
if not defined TESSDATA_SELECTED goto fail_tessdata
set "LANGCHECK=%DATA%\ocr_languages_check.txt"
if exist "%LANGCHECK%" del /q "%LANGCHECK%" >nul 2>&1
call :log "Using OCR language data: %TESSDATA_SELECTED%"
"%TESSERACT%" --tessdata-dir "%TESSDATA_SELECTED%" --list-langs >"%LANGCHECK%" 2>>"%LOG%"
if errorlevel 1 goto fail_tessdata_verify
if not exist "%LANGCHECK%" goto fail_tessdata_verify
findstr /x /c:"kor" "%LANGCHECK%" >nul 2>&1
if errorlevel 1 goto fail_tessdata_verify
findstr /x /c:"eng" "%LANGCHECK%" >nul 2>&1
if errorlevel 1 goto fail_tessdata_verify
findstr /x /c:"osd" "%LANGCHECK%" >nul 2>&1
if errorlevel 1 goto fail_tessdata_verify
>"%DATA%\tessdata_path.txt" echo %TESSDATA_SELECTED%
call :log "OCR languages READY: kor, eng, osd."
call :log "Environment READY."
exit /b 0

:check_langset
set "CHKDIR=%~1"
if not defined CHKDIR exit /b 1
if not exist "%CHKDIR%\eng.traineddata" exit /b 1
if not exist "%CHKDIR%\kor.traineddata" exit /b 1
if not exist "%CHKDIR%\osd.traineddata" exit /b 1
for %%I in ("%CHKDIR%\eng.traineddata") do if %%~zI LSS 1000000 exit /b 1
for %%I in ("%CHKDIR%\kor.traineddata") do if %%~zI LSS 500000 exit /b 1
for %%I in ("%CHKDIR%\osd.traineddata") do if %%~zI LSS 1000000 exit /b 1
exit /b 0

:ensure_lang
set "LANGNAME=%~1"
set "MINSIZE=%~2"
set "LANGFILE=%DOWNLOADED_TESSDATA%\%LANGNAME%.traineddata"
if exist "%LANGFILE%" for %%I in ("%LANGFILE%") do if %%~zI GEQ %MINSIZE% exit /b 0
call :download "https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/%LANGNAME%.traineddata" "%LANGFILE%"
if errorlevel 1 exit /b 1
if not exist "%LANGFILE%" exit /b 1
for %%I in ("%LANGFILE%") do if %%~zI LSS %MINSIZE% exit /b 1
exit /b 0

:download
set "DLURL=%~1"
set "DLOUT=%~2"
for %%I in ("%DLOUT%") do if not exist "%%~dpI" mkdir "%%~dpI" >nul 2>&1
if exist "%DLOUT%" del /q "%DLOUT%" >nul 2>&1
where curl.exe >nul 2>&1
if errorlevel 1 goto download_certutil
curl.exe -L --fail --retry 3 --connect-timeout 20 --max-time 360 -o "%DLOUT%" "%DLURL%" >>"%LOG%" 2>&1
if not errorlevel 1 if exist "%DLOUT%" exit /b 0
:download_certutil
certutil.exe -urlcache -split -f "%DLURL%" "%DLOUT%" >>"%LOG%" 2>&1
if errorlevel 1 exit /b 1
if not exist "%DLOUT%" exit /b 1
exit /b 0

:hashcheck
set "HASHFILE=%~1"
set "EXPECTED=%~2"
certutil.exe -hashfile "%HASHFILE%" SHA256 >"%TMPDIR%\hash.txt" 2>>"%LOG%"
if errorlevel 1 exit /b 1
findstr /I /C:"%EXPECTED%" "%TMPDIR%\hash.txt" >nul 2>&1
if errorlevel 1 exit /b 1
exit /b 0

:log
set "MSG=%~1"
echo %MSG%
>>"%LOG%" echo [%date% %time%] %MSG%
exit /b 0

:fail_arch
call :log "BLOCKED: Windows x64 AMD64 was not detected."
exit /b 32
:fail_python_download
call :log "FAILED: Python embeddable package download failed."
exit /b 41
:fail_python_hash
call :log "FAILED: Python package SHA256 verification failed."
exit /b 42
:fail_python_extract
call :log "FAILED: Python ZIP extraction failed."
exit /b 43
:fail_python_verify
call :log "FAILED: Portable Python did not start correctly."
exit /b 44
:fail_pip_download
call :log "FAILED: get-pip.py download failed."
exit /b 45
:fail_pip_install
call :log "FAILED: pip installation failed."
exit /b 46
:fail_packages
call :log "FAILED: Required Python module installation failed."
exit /b 47
:fail_tess_download
call :log "FAILED: Tesseract installer download failed."
exit /b 51
:fail_tess_hash
call :log "FAILED: Tesseract installer SHA256 verification failed."
exit /b 52
:fail_tess_install
call :log "FAILED: Tesseract installer finished but tesseract.exe was not found."
exit /b 53
:fail_tessdata
call :log "FAILED: OCR language data preparation failed."
exit /b 54
:fail_tessdata_verify
call :log "FAILED: OCR language verification failed. See data\ocr_languages_check.txt."
exit /b 55
