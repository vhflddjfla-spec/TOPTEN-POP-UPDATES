# -*- coding: utf-8 -*-
"""V5.1.17 R3: arrival source reconciliation and tidy-up ONLY.

Does not modify price-transition functions, program app.py, POP templates, or local AI data.
The caller has copied the live price master to a temporary workbook and handles atomic commit.
"""
from __future__ import annotations

import hashlib
import re
from datetime import date, datetime
from pathlib import Path
from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font, Alignment

VERSION = 'ARRIVAL_R3_SAFE_MERGE_20261110'
ARRIVAL = '신상등록_입력'
ARCHIVE = '신상등록_자동보관'
REVIEW = '신상등록_검토필요'
LOG = '신상등록_파일수집기록'
STATE = '신상등록_품번수집상태'
HEADERS = ['제품코드','칼라','상품명','상품명(영문)','소비자가','판매기준가',
           '적용 시작일','적용구분','마스터 등록','예약대기 여부','자료/등록 판정',
           '품번 중복 안내','POP 작업 참고일(D-1)']

def clean(v):
    return re.sub(r'[^A-Z0-9_-]', '', str(v or '').strip().upper())

def norm(v):
    return str(v or '').strip()

def price(v):
    try:
        return int(float(str(v).replace(',', ''))) if v not in (None, '') else 0
    except Exception:
        return 0

def day(v):
    from openpyxl.utils.datetime import from_excel
    if isinstance(v, datetime): return v.date()
    if isinstance(v, date): return v
    if isinstance(v, (int, float)) and 30000 <= float(v) <= 90000:
        try:
            z = from_excel(v)
            return z.date() if isinstance(z, datetime) else z
        except Exception: return None
    if v in (None, ''): return None
    for fmt in ('%Y-%m-%d','%Y/%m/%d','%Y.%m.%d','%m/%d','%m-%d'):
        try:
            dt = datetime.strptime(str(v).strip()[:10], fmt)
            return dt.replace(year=datetime.now().year).date() if fmt.startswith('%m') else dt.date()
        except (ValueError, TypeError): pass
    return None

def sheet(wb, name, headers):
    if name in wb.sheetnames: return wb[name], False
    ws = wb.create_sheet(name)
    for col, head in enumerate(headers, 1):
        c = ws.cell(1, col, head)
        c.fill = PatternFill('solid', fgColor='243B53')
        c.font = Font(color='FFFFFF', bold=True)
        c.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    ws.freeze_panes = 'C2'
    ws.auto_filter.ref = f'A1:{"O" if len(headers)==15 else "M" if len(headers)==13 else "J"}1'
    if name == ARRIVAL:
        for c,w in {'A':18,'B':10,'C':38,'D':38,'E':14,'F':15,'G':17,'H':16,'I':16,
                    'J':16,'K':28,'L':22,'M':24}.items():
            ws.column_dimensions[c].width=w
    return ws, True

def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def new_review(wb, values, reason):
    ws,_=sheet(wb,REVIEW,HEADERS+['검토일시','검토사유'])
    sku=clean(values[0])
    # Avoid perpetually duplicating unresolved review rows across repeated imports.
    for row in ws.iter_rows(min_row=2,values_only=True):
        if row and clean(row[0])==sku and norm(row[14] if len(row)>14 else '')==reason:
            return False
    ws.append([*list(values[:13]),datetime.now(),reason])
    return True

def sync_arrival_file(wb, data_dir):
    """Import a changed source, including styles with blank sale price or start date.

    Existing queue rows are supplemented only in blank cells. Existing master prices
    are never edited here. Source rows are grouped by style; colors do not create
    duplicate entries. Hash+schema logging avoids reimporting the same spreadsheet.
    """
    src = Path(data_dir) / '신상리스트.xlsx'
    queue,created = sheet(wb,ARRIVAL,HEADERS)
    log,_ = sheet(wb,LOG,['원본파일','SHA256','수집버전','처리일시','원본행수',
                           '신규품번','대기행 보완품번','기존/중복품번','검토품번','참고'])
    archive,_ = sheet(wb,ARCHIVE,HEADERS+['보관일시','보관사유'])
    state_ws,_ = sheet(wb,STATE,['품번','원본 품번별 SHA256','마지막 수집시각'])
    previous={}
    for sr in range(2,state_ws.max_row+1):
        scode=clean(state_ws.cell(sr,1).value)
        if scode: previous[scode]=(norm(state_ws.cell(sr,2).value),sr)
    if not src.is_file():
        return {'changed': created, 'source_found': False,'source_styles':0,
                'imported_new':0,'enriched':0,'ignored':0,'review':0}
    sha=digest(src)
    for r in range(2,log.max_row+1):
        if norm(log.cell(r,2).value)==sha and norm(log.cell(r,3).value)==VERSION:
            return {'changed':created,'source_found':True,'unchanged_file':True,
                    'source_styles':0,'imported_new':0,'enriched':0,'ignored':0,'review':0}

    master=wb.get('가격정책마스터') if hasattr(wb,'get') else wb['가격정책마스터']
    h={norm(c.value):c.column for c in master[1]}
    if '품번' not in h: raise RuntimeError('가격정책마스터 품번 열이 없습니다')
    oldcodes={clean(master.cell(r,h['품번']).value) for r in range(2,master.max_row+1)}
    queued={}
    for r in range(2,queue.max_row+1):
        c=clean(queue.cell(r,1).value)
        if c:queued.setdefault(c,[]).append(r)

    data=load_workbook(src,read_only=True,data_only=True)
    groups={}; source_rows=0
    try:
        found=None; head=1
        for ws in data.worksheets:
            for hr in range(1,min(15,ws.max_row or 1)+1):
                names=[norm(ws.cell(hr,c).value) for c in range(1,9)]
                if names[:2]==['제품코드','칼라'] and '판매기준가' in names:
                    found=ws;head=hr;break
            if found is not None:break
        if found is None:
            raise RuntimeError('신상리스트.xlsx 헤더를 찾지 못함: 제품코드/칼라/판매기준가 확인')
        for vals in found.iter_rows(min_row=head+1,max_col=8,values_only=True):
            row=list(vals);sku=clean(row[0])
            if not sku:continue
            groups.setdefault(sku,[]).append(row)
            source_rows+=1
    finally:
        data.close()
    new=enriched=ignored=review=skipped_same=0
    for sku,rows in groups.items():
        # Per-style fingerprint avoids repeatedly reimporting unchanged problem
        # rows whenever unrelated styles are added to HQ's source workbook.
        serial=repr([[x.isoformat() if isinstance(x,(datetime,date)) else x for x in rr] for rr in rows])
        per_style_sha=hashlib.sha256(serial.encode('utf-8')).hexdigest()
        prior=previous.get(sku)
        if prior and prior[0]==per_style_sha:
            skipped_same+=1
            continue
        if prior:
            sr=prior[1]
            state_ws.cell(sr,2).value=per_style_sha
            state_ws.cell(sr,3).value=datetime.now()
        else:
            state_ws.append([sku,per_style_sha,datetime.now()])
            previous[sku]=(per_style_sha,state_ws.max_row)
        # Group colors before selecting one master record per unique style.
        normal_set={price(r[4]) for r in rows if price(r[4])>0}
        sale_set={price(r[5]) for r in rows if price(r[5])>0}
        start_set={day(r[6]) for r in rows if day(r[6])}
        representative=next((r for r in rows if r[2]), rows[0])
        if sku in oldcodes:
            ignored+=1
            continue
        if len(normal_set)>1 or len(sale_set)>1 or len(start_set)>1:
            new_review(wb,[*representative,None,None,None,None,None],
                       '본사 신상리스트 동일 품번의 가격 또는 시작일이 서로 달라 확인 필요')
            review+=1
            # Supply both conflicting source values to the queue so registration is blocked.
            for rr in rows:
                if not any(tuple(queue.cell(x,i).value for i in range(1,9))==tuple(rr)
                           for x in queued.get(sku,[]) for _ in (0,)):
                    queue.append([*rr,None,None,None,None,None])
                    queued.setdefault(sku,[]).append(queue.max_row)
            continue
        normal=next(iter(normal_set),0)
        sale=next(iter(sale_set),0)
        start=next(iter(start_set),None)
        if normal<=0 and sale>0:normal=sale
        if sale<=0 and normal>0:sale=normal
        record=list(representative)
        if normal>0: record[4]=normal
        if sale>0: record[5]=sale
        if start is not None: record[6]=start
        if sku in queued:
            # If a revised HQ list conflicts with a nonblank queued value,
            # stop automatic registration rather than silently use stale pricing.
            conflicting=False
            for rr in queued[sku]:
                old_normal=price(queue.cell(rr,5).value)
                old_sale=price(queue.cell(rr,6).value)
                old_day=day(queue.cell(rr,7).value)
                if ((old_normal>0 and normal>0 and old_normal!=normal) or
                    (old_sale>0 and sale>0 and old_sale!=sale) or
                    (old_day and start and old_day!=start)):
                    conflicting=True
            if conflicting:
                new_review(wb,[*record,None,None,None,None,None],
                           '새 신상리스트와 기존 대기행의 가격/적용일이 서로 달라 수동 확인 필요')
                review+=1
                # Supply both values to the normal registrar so it cannot
                # register either ambiguous value by accident.
                if not any(tuple(queue.cell(x,i).value for i in range(1,9))==tuple(record)
                           for x in queued[sku]):
                    queue.append([*record,None,None,None,None,None])
                    queued[sku].append(queue.max_row)
                continue
            updated=False
            for rr in queued[sku]:
                # Existing values win; incompatible nonblank data is detected later by the registrar.
                for col,v in enumerate(record[2:8],3):
                    old=queue.cell(rr,col).value
                    if v not in ('',None) and (old in ('',None) or (col in (5,6) and price(old)==0)):
                        queue.cell(rr,col).value=v
                        updated=True
            if updated:enriched+=1
            ignored+=1
        else:
            queue.append([*record,None,None,None,None,None])
            queued[sku]=[queue.max_row]
            new+=1
            for duplicate in rows[1:]:
                archive.append([*duplicate,None,None,None,None,None,datetime.now(),
                                '원본 신상리스트 동일 품번 색상행 · 대표행만 보존'])
    log.append([src.name,sha,VERSION,datetime.now(),source_rows,new,enriched,ignored,review,
                '신상 공란 허용 · 동일 품번 1개 · 기존 마스터 보존'])
    queue.auto_filter.ref=f'A1:M{max(2,queue.max_row)}'
    return {'changed':True,'source_found':True,'source_styles':len(groups),
            'source_rows':source_rows,'imported_new':new,'enriched':enriched,
            'ignored':ignored,'review':review,'unchanged_styles':skipped_same}

def compact_arrival(wb):
    """Move applied, already-existing and unresolved intake rows out of active queue."""
    if ARRIVAL not in wb.sheetnames:
        return {'changed':False,'archived':0,'review':0,'remaining':0}
    ws=wb[ARRIVAL]
    archive,_=sheet(wb,ARCHIVE,HEADERS+['보관일시','보관사유'])
    # Only data rows in the 13-column intake are changed; all other sheets untouched.
    keep=[];archived=reviews=0
    for r in range(2,ws.max_row+1):
        vals=[ws.cell(r,c).value for c in range(1,14)]
        if not any(x not in (None,'') for x in vals):continue
        status=norm(vals[10])
        if status in ('기존등록','등록완료'):
            archive.append([*vals,datetime.now(),
                            '기존 마스터 중복' if status=='기존등록' else '신상 신규등록 완료'])
            archived+=1
        elif status in ('자료확인','자료불일치'):
            if new_review(wb,vals,'신상 가격 또는 적용일 충돌/가격정보 전부 누락'):
                reviews+=1
        else:
            keep.append(vals)
    removed=archived+sum(1 for r in range(2,ws.max_row+1)
                         if norm(ws.cell(r,11).value) in ('자료확인','자료불일치'))
    if removed:
        # Intake has no formulas or merged cells in its body. Keep source sheet header/styles.
        ws.delete_rows(2,ws.max_row-1)
        for vals in keep: ws.append(vals)
        ws.auto_filter.ref=f'A1:M{max(ws.max_row,2)}'
    return {'changed':bool(removed),'archived':archived,
            'review':reviews,'remaining':len(keep)}
