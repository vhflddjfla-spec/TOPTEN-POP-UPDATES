Option Explicit
Dim zipPath, destPath, fso, sh, src, dst
If WScript.Arguments.Count < 2 Then WScript.Quit 2
zipPath = WScript.Arguments(0)
destPath = WScript.Arguments(1)
Set fso = CreateObject("Scripting.FileSystemObject")
If Not fso.FolderExists(destPath) Then fso.CreateFolder(destPath)
Set sh = CreateObject("Shell.Application")
Set src = sh.NameSpace(zipPath)
Set dst = sh.NameSpace(destPath)
If src Is Nothing Or dst Is Nothing Then WScript.Quit 3
dst.CopyHere src.Items, 20
WScript.Sleep 3000
WScript.Quit 0
