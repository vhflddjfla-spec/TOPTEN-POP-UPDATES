@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "ROOT=%~1"
if not defined ROOT set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"
set "MODE=%~2"
if not defined MODE set "MODE=full"
set "DATA=%ROOT%\data"
set "RUNTIME=%ROOT%\runtime"
set "PYDIR=%RUNTIME%\Python313"
set "PYEXE=%PYDIR%\python.exe"
set "LOG=%ROOT%\run_setup_log.txt"
set "TMPDIR=%TEMP%\TOPTEN_POP_V4410_SETUP"
set "PYZIP=%TMPDIR%\python-3.13.14-embed-amd64.zip"
set "GETPIP=%TMPDIR%\get-pip.py"
set "PYURL=https://www.python.org/ftp/python/3.13.14/python-3.13.14-embed-amd64.zip"
set "PYHASH=90b4e5b9898b72d744650524bff92377c367f44bd5fbd09e3148656c080ad907"
set "PIPURL=https://bootstrap.pypa.io/get-pip.py"

if not exist "%DATA%" mkdir "%DATA%" >nul 2>&1
if not exist "%RUNTIME%" mkdir "%RUNTIME%" >nul 2>&1
if not exist "%TMPDIR%" mkdir "%TMPDIR%" >nul 2>&1
if not exist "%DATA%" exit /b 60
if not exist "%RUNTIME%" exit /b 60
>"%LOG%" echo TOPTEN POP V4.4.10 AUTO SETUP LOG
call :log "Setup start - PowerShell-free bootstrap / mode=%MODE%"

set "NATIVE_ARCH=%PROCESSOR_ARCHITECTURE%"
if defined PROCESSOR_ARCHITEW6432 set "NATIVE_ARCH=%PROCESSOR_ARCHITEW6432%"
if /I not "%NATIVE_ARCH%"=="AMD64" goto fail_arch

:python_check
if not exist "%PYEXE%" goto python_prepare
"%PYEXE%" -c "import struct,sys;raise SystemExit(0 if struct.calcsize('P')*8==64 and sys.version_info[:2]==(3,13) else 1)" >nul 2>&1
if errorlevel 1 goto python_rebuild
call :log "Portable Python OK: %PYEXE%"
goto python_pip_check

:python_rebuild
call :log "Portable Python exists but failed verification. Rebuilding runtime."
rmdir /s /q "%PYDIR%" >nul 2>&1

:python_prepare
call :log "Downloading official Python 3.13.14 embeddable x64 package."
if exist "%PYZIP%" del /q "%PYZIP%" >nul 2>&1
call :download "%PYURL%" "%PYZIP%"
if errorlevel 1 goto fail_python_download
for %%I in ("%PYZIP%") do set "PYSIZE=%%~zI"
if not defined PYSIZE goto fail_python_download
if !PYSIZE! LSS 9000000 goto fail_python_download
call :hashcheck "%PYZIP%" "%PYHASH%"
if errorlevel 1 goto fail_python_hash
if exist "%PYDIR%" rmdir /s /q "%PYDIR%" >nul 2>&1
mkdir "%PYDIR%" >nul 2>&1
where tar.exe >nul 2>&1
if errorlevel 1 goto python_unzip_vbs
call :log "Extracting Python with Windows tar.exe."
tar.exe -xf "%PYZIP%" -C "%PYDIR%" >>"%LOG%" 2>&1
if exist "%PYEXE%" goto python_unzip_done

:python_unzip_vbs
call :log "Extracting Python with Windows Shell ZIP fallback."
cscript.exe //nologo "%ROOT%\bootstrap_unzip.vbs" "%PYZIP%" "%PYDIR%" >>"%LOG%" 2>&1
set /a WAITZIP=0
:python_zip_wait
if exist "%PYEXE%" goto python_unzip_done
set /a WAITZIP+=1
if !WAITZIP! GEQ 30 goto fail_python_extract
timeout /t 1 /nobreak >nul
goto python_zip_wait

:python_unzip_done
if not exist "%PYEXE%" goto fail_python_extract
set "PTH=%PYDIR%\python313._pth"
if not exist "%PYDIR%\Lib\site-packages" mkdir "%PYDIR%\Lib\site-packages" >nul 2>&1
findstr /x /c:"Lib\site-packages" "%PTH%" >nul 2>&1
if errorlevel 1 >>"%PTH%" echo Lib\site-packages
findstr /x /c:"import site" "%PTH%" >nul 2>&1
if errorlevel 1 >>"%PTH%" echo import site
"%PYEXE%" -c "import struct;raise SystemExit(0 if struct.calcsize('P')*8==64 else 1)" >>"%LOG%" 2>&1
if errorlevel 1 goto fail_python_verify
call :log "Portable Python runtime ready."

:python_pip_check
"%PYEXE%" -m pip --version >nul 2>&1
if not errorlevel 1 goto python_packages
call :log "pip not found. Downloading official get-pip.py."
if exist "%GETPIP%" del /q "%GETPIP%" >nul 2>&1
call :download "%PIPURL%" "%GETPIP%"
if errorlevel 1 goto fail_pip_download
for %%I in ("%GETPIP%") do set "PIPSIZE=%%~zI"
if not defined PIPSIZE goto fail_pip_download
if !PIPSIZE! LSS 1000000 goto fail_pip_download
"%PYEXE%" "%GETPIP%" --disable-pip-version-check >>"%LOG%" 2>&1
if errorlevel 1 goto fail_pip_install

:python_packages
call :log "Checking Python modules."
"%PYEXE%" -c "import flask,openpyxl,PIL,fitz,pytesseract,packaging" >nul 2>&1
if not errorlevel 1 goto python_done
call :log "Installing required Python modules from PyPI."
"%PYEXE%" -m pip install --disable-pip-version-check --no-warn-script-location --retries 3 --timeout 45 flask openpyxl pillow pymupdf pytesseract packaging >>"%LOG%" 2>&1
if errorlevel 1 goto fail_packages
"%PYEXE%" -c "import flask,openpyxl,PIL,fitz,pytesseract,packaging" >>"%LOG%" 2>&1
if errorlevel 1 goto fail_packages

:python_done
>"%DATA%\python_path.txt" echo %PYEXE%
call :log "Python and required modules READY."
if /I "%MODE%"=="core" goto core_ready
goto tesseract_check

:core_ready
call :log "Core environment READY for update check."
exit /b 0

:tesseract_check
if not exist "%ROOT%\ocr_bootstrap.py" goto fail_tessdata
call :log "Auto-detecting installed Tesseract and OCR language data."
"%PYEXE%" "%ROOT%\ocr_bootstrap.py" "%ROOT%" >>"%LOG%" 2>&1
if errorlevel 1 goto fail_tessdata_verify
call :log "Tesseract and OCR language data verified by Python bootstrap."
call :log "Environment READY."
exit /b 0

:download
set "DLURL=%~1"
set "DLOUT=%~2"
for %%I in ("%DLOUT%") do if not exist "%%~dpI" mkdir "%%~dpI" >nul 2>&1
if exist "%DLOUT%" del /q "%DLOUT%" >nul 2>&1
where curl.exe >nul 2>&1
if errorlevel 1 goto download_certutil
curl.exe -L --fail --retry 3 --connect-timeout 20 --max-time 360 -o "%DLOUT%" "%DLURL%" >>"%LOG%" 2>&1
if not errorlevel 1 if exist "%DLOUT%" exit /b 0
:download_certutil
certutil.exe -urlcache -split -f "%DLURL%" "%DLOUT%" >>"%LOG%" 2>&1
if errorlevel 1 exit /b 1
if not exist "%DLOUT%" exit /b 1
exit /b 0

:hashcheck
set "HASHFILE=%~1"
set "EXPECTED=%~2"
certutil.exe -hashfile "%HASHFILE%" SHA256 >"%TMPDIR%\hash.txt" 2>>"%LOG%"
if errorlevel 1 exit /b 1
findstr /I /C:"%EXPECTED%" "%TMPDIR%\hash.txt" >nul 2>&1
if errorlevel 1 exit /b 1
exit /b 0

:log
set "MSG=%~1"
echo %MSG%
>>"%LOG%" echo [%date% %time%] %MSG%
exit /b 0

:fail_arch
call :log "BLOCKED: Windows x64 AMD64 was not detected."
exit /b 32
:fail_python_download
call :log "FAILED: Python embeddable package download failed."
exit /b 41
:fail_python_hash
call :log "FAILED: Python package SHA256 verification failed."
exit /b 42
:fail_python_extract
call :log "FAILED: Python ZIP extraction failed."
exit /b 43
:fail_python_verify
call :log "FAILED: Portable Python did not start correctly."
exit /b 44
:fail_pip_download
call :log "FAILED: get-pip.py download failed."
exit /b 45
:fail_pip_install
call :log "FAILED: pip installation failed."
exit /b 46
:fail_packages
call :log "FAILED: Required Python module installation failed."
exit /b 47
:fail_tess_download
call :log "FAILED: Tesseract automatic discovery/installation failed."
exit /b 51
:fail_tess_hash
call :log "FAILED: Tesseract installer verification failed."
exit /b 52
:fail_tess_install
call :log "FAILED: Tesseract executable was not found after automatic setup."
exit /b 53
:fail_tessdata
call :log "FAILED: OCR language data preparation failed."
exit /b 54
:fail_tessdata_verify
call :log "FAILED: OCR language verification failed. See data\ocr_languages_check.txt and run_setup_log.txt."
exit /b 55
