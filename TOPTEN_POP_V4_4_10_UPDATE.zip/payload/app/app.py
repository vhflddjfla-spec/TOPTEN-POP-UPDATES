# -*- coding: utf-8 -*-
from __future__ import annotations
import hashlib
import os, re, sys, time, socket, threading, webbrowser, subprocess, shutil, json, difflib, itertools
from contextlib import contextmanager
from pathlib import Path
from datetime import datetime
from typing import Any
from collections import OrderedDict

from flask import Flask, request, redirect, send_from_directory, render_template_string, jsonify
from openpyxl import load_workbook
from PIL import Image, ImageDraw, ImageFont
import fitz

_PYTESSERACT_IMPORT_ERROR = ''
try:
    import pytesseract
except Exception as exc:
    pytesseract = None
    _PYTESSERACT_IMPORT_ERROR = f'{type(exc).__name__}: {exc}'

ROOT = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parents[1]))
DATA_DIR = ROOT / 'data'
TEMPLATE_DIR = ROOT / 'templates'
PRODUCT_DIR = ROOT / 'product_images'
OUTPUT_DIR = ROOT / 'output'
CACHE_DIR = ROOT / 'cache'
LEGACY_BONUS_DIR = ROOT / 'bonus_pdfs'  # legacy migration fallback only; new PDFs use webhard_sync directly.
BONUS_MAP_FILE = DATA_DIR / 'bonus_page_matches.json'
WEBHARD_SYNC_DIR = ROOT / 'webhard_sync'
SYNC_STATE_FILE = DATA_DIR / 'webhard_sync_state.json'
QUEUE_FILE = DATA_DIR / 'generation_queue.json'
OCR_CACHE_FILE = DATA_DIR / 'ocr_page_cache.json'
OCR_LEARN_FILE = DATA_DIR / 'ocr_manual_learning.json'
VISUAL_CHOICE_FILE = DATA_DIR / 'carryover_visual_choices.json'
ADULT_SMALL_TEMPLATE = TEMPLATE_DIR / 'TT_ADULT_SMALL.pdf'
CLEARANCE_TEMPLATE = TEMPLATE_DIR / 'TT_CLEARANCE.pdf'
PID_FILE = DATA_DIR / 'server.pid'
CURRENT_XLSX = DATA_DIR / 'current_promotion.xlsx'
LAST_NAME = DATA_DIR / 'last_filename.txt'
for d in (DATA_DIR,TEMPLATE_DIR,PRODUCT_DIR,OUTPUT_DIR,CACHE_DIR,WEBHARD_SYNC_DIR): d.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)

_ITEMS_CACHE = None
_CACHE_MTIME = None
_PRODUCT_INDEX = None
_BONUS_MAP_CACHE = None
_BONUS_MAP_MTIME = None
_RENDER_CACHE = OrderedDict()
_RENDER_CACHE_MAX = 3
_OCR_CACHE = None
_OCR_CACHE_DIRTY = False
OCR_CACHE_VERSION = 'ocr-v4-stability-background'
MATCH_ALGORITHM_VERSION = 'match-v4.4.10-webhard-direct-no-duplicate'
OCR_AUTO_THRESHOLD = 0.75
OCR_RECOMMEND_THRESHOLD = 0.50
OCR_MARGIN_THRESHOLD = 0.07

# Background scan state. Heavy PDF/OCR work never runs inside a browser request.
_SCAN_LOCK = threading.Lock()
_SCAN_STATUS_LOCK = threading.Lock()
_SCAN_STATUS = {
    'running': False, 'mode': '', 'started_at': '', 'finished_at': '',
    'message': '대기 중', 'error': '', 'processed': 0
}

PREVIEW_DPI = 105
PREVIEW_MAX_WIDTH = 900

EXTS = ['.pdf','.png','.jpg','.jpeg','.webp']
# Font policy for the TOPTEN adult-small bottom bar.
# Font files are not bundled. The app searches the local fonts folder and Windows Fonts.
FONT_DIR = ROOT / 'fonts'
FONT_KO_NAMES = ['NanumBarunGothic.otf', 'NanumBarunGothic.ttf']
FONT_DIN_MEDIUM_NAMES = ['DINPro-Medium.otf', 'DINPro-Medium.ttf']
FONT_DIN_BOLD_NAMES = ['DINPro-Bold.otf', 'DINPro-Bold.ttf']

def resolve_font_file(names):
    candidates = []
    for name in names:
        candidates.extend([
            FONT_DIR / name,
            Path('C:/Windows/Fonts') / name,
            Path.home() / 'AppData/Local/Microsoft/Windows/Fonts' / name,
        ])
    for path in candidates:
        if path.exists():
            return path
    return None

FONT_KO = resolve_font_file(FONT_KO_NAMES)
FONT_DIN_MEDIUM = resolve_font_file(FONT_DIN_MEDIUM_NAMES)
FONT_DIN_BOLD = resolve_font_file(FONT_DIN_BOLD_NAMES)

DPI = 300
MM_TO_PX = DPI / 25.4
# The original TOPTEN visual PDFs are A4 masters intended to print at 100%.
A4_W_MM = 210.0
A4_H_MM = 297.0
# The acrylic case uses the full A4 width and a 240 mm high cutout.
# The original NEW ARRIVAL artwork begins 32 mm from the A4 top edge.
CUT_TOP_MM = 32.0
CUT_H_MM = 240.0
CUT_BOTTOM_MM = CUT_TOP_MM + CUT_H_MM
# Bottom bar is the measured physical size: 210 x 50 mm.
# It always covers the final 50 mm of the 210 x 240 mm finished POP.
BAR_H_MM = 50.0
BAR_TOP_MM = CUT_BOTTOM_MM - BAR_H_MM
VISUAL_VISIBLE_H_MM = BAR_TOP_MM - CUT_TOP_MM
A4_W_PX = round(A4_W_MM * MM_TO_PX)
A4_H_PX = round(A4_H_MM * MM_TO_PX)
POP_W_PX = A4_W_PX
POP_H_PX = round(CUT_H_MM * MM_TO_PX)
BAR_H_PX = round(BAR_H_MM * MM_TO_PX)
CUT_TOP_PX = round(CUT_TOP_MM * MM_TO_PX)
BAR_TOP_PX = round(BAR_TOP_MM * MM_TO_PX)

def pt_px(pt: float) -> int:
    return max(1, round(pt * DPI / 72.0))


HTML = r'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>TOPTEN POP 자동화</title><style>
*{box-sizing:border-box}body{margin:0;background:#f3f5f7;font-family:Malgun Gothic,Arial,sans-serif;color:#161616}.wrap{max-width:1560px;margin:auto;padding:24px}.top{background:#0d255f;color:white;padding:20px 24px;border-radius:12px;display:flex;justify-content:space-between;align-items:center}.top h1{margin:0;font-size:25px}.top small{opacity:.85}.panel{background:white;border-radius:12px;padding:18px;margin-top:16px;box-shadow:0 2px 10px #00000010}.row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.btn{border:0;border-radius:7px;padding:10px 16px;font-weight:700;cursor:pointer;background:#102c73;color:white;text-decoration:none;display:inline-block}.red{background:#e30613}.gray{background:#555}.green{background:#26734d}.orange{background:#b55d00}.search{padding:10px;border:1px solid #bbb;border-radius:7px;min-width:320px}.stats{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin-top:12px}.stat{background:#f7f8fa;padding:12px;border-radius:8px;text-align:center}.stat b{font-size:22px;color:#102c73}.layout{display:grid;grid-template-columns:minmax(700px,1.55fr) minmax(410px,.85fr);gap:16px;margin-top:16px}.tablebox{max-height:650px;overflow:auto;border:1px solid #ddd}table{width:100%;border-collapse:collapse;font-size:13px}th,td{padding:9px;border-bottom:1px solid #e2e2e2;text-align:center;white-space:nowrap}th{position:sticky;top:0;background:#edf1f7;z-index:2}.left{text-align:left;max-width:280px;overflow:hidden;text-overflow:ellipsis}.sale{color:#e30613;font-weight:700}.badge{padding:3px 8px;border-radius:12px;color:white;font-size:11px}.b-sale{background:#e30613}.b-normal{background:#555}.preview{min-height:440px;text-align:center;background:#f7f7f7;border-radius:8px;padding:12px}.preview img{max-width:100%;max-height:590px;box-shadow:0 3px 15px #0003;background:white}.detail{text-align:left;background:white;margin-top:10px;padding:12px;border-radius:8px;line-height:1.7}.muted{color:#777}.warn{color:#c00;font-weight:700}.queue{border:2px solid #dbe2f0;background:#fbfcff}.queue-list{max-height:245px;overflow:auto;border:1px solid #ddd;border-radius:7px;background:white}.queue-item{display:grid;grid-template-columns:28px 110px 1fr;gap:7px;align-items:center;padding:9px;border-bottom:1px solid #eee;font-size:13px}.queue-empty{padding:20px;text-align:center;color:#777}.loading{opacity:.55;pointer-events:none}.toast{position:fixed;right:24px;bottom:24px;background:#111;color:#fff;padding:12px 18px;border-radius:8px;display:none;z-index:20}@media(max-width:1050px){.layout{grid-template-columns:1fr}.stats{grid-template-columns:repeat(2,1fr)}}
</style><script>
function allcheck(x){document.querySelectorAll('#productForm input[name=codes]').forEach(e=>e.checked=x.checked)}
function checkedCodes(){return [...document.querySelectorAll('#productForm input[name=codes]:checked')].map(e=>e.value)}
function toast(t){let e=document.getElementById('toast');e.textContent=t;e.style.display='block';setTimeout(()=>e.style.display='none',1800)}
async function setVisualChoice(code,choice){let body=new URLSearchParams({code,choice});let r=await fetch('/api/visual-choice',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body});return await r.json()}
async function resolveVisualChoices(codes,force=false){if(!codes.length)return true;let qs=new URLSearchParams();codes.forEach(c=>qs.append('code',c));if(force)qs.set('force','1');let r=await fetch('/api/visual-choice-required?'+qs.toString());let d=await r.json();for(let i of (d.items||[])){let useBonus=confirm(`[${i.code}] ${i.title_ko}\n\n이월상품에 연결된 번외 POP가 있습니다.\n\n확인: 번외 POP 사용\n취소: 특별가격 POP 사용`);await setVisualChoice(i.code,useBonus?'bonus':'clearance')}return true}
async function changeVisualChoice(code){await resolveVisualChoices([code],true);await preview(code)}
async function preview(code){let box=document.getElementById('previewBox');box.classList.add('loading');try{let r=await fetch('/api/item/'+encodeURIComponent(code));let d=await r.json();document.getElementById('pv').src='/preview/'+encodeURIComponent(code)+'?v='+(d.preview_version||'1');document.getElementById('detail').innerHTML=`<b>${d.code}</b> · 시즌 ${d.season_letter||'-'}<br>상품명: ${d.title_ko}<br>정상가: ${d.normal_fmt}<br>할인가: <span class="sale">${d.sale_fmt}</span> · 할인율: <b>${d.discount_percent_fmt||'-'}</b><br>프로모션: ${d.promotion||'-'}<br>행사기간: ${d.date_range||'-'}<br>비주얼: ${d.visual_status}`}finally{box.classList.remove('loading')}}
async function queueAction(url,codes=[]){let body=new URLSearchParams();codes.forEach(c=>body.append('codes',c));let r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body});let d=await r.json();renderQueue(d.items||[]);return d}
async function addCheckedToQueue(){let c=checkedCodes();if(!c.length){toast('체크한 품번이 없습니다.');return}let d=await queueAction('/queue/add',c);toast(d.added+'개를 생성 목록에 추가했습니다.');}
async function removeQueueChecked(){let c=[...document.querySelectorAll('#queueList input[name=qcodes]:checked')].map(e=>e.value);if(!c.length){toast('삭제할 품번을 선택하세요.');return}await queueAction('/queue/remove',c);toast('목록에서 삭제했습니다.');}
async function clearQueue(){if(confirm('생성할 POP 목록을 모두 비울까요?')){await queueAction('/queue/clear');toast('목록을 비웠습니다.')}}
function renderQueue(items){let q=document.getElementById('queueList'),count=document.getElementById('queueCount');count.textContent=items.length;if(!items.length){q.innerHTML='<div class="queue-empty">체크한 상품을 목록에 추가하면 여기에 쌓입니다.</div>';return}q.innerHTML=items.map(i=>`<label class="queue-item"><input type="checkbox" name="qcodes" value="${i.code}"><b>${i.code}</b><span>${i.title_ko}</span></label>`).join('')}
async function generateQueue(){let codes=[...document.querySelectorAll('#queueList input[name=qcodes]')].map(e=>e.value);let count=codes.length;if(!count){toast('생성 목록이 비어 있습니다.');return}if(!confirm(count+'개 POP를 한꺼번에 생성할까요?'))return;let btn=document.getElementById('queueGenerate');btn.disabled=true;btn.textContent='생성 중...';try{let r=await fetch('/queue/generate',{method:'POST'});let d=await r.json();renderQueue(d.items||[]);toast(d.generated+'개 생성 완료');setTimeout(()=>location.reload(),700)}finally{btn.disabled=false;btn.textContent='목록 전체 POP 생성'}}
async function generateImmediate(mode){let form=document.getElementById('productForm');let codes=mode==='all'?[...form.querySelectorAll('input[name=codes]')].map(e=>e.value):checkedCodes();if(!codes.length){toast('생성할 품번이 없습니다.');return}let hidden=document.createElement('input');hidden.type='hidden';hidden.name='mode';hidden.value=mode;form.appendChild(hidden);form.submit()}
</script></head><body><div class="wrap">
<div class="top"><div><h1>TOPTEN 완전 자동 POP · V4.4.10 <span style="font-size:14px;font-weight:600;color:#666;margin-left:10px">Made By. 포항장성점 김대영</span></h1><small>엑셀 업로드 · 품번 이미지 자동 매칭 · 할인율 70% 이상 특별가격 · 70% 미만 번외 우선/성인소형 · 자동업데이트 지원</small></div><b>{{loaded_name}}</b></div>{% if missing_fonts %}<div class="panel warn">필수 폰트 미설치: {{missing_fonts|join(', ')}}<br>Windows에 설치하거나 fonts 폴더에 복사한 뒤 RUN.cmd를 다시 실행하세요.</div>{% endif %}
<div class="panel"><div class="row" style="margin-bottom:12px"><a class="btn green" href="/bonus">번외 PDF 자동매칭</a><a class="btn" href="/sync">웹하드 다운로드 폴더</a></div><form action="/upload" method="post" enctype="multipart/form-data" class="row"><input type="file" name="excel" accept=".xlsx,.xlsm" required><button class="btn">프로모션 엑셀 적용</button><span class="muted">인식 행사기간: <b>{{date_range or '-'}}</b></span></form>
<div class="stats"><div class="stat"><b>{{items|length}}</b><br>전체 상품</div><div class="stat"><b>{{normal_count}}</b><br>정상가</div><div class="stat"><b>{{sale_count}}</b><br>할인가</div><div class="stat"><b>{{matched_count}}</b><br>이미지 매칭</div><div class="stat"><b>{{missing_count}}</b><br>이미지 미매칭</div></div></div>
<div class="layout"><div class="panel" style="margin-top:0"><form method="get" action="/" class="row"><input class="search" name="q" value="{{q}}" placeholder="품번 또는 상품명 검색"><button class="btn">검색</button><a href="/" class="btn gray">초기화</a></form>
<form id="productForm" action="/generate" method="post"><div class="row" style="justify-content:space-between;margin:14px 0"><label><input type="checkbox" onclick="allcheck(this)"> 전체선택</label><div><button type="button" onclick="addCheckedToQueue()" class="btn orange">체크 상품을 생성 목록에 추가</button> <button type="button" onclick="generateImmediate('selected')" class="btn red">선택 POP 즉시 생성</button> <button type="button" onclick="generateImmediate('all')" class="btn green">검색결과 전체 생성</button></div></div>
<div class="tablebox"><table><thead><tr><th></th><th>구분</th><th>품번</th><th>성별/조닝</th><th>상품명</th><th>정상가</th><th>할인가</th><th>할인율</th><th>프로모션</th><th>이미지</th></tr></thead><tbody>{% for i in items %}<tr onclick="preview('{{i.code}}')" style="cursor:pointer"><td onclick="event.stopPropagation()"><input type="checkbox" name="codes" value="{{i.code}}"></td><td><span class="badge {{'b-sale' if i.is_discount else 'b-normal'}}">{{'할인가' if i.is_discount else '정상가'}}</span></td><td><b>{{i.code}}</b></td><td>{{i.gender}} / {{i.zone}}</td><td class="left">{{i.title_ko}}</td><td>{{i.normal_fmt}}</td><td class="sale">{{i.sale_fmt}}</td><td>{{i.discount_percent_fmt}}</td><td class="left">{{i.promotion or '-'}}</td><td>{{i.visual_status}}</td></tr>{% endfor %}</tbody></table></div></form></div>
<div><div class="panel queue" style="margin-top:0"><div class="row" style="justify-content:space-between"><h3 style="margin:0">생성할 POP 목록 (<span id="queueCount">{{queue_items|length}}</span>)</h3><button id="queueGenerate" class="btn red" onclick="generateQueue()">목록 전체 POP 생성</button></div><p class="muted">검색을 바꿔도 목록은 유지되며, 프로그램을 껐다 켜도 저장됩니다. 일괄 생성이 끝난 품번은 목록에서 자동 삭제됩니다.</p><div id="queueList" class="queue-list">{% for i in queue_items %}<label class="queue-item"><input type="checkbox" name="qcodes" value="{{i.code}}"><b>{{i.code}}</b><span>{{i.title_ko}}</span></label>{% else %}<div class="queue-empty">체크한 상품을 목록에 추가하면 여기에 쌓입니다.</div>{% endfor %}</div><div class="row" style="margin-top:10px"><button class="btn gray" onclick="removeQueueChecked()">선택 삭제</button><button class="btn gray" onclick="clearQueue()">목록 전체 비우기</button></div></div>
<div class="panel" style="margin-top:16px"><h3>POP 미리보기 / 상품 정보</h3><div id="previewBox" class="preview"><img id="pv" src="{{initial_preview}}"><div id="detail" class="detail">목록의 상품을 클릭하면 상품명, 가격, 프로모션 내용과 POP가 표시됩니다.</div></div></div></div></div>
{% if generated %}<div class="panel"><h3>생성 완료</h3><div class="row">{% for f in generated %}<a class="btn" href="/output/{{f}}" target="_blank">{{f}}</a>{% endfor %}</div></div>{% endif %}
</div><div id="toast" class="toast"></div></body></html>'''

def font(path, size:int, fallback_bold=False):
    candidates = []
    if path:
        candidates.append(Path(path))
    if fallback_bold:
        candidates.extend([Path('C:/Windows/Fonts/arialbd.ttf'), Path('C:/Windows/Fonts/malgunbd.ttf')])
    else:
        candidates.extend([Path('C:/Windows/Fonts/arial.ttf'), Path('C:/Windows/Fonts/malgun.ttf')])
    candidates.append(Path('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if fallback_bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
    for p in candidates:
        try:
            if p.exists():
                return ImageFont.truetype(str(p), size)
        except Exception:
            pass
    return ImageFont.load_default()

def missing_required_fonts():
    missing = []
    if FONT_KO is None: missing.append('NanumBarunGothic.otf')
    if FONT_DIN_MEDIUM is None: missing.append('DINPro-Medium.otf')
    if FONT_DIN_BOLD is None: missing.append('DINPro-Bold.otf')
    return missing

def n(v):
    try:
        if v in (None,''): return 0
        return int(float(str(v).replace(',','')))
    except:return 0

def clean_code(v): return re.sub(r'[^A-Z0-9_-]','',str(v or '').strip().upper())

def infer_gender_from_code(code, fallback=''):
    """Infer TOPTEN gender from the first digit of the final four digits.

    Store rule:
      1xxx = 남성, 2xxx = 여성, 3xxx = 공용.
    The product-code rule has priority over the promotion Excel gender value.
    If a code does not end in four digits or the first digit is not 1/2/3,
    preserve the supplied fallback value.
    """
    normalized = clean_code(code)
    match = re.search(r'(\d{4})$', normalized)
    if not match:
        return str(fallback or '').strip()
    return {'1': '남성', '2': '여성', '3': '공용'}.get(
        match.group(1)[0], str(fallback or '').strip()
    )

def normalize_date_range(value):
    """Convert common Excel/promotion period formats to M/D ~ M/D."""
    if value is None:
        return ''
    if isinstance(value, datetime):
        return f'{value.month}/{value.day}'
    text = str(value).strip()
    if not text:
        return ''
    text = re.sub(r'^.*?기간\s*[:：]?\s*', '', text)
    text = text.replace('～', '~').replace('−', '-').replace('–', '-').replace('—', '-')
    # Korean month/day, slash, dot, or dash date forms. Ignore a leading year.
    pairs = []
    patterns = [
        r'(?:(?:20\d{2})[./-])?(\d{1,2})[./-](\d{1,2})',
        r'(\d{1,2})\s*월\s*(\d{1,2})\s*일?',
    ]
    for pattern in patterns:
        pairs = re.findall(pattern, text)
        if len(pairs) >= 2:
            break
    if len(pairs) >= 2:
        (m1,d1),(m2,d2)=pairs[0],pairs[1]
        return f'{int(m1)}/{int(d1)} ~ {int(m2)}/{int(d2)}'
    # A single date is still displayed cleanly.
    if len(pairs) == 1:
        m,d=pairs[0]
        return f'{int(m)}/{int(d)}'
    return re.sub(r'\s+', ' ', text).strip()

def detect_sheet(ws):
    header=None; cols={}
    aliases={'code':['스타일','품번'],'title_ko':['상품명'],'title_en':['상품명(영문)','영문명'],'gender':['성별'],'zone':['조닝','종류'],'color':['컬러'],'normal':['정상가'],'sale':['조정가','할인가'],'promotion':['프로모션 내용'],'season':['시즌']}
    for r in range(1,min(ws.max_row,40)+1):
        vals=[str(ws.cell(r,c).value or '').strip() for c in range(1,ws.max_column+1)]
        if any(x in vals for x in ['스타일','품번']) and '정상가' in vals:
            header=r
            for key,names in aliases.items():
                for name in names:
                    if name in vals:
                        if key=='title_ko' and name=='상품명' and vals.count(name)>1: pass
                        cols[key]=vals.index(name)+1; break
            # explicit columns for this TOPTEN format
            if '상품명(영문)' in vals: cols['title_en']=vals.index('상품명(영문)')+1
            if '프로모션 내용' in vals: cols['promotion']=vals.index('프로모션 내용')+1
            break
    if not header: raise ValueError('헤더 행을 찾지 못했습니다. 품번/스타일과 정상가 열이 필요합니다.')
    return header,cols

def detect_date(ws):
    pats=[]
    for r in range(1,min(ws.max_row,20)+1):
      for c in range(1,min(ws.max_column,20)+1):
        s=str(ws.cell(r,c).value or '').strip()
        if '기간' in s or re.search(r'\d{1,2}월\s*\d{1,2}',s): pats.append(s)
    if not pats:return ''
    s=pats[0]
    s=re.sub(r'^.*?기간\s*[:：]?\s*','',s)
    s=re.sub(r'\s+',' ',s).strip()
    return s

def build_product_index():
    global _PRODUCT_INDEX
    index = {}
    if PRODUCT_DIR.exists():
        for p in PRODUCT_DIR.iterdir():
            if not p.is_file() or p.suffix.lower() not in EXTS:
                continue
            stem = clean_code(p.stem)
            base = re.split(r'[_-]', stem, maxsplit=1)[0]
            for key in {stem, base}:
                if key:
                    index.setdefault(key, []).append(p)
    for key, files in index.items():
        files.sort(key=lambda p: (EXTS.index(p.suffix.lower()), len(p.name)))
    _PRODUCT_INDEX = index
    return index

def find_visual(code):
    index = _PRODUCT_INDEX if _PRODUCT_INDEX is not None else build_product_index()
    code = clean_code(code)
    files = index.get(code, [])
    return files[0] if files else None

def normalize_product_name(text):
    """Normalize OCR/product names while keeping meaningful item words."""
    text = str(text or '').upper()
    text = re.sub(r'\([^)]*\)|\[[^]]*\]', ' ', text)
    text = re.sub(r'\d[\d,]*\s*원', ' ', text)
    text = re.sub(
        r'남성|여성|공용|키즈|정상가|할인가|기간한정|NEW\s*ARRIVAL|TOPTEN|탑텐|'
        r'봄|여름|가을|겨울|SPRING|SUMMER|FALL|WINTER|시즌|컬러|COLOR',
        ' ', text
    )
    return re.sub(r'[^0-9A-Z가-힣]+', '', text)


def _load_ocr_learning():
    try:
        raw = json.loads(OCR_LEARN_FILE.read_text('utf-8')) if OCR_LEARN_FILE.exists() else {}
        return raw if isinstance(raw, dict) else {}
    except Exception:
        return {}


def _save_ocr_learning(data):
    OCR_LEARN_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


def _learn_ocr_mapping(ocr_text, code):
    key = normalize_product_name(ocr_text)
    code = clean_code(code)
    if len(key) < 3 or not code:
        return
    data = _load_ocr_learning()
    data[key] = {'code': code, 'updated_at': datetime.now().isoformat(timespec='seconds')}
    _save_ocr_learning(data)


def _learned_code_for_text(ocr_text):
    norm = normalize_product_name(ocr_text)
    if not norm:
        return ''
    data = _load_ocr_learning()
    rec = data.get(norm)
    if isinstance(rec, dict) and rec.get('code'):
        return clean_code(rec['code'])
    best_code = ''
    best_score = 0.0
    for key, value in data.items():
        if not isinstance(value, dict) or not value.get('code'):
            continue
        score = difflib.SequenceMatcher(None, key, norm).ratio()
        if key in norm or norm in key:
            score = max(score, 0.94)
        if score > best_score:
            best_score, best_code = score, clean_code(value['code'])
    return best_code if best_score >= 0.90 else ''


def _remove_ocr_learning(codes=None, clear_all=False):
    if clear_all:
        _save_ocr_learning({})
        return
    targets = set(clean_code(c) for c in (codes or []) if clean_code(c))
    if not targets:
        return
    data = _load_ocr_learning()
    next_data = {
        key: value for key, value in data.items()
        if not isinstance(value, dict) or clean_code(value.get('code')) not in targets
    }
    if next_data != data:
        _save_ocr_learning(next_data)


def load_bonus_matches(force=False):
    global _BONUS_MAP_CACHE, _BONUS_MAP_MTIME
    try:
        mtime = BONUS_MAP_FILE.stat().st_mtime_ns if BONUS_MAP_FILE.exists() else -1
    except OSError:
        mtime = -1
    if not force and _BONUS_MAP_CACHE is not None and _BONUS_MAP_MTIME == mtime:
        return _BONUS_MAP_CACHE
    try:
        data = json.loads(BONUS_MAP_FILE.read_text('utf-8')) if BONUS_MAP_FILE.exists() else {}
    except Exception:
        data = {}
    _BONUS_MAP_CACHE, _BONUS_MAP_MTIME = data, mtime
    return data

def save_bonus_matches(data):
    global _BONUS_MAP_CACHE, _BONUS_MAP_MTIME
    BONUS_MAP_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    _BONUS_MAP_CACHE = data
    try: _BONUS_MAP_MTIME = BONUS_MAP_FILE.stat().st_mtime_ns
    except OSError: _BONUS_MAP_MTIME = None

def _normalize_webhard_rel(value):
    """Return a safe POSIX path relative to webhard_sync, or ''."""
    raw = str(value or '').strip().replace('\\', '/').lstrip('/')
    if not raw:
        return ''
    p = Path(raw)
    if p.is_absolute() or not p.parts or any(part in ('', '.', '..') for part in p.parts):
        return ''
    return p.as_posix()

def _resolve_webhard_pdf(value):
    """Resolve a mapping identifier to a PDF under webhard_sync.

    Legacy bonus_pdfs is only a fallback if legacy migration was interrupted.
    """
    rel = _normalize_webhard_rel(value)
    if rel:
        try:
            base = WEBHARD_SYNC_DIR.resolve()
            path = (WEBHARD_SYNC_DIR / Path(rel)).resolve()
            if base in path.parents and path.is_file() and path.suffix.lower() == '.pdf':
                return path
        except Exception:
            pass
    legacy_name = Path(str(value or '')).name
    legacy = LEGACY_BONUS_DIR / legacy_name
    if legacy.is_file() and legacy.suffix.lower() == '.pdf':
        return legacy
    return None

def _bonus_source_id(rec):
    if not isinstance(rec, dict):
        return ''
    return _normalize_webhard_rel(rec.get('source') or rec.get('file') or '')

def bonus_visual_for(code):
    rec = load_bonus_matches().get(clean_code(code))
    if not rec:
        return None
    source_id = _bonus_source_id(rec)
    path = _resolve_webhard_pdf(source_id or rec.get('file',''))
    return f"{path}::page={int(rec.get('page',0))}" if path and path.exists() else None

def season_letter_from_code(code):
    """TOPTEN style codes use the third alphabetic character as the season letter.

    Example: MSG2PP2501 -> G. 2026 = G, 2027 = H; E/F are carryover seasons.
    """
    code = clean_code(code)
    match = re.match(r'^[A-Z]{2}([A-Z])', code)
    return match.group(1) if match else ''


def is_carryover_code(code):
    return season_letter_from_code(code) in {'E', 'F'}


def _load_visual_choices():
    try:
        data = json.loads(VISUAL_CHOICE_FILE.read_text('utf-8')) if VISUAL_CHOICE_FILE.exists() else {}
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_visual_choices(data):
    VISUAL_CHOICE_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


def _bonus_record_signature(code):
    rec = load_bonus_matches().get(clean_code(code))
    if not isinstance(rec, dict):
        return ''
    source_id = _bonus_source_id(rec)
    return f"{source_id}|{int(rec.get('page', 0))}" if source_id else ''


def get_carryover_visual_choice(code):
    code = clean_code(code)
    current_sig = _bonus_record_signature(code)
    if not current_sig:
        return ''
    rec = _load_visual_choices().get(code)
    if not isinstance(rec, dict) or rec.get('bonus_signature') != current_sig:
        return ''
    choice = str(rec.get('choice') or '')
    return choice if choice in {'bonus', 'clearance'} else ''


def set_carryover_visual_choice(code, choice):
    code = clean_code(code)
    choice = str(choice or '').strip().lower()
    if not code or choice not in {'bonus', 'clearance'}:
        return False
    sig = _bonus_record_signature(code)
    if not sig:
        return False
    data = _load_visual_choices()
    data[code] = {
        'choice': choice,
        'bonus_signature': sig,
        'updated_at': datetime.now().isoformat(timespec='seconds')
    }
    _save_visual_choices(data)
    load_items(force=True)
    return True


def _gender_template_page(gender, template_kind):
    gender = str(gender or '').strip()
    if template_kind == 'clearance':
        return {'공용': 0, '남성': 1, '여성': 2}.get(gender, 0)
    # TT adult-small: page 6 = common, 7 = men, 8 = women (zero based 5/6/7).
    return {'공용': 5, '남성': 6, '여성': 7}.get(gender, 5)


def _template_visual(template_path, page):
    return f"{template_path}::page={int(page)}"


def resolve_item_visual(code, gender, is_discount, discount_percent=0.0):
    """Apply final V4.4 routing rules.

    Final store priority:
      - Normal price: matched bonus first; NEW ARRIVAL when no bonus exists.
      - Discount 70% or more: SPECIAL PRICE POP is mandatory, even when a bonus PDF exists.
      - Discount below 70%: matched bonus first; adult-small POP when no bonus exists.
    """
    code = clean_code(code)
    bonus = bonus_visual_for(code)
    carryover = is_carryover_code(code)
    season = season_letter_from_code(code)
    try:
        discount_percent = float(discount_percent or 0.0)
    except Exception:
        discount_percent = 0.0
    result = {
        'season_letter': season,
        'is_carryover': carryover,
        'bonus_available': bool(bonus),
        'requires_bonus_choice': False,
        'bonus_choice': '',
        'discount_percent': round(discount_percent, 1),
        'discount_percent_fmt': (f'{discount_percent:.1f}%'.replace('.0%', '%') if is_discount else '-'),
    }

    # Normal price: bonus is always first, NEW ARRIVAL is fallback.
    if not is_discount:
        if bonus:
            result.update({
                'visual_mode': 'standard_overlay',
                'visual': bonus,
                'visual_status': '정상가 · 번외 PDF 우선'
            })
        else:
            result.update({
                'visual_mode': 'standard_overlay',
                'visual': str(TEMPLATE_DIR / 'NEW_ARRIVAL.pdf'),
                'visual_status': '정상가 · NEW ARRIVAL'
            })
        return result

    # 70% or deeper markdown ALWAYS uses SPECIAL PRICE and ignores bonus mapping.
    if discount_percent >= 70.0:
        page = _gender_template_page(gender, 'clearance')
        result.update({
            'visual_mode': 'clearance',
            'visual': _template_visual(CLEARANCE_TEMPLATE, page),
            'visual_status': f'할인율 {discount_percent:.1f}% · 70% 이상 특별가격 POP 필수'
        })
        return result

    # Every discounted item below 70%: bonus first, adult-small fallback.
    if bonus:
        result.update({
            'visual_mode': 'standard_overlay',
            'visual': bonus,
            'visual_status': f'할인율 {discount_percent:.1f}% · 번외 PDF 우선'
        })
    else:
        page = _gender_template_page(gender, 'adult_small')
        result.update({
            'visual_mode': 'adult_small',
            'visual': _template_visual(ADULT_SMALL_TEMPLATE, page),
            'visual_status': f'할인율 {discount_percent:.1f}% · 성인소형 POP'
        })
    return result

def extract_filename_codes(filename, items):
    """Extract known product codes from a PDF filename, preserving filename order.

    The comparison ignores spaces, underscores, hyphens and brackets. Matching against
    the current promotion item list is safer than OCR and avoids treating dates or other
    numbers as product codes.
    """
    stem = Path(filename).stem.upper()
    compact = re.sub(r'[^A-Z0-9]', '', stem)
    found = []
    seen = set()
    for item in items:
        code = clean_code(item.get('code'))
        code_compact = re.sub(r'[^A-Z0-9]', '', code)
        if not code_compact or code_compact in seen:
            continue
        pos = compact.find(code_compact)
        if pos >= 0:
            found.append((pos, -len(code_compact), code))
            seen.add(code_compact)
    found.sort()
    return [code for _, __, code in found]

def _item_by_code(items):
    return {clean_code(i.get('code')): i for i in items if clean_code(i.get('code'))}


def _saved_runtime_path(filename):
    try:
        p = DATA_DIR / filename
        return p.read_text('utf-8', errors='ignore').strip().strip('"') if p.exists() else ''
    except Exception:
        return ''


def _find_tesseract_executable():
    """Locate the exact Tesseract selected by the V4.4.10 bootstrap first."""
    env = os.environ.get('TESSERACT_CMD', '').strip()
    candidates = [
        _saved_runtime_path('tesseract_path.txt'),
        env,
        shutil.which('tesseract') or '',
        r'C:\Program Files\Tesseract-OCR\tesseract.exe',
        r'C:\Program Files (x86)\Tesseract-OCR\tesseract.exe',
        str(Path.home() / 'AppData/Local/Programs/Tesseract-OCR/tesseract.exe'),
    ]
    for candidate in candidates:
        if candidate and Path(candidate).exists():
            return str(Path(candidate))
    return ''


def _find_tessdata_dir():
    """Locate the exact verified OCR language directory selected by bootstrap."""
    program_data = os.environ.get('ProgramData', r'C:\ProgramData')
    local_appdata = os.environ.get('LOCALAPPDATA', '')
    candidates = [
        _saved_runtime_path('tessdata_path.txt'),
        os.environ.get('TOPTEN_TESSDATA_DIR', '').strip(),
        os.environ.get('TESSDATA_PREFIX', '').strip(),
        str(Path(program_data) / 'TOPTEN_POP' / 'tessdata') if program_data else '',
        str(Path(local_appdata) / 'TOPTEN_POP' / 'tessdata') if local_appdata else '',
        str(ROOT / 'ocr_tessdata'),
        str(ROOT / 'bootstrap_assets' / 'tessdata'),
        str(DATA_DIR / 'downloaded_tessdata'),
    ]
    for candidate in candidates:
        if not candidate:
            continue
        p = Path(candidate)
        if p.is_dir() and all((p / f'{lang}.traineddata').exists() for lang in ('kor','eng','osd')):
            return str(p)
    return ''


def _tessdata_config():
    path = _find_tessdata_dir()
    return f'--tessdata-dir "{path}"' if path else ''


def ocr_engine_status():
    """Return a truthful OCR status and retry a delayed pytesseract import."""
    global pytesseract, _PYTESSERACT_IMPORT_ERROR
    if pytesseract is None:
        try:
            import importlib
            pytesseract = importlib.import_module('pytesseract')
            _PYTESSERACT_IMPORT_ERROR = ''
        except Exception as exc:
            _PYTESSERACT_IMPORT_ERROR = f'{type(exc).__name__}: {exc}'
            return False, f'pytesseract 불러오기 실패: {_PYTESSERACT_IMPORT_ERROR[:140]}'
    cmd = _find_tesseract_executable()
    if not cmd:
        return False, 'Tesseract 실행파일을 찾지 못함 (설치 경로 또는 TESSERACT_CMD 확인)'
    try:
        pytesseract.pytesseract.tesseract_cmd = cmd
        version = str(pytesseract.get_tesseract_version()).splitlines()[0]
        langs = sorted(set(pytesseract.get_languages(config=_tessdata_config())))
        if 'kor' not in langs:
            return False, f'한국어 OCR 데이터(kor) 없음 · 감지 언어: {", ".join(langs) or "없음"}'
        return True, f'정상 · Tesseract {version} · 언어: {", ".join(langs)}'
    except Exception as exc:
        return False, f'Tesseract 연결 오류: {type(exc).__name__}: {str(exc)[:140]}'


def _load_ocr_cache():
    global _OCR_CACHE
    if _OCR_CACHE is not None:
        return _OCR_CACHE
    try:
        _OCR_CACHE = json.loads(OCR_CACHE_FILE.read_text('utf-8')) if OCR_CACHE_FILE.exists() else {}
    except Exception:
        _OCR_CACHE = {}
    return _OCR_CACHE


def _save_ocr_cache():
    global _OCR_CACHE_DIRTY
    if not _OCR_CACHE_DIRTY:
        return
    OCR_CACHE_FILE.write_text(json.dumps(_load_ocr_cache(), ensure_ascii=False, indent=2), encoding='utf-8')
    _OCR_CACHE_DIRTY = False


def _ocr_cache_key(pdf_path, page_no):
    p = Path(pdf_path)
    st = p.stat()
    return hashlib.sha1(f'{p.resolve()}|{st.st_size}|{st.st_mtime_ns}|{page_no}|{OCR_CACHE_VERSION}'.encode('utf-8', errors='ignore')).hexdigest()


def _prepare_ocr_image(page):
    # 200 DPI is enough for printed POP titles while keeping first-scan time practical.
    pix = page.get_pixmap(matrix=fitz.Matrix(200/72, 200/72), alpha=False, colorspace=fitz.csRGB)
    im = Image.frombytes('RGB', (pix.width, pix.height), pix.samples)
    gray = im.convert('L')
    # Improve contrast for pale gray/colored POP text, then enlarge slightly for Hangul.
    from PIL import ImageEnhance, ImageFilter, ImageOps
    gray = ImageOps.autocontrast(gray, cutoff=1)
    gray = ImageEnhance.Contrast(gray).enhance(1.55)
    gray = gray.filter(ImageFilter.SHARPEN)
    return gray


def ocr_pdf_page(pdf_path, page_no, page=None, force=False):
    """Read image-only Korean/English text once and persist it by file signature."""
    global _OCR_CACHE_DIRTY
    ok, _ = ocr_engine_status()
    if not ok:
        return ''
    key = _ocr_cache_key(pdf_path, page_no)
    cache = _load_ocr_cache()
    if key in cache and not force:
        return str(cache[key].get('text', ''))
    own_doc = None
    try:
        if page is None:
            own_doc = fitz.open(str(pdf_path))
            page = own_doc.load_page(page_no)
        im = _prepare_ocr_image(page)
        config = '--oem 3 --psm 11 -c preserve_interword_spaces=1 ' + _tessdata_config()
        full = pytesseract.image_to_string(im, lang='kor+eng', config=config)
        # Product names are often concentrated in the lower half; a second pass improves recall.
        y0 = int(im.height * 0.48)
        lower = im.crop((0, y0, im.width, im.height))
        lower_text = pytesseract.image_to_string(lower, lang='kor+eng', config=config)
        text = re.sub(r'\s+', ' ', f'{full} {lower_text}').strip()
        cache[key] = {'text': text, 'at': datetime.now().isoformat(timespec='seconds')}
        _OCR_CACHE_DIRTY = True
        _save_ocr_cache()
        return text
    except Exception:
        return ''
    finally:
        if own_doc is not None:
            own_doc.close()


def _title_tokens(text):
    cleaned = str(text or '').upper()
    cleaned = re.sub(r'NEW\s*ARRIVAL|정상가|할인가|기간한정|TOPTEN|탑텐', ' ', cleaned)
    return [t for t in re.findall(r'[0-9A-Z가-힣]+', cleaned) if len(t) >= 2]


def _title_match_score(ocr_text, item):
    raw = str(ocr_text or '')
    page_norm = normalize_product_name(raw)
    if not page_norm:
        return 0.0
    best = 0.0
    for title in (item.get('title_ko'), item.get('title_en')):
        title_norm = normalize_product_name(title)
        if not title_norm:
            continue
        seq = difflib.SequenceMatcher(None, title_norm, page_norm).ratio()
        contain = 0.96 if title_norm in page_norm else 0.0
        title_tokens = set(_title_tokens(title))
        page_tokens = set(_title_tokens(raw))
        common = title_tokens & page_tokens
        recall = len(common) / max(1, len(title_tokens))
        precision = len(common) / max(1, len(page_tokens))
        token_f1 = (2 * recall * precision / (recall + precision)) if (recall + precision) else 0.0
        score = max(seq, contain, recall * 0.94, token_f1 * 0.96)
        gender = str(item.get('gender') or '')
        if gender and gender in raw:
            score = min(1.0, score + 0.035)
        best = max(best, score)
    return best


def _score_ocr_items(ocr_text, items, candidate_codes=None, limit=None):
    allowed = set(clean_code(c) for c in (candidate_codes or []))
    learned = _learned_code_for_text(ocr_text)
    scored = []
    for item in items:
        code = clean_code(item.get('code'))
        score = _title_match_score(ocr_text, item)
        if allowed and code in allowed:
            score = min(1.0, score + 0.045)
        if learned and code == learned:
            # Learned manual choices are strong evidence but are no longer irreversible.
            # Resetting the code/file/all mappings also removes the related learning entry.
            score = max(score, 0.90)
        scored.append((score, item))
    scored.sort(key=lambda x: (-x[0], clean_code(x[1].get('code'))))
    return scored if limit is None else scored[:limit]


def _best_ocr_item(ocr_text, items, candidate_codes=None):
    scored = _score_ocr_items(ocr_text, items, candidate_codes)
    if not scored:
        return None, 0.0, 0.0
    top_score, top_item = scored[0]
    second = scored[1][0] if len(scored) > 1 else 0.0
    return top_item, top_score, second


def _code_present_in_text(text, code):
    compact_text = re.sub(r'[^A-Z0-9]', '', str(text or '').upper())
    compact_code = re.sub(r'[^A-Z0-9]', '', clean_code(code).upper())
    return bool(compact_code and compact_code in compact_text)


def _unique_present_code(text, codes):
    present = []
    for code in codes:
        code = clean_code(code)
        if code and _code_present_in_text(text, code) and code not in present:
            present.append(code)
    return present[0] if len(present) == 1 else ''


def _suggestions_from_scored(scored, limit=3):
    suggestions = []
    for score, item in scored[:limit]:
        suggestions.append({
            'code': clean_code(item.get('code')),
            'title': str(item.get('title_ko') or ''),
            'score': round(float(score) * 100),
        })
    return suggestions


def _page_candidate_scores(page_text, candidate_items):
    scored = []
    learned = _learned_code_for_text(page_text)
    unique_exact = _unique_present_code(page_text, [i.get('code') for i in candidate_items])
    for order, item in enumerate(candidate_items):
        exact = bool(unique_exact and clean_code(item.get('code')) == unique_exact)
        score = 1.0 if exact else _title_match_score(page_text, item)
        if learned and clean_code(item.get('code')) == learned:
            score = max(score, 0.90)
        scored.append({
            'score': float(score), 'item': item, 'exact': exact, 'order': order
        })
    scored.sort(key=lambda x: (-x['score'], x['order']))
    return scored


def _global_page_assignment(page_payloads, filename_codes, items):
    """Assign equal-count filename codes to PDF pages by page evidence, not filename order.

    Each page is OCR-scored independently against every filename code. A one-to-one global
    assignment maximizes the total score. Filename order is used only as a tiny tie-breaker;
    it can never turn a weak OCR result into an automatic match.
    """
    by_code = _item_by_code(items)
    candidate_items = [by_code[c] for c in map(clean_code, filename_codes) if c in by_code]
    page_count = len(page_payloads)
    if not candidate_items or len(candidate_items) != page_count:
        return []

    matrix = []
    ranked_per_page = []
    for payload in page_payloads:
        ranked = _page_candidate_scores(payload['combined'], candidate_items)
        ranked_per_page.append(ranked)
        by_candidate = {clean_code(x['item'].get('code')): x for x in ranked}
        matrix.append([by_candidate[clean_code(item.get('code'))]['score'] for item in candidate_items])

    # Most bonus PDFs contain only a few pages. Exhaustive assignment is exact and reliable
    # for up to 8 pages; larger sets use a deterministic greedy fallback.
    if page_count <= 8:
        best_perm = None
        best_total = -1.0
        for perm in itertools.permutations(range(page_count)):
            total = 0.0
            for page_no, candidate_idx in enumerate(perm):
                score = matrix[page_no][candidate_idx]
                # Order is only a stable tie-breaker (max total impact under 0.01).
                if page_no == candidate_idx:
                    score += 0.001
                total += score
            if total > best_total:
                best_total = total
                best_perm = perm
        assignment = list(best_perm or range(page_count))
    else:
        assignment = [-1] * page_count
        available = set(range(page_count))
        for page_no in sorted(range(page_count), key=lambda p: max(matrix[p]), reverse=True):
            candidate_idx = max(available, key=lambda c: (matrix[page_no][c], -abs(page_no-c)))
            assignment[page_no] = candidate_idx
            available.remove(candidate_idx)

    results = []
    for page_no, candidate_idx in enumerate(assignment):
        payload = page_payloads[page_no]
        item = candidate_items[candidate_idx]
        code = clean_code(item.get('code'))
        score = matrix[page_no][candidate_idx]
        exact = (_unique_present_code(payload['combined'], filename_codes) == code)
        other_scores = [matrix[page_no][i] for i in range(page_count) if i != candidate_idx]
        second = max(other_scores) if other_scores else 0.0
        confident = bool(exact or (score >= OCR_AUTO_THRESHOLD and score - second >= OCR_MARGIN_THRESHOLD))
        recommended = bool(exact or score >= OCR_RECOMMEND_THRESHOLD)
        ranked = ranked_per_page[page_no]
        suggestions = _suggestions_from_scored(
            [(x['score'], x['item']) for x in ranked], limit=3
        )
        if exact:
            method = '페이지 내부 품번 확인 + 전역 1:1 배정'
        elif payload['ocr_text']:
            method = '페이지별 OCR 상품명 + 전역 1:1 배정'
        elif payload['embedded']:
            method = 'PDF 내부 상품명 + 전역 1:1 배정'
        else:
            method = '페이지 판독 불가 - 파일명 순서는 참고만 사용'
        results.append({
            'page': page_no, 'page_label': page_no + 1,
            'text': payload['combined'][:220],
            'code': code if recommended else '',
            'title': str(item.get('title_ko') or '') if recommended else '',
            'score': round(score * 100), 'method': method,
            'needs_manual': not confident, 'filename_codes': filename_codes,
            'suggestions': suggestions,
            'margin': round(max(0.0, score-second) * 100),
        })
    return results


def match_pdf_pages(pdf_path, items, force_ocr=False):
    """Match PDF pages safely using exact codes, filename candidates and OCR.

    V4.4.10 never assumes that filename code order equals PDF page order. When filename code
    count equals page count, every page is compared against every candidate and a global
    one-to-one assignment is calculated. Only scores of 75% or higher with a sufficient
    lead are fixed automatically; uncertain pages remain editable.
    """
    results = []
    by_code = _item_by_code(items)
    filename_codes = extract_filename_codes(Path(pdf_path).name, items)
    doc = fitz.open(str(pdf_path))
    try:
        page_count = doc.page_count
        page_texts = [
            re.sub(r'\s+', ' ', doc.load_page(n).get_text('text') or '').strip()
            for n in range(page_count)
        ]

        if filename_codes and page_count == 1:
            for code in filename_codes:
                item = by_code.get(clean_code(code), {})
                results.append({
                    'page': 0, 'page_label': 1, 'text': page_texts[0][:220],
                    'code': code, 'title': item.get('title_ko', ''), 'score': 100,
                    'method': '1페이지 공통 연결', 'needs_manual': False,
                    'filename_codes': filename_codes,
                    'suggestions': [{'code': code, 'title': item.get('title_ko', ''), 'score': 100}],
                    'margin': 100,
                })
            return results

        # Equal code/page count: inspect every page independently, then solve a global 1:1 assignment.
        if filename_codes and len(filename_codes) == page_count:
            page_payloads = []
            for page_no in range(page_count):
                embedded = page_texts[page_no]
                ocr_text = ocr_pdf_page(pdf_path, page_no, doc.load_page(page_no), force=force_ocr)
                combined = f'{embedded} {ocr_text}'.strip()
                page_payloads.append({
                    'embedded': embedded, 'ocr_text': ocr_text, 'combined': combined
                })
            assigned = _global_page_assignment(page_payloads, filename_codes, items)
            if assigned:
                return assigned

        # Filename/page-count mismatch: OCR each page and choose only among filename candidates.
        if filename_codes:
            used = set()
            for page_no in range(page_count):
                embedded = page_texts[page_no]
                ocr_text = ocr_pdf_page(pdf_path, page_no, doc.load_page(page_no), force=force_ocr)
                combined = f'{embedded} {ocr_text}'.strip()
                scored = _score_ocr_items(combined, items, filename_codes)
                unique_exact = _unique_present_code(combined, filename_codes)
                exact_item = by_code.get(unique_exact) if unique_exact else None
                # Prefer a unique page code; otherwise use the best unused OCR candidate.
                available = [(s, i) for s, i in scored if clean_code(i.get('code')) not in used]
                chosen = (1.0, exact_item) if exact_item else (available[0] if available else (scored[0] if scored else (0.0, None)))
                score, item = chosen
                second = max((s for s, i in scored if item is None or clean_code(i.get('code')) != clean_code(item.get('code'))), default=0.0)
                exact = bool(item and unique_exact == clean_code(item.get('code')))
                confident = bool(item and (exact or (score >= OCR_AUTO_THRESHOLD and score-second >= OCR_MARGIN_THRESHOLD)))
                if confident:
                    used.add(clean_code(item.get('code')))
                recommended = bool(item and (exact or score >= OCR_RECOMMEND_THRESHOLD))
                results.append({
                    'page': page_no, 'page_label': page_no + 1, 'text': combined[:220],
                    'code': item['code'] if recommended else '',
                    'title': item['title_ko'] if recommended else '',
                    'score': round(score*100) if item else 0,
                    'method': ('파일명 후보 + 페이지 내부 품번' if exact else
                               ('파일명 후보 + 이미지 OCR 상품명' if ocr_text else
                                f'개수 불일치 - OCR 사용 불가 (파일명 품번: {", ".join(filename_codes)})')),
                    'needs_manual': not confident, 'filename_codes': filename_codes,
                    'suggestions': _suggestions_from_scored(scored, limit=3),
                    'margin': round(max(0.0, score-second)*100) if item else 0,
                })
            return results

        for page_no, text in enumerate(page_texts):
            upper = text.upper(); item = None; score = 0.0; second = 0.0
            unique_exact = _unique_present_code(upper, [i.get('code') for i in items])
            exact_item = by_code.get(unique_exact) if unique_exact else None
            suggestions = []
            if exact_item:
                item = exact_item
                score = 1.0
                method = 'PDF 내부 품번'
                combined = text
                suggestions = [{'code': item['code'], 'title': item['title_ko'], 'score': 100}]
                confident = True
            else:
                ocr_text = ocr_pdf_page(pdf_path, page_no, doc.load_page(page_no), force=force_ocr)
                combined = f'{text} {ocr_text}'.strip()
                scored = _score_ocr_items(combined, items)
                if scored:
                    score, item = scored[0]
                    second = scored[1][0] if len(scored) > 1 else 0.0
                suggestions = _suggestions_from_scored(scored, limit=3)
                method = ('이미지 OCR 상품명 유사도' if ocr_text else
                          ('PDF 내부 상품명 유사도' if text else 'OCR 엔진 미설치/인식 실패'))
                confident = bool(item and score >= OCR_AUTO_THRESHOLD and score-second >= OCR_MARGIN_THRESHOLD)
            recommended = bool(item and (score >= OCR_RECOMMEND_THRESHOLD or confident))
            results.append({
                'page': page_no, 'page_label': page_no+1, 'text': combined[:220],
                'code': item['code'] if recommended else '',
                'title': item['title_ko'] if recommended else '',
                'score': round(score*100) if item else 0,
                'method': method, 'needs_manual': not confident,
                'filename_codes': [], 'suggestions': suggestions,
                'margin': round(max(0.0, score-second)*100) if item else 0,
            })
    finally:
        doc.close()
    return results

def calculate_discount_percent(normal, sale):
    """Return markdown percentage from normal price to sale price.

    Example: 39,900 -> 11,900 = 70.18%, therefore the V4.4 special-price rule applies.
    """
    try:
        normal = float(normal or 0)
        sale = float(sale or 0)
    except Exception:
        return 0.0
    if normal <= 0 or sale <= 0 or sale >= normal:
        return 0.0
    return max(0.0, min(100.0, (normal - sale) / normal * 100.0))


def load_items(force=False):
    global _ITEMS_CACHE, _CACHE_MTIME, _PRODUCT_INDEX
    if not CURRENT_XLSX.exists():
        return [], '', '엑셀 미등록'
    # Visual mappings and E/F choices can change without touching the Excel file.
    bonus_mtime = BONUS_MAP_FILE.stat().st_mtime_ns if BONUS_MAP_FILE.exists() else -1
    choice_mtime = VISUAL_CHOICE_FILE.stat().st_mtime_ns if VISUAL_CHOICE_FILE.exists() else -1
    template_sig = tuple(
        p.stat().st_mtime_ns if p.exists() else -1
        for p in (TEMPLATE_DIR / 'NEW_ARRIVAL.pdf', ADULT_SMALL_TEMPLATE, CLEARANCE_TEMPLATE)
    )
    mtime = (CURRENT_XLSX.stat().st_mtime_ns, bonus_mtime, choice_mtime, template_sig)
    if not force and _ITEMS_CACHE is not None and _CACHE_MTIME == mtime:
        return _ITEMS_CACHE

    _PRODUCT_INDEX = None
    build_product_index()
    wb = load_workbook(CURRENT_XLSX, data_only=True, read_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    header_idx = None
    header_values = []
    for idx, row in enumerate(rows[:40]):
        vals = [str(v or '').strip() for v in row]
        if any(x in vals for x in ('스타일', '품번')) and '정상가' in vals:
            header_idx = idx
            header_values = vals
            break
    if header_idx is None:
        wb.close()
        raise ValueError('헤더 행을 찾지 못했습니다. 품번/스타일과 정상가 열이 필요합니다.')

    def col(*names):
        for name in names:
            if name in header_values:
                return header_values.index(name)
        return None

    cols = {
        'code': col('스타일', '품번'), 'title_ko': col('상품명'),
        'title_en': col('상품명(영문)', '영문명'), 'gender': col('성별'),
        'zone': col('조닝', '종류'), 'color': col('컬러'),
        'normal': col('정상가'), 'sale': col('조정가', '할인가'),
        'promotion': col('프로모션 내용'), 'season': col('시즌')
    }

    date_range = ''
    for row in rows[:20]:
        for value in row[:20]:
            text_value = str(value or '').strip()
            candidate = normalize_date_range(value)
            has_two_dates = len(re.findall(r'\d{1,2}[./-]\d{1,2}|\d{1,2}\s*월\s*\d{1,2}', text_value)) >= 2
            if '기간' in text_value or has_two_dates:
                date_range = candidate
                break
        if date_range:
            break

    items = []
    for row in rows[header_idx + 1:]:
        def get(key):
            c = cols.get(key)
            return row[c] if c is not None and c < len(row) else None
        code = clean_code(get('code'))
        if not code:
            continue
        normal = n(get('normal'))
        sale = n(get('sale'))
        promo = str(get('promotion') or '').strip()
        multi = []
        for c, label in ((11, '2장'), (12, '3장'), (13, '4장')):
            if c < len(row):
                value = n(row[c])
                if value > 0:
                    multi.append(f'{label} {value:,}원')
        if not promo and multi:
            promo = ' / '.join(multi)
        is_disc = sale > 0 and (normal == 0 or sale < normal)
        discount_percent = calculate_discount_percent(normal, sale)
        gender = infer_gender_from_code(code, get('gender'))
        route = resolve_item_visual(code, gender, is_disc, discount_percent)
        item = {
            'code': code, 'title_ko': str(get('title_ko') or '').strip(),
            'title_en': str(get('title_en') or '').strip(),
            'gender': gender, 'zone': str(get('zone') or '').strip(),
            'color': str(get('color') or '').strip(), 'normal': normal, 'sale': sale,
            'normal_fmt': f'{normal:,}원' if normal else '-',
            'sale_fmt': f'{sale:,}원' if sale else '-', 'promotion': promo,
            'date_range': date_range, 'is_discount': is_disc,
            'discount_percent': round(discount_percent, 1),
            'discount_percent_fmt': (f'{discount_percent:.1f}%'.replace('.0%', '%') if is_disc else '-'),
        }
        item.update(route)
        items.append(item)
    wb.close()
    loaded = LAST_NAME.read_text('utf-8').strip() if LAST_NAME.exists() else CURRENT_XLSX.name
    _ITEMS_CACHE = (items, date_range, loaded)
    _CACHE_MTIME = mtime
    return _ITEMS_CACHE

def _row_metrics(im):
    """Return lightweight row statistics used for source-bar detection."""
    probe_w = 360
    scale = probe_w / max(1, im.width)
    probe_h = max(1, round(im.height * scale))
    probe = im.convert('RGB').resize((probe_w, probe_h), Image.Resampling.BILINEAR)
    rows = []
    for y in range(probe_h):
        colors = list(probe.crop((0, y, probe_w, y + 1)).getdata())
        n = max(1, len(colors))
        mr = sum(c[0] for c in colors) / n
        mg = sum(c[1] for c in colors) / n
        mb = sum(c[2] for c in colors) / n
        # Mean distance from the row mean: low values indicate a flat label band.
        dev = sum((abs(c[0]-mr)+abs(c[1]-mg)+abs(c[2]-mb))/3 for c in colors) / n
        rows.append((mr, mg, mb, dev))
    return rows, probe_h, probe


def _detect_bonus_visual_bottom(im):
    """Detect the beginning of a source PDF's own lower information strip.

    The lower strip may be white, gray, or tinted. We look only in the final
    quarter of the page, score full-width horizontal transitions, and prefer a
    boundary followed by a comparatively flat region. This avoids mistaking
    internal product photos or text panels for the source information bar.
    """
    rows, ph, probe = _row_metrics(im)
    if ph < 40:
        return im.height

    start = int(ph * 0.73)
    end = int(ph * 0.88)
    candidates = []
    for y in range(start, end):
        r0 = rows[max(0, y-2)]
        r1 = rows[y]
        transition = (abs(r1[0]-r0[0]) + abs(r1[1]-r0[1]) + abs(r1[2]-r0[2])) / 3
        row_a = list(probe.crop((0, max(0, y-2), probe.width, max(0, y-2)+1)).getdata())
        row_b = list(probe.crop((0, y, probe.width, y+1)).getdata())
        change_coverage = sum(
            1 for a, b in zip(row_a, row_b)
            if (abs(a[0]-b[0])+abs(a[1]-b[1])+abs(a[2]-b[2]))/3 >= 18
        ) / max(1, probe.width)

        below = rows[y:max(y+1, int(ph * 0.94))]
        flat_ratio = sum(1 for r in below if r[3] <= 24) / max(1, len(below))
        avg_dev = sum(r[3] for r in below) / max(1, len(below))

        if transition < 8 or change_coverage < 0.22 or flat_ratio < 0.55:
            continue
        score = (
            transition * 1.2
            + change_coverage * 55
            + flat_ratio * 35
            - (y / ph) * 30
            - avg_dev * 0.15
        )
        candidates.append((score, y))

    if not candidates:
        return im.height

    _, y_probe = max(candidates, key=lambda v: v[0])
    y_full = round(y_probe * im.height / ph)
    # Remove a small safety band above the detected source-bar boundary;
    # headquarters files often place the outlined gender box immediately above
    # the rest of their information strip.
    margin = max(2, round(im.height * 0.04))
    return max(1, min(im.height, y_full - margin))


def _edge_background_color(im):
    """Estimate a neutral fill colour from the artwork edges."""
    rgb = im.convert('RGB')
    w, h = rgb.size
    sw = max(1, w // 80)
    sh = max(1, h // 80)
    samples = []
    for box in ((0, 0, w, sh), (0, h-sh, w, h), (0, 0, sw, h), (w-sw, 0, w, h)):
        samples.extend(list(rgb.crop(box).resize((40, 4), Image.Resampling.BILINEAR).getdata()))
    if not samples:
        return (255, 255, 255)
    samples.sort(key=lambda c: c[0] + c[1] + c[2])
    mid = samples[len(samples)//2]
    return tuple(int(v) for v in mid)


def _fit_bonus_artwork(art, target_w, target_h):
    """Fit complete artwork into a fixed frame without cutting text or models."""
    art = art.convert('RGB')
    if art.width <= 0 or art.height <= 0:
        return Image.new('RGB', (target_w, target_h), 'white')
    bg = _edge_background_color(art)
    frame = Image.new('RGB', (target_w, target_h), bg)

    # Small safety inset prevents artwork typography from visually colliding
    # with the standard bottom bar while preserving the complete composition.
    inset_x = max(0, round(target_w * 0.006))
    inset_y = max(0, round(target_h * 0.006))
    avail_w = max(1, target_w - inset_x * 2)
    avail_h = max(1, target_h - inset_y * 2)
    scale = min(avail_w / art.width, avail_h / art.height)
    nw = max(1, round(art.width * scale))
    nh = max(1, round(art.height * scale))
    fitted = art.resize((nw, nh), Image.Resampling.LANCZOS)
    x = (target_w - nw) // 2
    y = (target_h - nh) // 2
    frame.paste(fitted, (x, y))
    return frame


def load_generation_queue():
    if not QUEUE_FILE.exists():
        return []
    try:
        raw = json.loads(QUEUE_FILE.read_text('utf-8'))
        return [clean_code(x) for x in raw if clean_code(x)]
    except Exception:
        return []


def save_generation_queue(codes):
    unique=[]; seen=set()
    for code in codes:
        code=clean_code(code)
        if code and code not in seen:
            unique.append(code); seen.add(code)
    QUEUE_FILE.write_text(json.dumps(unique, ensure_ascii=False, indent=2), encoding='utf-8')
    return unique


def visual_signature(pathstr):
    raw=str(pathstr or '')
    page=0
    if '::page=' in raw:
        raw,p=raw.rsplit('::page=',1)
        try: page=int(p)
        except Exception: page=0
    p=Path(raw) if raw else TEMPLATE_DIR/'NEW_ARRIVAL.pdf'
    try:
        st=p.stat(); base=f'{p.resolve()}|{page}|{st.st_size}|{st.st_mtime_ns}'
    except OSError:
        base=f'{p}|{page}|missing'
    return hashlib.sha1(base.encode('utf-8',errors='ignore')).hexdigest()[:16]


def item_preview_version(item):
    payload='|'.join(str(item.get(k,'')) for k in ('code','gender','title_ko','title_en','normal','sale','discount_percent','date_range','visual','visual_mode','bonus_choice','requires_bonus_choice'))
    payload += '|'+visual_signature(item.get('visual'))
    return hashlib.sha1(payload.encode('utf-8',errors='ignore')).hexdigest()[:16]


def _render_cache_key(pathstr):
    return f'{str(pathstr)}|{visual_signature(pathstr)}'

def render_visual_a4(pathstr):
    cache_key = _render_cache_key(pathstr)
    cached = _RENDER_CACHE.get(cache_key)
    if cached is not None:
        _RENDER_CACHE.move_to_end(cache_key)
        return cached.copy()
    """Render the complete source page at true A4 size.

    NEW ARRIVAL and every bonus PDF follow one identical rule: preserve the
    source page without automatic trimming, then generate_one() covers the
    final 210 x 50 mm of the finished 210 x 240 mm POP with the standard bar.
    This fixed physical overlay hides headquarters' original lower gender and
    product-information area without unreliable image-content detection.
    """
    page_index = 0
    raw_path = str(pathstr or '')
    if '::page=' in raw_path:
        raw_path, page_text = raw_path.rsplit('::page=', 1)
        try:
            page_index = max(0, int(page_text))
        except Exception:
            page_index = 0
    p = Path(raw_path) if raw_path else TEMPLATE_DIR / 'NEW_ARRIVAL.pdf'
    if not p.exists():
        p = TEMPLATE_DIR / 'NEW_ARRIVAL.pdf'
    canvas = Image.new('RGB', (A4_W_PX, A4_H_PX), 'white')
    try:
        if p.suffix.lower() == '.pdf':
            doc = fitz.open(str(p))
            page = doc.load_page(min(page_index, max(0, doc.page_count - 1)))
            scale = DPI / 72.0
            pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False)
            im = Image.frombytes('RGB', [pix.width, pix.height], pix.samples)
            doc.close()
        else:
            im = Image.open(p).convert('RGB')

        # Full-page actual-size normalization only; no bonus-specific cropping.
        if im.size != canvas.size:
            im = im.resize(canvas.size, Image.Resampling.LANCZOS)
        canvas.paste(im, (0, 0))
        _RENDER_CACHE[cache_key] = canvas.copy()
        _RENDER_CACHE.move_to_end(cache_key)
        while len(_RENDER_CACHE) > _RENDER_CACHE_MAX:
            _RENDER_CACHE.popitem(last=False)
        return canvas
    except Exception as exc:
        print(f'Visual load error: {exc}', flush=True)
        return canvas

def draw_right(draw, xy_right, text, font_obj, fill):
    box = draw.textbbox((0,0), text, font=font_obj)
    draw.text((xy_right[0]-(box[2]-box[0]), xy_right[1]), text, font=font_obj, fill=fill)

def clip_text_to_width(draw, text, font_obj, max_width):
    """Keep the fixed font size and shorten only the text when it exceeds the PPT box."""
    text = str(text or '').strip()
    if not text:
        return ''
    if draw.textbbox((0,0), text, font=font_obj)[2] <= max_width:
        return text
    ellipsis = '…'
    lo, hi = 0, len(text)
    while lo < hi:
        mid = (lo + hi + 1) // 2
        candidate = text[:mid].rstrip() + ellipsis
        if draw.textbbox((0,0), candidate, font=font_obj)[2] <= max_width:
            lo = mid
        else:
            hi = mid - 1
    return text[:lo].rstrip() + ellipsis

def _tag(draw, x, y, text, fnt, bg, fg='white', pad_x_mm=1.0, pad_y_mm=0.25):
    box = draw.textbbox((0,0), text, font=fnt)
    w, h = box[2]-box[0], box[3]-box[1]
    px = round(pad_x_mm * MM_TO_PX)
    py = round(pad_y_mm * MM_TO_PX)
    draw.rectangle((x, y, x+w+px*2, y+h+py*2), fill=bg)
    draw.text((x+px, y+py-box[1]), text, font=fnt, fill=fg)
    return x+w+px*2

def _fit_text_fixed_box(draw, text, font_obj, left, top, right, fill, align='left'):
    """Draw inside a fixed PPT text box. Both box edges stay immovable."""
    text = str(text or '').strip()
    if not text:
        return
    max_width = max(1, right - left)
    text = clip_text_to_width(draw, text, font_obj, max_width)
    box = draw.textbbox((0, 0), text, font=font_obj)
    width = box[2] - box[0]
    x = right - width if align == 'right' else left
    draw.text((x, top), text, font=font_obj, fill=fill)


def _fit_text_shrink_box(draw, text, font_path, start_pt, min_pt, left, top, right, fill, align='left'):
    """Keep both box edges fixed and reduce font size until the complete text fits."""
    text = str(text or '').strip()
    if not text:
        return
    max_width = max(1, right-left)
    chosen = None
    chosen_size = start_pt
    for pt in range(int(start_pt), int(min_pt)-1, -1):
        fnt = font(font_path, pt_px(pt))
        box = draw.textbbox((0,0), text, font=fnt)
        if box[2]-box[0] <= max_width:
            chosen = fnt
            chosen_size = pt
            break
    if chosen is None:
        chosen_size = min_pt
        chosen = font(font_path, pt_px(min_pt))
        # Last resort only for extraordinarily long names: preserve all characters by horizontal compression.
        box = draw.textbbox((0,0), text, font=chosen)
        tw, th = max(1, box[2]-box[0]), max(1, box[3]-box[1])
        layer = Image.new('RGBA', (tw+8, th+8), (255,255,255,0))
        ld = ImageDraw.Draw(layer)
        ld.text((4-box[0],4-box[1]), text, font=chosen, fill=fill)
        target_w = max_width
        layer = layer.resize((target_w, layer.height), Image.Resampling.LANCZOS)
        x = right-target_w if align=='right' else left
        draw._image.alpha_composite(layer, (x, top)) if draw._image.mode=='RGBA' else draw._image.paste(layer.convert('RGB'), (x,top), layer)
        return
    box = draw.textbbox((0,0), text, font=chosen)
    width = box[2]-box[0]
    x = right-width if align=='right' else left
    draw.text((x,top), text, font=chosen, fill=fill)


def _fixed_tag(draw, box_mm, text, font_obj, bg, fg='white'):
    """Draw a tag in an immovable rectangle; text is clipped within the fixed rectangle."""
    l, t, r, b = [round(v * MM_TO_PX) for v in box_mm]
    draw.rectangle((l, t, r, b), fill=bg)
    text = clip_text_to_width(draw, text, font_obj, max(1, r-l-round(1.4*MM_TO_PX)))
    tb = draw.textbbox((0,0), text, font=font_obj)
    th = tb[3]-tb[1]
    tw = tb[2]-tb[0]
    # Exact horizontal and vertical centering inside the fixed tag rectangle.
    x = l + max(0, ((r-l)-tw)//2) - tb[0]
    y = t + max(0, ((b-t)-th)//2) - tb[1]
    draw.text((x, y), text, font=font_obj, fill=fg)


def _pt_px_for_dpi(pt, dpi):
    return max(1, round(float(pt) * float(dpi) / 72.0))


def _font_for_dpi(path, pt, dpi, bold=False):
    return font(path, _pt_px_for_dpi(pt, dpi), fallback_bold=bold)


def _box_px(box_mm, dpi):
    scale = dpi / 25.4
    return tuple(round(v * scale) for v in box_mm)


def _fit_one_line(draw, text, font_path, start_pt, min_pt, box_mm, fill, dpi, align='left', bold=False):
    text = str(text or '').strip()
    if not text:
        return
    left, top, right, bottom = _box_px(box_mm, dpi)
    max_w = max(1, right-left)
    chosen = _font_for_dpi(font_path, min_pt, dpi, bold)
    for pt in range(int(start_pt), int(min_pt)-1, -1):
        candidate = _font_for_dpi(font_path, pt, dpi, bold)
        bbox = draw.textbbox((0,0), text, font=candidate)
        if bbox[2]-bbox[0] <= max_w:
            chosen = candidate
            break
    bbox = draw.textbbox((0,0), text, font=chosen)
    tw, th = bbox[2]-bbox[0], bbox[3]-bbox[1]
    x = right-tw-bbox[0] if align == 'right' else left-bbox[0]
    y = top-bbox[1] + max(0, ((bottom-top)-th)//2)
    draw.text((x,y), text, font=chosen, fill=fill)


def _title_char_count(text):
    """Count visible product-name characters; spaces are ignored for the 11-character store rule."""
    return len(re.sub(r'\s+', '', str(text or '').strip()))


def _smart_title_lines(text, max_chars=11):
    """Return one or exactly two clean lines using the store's 11-character rule.

    Important example:
      [분노의 질주] 가먼트다잉 그래픽 T (반팔)
    becomes
      [분노의 질주]
      가먼트다잉 그래픽 T (반팔)

    Bracketed collaboration/collection names are treated as a semantic prefix, so we do
    not create the awkward '[분노의 질주] 가먼트다잉 / 그래픽 T (반팔)' split.
    """
    text = re.sub(r'\s+', ' ', str(text or '').strip())
    if not text or _title_char_count(text) <= max_chars:
        return [text]

    # Prefer a leading [collection / collaboration] block as line 1.
    m = re.match(r'^(\[[^\]]+\])\s+(.+)$', text)
    if m and m.group(2).strip():
        return [m.group(1).strip(), m.group(2).strip()]

    words = text.split(' ')
    if len(words) >= 2:
        best_cut = None
        best_score = None
        for cut in range(1, len(words)):
            left = ' '.join(words[:cut]).strip()
            right = ' '.join(words[cut:]).strip()
            if not right:
                continue
            n = _title_char_count(left)
            # Strongly prefer line 1 at or below 11 chars; among them use the fullest line.
            over = max(0, n - max_chars)
            under = max(0, max_chars - n)
            score = (over * 1000 + under, abs(_title_char_count(right) - n))
            if best_score is None or score < best_score:
                best_score = score
                best_cut = cut
        if best_cut:
            return [' '.join(words[:best_cut]).strip(), ' '.join(words[best_cut:]).strip()]

    # No word boundary exists. Split at the 11th visible character without dropping spaces.
    visible = 0
    cut = 0
    for i, ch in enumerate(text):
        if not ch.isspace():
            visible += 1
        if visible >= max_chars:
            cut = i + 1
            break
    if cut <= 0 or cut >= len(text):
        cut = max(1, len(text)//2)
    return [text[:cut].rstrip(), text[cut:].lstrip()]


def _fit_smart_title(draw, text, font_path, start_pt, min_pt, box_mm, fill, dpi, bold=False):
    """Draw a product name in one line, or exactly two lines when it exceeds 11 chars."""
    text = str(text or '').strip()
    if not text:
        return 1
    lines = _smart_title_lines(text, 11)
    left, top, right, bottom = _box_px(box_mm, dpi)
    max_w, max_h = max(1, right-left), max(1, bottom-top)
    chosen = _font_for_dpi(font_path, min_pt, dpi, bold)
    for pt in range(int(start_pt), int(min_pt)-1, -1):
        candidate = _font_for_dpi(font_path, pt, dpi, bold)
        boxes = [draw.textbbox((0,0), line, font=candidate) for line in lines]
        widths = [b[2]-b[0] for b in boxes]
        heights = [b[3]-b[1] for b in boxes]
        line_gap = max(1, round(pt * dpi / 72 * 0.10)) if len(lines) == 2 else 0
        if max(widths or [0]) <= max_w and sum(heights) + line_gap <= max_h:
            chosen = candidate
            break
    boxes = [draw.textbbox((0,0), line, font=chosen) for line in lines]
    heights = [b[3]-b[1] for b in boxes]
    # Top-anchored layout keeps the first row exactly aligned with the template field.
    gap = max(1, round((bottom-top-sum(heights)) * 0.18)) if len(lines) == 2 else 0
    y = top
    for line, b in zip(lines, boxes):
        draw.text((left-b[0], y-b[1]), line, font=chosen, fill=fill)
        y += (b[3]-b[1]) + gap
    return len(lines)


def _split_two_lines(text, draw, fnt, max_w):
    text = str(text or '').strip()
    if not text:
        return ['']
    if draw.textbbox((0,0), text, font=fnt)[2] <= max_w:
        return [text]
    words = text.split()
    candidates = []
    if len(words) > 1:
        for cut in range(1, len(words)):
            a=' '.join(words[:cut]); b=' '.join(words[cut:])
            width=max(draw.textbbox((0,0),a,font=fnt)[2],draw.textbbox((0,0),b,font=fnt)[2])
            candidates.append((width,abs(len(a)-len(b)),a,b))
    else:
        for cut in range(1, len(text)):
            a=text[:cut]; b=text[cut:]
            width=max(draw.textbbox((0,0),a,font=fnt)[2],draw.textbbox((0,0),b,font=fnt)[2])
            candidates.append((width,abs(len(a)-len(b)),a,b))
    if not candidates:
        return [text]
    _,__,a,b=min(candidates)
    return [a,b]


def _fit_two_lines(draw, text, font_path, start_pt, min_pt, box_mm, fill, dpi, bold=False):
    text = str(text or '').strip()
    if not text:
        return
    left, top, right, bottom = _box_px(box_mm, dpi)
    max_w, max_h = max(1,right-left), max(1,bottom-top)
    lines=[text]; chosen=_font_for_dpi(font_path,min_pt,dpi,bold)
    for pt in range(int(start_pt), int(min_pt)-1, -1):
        candidate=_font_for_dpi(font_path,pt,dpi,bold)
        proposed=_split_two_lines(text,draw,candidate,max_w)
        line_heights=[]; widths=[]
        for line in proposed:
            bb=draw.textbbox((0,0),line,font=candidate)
            widths.append(bb[2]-bb[0]); line_heights.append(bb[3]-bb[1])
        gap=round(pt*dpi/72*0.06) if len(proposed)>1 else 0
        if max(widths or [0])<=max_w and sum(line_heights)+gap<=max_h:
            chosen=candidate; lines=proposed; break
    metrics=[draw.textbbox((0,0),line,font=chosen) for line in lines]
    heights=[b[3]-b[1] for b in metrics]
    gap=max(0,round((bottom-top-sum(heights))/max(1,len(lines)+1)))
    y=top+gap
    for line,b in zip(lines,metrics):
        draw.text((left-b[0],y-b[1]),line,font=chosen,fill=fill)
        y += (b[3]-b[1])+gap


def _draw_adult_small_fields(a4, item, dpi):
    d=ImageDraw.Draw(a4)
    black=(20,20,20); red=(230,0,18); gray=(45,45,45)
    _fit_one_line(d, f"{item.get('sale',0):,}" if item.get('sale') else '', FONT_DIN_BOLD, 152, 82,
                  (23.77,51.06,209.03,118.26), red, dpi, 'left', True)
    _fit_one_line(d, f"{item.get('normal',0):,}" if item.get('normal') else '', FONT_DIN_MEDIUM, 44, 28,
                  (29.12,114.87,140.97,132.88), black, dpi, 'left')
    _fit_one_line(d, item.get('date_range',''), FONT_DIN_MEDIUM, 25, 18,
                  (82.56,182.41,152.57,196.41), red, dpi, 'left')

    # Exact left alignment rule: gender tag edge, Korean title and English title share one X line.
    # The fixed gender tag on the adult-small template starts at about 30.1 mm.
    FIELD_LEFT = 30.10
    SAFE_RIGHT = 132.00  # never enter the colored lower-right triangle
    line_count = _fit_smart_title(d, item.get('title_ko',''), FONT_KO, 31, 18,
                                  (FIELD_LEFT,193.80,SAFE_RIGHT,214.60), black, dpi, True)
    en_top = 214.70 if line_count == 2 else 211.80
    _fit_one_line(d, str(item.get('title_en') or '').upper(), FONT_DIN_MEDIUM, 21, 11,
                  (FIELD_LEFT,en_top,SAFE_RIGHT,223.30), gray, dpi, 'left')

def _draw_clearance_fields(a4, item, dpi):
    d=ImageDraw.Draw(a4)
    black=(20,20,20); red=(230,0,18); gray=(45,45,45)
    _fit_one_line(d, f"{item.get('normal',0):,}" if item.get('normal') else '', FONT_DIN_MEDIUM, 24, 17,
                  (163.14,222.76,195.03,234.30), black, dpi, 'right')
    _fit_one_line(d, f"{item.get('sale',0):,}" if item.get('sale') else '', FONT_DIN_BOLD, 65, 40,
                  (127.75,228.53,195.03,256.20), red, dpi, 'right', True)

    # Exact left alignment rule for SPECIAL PRICE: gender tag, Korean title and English title.
    FIELD_LEFT = 19.30
    SAFE_RIGHT = 127.02
    line_count = _fit_smart_title(d, item.get('title_ko',''), FONT_KO, 27, 17,
                                  (FIELD_LEFT,230.40,SAFE_RIGHT,253.30), black, dpi, True)
    en_top = 254.00 if line_count == 2 else 246.50
    _fit_one_line(d, str(item.get('title_en') or '').upper(), FONT_DIN_MEDIUM, 12.7, 8,
                  (FIELD_LEFT,en_top,SAFE_RIGHT,264.00), gray, dpi, 'left')

def render_custom_template_a4(item, dpi):
    if dpi == DPI:
        a4 = render_visual_a4(item.get('visual'))
    else:
        a4 = _render_visual_preview(item.get('visual'))
    if item.get('visual_mode') == 'clearance':
        _draw_clearance_fields(a4, item, dpi)
    else:
        _draw_adult_small_fields(a4, item, dpi)
    return a4


def generate_bottom_bar(item):
    """Render the adult-small TOPTEN bottom bar with locked PPT text boxes.

    Font mapping:
      - gender / Korean title / English title / old normal price: NanumBarunGothic
      - event date: DINPro-Medium
      - normal main price / discount main price: DINPro-Bold

    Every field uses a fixed left and right boundary derived from the sample/PPT.
    Product names longer than 11 visible characters are rendered as exactly two clean lines; all left edges remain locked.
    """
    bar = Image.new('RGB', (A4_W_PX, BAR_H_PX), 'white')
    d = ImageDraw.Draw(bar)

    black = (20, 20, 20)
    gray = (45, 45, 45)
    red = (230, 0, 18)
    gender_bg = (32, 32, 32)
    period_bg = (196, 0, 18)

    # Fixed point sizes supplied by the store.
    f_gender = font(FONT_KO, pt_px(11))
    f_period = font(FONT_KO, pt_px(11))
    f_date = font(FONT_DIN_MEDIUM, pt_px(17))
    f_title = font(FONT_KO, pt_px(27))
    f_en = font(FONT_KO, pt_px(13))
    f_main = font(FONT_DIN_BOLD, pt_px(59), fallback_bold=True)
    f_old = font(FONT_KO, pt_px(23))

    # LOCKED BOUNDARIES (millimetres within the measured 210 x 50 mm bottom bar).
    # Both the start and end of every text box remain fixed.
    # Original PPT geometry is vertically centered with 5 mm margins.
    GENDER_BOX = (17.4, 6.8, 29.6, 12.2)
    PERIOD_BOX = (30.4, 6.8, 48.7, 12.2)
    DATE_LEFT, DATE_RIGHT, DATE_TOP = 50.4, 93.0, 5.55
    TITLE_LEFT, TITLE_RIGHT, TITLE_TOP = 17.4, 124.0, 13.2
    EN_LEFT, EN_RIGHT, EN_TOP = 17.4, 124.0, 28.0
    PRICE_LEFT, PRICE_RIGHT, PRICE_TOP = 126.0, 193.45, 11.3
    OLD_LEFT, OLD_RIGHT, OLD_TOP = 158.0, 193.45, 5.1

    gender = (item.get('gender') or '공용').strip()
    _fixed_tag(d, GENDER_BOX, gender, f_gender, gender_bg)

    if item.get('is_discount'):
        _fixed_tag(d, PERIOD_BOX, '기간한정', f_period, period_bg)
        _fit_text_fixed_box(
            d, item.get('date_range',''), f_date,
            round(DATE_LEFT*MM_TO_PX), round(DATE_TOP*MM_TO_PX), round(DATE_RIGHT*MM_TO_PX), red, 'left'
        )

    # Gender tag, Korean product name and English product name all start on the same X line.
    title_lines = _fit_smart_title(
        d, item.get('title_ko',''), FONT_KO, 27, 15,
        (TITLE_LEFT, TITLE_TOP, TITLE_RIGHT, 30.8), black, DPI, True
    )
    en_top_mm = 31.0 if title_lines == 2 else EN_TOP
    _fit_one_line(
        d, str(item.get('title_en') or '').upper(), FONT_KO, 13, 9,
        (EN_LEFT, en_top_mm, EN_RIGHT, 38.8), gray, DPI, 'left'
    )

    if item.get('is_discount'):
        old = f"{item.get('normal',0):,}" if item.get('normal') else ''
        sale = f"{item.get('sale',0):,}" if item.get('sale') else ''
        _fit_text_fixed_box(
            d, old, f_old,
            round(OLD_LEFT*MM_TO_PX), round(OLD_TOP*MM_TO_PX), round(OLD_RIGHT*MM_TO_PX), black, 'right'
        )
        if old:
            # Straight horizontal red cancellation arrow, pointing from right to left.
            ob = d.textbbox((0,0), old, font=f_old)
            ow = ob[2]-ob[0]
            old_right_px = round(OLD_RIGHT*MM_TO_PX)
            text_left_px = old_right_px - ow
            left_x = max(round(OLD_LEFT*MM_TO_PX), text_left_px - round(4.0*MM_TO_PX))
            right_x = old_right_px
            y = round(8.55*MM_TO_PX)
            width = max(2, round(.28*MM_TO_PX))
            d.line((right_x, y, left_x, y), fill=red, width=width)
            # Arrowhead at the left end: direction is right -> left.
            head = round(2.0*MM_TO_PX)
            d.line((left_x, y, left_x+head, y-head), fill=red, width=width)
            d.line((left_x, y, left_x+head, y+head), fill=red, width=width)
        _fit_text_fixed_box(
            d, sale, f_main,
            round(PRICE_LEFT*MM_TO_PX), round(PRICE_TOP*MM_TO_PX), round(PRICE_RIGHT*MM_TO_PX), red, 'right'
        )
    else:
        price = f"{item.get('normal',0):,}" if item.get('normal') else ''
        _fit_text_fixed_box(
            d, price, f_main,
            round(PRICE_LEFT*MM_TO_PX), round(PRICE_TOP*MM_TO_PX), round(PRICE_RIGHT*MM_TO_PX), black, 'right'
        )
    return bar

def save_a4_pdf(a4_image, pdf_path):
    """Save a true A4 page. Print at Actual size / 100%."""
    tmp = CACHE_DIR / '_a4_page.png'
    a4_image.save(tmp, 'PNG', dpi=(DPI,DPI))
    a4 = fitz.paper_rect('a4')
    doc = fitz.open()
    page = doc.new_page(width=a4.width, height=a4.height)
    page.insert_image(page.rect, filename=str(tmp))
    # Clear full-width cut guides. Cut exactly on both dashed lines to obtain 210 x 240 mm.
    for idx, mm in enumerate((CUT_TOP_MM, CUT_BOTTOM_MM)):
        y = mm / 25.4 * 72
        dash = 8.0
        gap = 5.0
        x = 0.0
        while x < a4.width:
            page.draw_line(fitz.Point(x,y), fitz.Point(min(a4.width,x+dash),y), color=(.55,.55,.55), width=.45)
            x += dash+gap
        label_y = y-9 if idx == 0 else y+3
        page.insert_text(fitz.Point(8,label_y), 'CUT HERE - 210 x 240 mm', fontsize=7, color=(.45,.45,.45), fontname='helv')
    doc.save(str(pdf_path), deflate=True)
    doc.close()

def generate_one(item,out_path=None):
    if item.get('visual_mode') in {'adult_small', 'clearance'}:
        a4_page = render_custom_template_a4(item, DPI)
    else:
        a4_page = render_visual_a4(item.get('visual'))
        bar = generate_bottom_bar(item)
        a4_page.paste(bar, (0, BAR_TOP_PX))
    pop = a4_page.crop((0, CUT_TOP_PX, A4_W_PX, CUT_TOP_PX + POP_H_PX))
    if out_path:
        out_path = Path(out_path)
        pop.save(out_path, 'PNG', dpi=(DPI,DPI))
        save_a4_pdf(a4_page, out_path.with_suffix('.pdf'))
    return pop

def items_map():
    its,dr,ln=load_items(); return {i['code']:i for i in its},its,dr,ln



def load_sync_state():
    if not SYNC_STATE_FILE.exists():
        return {}
    try:
        return json.loads(SYNC_STATE_FILE.read_text('utf-8'))
    except Exception:
        return {}


def save_sync_state(data):
    SYNC_STATE_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


def safe_filename(name):
    return re.sub(r'[^0-9A-Za-z가-힣._-]+', '_', Path(name).name)


def _sync_source_key(src):
    """Return a stable POSIX-style path relative to webhard_sync."""
    try:
        return src.resolve().relative_to(WEBHARD_SYNC_DIR.resolve()).as_posix()
    except Exception:
        return src.name


def _apply_automatic_bonus_matches(source_id, results, refresh_items=True):
    """Persist direct webhard_sync source paths; no duplicate PDF copy is created."""
    source_id = _normalize_webhard_rel(source_id)
    if not source_id:
        return 0
    automatic = [r for r in results if r.get('code') and not r.get('needs_manual')]
    if not automatic:
        return 0
    data = load_bonus_matches()
    saved = 0
    for r in automatic:
        code = clean_code(r['code'])
        if not code:
            continue
        data[code] = {'file': source_id, 'source': source_id, 'page': int(r['page'])}
        saved += 1
    if saved:
        save_bonus_matches(data)
        if refresh_items:
            load_items(force=True)
    return saved


def _set_scan_status(**kwargs):
    with _SCAN_STATUS_LOCK:
        _SCAN_STATUS.update(kwargs)


def get_scan_status():
    with _SCAN_STATUS_LOCK:
        return dict(_SCAN_STATUS)


def _run_scan_job(force=False, retry_manual=False, source='자동'):
    """Run one complete Webhard scan outside Flask request threads."""
    if not _SCAN_LOCK.acquire(blocking=False):
        return False
    try:
        _set_scan_status(
            running=True, mode=('미매칭 OCR 재분석' if retry_manual else source),
            started_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            finished_at='', message='PDF 확인 및 매칭 중', error='', processed=0
        )
        state = scan_webhard_folder(force=force, retry_manual=retry_manual)
        _set_scan_status(
            running=False, finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            message='분석 완료', processed=len(state), error=''
        )
    except Exception as exc:
        _set_scan_status(
            running=False, finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            message='분석 오류', error=f'{type(exc).__name__}: {exc}'[:300]
        )
    finally:
        _SCAN_LOCK.release()
    return True


def start_scan_job(force=False, retry_manual=False, source='자동'):
    if get_scan_status().get('running'):
        return False
    threading.Thread(
        target=_run_scan_job,
        kwargs={'force': force, 'retry_manual': retry_manual, 'source': source},
        daemon=True
    ).start()
    return True


def scan_webhard_folder(force=False, retry_manual=False):
    """Analyze PDFs in webhard_sync in place; no bonus_pdfs duplicate is made."""
    state = load_sync_state()
    changed = False
    now = time.time()
    items = load_items(force=False)[0]
    ocr_ok, ocr_message = ocr_engine_status()
    excel_sig = str(CURRENT_XLSX.stat().st_mtime_ns) if CURRENT_XLSX.exists() else 'no-excel'
    analysis_context = f'{OCR_CACHE_VERSION}|{MATCH_ALGORITHM_VERSION}|ocr={int(ocr_ok)}|excel={excel_sig}'
    try:
        pdfs = sorted(
            (p for p in WEBHARD_SYNC_DIR.rglob('*') if p.is_file() and p.suffix.lower() == '.pdf'),
            key=lambda p: (p.stat().st_mtime_ns, _sync_source_key(p))
        )
    except OSError:
        pdfs = []

    current_keys = set()
    for src in pdfs:
        try:
            st = src.stat()
        except OSError:
            continue
        key = _sync_source_key(src)
        current_keys.add(key)
        rec = state.get(key, {})
        sig = f'{st.st_size}:{st.st_mtime_ns}'
        if rec.get('sig') != sig:
            rec = {
                'sig': sig, 'first_seen': now, 'status': 'waiting', 'size': st.st_size,
                'relative_path': key, 'source_file': key
            }
            state[key] = rec
            changed = True
            if not force:
                continue

        if not force and now - float(rec.get('first_seen', now)) < 3:
            continue

        unresolved = rec.get('status') in ('manual_required', 'error', 'ready', 'waiting')
        context_changed = rec.get('analysis_context') != analysis_context
        should_analyze = (
            force or rec.get('analyzed_sig') != sig
            or (unresolved and (retry_manual or context_changed))
        )
        if should_analyze:
            try:
                force_page_ocr = bool(unresolved and (retry_manual or context_changed))
                results = match_pdf_pages(src, items, force_ocr=force_page_ocr)
                auto_count = _apply_automatic_bonus_matches(key, results)
                manual_count = sum(1 for r in results if r.get('needs_manual') or not r.get('code'))
                status = 'auto_matched' if results and manual_count == 0 and auto_count == len(results) else 'manual_required'
                rec.update({
                    'status': status, 'source_file': key,
                    'detected_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'analyzed_sig': sig, 'auto_count': auto_count,
                    'manual_count': manual_count,
                    'page_count': len({int(r.get('page', 0)) for r in results}) if results else 0,
                    'relative_path': key, 'analysis_context': analysis_context,
                    'ocr_status': ocr_message, 'error': ''
                })
                rec.pop('bonus_file', None)
            except Exception as e:
                rec.update({
                    'status': 'error', 'source_file': key,
                    'detected_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'relative_path': key, 'analysis_context': analysis_context,
                    'ocr_status': ocr_message, 'error': str(e)[:300]
                })
                rec.pop('bonus_file', None)
        elif rec.get('status') == 'waiting':
            rec['status'] = 'ready'
        state[key] = rec
        changed = True

    for key in list(state):
        if key not in current_keys:
            state[key]['source_missing'] = True
        else:
            state[key].pop('source_missing', None)

    if changed:
        save_sync_state(state)
    return state


def _reset_sync_records(target_files=None):
    reset_all = target_files is None
    targets = {_normalize_webhard_rel(x) for x in (target_files or []) if _normalize_webhard_rel(x)}
    state = load_sync_state()
    changed = False
    for key, rec in state.items():
        source_id = _normalize_webhard_rel(rec.get('relative_path') or rec.get('source_file') or key)
        if not reset_all and source_id not in targets:
            continue
        rec['status'] = 'ready'
        rec['auto_count'] = 0
        rec['manual_count'] = 0
        rec.pop('analysis_context', None)
        rec.pop('analyzed_sig', None)
        changed = True
    if changed:
        save_sync_state(state)


def reset_bonus_mappings(code=None, filename=None, reset_sync=True):
    data = dict(load_bonus_matches())
    code = clean_code(code) if code else ''
    filename = _normalize_webhard_rel(filename) if filename else ''
    removed_files = set()
    removed_codes = set()
    next_data = {}
    removed = 0
    for saved_code, rec in data.items():
        source_id = _bonus_source_id(rec)
        should_remove = bool(
            (code and clean_code(saved_code) == code) or
            (filename and source_id == filename) or
            (not code and not filename)
        )
        if should_remove:
            removed += 1
            removed_codes.add(clean_code(saved_code))
            if source_id:
                removed_files.add(source_id)
        else:
            next_data[saved_code] = rec
    save_bonus_matches(next_data)
    _remove_ocr_learning(removed_codes, clear_all=(not code and not filename))
    load_items(force=True)
    if reset_sync:
        if code or filename:
            if removed_files:
                _reset_sync_records(removed_files)
        else:
            _reset_sync_records(None)
    return removed


def _run_full_rematch_job():
    """Clear mappings and re-evaluate every PDF directly under webhard_sync."""
    if not _SCAN_LOCK.acquire(blocking=False):
        return False
    try:
        _set_scan_status(
            running=True, mode='전 품번 재매칭',
            started_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            finished_at='', message='기존 매칭 초기화 중', error='', processed=0
        )
        reset_bonus_mappings(reset_sync=True)
        items = load_items(force=False)[0]
        state = load_sync_state()
        ocr_ok, _ = ocr_engine_status()
        excel_sig = str(CURRENT_XLSX.stat().st_mtime_ns) if CURRENT_XLSX.exists() else 'no-excel'
        analysis_context = f'{OCR_CACHE_VERSION}|{MATCH_ALGORITHM_VERSION}|ocr={int(ocr_ok)}|excel={excel_sig}'
        pdfs = sorted(
            (p for p in WEBHARD_SYNC_DIR.rglob('*') if p.is_file() and p.suffix.lower() == '.pdf'),
            key=lambda p: (p.stat().st_mtime_ns, _sync_source_key(p))
        )
        total_auto = 0
        total_manual = 0
        for idx, pdf in enumerate(pdfs, start=1):
            source_id = _sync_source_key(pdf)
            _set_scan_status(message=f'{idx}/{len(pdfs)} 분석 중: {source_id[:80]}', processed=idx-1)
            rec = state.setdefault(source_id, {'relative_path': source_id, 'source_file': source_id})
            try:
                results = match_pdf_pages(pdf, items, force_ocr=False)
                auto_count = _apply_automatic_bonus_matches(source_id, results, refresh_items=False)
                manual_count = sum(1 for r in results if r.get('needs_manual') or not r.get('code'))
                total_auto += auto_count
                total_manual += manual_count
                rec.update({
                    'status': 'auto_matched' if results and manual_count == 0 else 'manual_required',
                    'auto_count': auto_count, 'manual_count': manual_count,
                    'page_count': len({int(r.get('page', 0)) for r in results}) if results else 0,
                    'analysis_context': analysis_context,
                    'detected_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'relative_path': source_id, 'source_file': source_id,
                })
                rec.pop('bonus_file', None)
            except Exception as exc:
                rec.update({
                    'status': 'error', 'error': f'{type(exc).__name__}: {exc}'[:300],
                    'relative_path': source_id, 'source_file': source_id
                })
            state[source_id] = rec
        save_sync_state(state)
        load_items(force=True)
        _set_scan_status(
            running=False, finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            message=f'전 품번 재매칭 완료 · 자동 {total_auto}개 · 수동확인 {total_manual}개',
            processed=len(pdfs), error=''
        )
    except Exception as exc:
        _set_scan_status(
            running=False, finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            message='전 품번 재매칭 오류', error=f'{type(exc).__name__}: {exc}'[:300]
        )
    finally:
        _SCAN_LOCK.release()
    return True


def start_full_rematch_job():
    if get_scan_status().get('running'):
        return False
    threading.Thread(target=_run_full_rematch_job, daemon=True).start()
    return True

def webhard_watch_loop():
    # A light scheduler only. OCR itself runs in a separate single background job.
    # A longer interval prevents 7 GB folder rescans from competing with previews.
    time.sleep(3)
    while True:
        try:
            start_scan_job(source='자동 새 파일 확인')
        except Exception as e:
            print('WEBHARD WATCH ERROR:', e, flush=True)
        time.sleep(30)


SYNC_HTML = r"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>웹하드 다운로드 폴더</title><style>body{font-family:Malgun Gothic,Arial;margin:0;background:#f3f5f7}.wrap{max-width:1200px;margin:auto;padding:24px}.panel{background:#fff;padding:18px;border-radius:12px;margin-bottom:16px}.btn{background:#102c73;color:#fff;border:0;border-radius:7px;padding:10px 15px;text-decoration:none;font-weight:700;cursor:pointer;display:inline-block}.green{background:#26734d}.gray{background:#555}.muted{color:#666}code{background:#f0f2f5;padding:3px 7px;border-radius:5px}table{width:100%;border-collapse:collapse}th,td{padding:10px;border-bottom:1px solid #ddd;text-align:left}th{background:#edf1f7}.ready{color:#15733a;font-weight:700}.wait{color:#b66a00;font-weight:700}.status{padding:12px;border-radius:8px;background:#eef3fb}.spin{display:inline-block;width:14px;height:14px;border:2px solid #aaa;border-top-color:#102c73;border-radius:50%;animation:r 1s linear infinite}@keyframes r{to{transform:rotate(360deg)}}</style>{% if scan.running %}<meta http-equiv="refresh" content="3">{% endif %}</head><body><div class="wrap"><div class="panel"><a class="btn gray" href="/">← 메인 화면</a> <a class="btn green" href="/sync/open-folder">다운로드 폴더 열기</a> <a class="btn" href="/sync/start?mode=new">신규 파일 백그라운드 분석</a> <a class="btn green" href="/sync/start?mode=retry">기존 미매칭 OCR 재분석</a><h2>웹하드 반자동 다운로드 폴더</h2><p>이 화면은 저장된 상태만 즉시 표시합니다. PDF·OCR 분석은 백그라운드에서 실행되어 화면 로딩을 막지 않습니다.</p><p><code>{{folder}}</code></p><div class="status">{% if scan.running %}<span class="spin"></span> <b>{{scan.mode}}</b> · {{scan.message}}{% else %}<b>{{scan.message}}</b>{% endif %}{% if scan.started_at %}<br><span class="muted">시작: {{scan.started_at}}{% if scan.finished_at %} · 완료: {{scan.finished_at}}{% endif %} · 감지 파일: {{scan.processed}}</span>{% endif %}{% if scan.error %}<br><span style="color:#c00">{{scan.error}}</span>{% endif %}</div></div><div class="panel"><h3>감지된 PDF</h3><table><thead><tr><th>폴더/파일명</th><th>상태</th><th>자동 연결</th><th>감지 시각</th><th>작업</th></tr></thead><tbody>{% for name,rec in rows %}<tr><td>{{rec.relative_path or name}}</td><td class="{{'ready' if rec.status=='auto_matched' else 'wait'}}">{% if rec.status=='auto_matched' %}자동 매칭·대체 완료{% elif rec.status=='manual_required' %}불일치 - 수동 확인 필요{% elif rec.status=='error' %}분석 오류{% elif rec.status=='ready' %}분석 대기{% else %}다운로드 완료 확인 중{% endif %}</td><td>{{rec.auto_count or 0}}개</td><td>{{rec.detected_at or '-'}}</td><td>{% if rec.status in ['manual_required','error','ready'] and rec.relative_path %}<a class="btn green" href="/sync/analyze/{{rec.relative_path}}">수동 확인</a>{% elif rec.status=='auto_matched' %}<span class="ready">완료</span>{% endif %}</td></tr>{% else %}<tr><td colspan="5">아직 PDF가 없습니다.</td></tr>{% endfor %}</tbody></table></div></div></body></html>"""

@app.get('/sync')
def sync_page():
    state = load_sync_state()
    rows = sorted(state.items(), key=lambda kv: kv[1].get('detected_at',''), reverse=True)
    return render_template_string(
        SYNC_HTML, folder=str(WEBHARD_SYNC_DIR), rows=rows, scan=get_scan_status()
    )

@app.get('/sync/start')
def sync_start():
    mode = request.args.get('mode', 'new')
    start_scan_job(force=True, retry_manual=(mode == 'retry'), source='신규 파일 분석')
    return redirect('/sync')

@app.get('/sync/open-folder')
def sync_open_folder():
    try:
        if os.name == 'nt':
            os.startfile(str(WEBHARD_SYNC_DIR))
        else:
            subprocess.Popen(['xdg-open', str(WEBHARD_SYNC_DIR)])
    except Exception:
        pass
    return redirect('/sync')

@app.get('/sync/analyze/<path:filename>')
def sync_analyze(filename):
    source_id = _normalize_webhard_rel(filename)
    path = _resolve_webhard_pdf(source_id)
    if not path:
        return redirect('/sync')
    _,items,_,_=items_map()
    results = match_pdf_pages(path, items, force_ocr=True)
    return render_template_string(BONUS_HTML, results=results, filename=source_id, items=items, matches=load_bonus_matches(), ocr_status=ocr_engine_status()[1], ocr_threshold=round(OCR_AUTO_THRESHOLD*100), ocr_margin=round(OCR_MARGIN_THRESHOLD*100))

BONUS_HTML = r"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>번외 PDF 자동매칭</title><style>body{font-family:Malgun Gothic,Arial;margin:0;background:#f3f5f7}.wrap{max-width:1480px;margin:auto;padding:24px}.panel{background:white;padding:18px;border-radius:12px;margin-bottom:16px}.btn{background:#102c73;color:white;border:0;border-radius:7px;padding:10px 15px;text-decoration:none;font-weight:700;cursor:pointer;display:inline-block}.green{background:#26734d}.red{background:#d10b18}.gray{background:#555}.orange{background:#a85a00}.inline{display:inline-block;margin:3px}table{width:100%;border-collapse:collapse;font-size:13px}th,td{border-bottom:1px solid #ddd;padding:9px;text-align:left;vertical-align:top}th{background:#edf1f7}select{width:100%;min-width:300px;padding:7px}.score-high{color:#16753d;font-weight:700}.score-low{color:#c00;font-weight:700}.muted{color:#777}.auto{color:#16753d;font-weight:700}.manual{color:#c00;font-weight:700}.rule{background:#eef7f1;padding:12px;border-radius:8px;line-height:1.7}.danger{background:#fff1f1;border:1px solid #f0b7b7;padding:12px;border-radius:8px;margin-top:12px}.suggest{line-height:1.65;margin:4px 0;padding-left:20px}.small{font-size:12px}.page-thumb{display:block;width:180px;max-height:255px;object-fit:contain;background:#eee;border:1px solid #ccc;border-radius:5px}</style></head><body><div class="wrap"><div class="panel"><a class="btn" href="/">← 메인 화면</a> <a class="btn gray" href="/sync">웹하드 상태</a><h2>번외 PDF 페이지 자동매칭 · V4.4.10</h2><p><b>OCR 상태:</b> {{ocr_status}} · <b>자동확정 기준:</b> {{ocr_threshold}}% 이상, 2위와 점수 차이 {{ocr_margin}}%p 이상</p><div class="rule"><b>V4.4.10 매칭 방식</b><br>① 페이지 안에 품번이 직접 보이면 최우선 확정 → ② 파일명 품번 수와 페이지 수가 같아도 순서대로 고정하지 않음 → ③ 모든 페이지를 모든 후보 품번과 비교해 전체 점수가 가장 높은 1:1 조합을 계산 → ④ OCR 75% 미만 또는 후보 간 차이가 작은 페이지는 자동 고정하지 않고 수동 확인 → ⑤ 파일명 순서는 판독 결과가 완전히 같을 때만 참고값으로 사용</div><p class="muted">초기화는 PDF와 OCR 글자 캐시를 삭제하지 않고, 품번→페이지 연결과 관련 수동학습만 해제합니다. ‘전 품번 재매칭’은 기존 연결을 모두 풀고 현재 V4.4.10 조건으로 모든 번외 PDF를 백그라운드에서 다시 판정합니다.</p><form action="/bonus/analyze" method="post" enctype="multipart/form-data"><input type="file" name="pdf" accept=".pdf" required> <button class="btn green">PDF 분석</button></form><div class="danger"><form class="inline" action="/bonus/reset-all" method="post" onsubmit="return confirm('저장된 모든 번외 품번 연결을 초기화할까요? PDF와 OCR 글자 캐시는 유지되고 수동학습 연결은 함께 초기화됩니다.')"><button class="btn red">전체 매칭 초기화</button></form><form class="inline" action="/bonus/rematch-all" method="post" onsubmit="return confirm('기존 연결을 모두 풀고 모든 번외 PDF를 다시 매칭할까요? 작업은 백그라운드에서 실행됩니다.')"><button class="btn orange">전 품번 재매칭</button></form>{% if filename %}<form class="inline" action="/bonus/reset-file" method="post" onsubmit="return confirm('현재 PDF에 저장된 연결만 초기화할까요?')"><input type="hidden" name="filename" value="{{filename}}"><button class="btn gray">현재 PDF 매칭 초기화</button></form>{% endif %}</div></div>{% if results %}<div class="panel"><form action="/bonus/save" method="post"><input type="hidden" name="filename" value="{{filename}}"><table><thead><tr><th>페이지</th><th>페이지 미리보기</th><th>인식 내용</th><th>판정 방식</th><th>추천 후보</th><th>상태</th><th>최종 연결</th></tr></thead><tbody>{% for r in results %}<tr><td><b>{{r.page_label}}</b></td><td><a href="{{url_for('bonus_page_preview', filename=filename, page=r.page)}}" target="_blank"><img class="page-thumb" loading="lazy" src="{{url_for('bonus_page_preview', filename=filename, page=r.page)}}"></a></td><td>{{r.text or 'PDF/OCR 인식 내용 없음'}}</td><td>{{r.method}}<br><span class="small muted">선택 점수 {{r.score}}% · 후보 차이 {{r.margin or 0}}%p</span></td><td>{% if r.suggestions %}<ol class="suggest">{% for s in r.suggestions %}<li><b>{{s.code}}</b> · {{s.title}} <span class="{{'score-high' if s.score>=ocr_threshold else 'score-low'}}">{{s.score}}%</span></li>{% endfor %}</ol>{% else %}-{% endif %}</td><td class="{{'manual' if r.needs_manual else 'auto'}}">{{'수동 확인 필요' if r.needs_manual else '자동배정 완료'}}</td><td><input type="hidden" name="page" value="{{r.page}}"><input type="hidden" name="ocr_text" value="{{r.text|e}}"><select name="code"><option value="">연결하지 않음</option>{% for i in items %}<option value="{{i.code}}" {{'selected' if i.code==r.code else ''}}>{{i.code}} | {{i.title_ko}}</option>{% endfor %}</select></td></tr>{% endfor %}</tbody></table><p><button class="btn red">확인한 매칭 저장</button></p></form></div>{% endif %}<div class="panel"><h3>현재 저장된 번외 매칭 · {{matches|length}}개</h3><table><tr><th>품번</th><th>PDF</th><th>페이지</th><th>페이지 미리보기</th><th>변경</th></tr>{% for code,rec in matches.items() %}<tr><td><b>{{code}}</b></td><td>{{rec.file}}</td><td>{{rec.page+1}}</td><td><a href="{{url_for('bonus_page_preview', filename=rec.file, page=rec.page)}}" target="_blank"><img class="page-thumb" loading="lazy" src="{{url_for('bonus_page_preview', filename=rec.file, page=rec.page)}}"></a></td><td><form action="/bonus/reset-code" method="post" onsubmit="return confirm('{{code}} 연결을 해제할까요?')"><input type="hidden" name="code" value="{{code}}"><button class="btn gray">이 품번 초기화</button></form></td></tr>{% else %}<tr><td colspan="5">저장된 번외 매칭이 없습니다.</td></tr>{% endfor %}</table></div></div></body></html>"""

@app.get('/bonus/page-preview/<path:filename>/<int:page>')
def bonus_page_preview(filename, page):
    source_id = _normalize_webhard_rel(filename)
    pdf_path = _resolve_webhard_pdf(source_id or filename)
    if not pdf_path:
        return ('not found', 404)
    try:
        st = pdf_path.stat()
        key = hashlib.sha1(f'{pdf_path.resolve()}|{st.st_size}|{st.st_mtime_ns}|{page}|thumb-v4.4.10'.encode('utf-8')).hexdigest()[:24]
        cache_path = CACHE_DIR / f'bonus_page_{key}.jpg'
        if not cache_path.exists():
            with fitz.open(str(pdf_path)) as doc:
                if page < 0 or page >= doc.page_count:
                    return ('page not found', 404)
                p = doc.load_page(page)
                pix = p.get_pixmap(matrix=fitz.Matrix(1.15, 1.15), alpha=False)
                im = Image.frombytes('RGB', (pix.width, pix.height), pix.samples)
                if im.width > 420:
                    nh = round(im.height * 420 / im.width)
                    im = im.resize((420, nh), Image.Resampling.LANCZOS)
                im.save(cache_path, 'JPEG', quality=82, optimize=True, progressive=True)
        response = send_from_directory(CACHE_DIR, cache_path.name, mimetype='image/jpeg')
        response.headers['Cache-Control'] = 'public, max-age=31536000, immutable'
        return response
    except Exception as exc:
        return (f'preview error: {exc}', 500)


@app.get('/bonus')
def bonus_page():
    _,items,_,_=items_map()
    return render_template_string(BONUS_HTML, results=None, items=items, matches=load_bonus_matches(), ocr_status=ocr_engine_status()[1], ocr_threshold=round(OCR_AUTO_THRESHOLD*100), ocr_margin=round(OCR_MARGIN_THRESHOLD*100))

@app.post('/bonus/analyze')
def bonus_analyze():
    f = request.files.get('pdf')
    if not f or not f.filename:
        return redirect('/bonus')
    safe = safe_filename(f.filename)
    upload_dir = WEBHARD_SYNC_DIR / '_manual_uploads'
    upload_dir.mkdir(parents=True, exist_ok=True)
    path = upload_dir / safe
    if path.exists():
        path = upload_dir / f'{path.stem}_{int(time.time())}{path.suffix}'
    f.save(path)
    source_id = _sync_source_key(path)
    _,items,_,_=items_map()
    results = match_pdf_pages(path,items)
    return render_template_string(BONUS_HTML,results=results,filename=source_id,items=items,matches=load_bonus_matches(),ocr_status=ocr_engine_status()[1], ocr_threshold=round(OCR_AUTO_THRESHOLD*100), ocr_margin=round(OCR_MARGIN_THRESHOLD*100))

@app.post('/bonus/save')
def bonus_save():
    filename = _normalize_webhard_rel(request.form.get('filename',''))
    pages = request.form.getlist('page')
    codes = request.form.getlist('code')
    ocr_texts = request.form.getlist('ocr_text')
    data = {k:v for k,v in load_bonus_matches().items() if _bonus_source_id(v) != filename}
    for idx,(page,code) in enumerate(zip(pages,codes)):
        code=clean_code(code)
        if code and filename:
            data[code]={'file':filename,'source':filename,'page':int(page)}
            if idx < len(ocr_texts):
                _learn_ocr_mapping(ocr_texts[idx], code)
    save_bonus_matches(data)
    load_items(force=True)
    return redirect('/bonus')


@app.post('/bonus/reset-code')
def bonus_reset_code():
    reset_bonus_mappings(code=request.form.get('code', ''))
    return redirect('/bonus')


@app.post('/bonus/reset-file')
def bonus_reset_file():
    reset_bonus_mappings(filename=request.form.get('filename', ''))
    return redirect('/bonus')


@app.post('/bonus/reset-all')
def bonus_reset_all():
    reset_bonus_mappings()
    return redirect('/bonus')


@app.post('/bonus/rematch-all')
def bonus_rematch_all():
    start_full_rematch_job()
    return redirect('/sync')

@app.get('/health')
def health():
    return {'status': 'ok'}

@app.route('/')
def index():
    mp,all_items,date_range,loaded=items_map(); q=request.args.get('q','').strip().upper()
    items=all_items
    if q: items=[i for i in items if q in i['code'] or q in i['title_ko'].upper()]
    queue_codes=load_generation_queue()
    queue_items=[mp[c] for c in queue_codes if c in mp]
    if len(queue_items)!=len(queue_codes): save_generation_queue([i['code'] for i in queue_items])
    generated=[p.name for p in sorted(OUTPUT_DIR.glob('*.pdf'),key=lambda p:p.stat().st_mtime,reverse=True)[:20]]
    init=''
    return render_template_string(HTML,items=items,queue_items=queue_items,date_range=date_range,loaded_name=loaded,q=q,normal_count=sum(not i['is_discount'] for i in items),sale_count=sum(i['is_discount'] for i in items),matched_count=sum(bool(i.get('bonus_available')) for i in items),missing_count=sum(not bool(i.get('bonus_available')) for i in items),generated=generated,initial_preview=init,missing_fonts=missing_required_fonts())

@app.post('/upload')
def upload():
    f=request.files.get('excel')
    if f and f.filename:
        f.save(CURRENT_XLSX); LAST_NAME.write_text(f.filename,encoding='utf-8'); load_items(force=True)
    return redirect('/')

@app.get('/api/item/<code>')
def api_item(code):
    mp,_,_,_=items_map(); i=mp.get(clean_code(code))
    if not i: return jsonify({})
    result=dict(i); result['preview_version']=item_preview_version(i)
    return jsonify(result)

@app.get('/api/visual-choice-required')
def visual_choice_required():
    # Backward-compatible endpoint. V4.4 has no E/F choice popup.
    return jsonify({'items': []})


@app.post('/api/visual-choice')
def visual_choice_save():
    code = clean_code(request.form.get('code',''))
    choice = request.form.get('choice','')
    if not set_carryover_visual_choice(code, choice):
        return jsonify({'ok': False, 'error': '선택을 저장할 수 없습니다.'}), 400
    return jsonify({'ok': True, 'code': code, 'choice': choice})

def _render_visual_preview(pathstr):
    """Render only a screen-sized A4 image; never create a print PDF for preview."""
    page_index = 0
    raw_path = str(pathstr or '')
    if '::page=' in raw_path:
        raw_path, page_text = raw_path.rsplit('::page=', 1)
        try: page_index = max(0, int(page_text))
        except Exception: page_index = 0
    p = Path(raw_path) if raw_path else TEMPLATE_DIR / 'NEW_ARRIVAL.pdf'
    if not p.exists(): p = TEMPLATE_DIR / 'NEW_ARRIVAL.pdf'
    w = round(A4_W_MM * PREVIEW_DPI / 25.4)
    h = round(A4_H_MM * PREVIEW_DPI / 25.4)
    canvas = Image.new('RGB', (w, h), 'white')
    try:
        if p.suffix.lower() == '.pdf':
            with fitz.open(str(p)) as doc:
                page = doc.load_page(min(page_index, max(0, doc.page_count - 1)))
                pix = page.get_pixmap(matrix=fitz.Matrix(PREVIEW_DPI/72, PREVIEW_DPI/72), alpha=False)
                im = Image.frombytes('RGB', (pix.width, pix.height), pix.samples)
        else:
            im = Image.open(p).convert('RGB')
        if im.size != canvas.size:
            im = im.resize(canvas.size, Image.Resampling.LANCZOS)
        canvas.paste(im, (0, 0))
    except Exception as exc:
        print('Preview visual error:', exc, flush=True)
    return canvas


def generate_fast_preview(item, path):
    scale = PREVIEW_DPI / DPI
    if item.get('visual_mode') in {'adult_small', 'clearance'}:
        a4 = render_custom_template_a4(item, PREVIEW_DPI)
    else:
        a4 = _render_visual_preview(item.get('visual'))
        bar = generate_bottom_bar(item)
        bar = bar.resize((a4.width, round(BAR_H_PX * scale)), Image.Resampling.LANCZOS)
        a4.paste(bar, (0, round(BAR_TOP_PX * scale)))
    top = round(CUT_TOP_PX * scale)
    pop_h = round(POP_H_PX * scale)
    pop = a4.crop((0, top, a4.width, min(a4.height, top + pop_h)))
    if pop.width > PREVIEW_MAX_WIDTH:
        nh = round(pop.height * PREVIEW_MAX_WIDTH / pop.width)
        pop = pop.resize((PREVIEW_MAX_WIDTH, nh), Image.Resampling.LANCZOS)
    pop.save(path, 'JPEG', quality=88, optimize=True, progressive=True)


@app.get('/preview/<code>')
def preview(code):
    mp,_,_,_=items_map(); i=mp.get(clean_code(code))
    if not i:return ('not found',404)
    version=item_preview_version(i)
    path=CACHE_DIR/f'preview_fast_{i["code"]}_{version}.jpg'
    if not path.exists():
        generate_fast_preview(i,path)
        for old in CACHE_DIR.glob(f'preview_fast_{i["code"]}_*.jpg'):
            if old != path:
                try: old.unlink()
                except OSError: pass
    response=send_from_directory(CACHE_DIR,path.name,mimetype='image/jpeg')
    response.headers['Cache-Control']='public, max-age=31536000, immutable'
    return response

def queue_payload():
    mp,_,_,_=items_map()
    codes=load_generation_queue()
    return [{'code':c,'title_ko':mp[c].get('title_ko','')} for c in codes if c in mp]

@app.post('/queue/add')
def queue_add():
    old=load_generation_queue(); incoming=request.form.getlist('codes')
    new=save_generation_queue(old+incoming)
    return jsonify({'added':len(new)-len(old),'items':queue_payload()})

@app.post('/queue/remove')
def queue_remove():
    remove={clean_code(x) for x in request.form.getlist('codes')}
    save_generation_queue([c for c in load_generation_queue() if c not in remove])
    return jsonify({'items':queue_payload()})

@app.post('/queue/clear')
def queue_clear():
    save_generation_queue([])
    return jsonify({'items':[]})

@app.post('/queue/generate')
def queue_generate():
    mp,_,_,_=items_map(); codes=load_generation_queue(); generated=[]; failed=[]
    for code in codes:
        item=mp.get(code)
        if not item:
            failed.append(code); continue
        try:
            generate_one(item,OUTPUT_DIR/f'POP_{item["code"]}.png'); generated.append(code)
        except Exception:
            failed.append(code)
    save_generation_queue(failed)
    return jsonify({'generated':len(generated),'failed':failed,'items':queue_payload()})

@app.post('/generate')
def generate():
    mp,items,_,_=items_map(); mode=request.form.get('mode'); codes=request.form.getlist('codes')
    targets=items if mode=='all' else [mp[c] for c in codes if c in mp]
    for i in targets: generate_one(i,OUTPUT_DIR/f'POP_{i["code"]}.png')
    return redirect('/')

@app.get('/output/<name>')
def output(name): return send_from_directory(OUTPUT_DIR,name,as_attachment=False)

def configured_port():
    try:
        return int(os.environ.get('TOPTEN_POP_PORT', '8080'))
    except Exception:
        return 8080

if __name__=='__main__':
    p = configured_port()
    PID_FILE.write_text(str(os.getpid()), encoding='ascii')
    threading.Thread(target=webhard_watch_loop, daemon=True).start()
    print(f'READY http://127.0.0.1:{p}', flush=True)
    try:
        app.run('127.0.0.1', p, debug=False, threaded=True, use_reloader=False)
    finally:
        try:
            if PID_FILE.exists() and PID_FILE.read_text('ascii').strip() == str(os.getpid()):
                PID_FILE.unlink()
        except Exception:
            pass
