@echo off
setlocal EnableExtensions EnableDelayedExpansion
set "ROOT=%~1"
if not defined ROOT set "ROOT=%~dp0"
if "%ROOT:~-1%"=="\" set "ROOT=%ROOT:~0,-1%"
set "DATA=%ROOT%\data"
set "RUNTIME=%ROOT%\runtime"
set "PYDIR=%RUNTIME%\Python313"
set "PYEXE=%PYDIR%\python.exe"
set "TESSDATA=%ROOT%\ocr_tessdata"
set "LOG=%ROOT%\run_setup_log.txt"
set "TMPDIR=%TEMP%\TOPTEN_POP_V446_SETUP"
set "PYZIP=%TMPDIR%\python-3.13.14-embed-amd64.zip"
set "GETPIP=%TMPDIR%\get-pip.py"
set "TESSSETUP=%TMPDIR%\tesseract-ocr-w64-setup-5.4.0.20240606.exe"
set "PYURL=https://www.python.org/ftp/python/3.13.14/python-3.13.14-embed-amd64.zip"
set "PYHASH=90b4e5b9898b72d744650524bff92377c367f44bd5fbd09e3148656c080ad907"
set "PIPURL=https://bootstrap.pypa.io/get-pip.py"
set "TESSURL=https://github.com/UB-Mannheim/tesseract/releases/download/v5.4.0.20240606/tesseract-ocr-w64-setup-5.4.0.20240606.exe"
set "TESSHASH=c885fff6998e0608ba4bb8ab51436e1c6775c2bafc2559a19b423e18678b60c9"

if not exist "%DATA%" mkdir "%DATA%" >nul 2>&1
if not exist "%RUNTIME%" mkdir "%RUNTIME%" >nul 2>&1
if not exist "%TESSDATA%" mkdir "%TESSDATA%" >nul 2>&1
if not exist "%TMPDIR%" mkdir "%TMPDIR%" >nul 2>&1
>"%LOG%" echo TOPTEN POP V4.4.6 AUTO SETUP LOG
call :log "Setup start - PowerShell-free bootstrap"

if /I not "%PROCESSOR_ARCHITECTURE%"=="AMD64" goto check_wow64
goto python_check
:check_wow64
if /I "%PROCESSOR_ARCHITEW6432%"=="AMD64" goto python_check
call :log "BLOCKED: Windows x64 AMD64 was not detected."
exit /b 32

:python_check
if not exist "%PYEXE%" goto python_prepare
"%PYEXE%" -c "import struct,sys;raise SystemExit(0 if struct.calcsize('P')*8==64 and sys.version_info[:2]==(3,13) else 1)" >nul 2>&1
if errorlevel 1 goto python_rebuild
call :log "Portable Python OK: %PYEXE%"
goto python_pip_check

:python_rebuild
call :log "Portable Python exists but failed verification. Rebuilding runtime."
rmdir /s /q "%PYDIR%" >nul 2>&1

:python_prepare
call :log "Downloading official Python 3.13.14 embeddable x64 package."
if exist "%PYZIP%" del /q "%PYZIP%" >nul 2>&1
call :download "%PYURL%" "%PYZIP%"
if errorlevel 1 goto fail_python_download
for %%I in ("%PYZIP%") do set "PYSIZE=%%~zI"
if not defined PYSIZE goto fail_python_download
if !PYSIZE! LSS 9000000 goto fail_python_download
call :hashcheck "%PYZIP%" "%PYHASH%"
if errorlevel 1 goto fail_python_hash
if exist "%PYDIR%" rmdir /s /q "%PYDIR%" >nul 2>&1
mkdir "%PYDIR%" >nul 2>&1
where tar.exe >nul 2>&1
if errorlevel 1 goto python_unzip_vbs
call :log "Extracting Python with Windows tar.exe."
tar.exe -xf "%PYZIP%" -C "%PYDIR%" >>"%LOG%" 2>&1
if exist "%PYEXE%" goto python_unzip_done

:python_unzip_vbs
call :log "Extracting Python with Windows Shell ZIP fallback."
cscript.exe //nologo "%ROOT%\bootstrap_unzip.vbs" "%PYZIP%" "%PYDIR%" >>"%LOG%" 2>&1
set /a WAITZIP=0
:python_zip_wait
if exist "%PYEXE%" goto python_unzip_done
set /a WAITZIP+=1
if !WAITZIP! GEQ 30 goto fail_python_extract
timeout /t 1 /nobreak >nul
goto python_zip_wait

:python_unzip_done
if not exist "%PYEXE%" goto fail_python_extract
set "PTH=%PYDIR%\python313._pth"
if not exist "%PYDIR%\Lib\site-packages" mkdir "%PYDIR%\Lib\site-packages" >nul 2>&1
findstr /x /c:"Lib\site-packages" "%PTH%" >nul 2>&1
if errorlevel 1 >>"%PTH%" echo Lib\site-packages
findstr /x /c:"import site" "%PTH%" >nul 2>&1
if errorlevel 1 >>"%PTH%" echo import site
"%PYEXE%" -c "import struct,sys;raise SystemExit(0 if struct.calcsize('P')*8==64 else 1)" >>"%LOG%" 2>&1
if errorlevel 1 goto fail_python_verify
call :log "Portable Python runtime ready."

:python_pip_check
"%PYEXE%" -m pip --version >nul 2>&1
if not errorlevel 1 goto python_packages
call :log "pip not found. Downloading official get-pip.py."
if exist "%GETPIP%" del /q "%GETPIP%" >nul 2>&1
call :download "%PIPURL%" "%GETPIP%"
if errorlevel 1 goto fail_pip_download
for %%I in ("%GETPIP%") do set "PIPSIZE=%%~zI"
if not defined PIPSIZE goto fail_pip_download
if !PIPSIZE! LSS 1000000 goto fail_pip_download
"%PYEXE%" "%GETPIP%" --disable-pip-version-check >>"%LOG%" 2>&1
if errorlevel 1 goto fail_pip_install

:python_packages
call :log "Checking Python modules."
"%PYEXE%" -c "import flask,openpyxl,PIL,fitz,pytesseract,packaging" >nul 2>&1
if not errorlevel 1 goto python_done
call :log "Installing required Python modules from PyPI."
"%PYEXE%" -m pip install --disable-pip-version-check --no-warn-script-location --retries 3 --timeout 45 flask openpyxl pillow pymupdf pytesseract packaging >>"%LOG%" 2>&1
if errorlevel 1 goto fail_packages
"%PYEXE%" -c "import flask,openpyxl,PIL,fitz,pytesseract,packaging" >>"%LOG%" 2>&1
if errorlevel 1 goto fail_packages

:python_done
>"%DATA%\python_path.txt" echo %PYEXE%
call :log "Python and required modules READY."

goto tesseract_check

:tesseract_check
set "TESSERACT="
if exist "%DATA%\tesseract_path.txt" set /p TESSERACT=<"%DATA%\tesseract_path.txt"
if defined TESSERACT if exist "%TESSERACT%" goto tesseract_ready
if exist "C:\Program Files\Tesseract-OCR\tesseract.exe" set "TESSERACT=C:\Program Files\Tesseract-OCR\tesseract.exe"
if defined TESSERACT goto tesseract_ready
if exist "%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe" set "TESSERACT=%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe"
if defined TESSERACT goto tesseract_ready
for /f "delims=" %%T in ('where tesseract.exe 2^>nul') do if not defined TESSERACT set "TESSERACT=%%T"
if defined TESSERACT goto tesseract_ready

goto tesseract_install

:tesseract_install
call :log "Tesseract not found. Trying winget first."
where winget.exe >nul 2>&1
if errorlevel 1 goto tesseract_direct
winget.exe install --id UB-Mannheim.TesseractOCR -e --silent --accept-package-agreements --accept-source-agreements --disable-interactivity >>"%LOG%" 2>&1
if exist "C:\Program Files\Tesseract-OCR\tesseract.exe" set "TESSERACT=C:\Program Files\Tesseract-OCR\tesseract.exe"
if defined TESSERACT goto tesseract_ready

:tesseract_direct
call :log "Downloading verified UB-Mannheim Tesseract 5.4.0 installer."
if exist "%TESSSETUP%" del /q "%TESSSETUP%" >nul 2>&1
call :download "%TESSURL%" "%TESSSETUP%"
if errorlevel 1 goto fail_tess_download
for %%I in ("%TESSSETUP%") do set "TESSSIZE=%%~zI"
if not defined TESSSIZE goto fail_tess_download
if !TESSSIZE! LSS 40000000 goto fail_tess_download
call :hashcheck "%TESSSETUP%" "%TESSHASH%"
if errorlevel 1 goto fail_tess_hash
call :log "Installing Tesseract silently. A Windows UAC approval may appear."
start /wait "" "%TESSSETUP%" /S >>"%LOG%" 2>&1
if exist "C:\Program Files\Tesseract-OCR\tesseract.exe" set "TESSERACT=C:\Program Files\Tesseract-OCR\tesseract.exe"
if exist "%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe" set "TESSERACT=%LOCALAPPDATA%\Programs\Tesseract-OCR\tesseract.exe"
if not defined TESSERACT goto fail_tess_install

:tesseract_ready
>"%DATA%\tesseract_path.txt" echo %TESSERACT%
call :log "Tesseract READY: %TESSERACT%"

goto tessdata_eng

:tessdata_eng
set "ENG=%TESSDATA%\eng.traineddata"
if exist "%ENG%" for %%I in ("%ENG%") do if %%~zI GEQ 1000000 goto tessdata_kor
call :log "Downloading OCR language: eng"
call :download "https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/eng.traineddata" "%ENG%"
if errorlevel 1 goto fail_tessdata

:tessdata_kor
set "KOR=%TESSDATA%\kor.traineddata"
if exist "%KOR%" for %%I in ("%KOR%") do if %%~zI GEQ 500000 goto tessdata_osd
call :log "Downloading OCR language: kor"
call :download "https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/kor.traineddata" "%KOR%"
if errorlevel 1 goto fail_tessdata

:tessdata_osd
set "OSD=%TESSDATA%\osd.traineddata"
if exist "%OSD%" for %%I in ("%OSD%") do if %%~zI GEQ 1000000 goto tessdata_verify
call :log "Downloading OCR language: osd"
call :download "https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/osd.traineddata" "%OSD%"
if errorlevel 1 goto fail_tessdata

:tessdata_verify
set "TESSDATA_PREFIX=%TESSDATA%"
"%TESSERACT%" --list-langs >"%TMPDIR%\langs.txt" 2>>"%LOG%"
if errorlevel 1 goto fail_tessdata
findstr /x /c:"kor" "%TMPDIR%\langs.txt" >nul 2>&1
if errorlevel 1 goto fail_tessdata
findstr /x /c:"eng" "%TMPDIR%\langs.txt" >nul 2>&1
if errorlevel 1 goto fail_tessdata
call :log "OCR languages READY: kor, eng, osd."
call :log "Environment READY."
exit /b 0

:download
set "DLURL=%~1"
set "DLOUT=%~2"
if exist "%DLOUT%" del /q "%DLOUT%" >nul 2>&1
where curl.exe >nul 2>&1
if errorlevel 1 goto download_certutil
curl.exe -L --fail --retry 3 --connect-timeout 20 --max-time 360 -o "%DLOUT%" "%DLURL%" >>"%LOG%" 2>&1
if not errorlevel 1 if exist "%DLOUT%" exit /b 0
:download_certutil
certutil.exe -urlcache -split -f "%DLURL%" "%DLOUT%" >>"%LOG%" 2>&1
if errorlevel 1 exit /b 1
if not exist "%DLOUT%" exit /b 1
exit /b 0

:hashcheck
set "HASHFILE=%~1"
set "EXPECTED=%~2"
certutil.exe -hashfile "%HASHFILE%" SHA256 >"%TMPDIR%\hash.txt" 2>>"%LOG%"
if errorlevel 1 exit /b 1
findstr /I /C:"%EXPECTED%" "%TMPDIR%\hash.txt" >nul 2>&1
if errorlevel 1 exit /b 1
exit /b 0

:log
set "MSG=%~1"
echo %MSG%
>>"%LOG%" echo [%date% %time%] %MSG%
exit /b 0

:fail_python_download
call :log "FAILED: Python embeddable package download failed."
exit /b 41
:fail_python_hash
call :log "FAILED: Python package SHA256 verification failed."
exit /b 42
:fail_python_extract
call :log "FAILED: Python ZIP extraction failed."
exit /b 43
:fail_python_verify
call :log "FAILED: Portable Python did not start correctly."
exit /b 44
:fail_pip_download
call :log "FAILED: get-pip.py download failed."
exit /b 45
:fail_pip_install
call :log "FAILED: pip installation failed."
exit /b 46
:fail_packages
call :log "FAILED: Required Python module installation failed."
exit /b 47
:fail_tess_download
call :log "FAILED: Tesseract installer download failed."
exit /b 51
:fail_tess_hash
call :log "FAILED: Tesseract installer SHA256 verification failed."
exit /b 52
:fail_tess_install
call :log "FAILED: Tesseract installer finished but tesseract.exe was not found."
exit /b 53
:fail_tessdata
call :log "FAILED: OCR language data setup failed."
exit /b 54
