# -*- coding: utf-8 -*-
"""TOPTEN POP automatic updater - V4.4.6 PowerShell-free first-run update.

The updater never renames the live program directory itself. It stages files,
records a pending finalize job, and lets RUN.cmd launch a TEMP copy of the
finalizer after RUN.cmd exits. This avoids Windows directory/file locks.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import sys
import tempfile
import time
import urllib.request
import zipfile
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
CACHE_DIR = ROOT / "cache"
SETTINGS_FILE = DATA_DIR / "update_settings.json"
VERSION_FILE = ROOT / "version.json"
LOG_FILE = ROOT / "auto_update_log.txt"
LOCK_FILE = DATA_DIR / "auto_update.lock"
PENDING_FINALIZE = DATA_DIR / "pending_finalize.json"
PENDING_RUN = DATA_DIR / "pending_RUN.cmd"
RENAME_STATE = DATA_DIR / "folder_rename_state.json"
FINALIZER_SPAWNED = DATA_DIR / "finalizer_spawned.json"
DEFAULT_MANIFEST_URL = "https://raw.githubusercontent.com/vhflddjfla-spec/TOPTEN-POP-UPDATES/refs/heads/main/latest.json"

PROTECTED_TOP_LEVEL = {
    "data", "bonus_pdfs", "webhard_sync", "output", "cache",
    "product_images", "fonts", "ocr_tessdata", "runtime"
}
SPECIAL_STAGE_FILES = {"RUN.cmd"}
SPECIAL_META_FILES = {"cleanup.json"}


def log(message: str) -> None:
    line = f"[{datetime.now().isoformat(timespec='seconds')}] {message}"
    print(line, flush=True)
    try:
        with LOG_FILE.open("a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def read_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception:
        return default


def write_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def ensure_settings():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    settings = read_json(SETTINGS_FILE, {})
    if not isinstance(settings, dict):
        settings = {}
    settings["manifest_url"] = DEFAULT_MANIFEST_URL
    settings.setdefault("enabled", True)
    settings.setdefault("auto_install", True)
    settings.setdefault("timeout_seconds", 8)
    write_json(SETTINGS_FILE, settings)
    return settings


def version_tuple(value: str):
    parts = []
    for token in str(value or "0").strip().lstrip("vV").split("."):
        digits = "".join(ch for ch in token if ch.isdigit())
        parts.append(int(digits or 0))
    while len(parts) < 4:
        parts.append(0)
    return tuple(parts[:4])


def current_version() -> str:
    return str(read_json(VERSION_FILE, {}).get("version") or "0.0.0")


def expected_folder_name(version: str) -> str:
    meta = read_json(VERSION_FILE, {})
    explicit = str(meta.get("folder_name") or "").strip()
    if explicit:
        return explicit
    display = str(meta.get("display_version") or "").strip().lstrip("vV")
    if display:
        return f"TOPTEN_POP_V{display}"
    return f"TOPTEN_POP_V{str(version).strip().lstrip('vV')}"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest().lower()


def download(url: str, dest: Path, timeout: int = 8) -> None:
    req = urllib.request.Request(url, headers={"User-Agent": "TOPTEN-POP-Updater/4.4.6"})
    with urllib.request.urlopen(req, timeout=timeout) as response, dest.open("wb") as out:
        shutil.copyfileobj(response, out)


def safe_extract(zip_path: Path, dest: Path) -> None:
    dest_real = dest.resolve()
    with zipfile.ZipFile(zip_path) as zf:
        for info in zf.infolist():
            name = info.filename.replace("\\", "/")
            if not name or name.endswith("/"):
                continue
            target = (dest / name).resolve()
            if dest_real not in target.parents and target != dest_real:
                raise RuntimeError(f"unsafe zip path: {name}")
        zf.extractall(dest)


def find_payload(extract_dir: Path) -> Path:
    direct = extract_dir / "payload"
    if direct.is_dir():
        return direct
    children = [p for p in extract_dir.iterdir() if p.is_dir()]
    if len(children) == 1 and (children[0] / "payload").is_dir():
        return children[0] / "payload"
    return extract_dir


def collect_payload_files(payload: Path):
    files = []
    for src in payload.rglob("*"):
        if not src.is_file():
            continue
        rel = src.relative_to(payload)
        rel_posix = str(rel).replace("\\", "/")
        if not rel.parts:
            continue
        if rel.parts[0].lower() in PROTECTED_TOP_LEVEL:
            continue
        if rel_posix in SPECIAL_STAGE_FILES or rel_posix in SPECIAL_META_FILES:
            continue
        files.append((src, rel))
    return files


def acquire_lock() -> bool:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    try:
        if LOCK_FILE.exists() and time.time() - LOCK_FILE.stat().st_mtime > 600:
            LOCK_FILE.unlink(missing_ok=True)
        fd = os.open(str(LOCK_FILE), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, str(os.getpid()).encode("ascii", errors="ignore"))
        os.close(fd)
        return True
    except FileExistsError:
        return False


def release_lock() -> None:
    try:
        LOCK_FILE.unlink(missing_ok=True)
    except Exception:
        pass


def payload_cleanup_list(payload: Path):
    cfg = read_json(payload / "cleanup.json", {})
    if isinstance(cfg, dict):
        return cfg.get("delete_paths") or []
    return []


def install_payload(payload: Path, remote_version: str, manifest: dict) -> Path:
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup = ROOT / f"update_backup_auto_{stamp}"
    backup.mkdir(parents=True, exist_ok=True)
    changed = []
    created = []
    try:
        run_src = payload / "RUN.cmd"
        if run_src.exists():
            if (ROOT / "RUN.cmd").exists():
                shutil.copy2(ROOT / "RUN.cmd", backup / "RUN.cmd")
            DATA_DIR.mkdir(parents=True, exist_ok=True)
            shutil.copy2(run_src, PENDING_RUN)

        for src, rel in collect_payload_files(payload):
            target = ROOT / rel
            backup_target = backup / rel
            if target.exists():
                backup_target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(target, backup_target)
                changed.append((target, backup_target))
            else:
                created.append(target)
            target.parent.mkdir(parents=True, exist_ok=True)
            tmp = target.with_name(target.name + ".update_tmp")
            shutil.copy2(src, tmp)
            os.replace(tmp, target)

        version_data = read_json(VERSION_FILE, {})
        version_data["version"] = str(remote_version)
        display_version = str(manifest.get("display_version") or version_data.get("display_version") or remote_version).strip().lstrip("vV")
        version_data["display_version"] = display_version
        version_data["folder_name"] = str(manifest.get("folder_name") or version_data.get("folder_name") or f"TOPTEN_POP_V{display_version}")
        version_data["name"] = f"TOPTEN POP V{display_version}"
        version_data.setdefault("product", "TOPTEN POP Automation")
        write_json(VERSION_FILE, version_data)

        delete_paths = []
        if isinstance(manifest.get("delete_paths"), list):
            delete_paths.extend(manifest.get("delete_paths") or [])
        delete_paths.extend(payload_cleanup_list(payload))

        try:
            RENAME_STATE.unlink(missing_ok=True)
            FINALIZER_SPAWNED.unlink(missing_ok=True)
        except Exception:
            pass

        write_json(PENDING_FINALIZE, {
            "version": str(remote_version),
            "old_root": str(ROOT),
            "target_name": str(manifest.get("folder_name") or expected_folder_name(remote_version)),
            "restart": True,
            "delete_paths": delete_paths,
            "created_at": datetime.now().isoformat(timespec="seconds"),
        })
        return backup
    except Exception:
        try:
            PENDING_RUN.unlink(missing_ok=True)
        except Exception:
            pass
        for target in created:
            try:
                if target.is_file():
                    target.unlink(missing_ok=True)
            except Exception:
                pass
        for target, backup_target in reversed(changed):
            try:
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(backup_target, target)
            except Exception:
                pass
        raise


def ensure_current_folder_finalize(current: str) -> None:
    """Schedule one rename attempt without ever creating a launch loop.

    If a previous rename failed for this exact root/version, normal RUN.cmd
    launches do not enqueue it again.  A later real version update or a manual
    installer can still retry.
    """
    expected = expected_folder_name(current)
    if ROOT.name.lower() == expected.lower():
        try:
            RENAME_STATE.unlink(missing_ok=True)
            FINALIZER_SPAWNED.unlink(missing_ok=True)
        except Exception:
            pass
        return

    state = read_json(RENAME_STATE, {})
    if isinstance(state, dict):
        same_failed = (
            state.get("status") == "failed"
            and str(state.get("version") or "") == str(current)
            and str(state.get("root") or "").lower() == str(ROOT).lower()
        )
        if same_failed:
            log("이전 폴더명 변경 실패가 기록되어 있어 반복 시도를 차단합니다. 프로그램은 현재 폴더에서 정상 실행합니다.")
            return

    if not PENDING_FINALIZE.exists():
        write_json(PENDING_FINALIZE, {
            "version": current,
            "old_root": str(ROOT),
            "target_name": expected,
            "restart": True,
            "delete_paths": [],
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "reason": "folder_name_normalization",
        })
        log(f"현재 폴더명 정리 1회 예약: {ROOT.name} -> {expected}")


def main() -> int:
    settings = ensure_settings()
    current = current_version()

    if not settings.get("enabled", True):
        ensure_current_folder_finalize(current)
        return 0
    if not acquire_lock():
        return 0

    try:
        manifest_url = DEFAULT_MANIFEST_URL
        timeout = int(settings.get("timeout_seconds") or 8)
        auto_install = bool(settings.get("auto_install", True))
        log(f"업데이트 확인: 현재 {current}")
        try:
            req = urllib.request.Request(manifest_url, headers={"User-Agent": "TOPTEN-POP-Updater/4.4.6"})
            with urllib.request.urlopen(req, timeout=timeout) as response:
                manifest = json.loads(response.read().decode("utf-8-sig"))
        except Exception as exc:
            log(f"업데이트 서버 연결 실패 - 현재 버전으로 계속 실행: {type(exc).__name__}: {exc}")
            ensure_current_folder_finalize(current)
            return 0

        remote = str(manifest.get("version") or "0.0.0")
        if version_tuple(remote) <= version_tuple(current):
            log(f"최신 버전 사용 중: {current}")
            ensure_current_folder_finalize(current)
            return 0

        if not auto_install:
            return 0

        url = str(manifest.get("download_url") or manifest.get("url") or "").strip()
        if not url:
            raise RuntimeError("latest.json에 download_url이 없습니다.")
        expected_hash = str(manifest.get("sha256") or "").strip().lower().replace(" ", "")

        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix="topten_update_", dir=str(CACHE_DIR)) as td:
            td = Path(td)
            archive = td / f"TOPTEN_POP_{remote}.zip"
            log(f"새 버전 V{remote} 다운로드 중...")
            download(url, archive, timeout=max(timeout, 15))
            actual_hash = sha256_file(archive)
            if expected_hash and actual_hash != expected_hash:
                raise RuntimeError(f"SHA256 불일치: expected={expected_hash} actual={actual_hash}")
            extract_dir = td / "extract"
            extract_dir.mkdir()
            safe_extract(archive, extract_dir)
            payload = find_payload(extract_dir)
            if not collect_payload_files(payload) and not (payload / "RUN.cmd").exists():
                raise RuntimeError("업데이트 ZIP에서 payload를 찾지 못했습니다.")
            backup = install_payload(payload, remote, manifest)
            log(f"자동업데이트 적용 완료: V{remote} / 백업: {backup.name}")
            log("RUN.cmd 종료 후 TEMP 마무리 프로세스에서 정리/폴더명 변경/재실행합니다.")
        return 0
    except Exception as exc:
        log(f"자동업데이트 실패 - 현재 버전 유지: {type(exc).__name__}: {exc}")
        ensure_current_folder_finalize(current_version())
        return 1
    finally:
        release_lock()


if __name__ == "__main__":
    sys.exit(main())
