# -*- coding: utf-8 -*-
"""TOPTEN POP deferred cleanup / folder rename finalizer.

This file is copied to %TEMP% and launched only after RUN.cmd or the manual
installer exits.  Important goals:
- never create a RUN -> finalizer -> RUN infinite loop
- never delete store data just to resolve a folder-name collision
- remove old updater junk and stale safe patch folders
- rename the install folder to TOPTEN_POP_V<version> when Windows allows it
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import time
from datetime import datetime, timedelta
from pathlib import Path

PROTECTED = {
    "data", "bonus_pdfs", "webhard_sync", "output", "cache",
    "product_images", "fonts", "templates", "ocr_tessdata", "runtime"
}

OBSOLETE_FILES = {
    "SET_UPDATE_SERVER.cmd",
    "set_update_server.py",
    "update_settings.example.json",
    "latest.example.json",
    "V4_4_0_UPDATE_COMPLETE.txt",
    "업데이트_설명서.txt",
    "자동업데이트_배포방법.txt",
    "README_업데이트방법.txt",
    "TOPTEN_POP_V4_3_최종_업데이트_메모.txt",
}

OBSOLETE_FILE_GLOBS = (
    "V*_UPDATE_COMPLETE.txt",
    "V4.*_검증내역.txt",
    "*.update_tmp",
    "TOPTEN_POP_V*_UPDATE.zip",
    "TOPTEN_POP_V*_FINAL_UPDATE.zip",
    "TOPTEN_POP_V*_UNIFIED_INSTALLER.zip",
)


def read_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception:
        return default


def write_json(path: Path, data) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def append_log(root: Path, msg: str) -> None:
    try:
        root.mkdir(parents=True, exist_ok=True)
        with (root / "auto_update_log.txt").open("a", encoding="utf-8") as f:
            f.write(f"[{datetime.now().isoformat(timespec='seconds')}] {msg}\n")
    except Exception:
        pass



def migrate_legacy_bonus_storage(root: Path) -> bool:
    """Migrate V4.4.0 bonus_pdfs copies to direct webhard_sync references.

    Existing PDFs already present in webhard_sync are reused. Orphan/manual legacy
    PDFs are moved once into webhard_sync/_migrated_legacy_bonus. Mapping JSON is
    rewritten to relative source paths. bonus_pdfs is removed only after every
    legacy PDF and every saved mapping has a valid webhard_sync source.
    """
    legacy_dir = root / "bonus_pdfs"
    webhard = root / "webhard_sync"
    data_dir = root / "data"
    mapping_file = data_dir / "bonus_page_matches.json"
    state_file = data_dir / "webhard_sync_state.json"
    report_file = data_dir / "storage_migration_v4_4_1.json"

    if not legacy_dir.exists():
        write_json(report_file, {
            "status": "already_direct",
            "updated_at": datetime.now().isoformat(timespec="seconds"),
            "message": "bonus_pdfs 없음 - webhard_sync 직접 참조 구조 사용"
        })
        return True

    webhard.mkdir(parents=True, exist_ok=True)
    state = read_json(state_file, {})
    if not isinstance(state, dict):
        state = {}
    mappings = read_json(mapping_file, {})
    if not isinstance(mappings, dict):
        mappings = {}

    def norm_rel(value):
        raw = str(value or "").strip().replace("\\\\", "/").lstrip("/")
        if not raw:
            return ""
        rel = Path(raw)
        if rel.is_absolute() or not rel.parts or any(x in ("", ".", "..") for x in rel.parts):
            return ""
        return rel.as_posix()

    legacy_to_source = {}
    for key, rec in state.items():
        if not isinstance(rec, dict):
            continue
        old_name = Path(str(rec.get("bonus_file") or "")).name
        rel = norm_rel(rec.get("relative_path") or rec.get("source_file") or key)
        if old_name and rel and (webhard / Path(rel)).is_file():
            legacy_to_source[old_name] = rel

    migrated_dir = webhard / "_migrated_legacy_bonus"
    moved_count = 0
    reused_count = 0
    errors = []

    legacy_pdfs = []
    try:
        legacy_pdfs = [x for x in legacy_dir.rglob("*") if x.is_file() and x.suffix.lower() == ".pdf"]
    except Exception as exc:
        errors.append(f"legacy scan: {exc}")

    for src in legacy_pdfs:
        old_name = src.name
        rel = legacy_to_source.get(old_name, "")
        if rel and (webhard / Path(rel)).is_file():
            reused_count += 1
            continue
        try:
            migrated_dir.mkdir(parents=True, exist_ok=True)
            dest = migrated_dir / old_name
            if dest.exists():
                try:
                    same = dest.stat().st_size == src.stat().st_size
                except Exception:
                    same = False
                if not same:
                    n = 2
                    while True:
                        candidate = migrated_dir / f"{dest.stem}_{n}{dest.suffix}"
                        if not candidate.exists():
                            dest = candidate
                            break
                        n += 1
                else:
                    src.unlink(missing_ok=True)
                    legacy_to_source[old_name] = dest.relative_to(webhard).as_posix()
                    reused_count += 1
                    continue
            shutil.move(str(src), str(dest))
            legacy_to_source[old_name] = dest.relative_to(webhard).as_posix()
            moved_count += 1
        except Exception as exc:
            errors.append(f"{src.name}: {exc}")

    new_mappings = {}
    unresolved = []
    for code, rec in mappings.items():
        if not isinstance(rec, dict):
            new_mappings[code] = rec
            continue
        raw = str(rec.get("source") or rec.get("file") or "")
        rel = norm_rel(raw)
        if rel and (webhard / Path(rel)).is_file():
            source_rel = rel
        else:
            source_rel = legacy_to_source.get(Path(raw).name, "")
        if source_rel and (webhard / Path(source_rel)).is_file():
            nr = dict(rec)
            nr["file"] = source_rel
            nr["source"] = source_rel
            new_mappings[code] = nr
        else:
            # Preserve record for fallback if migration cannot prove the source.
            new_mappings[code] = rec
            unresolved.append(str(code))

    # Rewrite sync-state records to direct source paths.
    new_state = {}
    for key, rec in state.items():
        if not isinstance(rec, dict):
            new_state[key] = rec
            continue
        nr = dict(rec)
        rel = norm_rel(nr.get("relative_path") or nr.get("source_file") or key)
        if rel:
            nr["relative_path"] = rel
            nr["source_file"] = rel
        nr.pop("bonus_file", None)
        new_state[key] = nr

    if errors or unresolved:
        append_log(root, "V4.4.1 저장구조 이전 보류: " + "; ".join(errors + ([f"미해결 매핑 {len(unresolved)}개"] if unresolved else [])))
        write_json(report_file, {
            "status": "partial",
            "moved": moved_count,
            "reused": reused_count,
            "unresolved_codes": unresolved,
            "errors": errors,
            "updated_at": datetime.now().isoformat(timespec="seconds")
        })
        # Save only state cleanup that does not invalidate legacy fallback; mappings stay old.
        write_json(state_file, new_state)
        return False

    write_json(mapping_file, new_mappings)
    write_json(state_file, new_state)

    try:
        # Remove empty subfolders first, then the full duplicate store.
        if legacy_dir.exists():
            shutil.rmtree(legacy_dir)
        append_log(root, f"V4.4.1 저장구조 이전 완료: webhard_sync 직접 참조 / 재사용 {reused_count} / 이동 {moved_count} / bonus_pdfs 삭제")
        write_json(report_file, {
            "status": "success",
            "moved": moved_count,
            "reused": reused_count,
            "mapping_count": len(new_mappings),
            "bonus_pdfs_removed": True,
            "updated_at": datetime.now().isoformat(timespec="seconds")
        })
        return True
    except Exception as exc:
        append_log(root, f"매핑 이전은 완료했으나 bonus_pdfs 삭제 실패(다음 실행에서도 직접 참조 사용): {exc}")
        write_json(report_file, {
            "status": "mapped_cleanup_failed",
            "moved": moved_count,
            "reused": reused_count,
            "mapping_count": len(new_mappings),
            "bonus_pdfs_removed": False,
            "error": str(exc),
            "updated_at": datetime.now().isoformat(timespec="seconds")
        })
        return False


def safe_rel(value: str):
    raw = str(value or "").strip().replace("\\", "/").lstrip("/")
    if not raw or raw == ".." or raw.startswith("../") or "/../" in raw:
        return None
    p = Path(raw)
    if p.is_absolute() or not p.parts:
        return None
    if p.parts[0].lower() in PROTECTED:
        return None
    return p


def safe_delete(root: Path, value: str) -> bool:
    rel = safe_rel(value)
    if rel is None:
        return False
    target = root / rel
    try:
        if target.is_dir() and not target.is_symlink():
            shutil.rmtree(target)
            return True
        if target.exists() or target.is_symlink():
            target.unlink(missing_ok=True)
            return True
    except Exception as exc:
        append_log(root, f"정리 실패(계속 진행): {rel}: {exc}")
    return False


def remove_patch_folders(root: Path) -> None:
    """Delete only folders that unmistakably look like extracted update packs."""
    try:
        children = list(root.iterdir())
    except Exception:
        return
    for child in children:
        try:
            if not child.is_dir() or child.name.lower() in PROTECTED:
                continue
            looks_old = (child / "APPLY_UPDATE.cmd").is_file() and (child / "payload").is_dir()
            looks_new = (child / "INSTALL_UPDATE.py").is_file() and (child / "payload").is_dir()
            if looks_old or looks_new:
                shutil.rmtree(child)
                append_log(root, f"압축 해제된 업데이트 폴더 삭제: {child.name}")
        except Exception as exc:
            append_log(root, f"업데이트 폴더 정리 실패(계속 진행): {child.name}: {exc}")


def trim_old_backups(root: Path, keep: int = 2) -> None:
    try:
        backups = [
            p for p in root.iterdir()
            if p.is_dir() and (
                p.name.startswith("update_backup_auto_")
                or p.name.startswith("update_backup_V")
                or p.name.startswith("update_backup_")
            )
        ]
        backups.sort(key=lambda p: p.stat().st_mtime, reverse=True)
        for p in backups[keep:]:
            try:
                shutil.rmtree(p)
                append_log(root, f"오래된 업데이트 백업 삭제: {p.name}")
            except Exception as exc:
                append_log(root, f"오래된 백업 삭제 실패(계속 진행): {p.name}: {exc}")
    except Exception:
        pass


def cleanup(root: Path, extra_paths=None) -> None:
    for name in OBSOLETE_FILES:
        safe_delete(root, name)
    for value in extra_paths or []:
        safe_delete(root, value)

    for base in (root, root / "app"):
        try:
            pycache = base / "__pycache__"
            if pycache.is_dir():
                shutil.rmtree(pycache)
        except Exception:
            pass

    for pattern in OBSOLETE_FILE_GLOBS:
        try:
            for p in root.glob(pattern):
                if p.is_file():
                    try:
                        p.unlink()
                        append_log(root, f"구버전 파일 삭제: {p.name}")
                    except Exception as exc:
                        append_log(root, f"구버전 파일 삭제 실패(계속 진행): {p.name}: {exc}")
        except Exception:
            pass

    remove_patch_folders(root)
    trim_old_backups(root, keep=2)


def desired_name(version: str, root: Path | None = None) -> str:
    if root is not None:
        meta = read_json(root / "version.json", {})
        explicit = str(meta.get("folder_name") or "").strip()
        if explicit:
            return explicit
        display = str(meta.get("display_version") or "").strip().lstrip("vV")
        if display:
            return f"TOPTEN_POP_V{display}"
    return f"TOPTEN_POP_V{str(version).strip().lstrip('vV')}"


def protected_tree_has_files(path: Path) -> bool:
    """Return True when an existing target contains real store/user data.

    We refuse to auto-delete such a conflicting target folder.
    """
    for name in PROTECTED:
        p = path / name
        if not p.exists():
            continue
        try:
            if p.is_file():
                return True
            for _ in p.rglob("*"):
                return True
        except Exception:
            return True
    return False


def safe_remove_stale_target(target: Path, log_root: Path) -> bool:
    """Remove a conflicting canonical folder only when it contains no protected data."""
    if not target.exists():
        return True
    try:
        if protected_tree_has_files(target):
            append_log(log_root, f"폴더명 충돌: 대상 폴더에 보호 데이터가 있어 자동 삭제하지 않음: {target}")
            return False
        # Require at least one program marker before removing a directory.
        markers = [target / "RUN.cmd", target / "version.json", target / "app" / "app.py"]
        if not any(p.exists() for p in markers):
            append_log(log_root, f"폴더명 충돌: 대상 폴더가 TOPTEN 설치 폴더인지 확인되지 않아 삭제하지 않음: {target}")
            return False
        shutil.rmtree(target)
        append_log(log_root, f"보호 데이터 없는 중복 구버전 폴더 자동 삭제: {target.name}")
        return True
    except Exception as exc:
        append_log(log_root, f"중복 폴더 자동 삭제 실패: {target}: {exc}")
        return False


def stop_leftover_run_windows(root: Path) -> None:
    """No-op by design.

    V4.2 removes the old PowerShell/CIM process scan because some store PCs
    cannot start powershell.exe. The finalizer already runs from TEMP after
    RUN.cmd exits and rename_root has retry logic, so PowerShell is not needed.
    """
    return

def rename_state_path(root: Path) -> Path:
    return root / "data" / "folder_rename_state.json"


def set_rename_state(root: Path, *, status: str, version: str, reason: str = "") -> None:
    write_json(rename_state_path(root), {
        "status": status,
        "version": str(version),
        "root": str(root),
        "reason": str(reason),
        "updated_at": datetime.now().isoformat(timespec="seconds"),
    })


def clear_rename_state(root: Path) -> None:
    try:
        rename_state_path(root).unlink(missing_ok=True)
    except Exception:
        pass


def rename_root(root: Path, version: str) -> tuple[Path, bool, str]:
    root = root.resolve()
    target = root.parent / desired_name(version, root)
    if root.name.lower() == target.name.lower():
        clear_rename_state(root)
        return root, True, "already-canonical"

    if target.exists() and not safe_remove_stale_target(target, root):
        reason = f"같은 이름의 폴더가 이미 존재하며 보호 데이터 또는 미확인 파일이 있음: {target}"
        set_rename_state(root, status="failed", version=version, reason=reason)
        return root, False, reason

    stop_leftover_run_windows(root)
    time.sleep(1.2)

    last_exc = None
    # Retry for roughly 25 seconds. Windows AV / Explorer / old cmd handles can
    # release the directory a little late after the installer exits.
    for attempt in range(24):
        try:
            root.rename(target)
            append_log(target, f"폴더명 자동 변경 완료: {root.name} -> {target.name}")
            clear_rename_state(target)
            return target, True, "renamed"
        except Exception as exc:
            last_exc = exc
            stop_leftover_run_windows(root)
            time.sleep(0.7 + min(attempt, 8) * 0.18)

    reason = f"Windows가 폴더를 사용 중이라 이름 변경 실패: {last_exc}"
    append_log(root, reason)
    set_rename_state(root, status="failed", version=version, reason=reason)
    return root, False, reason


def replace_pending_run(root: Path) -> None:
    pending = root / "data" / "pending_RUN.cmd"
    if not pending.exists():
        return
    for attempt in range(12):
        try:
            shutil.copy2(pending, root / "RUN.cmd")
            pending.unlink(missing_ok=True)
            append_log(root, "RUN.cmd 새 버전 교체 완료")
            return
        except Exception as exc:
            if attempt == 11:
                append_log(root, f"RUN.cmd 교체 실패: {exc}")
            time.sleep(0.5)


def clear_pending(root: Path) -> None:
    try:
        (root / "data" / "pending_finalize.json").unlink(missing_ok=True)
    except Exception:
        pass
    try:
        (root / "data" / "finalizer_spawned.json").unlink(missing_ok=True)
    except Exception:
        pass


def restart_run(root: Path) -> None:
    run = root / "RUN.cmd"
    if not run.exists():
        return
    try:
        if os.name == "nt":
            subprocess.Popen(
                ["cmd.exe", "/c", "start", "", str(run)],
                cwd=str(root),
                creationflags=getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0),
            )
        else:
            append_log(root, "비-Windows 테스트 환경: RUN.cmd 재실행 생략")
    except Exception as exc:
        append_log(root, f"업데이트 후 자동 재실행 실패: {exc}")


def do_finalize(root: Path, version: str, restart: bool, delay: float, extra_delete=None) -> Path:
    if delay:
        time.sleep(delay)
    root = root.resolve()
    if not root.exists():
        return root

    # CRITICAL ON WINDOWS: never keep this finalizer's current working
    # directory inside the install tree. Otherwise cleanup/rename can fail
    # even after every RUN.cmd window has closed.
    try:
        temp_cwd = Path(os.environ.get("TEMP") or os.environ.get("TMP") or str(root.parent)).resolve()
        temp_cwd.mkdir(parents=True, exist_ok=True)
        os.chdir(temp_cwd)
    except Exception:
        try:
            os.chdir(root.parent)
        except Exception:
            pass

    # Consume the job BEFORE any restart attempt. Even if rename fails, RUN.cmd
    # must never immediately enqueue/spawn the same job forever.
    pending = read_json(root / "data" / "pending_finalize.json", {})
    clear_pending(root)

    replace_pending_run(root)
    migrate_legacy_bonus_storage(root)
    cleanup(root, extra_delete)
    new_root, renamed, reason = rename_root(root, version)
    cleanup(new_root, extra_delete)

    if not renamed:
        append_log(new_root, "폴더명 변경은 보류했지만 프로그램 실행은 정상 진행합니다. 반복 CMD 실행은 차단됩니다.")

    if restart:
        time.sleep(0.8)
        restart_run(new_root)
    return new_root


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("root")
    ap.add_argument("--version")
    ap.add_argument("--manual", action="store_true")
    ap.add_argument("--restart", action="store_true")
    ap.add_argument("--delay", type=float, default=0.0)
    args = ap.parse_args()

    root = Path(args.root)
    pending = read_json(root / "data" / "pending_finalize.json", {})
    version = str(
        args.version
        or pending.get("version")
        or read_json(root / "version.json", {}).get("version")
        or "0.0.0"
    )
    restart = bool(args.restart or pending.get("restart", False))
    delete_paths = pending.get("delete_paths") if isinstance(pending, dict) else []
    new_root = do_finalize(root, version, restart, args.delay, delete_paths)
    if args.manual:
        print(str(new_root))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
