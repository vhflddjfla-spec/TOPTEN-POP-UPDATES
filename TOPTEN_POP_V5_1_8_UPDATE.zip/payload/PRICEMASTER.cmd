﻿@echo off
setlocal EnableExtensions
chcp 65001 >nul
set "ROOT=%~dp0"
cd /d "%ROOT%"

if not exist "%ROOT%data\TOPTEN_가격정책_마스터.xlsx" (
  echo [ERROR] 실사용 가격정책 마스터가 없습니다.
  echo        %ROOT%data\TOPTEN_가격정책_마스터.xlsx
  echo.
  echo 초기본을 새로 생성하지 않습니다. RUN.cmd를 실행하여 실사용 마스터를 준비하세요.
  pause
  exit /b 2
)

set "PYEXE="
if exist "%ROOT%data\python_path.txt" set /p PYEXE=<"%ROOT%data\python_path.txt"
if defined PYEXE if exist "%PYEXE%" goto have_python
set "PYEXE="
where py >nul 2>&1 && set "PYEXE=py -3"
if defined PYEXE goto run_python
where python >nul 2>&1 && set "PYEXE=python"
if defined PYEXE goto run_python

echo [ERROR] Python이 준비되지 않았습니다. RUN.cmd를 먼저 1회 실행하세요.
pause
exit /b 1

:have_python
"%PYEXE%" "%ROOT%publish_price_master.py"
goto after_run

:run_python
%PYEXE% "%ROOT%publish_price_master.py"

:after_run
if errorlevel 1 (
  echo.
  echo [ERROR] 가격정책 중앙배포 파일 생성을 중단했습니다.
  echo 기존/최신 실사용 마스터는 삭제하거나 초기화하지 않았습니다.
  pause
  exit /b 1
)
echo.
echo [OK] 현재 실사용 마스터 기준 GitHub 업로드 파일 생성 완료.
echo      XLSX를 먼저, price_master.json을 마지막에 업로드하세요.
explorer "%ROOT%github_price_master_release"
pause
