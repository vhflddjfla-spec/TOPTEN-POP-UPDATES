# -*- coding: utf-8 -*-
from __future__ import annotations
import hashlib, json, shutil
from datetime import datetime, date
from pathlib import Path
from openpyxl import load_workbook

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'data'/'TOPTEN_가격정책_마스터.xlsx'
INITIAL=ROOT/'TOPTEN_가격정책_마스터_초기본.xlsx'
OUT=ROOT/'github_price_master_release'
REMOTE_NAME='TOPTEN_PRICE_POLICY_MASTER.xlsx'
REMOTE_URL='https://raw.githubusercontent.com/vhflddjfla-spec/TOPTEN-POP-UPDATES/refs/heads/main/'+REMOTE_NAME

def sha256(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest().lower()

def clean_code(v):
    if v is None: return ''
    s=str(v).strip()
    if s.endswith('.0') and s[:-2].isdigit(): s=s[:-2]
    return s

def to_date(v):
    if v in (None,''): return None
    if isinstance(v,datetime): return v.date()
    if isinstance(v,date): return v
    s=str(v).strip()
    for fmt in ('%Y-%m-%d','%Y/%m/%d','%Y.%m.%d'):
        try: return datetime.strptime(s[:10],fmt).date()
        except Exception: pass
    return None

def header_map(ws,row=1):
    return {str(ws.cell(row,c).value or '').strip():c for c in range(1,int(ws.max_column or 0)+1) if str(ws.cell(row,c).value or '').strip()}

def validate_and_guard(path):
    wb=load_workbook(path,data_only=False,read_only=False)
    try:
        candidates=[]
        if '가격정책마스터' in wb.sheetnames: candidates.append(wb['가격정책마스터'])
        candidates += [ws for ws in wb.worksheets if ws not in candidates]
        master=None; h=None; header_row=None
        for ws in candidates:
            for r in range(1,min(int(ws.max_row or 0),25)+1):
                vals=[str(ws.cell(r,c).value or '').strip() for c in range(1,int(ws.max_column or 0)+1)]
                if '품번' in vals and '정상가' in vals and '가격정책' in vals and ('조정가' in vals or '할인가' in vals):
                    master=ws; h=header_map(ws,r); header_row=r; break
            if master is not None: break
        if master is None:
            raise RuntimeError('가격정책 마스터 필수 헤더를 찾지 못했습니다.')
        today=datetime.now().date()
        expired=[]
        for r in range(header_row+1,master.max_row+1):
            code=clean_code(master.cell(r,h.get('품번',2)).value)
            if not code: continue
            policy=str(master.cell(r,h.get('가격정책',8)).value or '').strip()
            end=to_date(master.cell(r,h.get('행사종료일',10)).value) if '행사종료일' in h else None
            if policy=='기간한정' and end and end<=today:
                expired.append(code)
                if len(expired)>=20: break
        due=[]
        if '변경리스트_입력' in wb.sheetnames:
            ws=wb['변경리스트_입력']; ch=header_map(ws,1)
            for r in range(2,ws.max_row+1):
                code=clean_code(ws.cell(r,ch.get('품번',3)).value)
                if not code: continue
                status=str(ws.cell(r,ch.get('처리상태',12)).value or '').strip()
                ad=to_date(ws.cell(r,ch.get('적용일',1)).value)
                if ad and ad<=today and not status.startswith('처리완료'):
                    due.append(code)
                    if len(due)>=20: break
        if due or expired:
            parts=[]
            if due: parts.append(f'오늘/과거 적용일 미반영 {len(due)}건 이상 (예: {", ".join(due[:5])})')
            if expired: parts.append(f'기간종료 미복귀 {len(expired)}건 이상 (예: {", ".join(expired[:5])})')
            raise RuntimeError('미처리 가격정책이 남아 있어 중앙배포를 차단했습니다. V5.1.8 RUN.cmd를 실행해 자동반영 후 다시 PRICEMASTER.cmd를 실행하세요. / '+' / '.join(parts))
        return True
    finally:
        wb.close()

def main():
    try:
        if not SOURCE.exists():
            raise RuntimeError('실사용 마스터가 없습니다: '+str(SOURCE))
        validate_and_guard(SOURCE)
        digest_source=sha256(SOURCE)
        if INITIAL.exists() and sha256(INITIAL)==digest_source:
            raise RuntimeError('실사용 마스터가 내장 초기본과 동일합니다. 초기본을 중앙 최신본으로 재발행하지 않도록 차단했습니다.')
        OUT.mkdir(parents=True,exist_ok=True)
        dest=OUT/REMOTE_NAME
        shutil.copy2(SOURCE,dest)
        digest=sha256(dest)
        master_version='pm-'+digest[:16]
        manifest={
          'schema_version':2,
          'master_version':master_version,
          'file_name':REMOTE_NAME,
          'download_url':REMOTE_URL,
          'sha256':digest,
          'minimum_app_version':'5.1.8',
          'published_at':datetime.now().isoformat(timespec='seconds'),
          'message':'TOPTEN 중앙 가격정책 마스터 '+master_version,
        }
        (OUT/'price_master.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
        (OUT/'README_UPLOAD.txt').write_text(
          'GitHub TOPTEN-POP-UPDATES 저장소 main 루트에 아래 2개 파일을 업로드/덮어쓰기 하세요.\n'
          '1) TOPTEN_PRICE_POLICY_MASTER.xlsx\n2) price_master.json\n\n'
          '반드시 XLSX를 먼저 올리고 price_master.json을 마지막에 올리세요.\n'
          'V5.1.8부터 동일 XLSX는 동일 master_version을 사용하고, 초기본/미처리 마스터 발행을 차단합니다.\n',encoding='utf-8')
        print('[OK] GitHub 업로드용 가격정책 생성 완료')
        print('SOURCE:',SOURCE)
        print('Folder:',OUT)
        print('Version:',master_version)
        print('SHA256:',digest)
        return 0
    except Exception as exc:
        print('[ERROR]',exc)
        return 2
if __name__=='__main__': raise SystemExit(main())
