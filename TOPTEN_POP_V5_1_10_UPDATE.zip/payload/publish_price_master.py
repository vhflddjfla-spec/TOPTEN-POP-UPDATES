# -*- coding: utf-8 -*-
from __future__ import annotations
import copy
import hashlib
import json
import os
import re
import shutil
import sys
import urllib.request
import urllib.error
from datetime import datetime, date
from pathlib import Path

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
LIVE_MASTER = DATA / 'TOPTEN_가격정책_마스터.xlsx'
OUT = ROOT / 'github_price_master_release'
REMOTE_NAME = 'TOPTEN_PRICE_POLICY_MASTER.xlsx'
REMOTE_URL = 'https://raw.githubusercontent.com/vhflddjfla-spec/TOPTEN-POP-UPDATES/refs/heads/main/' + REMOTE_NAME
LOG_DIR = DATA / 'logs'
LOG_FILE = LOG_DIR / 'pricemaster.log'
BACKUP_DIR = ROOT / 'backups' / 'price_master_publish'

MASTER_SHEET = '가격정책마스터'
CHANGE_SHEET = '변경리스트_입력'
PERIOD_EDIT_SHEET = '행사기간_수정'
HISTORY_SHEET = '변경이력'

HISTORY_HEADERS = [
    '처리일시','적용일','작업유형','구분','품번','상품명','이전정책','이전가격','새정책','새가격',
    '행사시작일','행사종료일','기간종료후정책','기간종료후가격','원본내용','원본파일','처리메모'
]


def log(message: str):
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    line = f"[{datetime.now().isoformat(timespec='seconds')}] {message}"
    print(line, flush=True)
    with LOG_FILE.open('a', encoding='utf-8') as f:
        f.write(line + '\n')


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest().lower()


def n(value) -> int:
    try:
        if value in (None, ''):
            return 0
        return int(float(str(value).replace(',', '')))
    except Exception:
        return 0


def clean_code(value) -> str:
    return re.sub(r'[^A-Z0-9_-]', '', str(value or '').strip().upper())


def to_date(value):
    if value in (None, ''):
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if hasattr(value, 'year') and hasattr(value, 'month') and hasattr(value, 'day'):
        try:
            return date(int(value.year), int(value.month), int(value.day))
        except Exception:
            pass
    text = str(value).strip()
    for fmt in ('%Y-%m-%d', '%Y/%m/%d', '%Y.%m.%d', '%m/%d', '%m-%d'):
        try:
            d = datetime.strptime(text[:10], fmt)
            if fmt.startswith('%m'):
                d = d.replace(year=datetime.now().year)
            return d.date()
        except Exception:
            pass
    return None


def normalize_policy(value) -> str:
    raw = str(value or '').strip()
    if not raw:
        return ''
    compact = re.sub(r'\s+', '', raw).replace('期間限定', '기간한정')
    if '기간한정' in compact or '기간한정할인' in compact:
        return '기간한정'
    if '가격인하' in compact or '가격하향' in compact or '가격유지' in compact:
        return '가격인하'
    if '정상가' in compact or '정상가격' in compact:
        return '정상가'
    return ''


def is_auto_policy(value) -> bool:
    raw = re.sub(r'\s+', '', str(value or '').strip())
    return raw in ('', '자동', '자동판정', '자동판단', '자동분류')


def infer_policy(normal_price, sale_price) -> str:
    normal, sale = n(normal_price), n(sale_price)
    if normal <= 0 or sale <= 0:
        return ''
    return '가격인하' if sale < normal else '정상가'


def infer_reduction_transition(existing_policy, existing_price, normal_price, new_price, has_existing=True) -> str:
    existing_policy = normalize_policy(existing_policy)
    old, normal, new = n(existing_price), n(normal_price), n(new_price)
    if not has_existing or existing_policy != '가격인하' or old <= 0:
        return '신규 가격인하'
    if new <= 0:
        return '가격 유지'
    if new < old:
        return '추가 가격인하'
    if new == old:
        return '가격 유지'
    if normal > 0 and new < normal:
        return '가격인하 가격조정'
    return '가격인하'


def money(value) -> str:
    v = n(value)
    return '-' if v <= 0 else f'{v:,}'


def header_map(ws, header_row=1):
    return {
        str(ws.cell(header_row, c).value or '').strip(): c
        for c in range(1, (ws.max_column or 0) + 1)
        if str(ws.cell(header_row, c).value or '').strip()
    }


def find_master_sheet(wb):
    candidates = []
    if MASTER_SHEET in wb.sheetnames:
        candidates.append(wb[MASTER_SHEET])
    candidates.extend(ws for ws in wb.worksheets if ws not in candidates)
    for ws in candidates:
        for r in range(1, min(ws.max_row or 0, 25) + 1):
            vals = [str(ws.cell(r, c).value or '').strip() for c in range(1, (ws.max_column or 0) + 1)]
            if '품번' in vals and '정상가' in vals and '가격정책' in vals and ('조정가' in vals or '할인가' in vals):
                return ws, r, {v: i + 1 for i, v in enumerate(vals) if v}
    raise RuntimeError('가격정책 마스터 헤더(품번/정상가/조정가/가격정책)를 찾지 못했습니다.')


def ensure_master_columns(ws, header_row, h):
    required = [
        '구분','품번','상품명','상품영문','정상가','조정가','프로모션 내용','가격정책','적용일',
        '행사시작일','행사종료일','기간종료후정책','기간종료후가격','원본정책문구','최종동기화일','원본파일'
    ]
    for name in required:
        if name not in h:
            col = (ws.max_column or 0) + 1
            ws.cell(header_row, col).value = name
            h[name] = col
    return h


def ensure_history_sheet(wb):
    if HISTORY_SHEET not in wb.sheetnames:
        ws = wb.create_sheet(HISTORY_SHEET)
        for c, name in enumerate(HISTORY_HEADERS, 1):
            ws.cell(1, c).value = name
    return wb[HISTORY_SHEET]


def history_append(ws, values):
    row = ws.max_row or 1
    check_cols = max(1, min(ws.max_column or len(values), len(values)))
    while row > 1 and not any(ws.cell(row, c).value not in (None, '') for c in range(1, check_cols + 1)):
        row -= 1
    row += 1
    for c, value in enumerate(values, 1):
        ws.cell(row, c).value = value
    return row


def build_code_rows(ws, h, header_row):
    out = {}
    for r in range(header_row + 1, (ws.max_row or 0) + 1):
        code = clean_code(ws.cell(r, h['품번']).value)
        if code:
            out[code] = r
    return out


def copy_previous_style(ws, row, header_row):
    if row - 1 <= header_row:
        return
    for c in range(1, (ws.max_column or 0) + 1):
        src, dst = ws.cell(row - 1, c), ws.cell(row, c)
        if src.has_style:
            dst._style = copy.copy(src._style)
        if src.number_format:
            dst.number_format = src.number_format
        if src.alignment:
            dst.alignment = copy.copy(src.alignment)
        if src.protection:
            dst.protection = copy.copy(src.protection)


def master_baseline(ws, row, h):
    old_policy = normalize_policy(ws.cell(row, h['가격정책']).value)
    old_normal = n(ws.cell(row, h['정상가']).value)
    old_sale = n(ws.cell(row, h['조정가']).value)
    old_base_policy = normalize_policy(ws.cell(row, h['기간종료후정책']).value)
    old_base_price = n(ws.cell(row, h['기간종료후가격']).value)
    if old_policy == '기간한정':
        base_policy = old_base_policy or ('정상가' if old_sale >= old_normal and old_normal > 0 else '가격인하')
        base_price = old_base_price or (old_normal if base_policy == '정상가' else old_sale)
    else:
        base_policy = old_policy or ('정상가' if old_sale >= old_normal and old_normal > 0 else '가격인하')
        base_price = old_normal if base_policy == '정상가' else old_sale
    return old_policy, old_normal, old_sale, base_policy, base_price


def apply_policy_change(ws, row, h, rec):
    old_policy, old_normal, old_sale, base_policy, base_price = master_baseline(ws, row, h)
    old_start = to_date(ws.cell(row, h['행사시작일']).value)
    old_end = to_date(ws.cell(row, h['행사종료일']).value)
    old_return_policy = normalize_policy(ws.cell(row, h['기간종료후정책']).value)
    old_return_price = n(ws.cell(row, h['기간종료후가격']).value)

    incoming_policy = normalize_policy(rec.get('policy'))
    incoming_normal = n(rec.get('normal')) or old_normal
    incoming_sale = n(rec.get('sale'))
    ref = rec.get('apply_date') or datetime.now().date()
    if isinstance(ref, datetime):
        ref = ref.date()
    if not isinstance(ref, date):
        ref = datetime.now().date()

    had_existing = bool(old_policy or old_normal > 0 or old_sale > 0 or old_return_policy or old_return_price > 0)
    decision = incoming_policy or ''
    if incoming_policy == '가격인하':
        decision = infer_reduction_transition(base_policy, base_price, incoming_normal, incoming_sale or base_price, had_existing)

    preserve_period = old_policy == '기간한정' and old_end is not None and ref <= old_end and incoming_policy in ('가격인하', '정상가')

    if rec.get('season'):
        ws.cell(row, h['구분']).value = rec['season']
    if rec.get('title_ko'):
        ws.cell(row, h['상품명']).value = rec['title_ko']
    if rec.get('title_en'):
        ws.cell(row, h['상품영문']).value = rec['title_en']
    if rec.get('normal_raw') not in (None, '') or rec.get('normal'):
        ws.cell(row, h['정상가']).value = rec.get('normal_raw') if rec.get('normal_raw') not in (None, '') else incoming_normal
    if rec.get('promo') not in (None, ''):
        ws.cell(row, h['프로모션 내용']).value = rec.get('promo')

    raw_label = str(rec.get('raw_policy') or '').strip()
    typed_mismatch = incoming_policy == '가격인하' and raw_label and raw_label not in ('가격인하', '자동판정') and decision not in raw_label
    typed_note = f" · 입력 '{raw_label}' → 마스터 기준 재판정" if typed_mismatch else ''

    if incoming_policy == '기간한정':
        if old_policy == '기간한정':
            return_policy = old_return_policy or base_policy
            return_price = old_return_price or base_price
        else:
            return_policy = base_policy
            return_price = base_price
        if not return_policy:
            candidate = incoming_sale or incoming_normal
            return_policy = '정상가' if incoming_normal > 0 and candidate >= incoming_normal else '가격인하'
            return_price = incoming_normal if return_policy == '정상가' else candidate
        ws.cell(row, h['가격정책']).value = '기간한정'
        if incoming_sale > 0:
            ws.cell(row, h['조정가']).value = rec.get('sale_raw') if rec.get('sale_raw') not in (None, '') else incoming_sale
        if rec.get('event_start') is not None:
            ws.cell(row, h['행사시작일']).value = rec['event_start']
        if rec.get('event_end') is not None:
            ws.cell(row, h['행사종료일']).value = rec['event_end']
        ws.cell(row, h['기간종료후정책']).value = return_policy
        ws.cell(row, h['기간종료후가격']).value = return_price
        decision = '기간한정'
        note = f'기간한정 적용 · 종료후 {return_policy} {money(return_price)}'
    elif preserve_period:
        if incoming_policy == '정상가':
            new_base_price = incoming_normal
            decision = '정상가'
        else:
            new_base_price = incoming_sale or base_price or old_sale
        ws.cell(row, h['기간종료후정책']).value = incoming_policy
        ws.cell(row, h['기간종료후가격']).value = new_base_price
        if incoming_policy == '가격인하':
            note = f'자동판정: {decision}{typed_note} · 기간한정 유지 · 종료후 기준 {money(base_price)} → {money(new_base_price)}'
        else:
            note = f'기간한정 유지 · 종료후 정상가 {money(new_base_price)}로 갱신'
    else:
        ws.cell(row, h['가격정책']).value = incoming_policy
        if incoming_policy == '정상가':
            ws.cell(row, h['조정가']).value = incoming_normal
            decision = '정상가'
            note = f'정상가 기준정책 반영 · {money(incoming_normal)}'
        elif incoming_policy == '가격인하':
            new_sale = incoming_sale or base_price or old_sale
            if new_sale > 0:
                ws.cell(row, h['조정가']).value = rec.get('sale_raw') if rec.get('sale_raw') not in (None, '') else new_sale
            if decision == '가격 유지':
                note = f'자동판정: 가격 유지{typed_note} · {money(new_sale)} 유지'
            else:
                before_price = base_price if base_price > 0 else (old_sale if old_sale > 0 else incoming_normal)
                note = f'자동판정: {decision}{typed_note} · {money(before_price)} → {money(new_sale)}'
        else:
            raise RuntimeError(f'지원하지 않는 가격정책: {incoming_policy or rec.get("raw_policy")}')
        ws.cell(row, h['행사시작일']).value = None
        ws.cell(row, h['행사종료일']).value = None
        ws.cell(row, h['기간종료후정책']).value = None
        ws.cell(row, h['기간종료후가격']).value = None

    if rec.get('apply_date') is not None:
        ws.cell(row, h['적용일']).value = rec.get('apply_date')
    ws.cell(row, h['원본정책문구']).value = rec.get('raw_policy') or decision or incoming_policy
    ws.cell(row, h['최종동기화일']).value = datetime.now()
    ws.cell(row, h['원본파일']).value = rec.get('source_name') or 'PRICEMASTER.cmd'
    return {
        'old_policy': old_policy,
        'old_price': old_sale,
        'new_policy': normalize_policy(ws.cell(row, h['가격정책']).value),
        'new_price': n(ws.cell(row, h['조정가']).value),
        'event_start': to_date(ws.cell(row, h['행사시작일']).value),
        'event_end': to_date(ws.cell(row, h['행사종료일']).value),
        'return_policy': normalize_policy(ws.cell(row, h['기간종료후정책']).value),
        'return_price': n(ws.cell(row, h['기간종료후가격']).value),
        'decision': decision,
        'note': note,
    }


def settle_workbook(path: Path):
    """Apply only rows due today/past and period expirations due today/past.

    Future 예약대기 rows are preserved. The live workbook is replaced atomically only
    after a complete save/validation succeeds.
    """
    today = datetime.now().date()
    tmp = DATA / 'pricemaster_publish_settle.tmp.xlsx'
    shutil.copy2(path, tmp)
    wb = load_workbook(tmp)
    try:
        ws, header_row, h = find_master_sheet(wb)
        h = ensure_master_columns(ws, header_row, h)
        hist = ensure_history_sheet(wb)
        code_rows = build_code_rows(ws, h, header_row)
        now = datetime.now()
        expired = 0
        processed = 0
        duplicates = 0
        added = 0
        errors = 0
        scheduled = 0

        # 1) 기간한정 종료복귀를 먼저 처리한다. 행사종료일 당일 = 다음날 가격표 작업일.
        for r in range(header_row + 1, (ws.max_row or 0) + 1):
            if normalize_policy(ws.cell(r, h['가격정책']).value) != '기간한정':
                continue
            end = to_date(ws.cell(r, h['행사종료일']).value)
            if end is None or end > today:
                continue
            code = clean_code(ws.cell(r, h['품번']).value)
            old_price = n(ws.cell(r, h['조정가']).value)
            old_start = to_date(ws.cell(r, h['행사시작일']).value)
            return_policy = normalize_policy(ws.cell(r, h['기간종료후정책']).value)
            return_price = n(ws.cell(r, h['기간종료후가격']).value)
            normal = n(ws.cell(r, h['정상가']).value)
            if return_policy not in ('정상가', '가격인하'):
                return_policy = '정상가' if normal > 0 and (return_price <= 0 or return_price >= normal) else '가격인하'
            new_price = (normal if normal > 0 else (return_price or old_price)) if return_policy == '정상가' else (return_price or old_price)
            ws.cell(r, h['가격정책']).value = return_policy
            if new_price > 0:
                ws.cell(r, h['조정가']).value = new_price
            ws.cell(r, h['적용일']).value = today
            ws.cell(r, h['행사시작일']).value = None
            ws.cell(r, h['행사종료일']).value = None
            ws.cell(r, h['기간종료후정책']).value = None
            ws.cell(r, h['기간종료후가격']).value = None
            ws.cell(r, h['원본정책문구']).value = f'기간한정 종료복귀 → {return_policy}'
            ws.cell(r, h['최종동기화일']).value = now
            ws.cell(r, h['원본파일']).value = 'PRICEMASTER.cmd 중앙배포 전 자동복귀'
            note = f'행사종료 {end.isoformat()} · 가격표 작업일 {today.isoformat()}부터 {return_policy} {money(new_price)} 복귀'
            history_append(hist, [
                now, today, '기간한정 종료복귀', ws.cell(r, h['구분']).value, code, ws.cell(r, h['상품명']).value,
                '기간한정', old_price, return_policy, new_price, old_start, end, return_policy, new_price,
                '기간한정 자동종료', 'PRICEMASTER.cmd', note
            ])
            expired += 1

        # 2) 변경리스트의 오늘/과거 적용일 행만 처리한다. 미래행은 예약대기 유지.
        if CHANGE_SHEET in wb.sheetnames:
            cws = wb[CHANGE_SHEET]
            ch = header_map(cws, 1)
            seen = {}
            for r in range(2, (cws.max_row or 0) + 1):
                vals = [cws.cell(r, c).value for c in range(1, min(cws.max_column or 0, 14) + 1)]
                if not any(v not in (None, '') for v in vals):
                    continue
                code = clean_code(cws.cell(r, ch.get('품번', 3)).value)
                if not code:
                    continue
                status = str(cws.cell(r, ch.get('처리상태', 12)).value or '').strip()
                if status.startswith('처리완료'):
                    continue
                apply_date = to_date(cws.cell(r, ch.get('적용일', 1)).value)
                if apply_date and apply_date > today:
                    cws.cell(r, ch.get('처리상태', 12)).value = '예약대기'
                    cws.cell(r, ch.get('처리일', 13)).value = None
                    cws.cell(r, ch.get('처리메모', 14)).value = f'{apply_date.isoformat()} 00:00부터 자동판정/반영 예정'
                    scheduled += 1
                    continue

                row = code_rows.get(code)
                existing_normal = n(ws.cell(row, h['정상가']).value) if row else 0
                normal_raw = cws.cell(r, ch.get('정상가', 6)).value
                sale_raw = cws.cell(r, ch.get('조정가', 7)).value
                effective_normal = n(normal_raw) or existing_normal
                input_sale = n(sale_raw)
                raw = str(cws.cell(r, ch.get('정책/변경내용', 9)).value or '').strip()
                event_start = to_date(cws.cell(r, ch.get('행사시작일', 10)).value)
                event_end = to_date(cws.cell(r, ch.get('행사종료일', 11)).value)
                policy = normalize_policy(raw)
                if is_auto_policy(raw):
                    if event_start and event_end:
                        policy = '기간한정'; raw = '자동판정(행사기간)'
                    elif event_start or event_end:
                        cws.cell(r, ch.get('처리상태', 12)).value = '오류'
                        cws.cell(r, ch.get('처리메모', 14)).value = '기간한정은 행사시작일/종료일을 모두 입력해 주세요.'
                        errors += 1; continue
                    else:
                        policy = infer_policy(effective_normal, input_sale)
                        raw = '자동판정'
                if not policy:
                    cws.cell(r, ch.get('처리상태', 12)).value = '오류'
                    cws.cell(r, ch.get('처리메모', 14)).value = '정책/변경내용 확인 필요'
                    errors += 1; continue
                if policy == '기간한정' and (not event_start or not event_end):
                    cws.cell(r, ch.get('처리상태', 12)).value = '오류'
                    cws.cell(r, ch.get('처리메모', 14)).value = '기간한정은 시작일/종료일 필수'
                    errors += 1; continue
                if event_start and event_end and event_start > event_end:
                    cws.cell(r, ch.get('처리상태', 12)).value = '오류'
                    cws.cell(r, ch.get('처리메모', 14)).value = '행사 시작일이 종료일보다 늦음'
                    errors += 1; continue

                promo = str(cws.cell(r, ch.get('프로모션 내용', 8)).value or '').strip()
                key = (code, apply_date, policy, effective_normal, input_sale, event_start, event_end, promo)
                if key in seen:
                    cws.cell(r, ch.get('처리상태', 12)).value = '처리완료(중복)'
                    cws.cell(r, ch.get('처리일', 13)).value = now
                    cws.cell(r, ch.get('처리메모', 14)).value = f'동일 입력 중복 · {seen[key]}행 적용값 사용'
                    duplicates += 1; continue
                seen[key] = r

                if row is None:
                    row = (ws.max_row or header_row) + 1
                    copy_previous_style(ws, row, header_row)
                    ws.cell(row, h['품번']).value = code
                    code_rows[code] = row
                    added += 1

                rec = {
                    'season': str(cws.cell(r, ch.get('구분', 2)).value or '').strip(),
                    'code': code,
                    'title_ko': str(cws.cell(r, ch.get('상품명', 4)).value or '').strip(),
                    'title_en': str(cws.cell(r, ch.get('상품영문', 5)).value or '').strip(),
                    'normal_raw': normal_raw,
                    'sale_raw': sale_raw,
                    'normal': effective_normal,
                    'sale': input_sale,
                    'promo': promo,
                    'policy': policy,
                    'raw_policy': raw,
                    'event_start': event_start,
                    'event_end': event_end,
                    'apply_date': apply_date,
                    'source_name': 'PRICEMASTER.cmd 중앙배포 전 자동반영',
                }
                result = apply_policy_change(ws, row, h, rec)
                history_append(hist, [
                    now, apply_date, result.get('decision') or raw or policy, ws.cell(row, h['구분']).value, code, ws.cell(row, h['상품명']).value,
                    result['old_policy'], result['old_price'], result['new_policy'], result['new_price'],
                    result['event_start'], result['event_end'], result['return_policy'], result['return_price'],
                    raw, 'PRICEMASTER.cmd', result['note']
                ])
                cws.cell(r, ch.get('처리상태', 12)).value = '처리완료'
                cws.cell(r, ch.get('처리일', 13)).value = now
                cws.cell(r, ch.get('처리메모', 14)).value = result['note']
                processed += 1

        # 3) 행사기간_수정의 미처리행은 즉시 반영한다.
        if PERIOD_EDIT_SHEET in wb.sheetnames:
            pws = wb[PERIOD_EDIT_SHEET]
            ph = header_map(pws, 1)
            seen_period = {}
            for r in range(2, (pws.max_row or 0) + 1):
                vals = [pws.cell(r, c).value for c in range(1, min(pws.max_column or 0, 7) + 1)]
                if not any(v not in (None, '') for v in vals):
                    continue
                status = str(pws.cell(r, ph.get('처리상태', 5)).value or '').strip()
                if status.startswith('처리완료'):
                    continue
                code = clean_code(pws.cell(r, ph.get('품번', 1)).value)
                mr = code_rows.get(code)
                if not code or mr is None:
                    pws.cell(r, ph.get('처리상태', 5)).value = '오류'
                    pws.cell(r, ph.get('처리메모', 7)).value = '마스터에서 품번을 찾지 못함'
                    errors += 1; continue
                if normalize_policy(ws.cell(mr, h['가격정책']).value) != '기간한정':
                    pws.cell(r, ph.get('처리상태', 5)).value = '오류'
                    pws.cell(r, ph.get('처리메모', 7)).value = '현재 기간한정 품번이 아님'
                    errors += 1; continue
                old_s, old_e = to_date(ws.cell(mr, h['행사시작일']).value), to_date(ws.cell(mr, h['행사종료일']).value)
                new_s = to_date(pws.cell(r, ph.get('새 행사시작일', 2)).value) or old_s
                new_e = to_date(pws.cell(r, ph.get('새 행사종료일', 3)).value) or old_e
                if not new_s or not new_e or new_s > new_e:
                    pws.cell(r, ph.get('처리상태', 5)).value = '오류'
                    pws.cell(r, ph.get('처리메모', 7)).value = '행사기간 확인 필요'
                    errors += 1; continue
                reason = str(pws.cell(r, ph.get('변경사유', 4)).value or '').strip()
                key = (code, new_s, new_e, reason)
                if key in seen_period:
                    pws.cell(r, ph.get('처리상태', 5)).value = '처리완료(중복)'
                    pws.cell(r, ph.get('처리일', 6)).value = now
                    pws.cell(r, ph.get('처리메모', 7)).value = f'동일 기간수정 중복 · {seen_period[key]}행 적용값 사용'
                    duplicates += 1; continue
                seen_period[key] = r
                ws.cell(mr, h['행사시작일']).value = new_s
                ws.cell(mr, h['행사종료일']).value = new_e
                ws.cell(mr, h['최종동기화일']).value = now
                ws.cell(mr, h['원본파일']).value = 'PRICEMASTER.cmd 중앙배포 전 기간수정'
                note = f'행사기간 {old_s or "-"}~{old_e or "-"} → {new_s}~{new_e}'
                history_append(hist, [
                    now, None, '행사기간 수정', ws.cell(mr, h['구분']).value, code, ws.cell(mr, h['상품명']).value,
                    '기간한정', n(ws.cell(mr, h['조정가']).value), '기간한정', n(ws.cell(mr, h['조정가']).value),
                    new_s, new_e, normalize_policy(ws.cell(mr, h['기간종료후정책']).value), n(ws.cell(mr, h['기간종료후가격']).value),
                    reason, 'PRICEMASTER.cmd', note
                ])
                pws.cell(r, ph.get('처리상태', 5)).value = '처리완료'
                pws.cell(r, ph.get('처리일', 6)).value = now
                pws.cell(r, ph.get('처리메모', 7)).value = note
                processed += 1

        try:
            for table in ws.tables.values():
                table.ref = f'A{header_row}:{get_column_letter(ws.max_column)}{ws.max_row}'
                break
        except Exception:
            pass

        wb.save(tmp)
    finally:
        wb.close()

    # Validate the saved temp before replacing the live source.
    test = load_workbook(tmp, read_only=True, data_only=False)
    try:
        tws, tr, th = find_master_sheet(test)
        for req in ('품번','정상가','조정가','가격정책'):
            if req not in th:
                raise RuntimeError('저장 후 필수열 검증 실패: ' + req)
        if (tws.max_row or 0) <= tr:
            raise RuntimeError('저장 후 마스터 데이터가 비어 있습니다.')
    finally:
        test.close()

    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup = BACKUP_DIR / f'TOPTEN_가격정책_마스터_before_publish_{stamp}.xlsx'
    shutil.copy2(path, backup)
    os.replace(tmp, path)
    return {
        'processed': processed,
        'expired': expired,
        'duplicates': duplicates,
        'added': added,
        'errors': errors,
        'scheduled': scheduled,
        'backup': str(backup),
    }


def due_summary(path: Path):
    """Return only today's/past unprocessed rows and due period expirations."""
    today = datetime.now().date()
    wb = load_workbook(path, read_only=True, data_only=False)
    due, expired, scheduled = 0, 0, 0
    try:
        ws, header_row, h = find_master_sheet(wb)
        for row in ws.iter_rows(min_row=header_row + 1, values_only=True):
            idx_policy = h.get('가격정책', 0) - 1
            idx_end = h.get('행사종료일', 0) - 1
            if idx_policy >= 0 and idx_end >= 0 and idx_policy < len(row) and idx_end < len(row):
                if normalize_policy(row[idx_policy]) == '기간한정':
                    end = to_date(row[idx_end])
                    if end is not None and end <= today:
                        expired += 1
        if CHANGE_SHEET in wb.sheetnames:
            cws = wb[CHANGE_SHEET]
            header = next(cws.iter_rows(min_row=1, max_row=1, values_only=True), ())
            ch = {str(v or '').strip(): i for i, v in enumerate(header)}
            for row in cws.iter_rows(min_row=2, values_only=True):
                if not any(v not in (None, '') for v in row[:14]):
                    continue
                status = str(row[ch.get('처리상태', 11)] if ch.get('처리상태', 11) < len(row) else '' or '').strip()
                if status.startswith('처리완료'):
                    continue
                ad = to_date(row[ch.get('적용일', 0)] if ch.get('적용일', 0) < len(row) else None)
                if ad and ad > today:
                    scheduled += 1
                else:
                    due += 1
        if PERIOD_EDIT_SHEET in wb.sheetnames:
            pws = wb[PERIOD_EDIT_SHEET]
            header = next(pws.iter_rows(min_row=1, max_row=1, values_only=True), ())
            ph = {str(v or '').strip(): i for i, v in enumerate(header)}
            for row in pws.iter_rows(min_row=2, values_only=True):
                if not any(v not in (None, '') for v in row[:7]):
                    continue
                status = str(row[ph.get('처리상태', 4)] if ph.get('처리상태', 4) < len(row) else '' or '').strip()
                if not status.startswith('처리완료'):
                    due += 1
        return {'due': due, 'expired': expired, 'scheduled': scheduled}
    finally:
        wb.close()


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def try_running_app_apply():
    """If the app is running, let its own route settle the master first."""
    port = os.environ.get('TOPTEN_POP_PORT', '8080')
    url = f'http://127.0.0.1:{port}/price-master/apply-live'
    req = urllib.request.Request(url, data=b'', method='POST')
    opener = urllib.request.build_opener(NoRedirect)
    try:
        with opener.open(req, timeout=8) as r:
            return 200 <= int(getattr(r, 'status', 200)) < 400
    except urllib.error.HTTPError as exc:
        # Flask route returns 302 after synchronous processing. With redirects blocked,
        # that 302 is success and guarantees the route already finished its workbook work.
        return exc.code in (301, 302, 303, 307, 308)
    except Exception:
        return False


def build_release():
    if not LIVE_MASTER.exists():
        raise RuntimeError('실사용 마스터가 없습니다: ' + str(LIVE_MASTER) + '\n초기본으로 대체 생성하지 않습니다. RUN.cmd를 1회 실행하세요.')

    log('SOURCE=' + str(LIVE_MASTER))
    before_sha = sha256(LIVE_MASTER)
    log('LIVE BEFORE SHA256=' + before_sha)
    before = due_summary(LIVE_MASTER)
    log('BEFORE due={due} expired={expired} future={scheduled}'.format(**before))

    # Running app route first; otherwise standalone processor uses the exact same rules.
    app_applied = False
    if before['due'] or before['expired']:
        app_applied = try_running_app_apply()
        if app_applied:
            log('Running app /price-master/apply-live completed')
        after_route = due_summary(LIVE_MASTER)
        if after_route['due'] or after_route['expired']:
            log('Standalone settle required after route/unavailable app')
            result = settle_workbook(LIVE_MASTER)
            log('SETTLE=' + json.dumps(result, ensure_ascii=False))
        else:
            log('No standalone settle needed')
    else:
        log('No due/expired rows; live master will be published as-is')

    final_summary = due_summary(LIVE_MASTER)
    if final_summary['due'] or final_summary['expired']:
        raise RuntimeError(
            f'자동반영 후에도 미처리 대상이 남아 있습니다. due={final_summary["due"]}, expired={final_summary["expired"]}. '
            f'Excel에서 마스터가 열려 있으면 닫고 다시 실행하세요. 로그: {LOG_FILE}'
        )
    log('AFTER due=0 expired=0 future={}'.format(final_summary['scheduled']))

    # Never source or compare against the bundled initial workbook. Only live data master.
    OUT.mkdir(parents=True, exist_ok=True)
    dest = OUT / REMOTE_NAME
    shutil.copy2(LIVE_MASTER, dest)
    digest = sha256(dest)
    master_version = 'pm-' + digest[:16]
    manifest = {
        'schema_version': 2,
        'master_version': master_version,
        'file_name': REMOTE_NAME,
        'download_url': REMOTE_URL,
        'sha256': digest,
        'minimum_app_version': '5.1.10',
        'published_at': datetime.now().isoformat(timespec='seconds'),
        'message': 'TOPTEN 중앙 가격정책 마스터 ' + master_version,
    }
    (OUT / 'price_master.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    (OUT / 'README_UPLOAD.txt').write_text(
        'GitHub TOPTEN-POP-UPDATES 저장소 main 루트에 아래 2개 파일을 업로드/덮어쓰기 하세요.\n'
        '1) TOPTEN_PRICE_POLICY_MASTER.xlsx\n2) price_master.json\n\n'
        '반드시 XLSX를 먼저 올리고 price_master.json을 마지막에 올리세요.\n'
        'V5.1.10 PRICEMASTER는 data\\TOPTEN_가격정책_마스터.xlsx 실사용본만 사용하며 초기본을 절대 재생성/배포하지 않습니다.\n'
        '실행 시 오늘 도래 변경리스트와 기간한정 종료복귀를 먼저 처리한 뒤 생성합니다.\n',
        encoding='utf-8'
    )
    result = {
        'ok': True,
        'source': str(LIVE_MASTER),
        'source_sha256': sha256(LIVE_MASTER),
        'output': str(dest),
        'sha256': digest,
        'master_version': master_version,
        'future_reservations': final_summary['scheduled'],
        'generated_at': datetime.now().isoformat(timespec='seconds'),
    }
    (OUT / 'publish_result.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    log('OUTPUT=' + str(dest))
    log('MASTER_VERSION=' + master_version)
    log('OUTPUT SHA256=' + digest)
    return result


def main():
    try:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        log('===== PRICEMASTER V5.1.10 START =====')
        result = build_release()
        print('\n[OK] 현재 실사용 가격정책 기준 중앙배포 파일 생성 완료')
        print('SOURCE :', result['source'])
        print('OUTPUT :', result['output'])
        print('VERSION:', result['master_version'])
        print('SHA256 :', result['sha256'])
        print('미래 예약대기:', result['future_reservations'], '행 (정상 보존)')
        print('LOG    :', LOG_FILE)
        return 0
    except PermissionError as exc:
        log('ERROR PermissionError: ' + str(exc))
        print('\n[ERROR] 가격정책 마스터가 Excel에서 열려 있거나 파일 교체가 차단되었습니다.')
        print('Excel에서 TOPTEN_가격정책_마스터.xlsx를 완전히 닫고 다시 실행하세요.')
        print('상세:', exc)
        print('로그:', LOG_FILE)
        return 5
    except Exception as exc:
        log('ERROR ' + type(exc).__name__ + ': ' + str(exc))
        print('\n[ERROR]', exc)
        print('로그:', LOG_FILE)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
