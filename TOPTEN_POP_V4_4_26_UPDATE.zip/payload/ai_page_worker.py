# -*- coding: utf-8 -*-
from __future__ import annotations
import argparse, json, os, sys, time, site, re, urllib.request, threading
from pathlib import Path

_AI_SITE=os.environ.get('TOPTEN_AI_SITE','').strip()
if _AI_SITE: site.addsitedir(_AI_SITE)
_ANSI_RE=re.compile(r'\x1b\[[0-9;]*[A-Za-z]')
_PERCENT_RE=re.compile(r'(\d{1,3}(?:\.\d+)?)%')
EXPECTED_VL_BYTES=1_930_000_000  # approximate PaddleOCR-VL-1.6 repository payload


def _write_progress(path, **data):
    p=Path(path)
    payload={'stage':'model','done':0,'total':0,'message':'PaddleOCR-VL 1.6 모델 준비 중','source':'','download_percent':0.0,
             'downloaded_bytes':0,'total_bytes':EXPECTED_VL_BYTES,'speed_bps':0.0,'eta_seconds':-1,
             'current_index':0,'current_elapsed_seconds':0,'elapsed_seconds':0,'last_page_seconds':0.0,'page_eta_seconds':-1}
    try:
        if p.exists():
            old=json.loads(p.read_text('utf-8'))
            if isinstance(old,dict): payload.update(old)
    except Exception: pass
    payload.update(data)
    tmp=p.with_suffix(p.suffix+'.tmp'); tmp.write_text(json.dumps(payload,ensure_ascii=False),encoding='utf-8'); tmp.replace(p)


def _tree_bytes(root):
    if not root or not Path(root).exists(): return 0
    total=0
    try:
        for p in Path(root).rglob('*'):
            try:
                if p.is_file() and not p.is_symlink(): total+=p.stat().st_size
            except Exception: pass
    except Exception: pass
    return total


def _download_roots():
    home=Path.home()
    return [
        home/'.paddlex'/'official_models'/'PaddleOCR-VL-1.6',
        home/'.cache'/'huggingface'/'hub'/'models--PaddlePaddle--PaddleOCR-VL-1.6',
        home/'.cache'/'huggingface'/'hub'/'models--PaddlePaddle--PaddleOCR-VL-1.6-0.9B',
    ]


def _best_download_bytes():
    vals=[_tree_bytes(p) for p in _download_roots()]
    return max(vals) if vals else 0


class _ByteDownloadMonitor:
    def __init__(self,progress_path,total,source):
        self.progress_path=progress_path; self.total_tasks=total; self.source=source; self.stop_evt=threading.Event(); self.thread=None
        self.base=_best_download_bytes(); self.start=time.monotonic(); self.last_t=self.start; self.last_b=self.base; self.ema=0.0
    def start_monitor(self):
        self.thread=threading.Thread(target=self._run,daemon=True); self.thread.start()
    def stop_monitor(self):
        self.stop_evt.set()
        if self.thread:
            try:self.thread.join(timeout=2)
            except Exception:pass
    def _run(self):
        while not self.stop_evt.wait(1.0):
            now=time.monotonic(); cur=_best_download_bytes(); dt=max(.01,now-self.last_t); delta=max(0,cur-self.last_b); inst=delta/dt
            if inst>0: self.ema=inst if self.ema<=0 else self.ema*.72+inst*.28
            self.last_t=now; self.last_b=cur
            total=max(EXPECTED_VL_BYTES,cur if cur>EXPECTED_VL_BYTES else EXPECTED_VL_BYTES)
            pct=max(0.0,min(100.0,cur*100.0/total)) if total else 0.0
            remain=max(0,total-cur); eta=int(remain/self.ema) if self.ema>16*1024 else -1
            _write_progress(self.progress_path,stage='download',done=0,total=self.total_tasks,source=self.source,download_percent=pct,
                            downloaded_bytes=cur,total_bytes=total,speed_bps=round(self.ema,1),eta_seconds=eta,
                            message=f'AI 모델 다운로드 · {self.source} · {pct:.2f}%')


class _DownloadProgressWriter:
    """Console tee. File-count percentages are kept only as fallback when byte monitoring cannot see cache files."""
    def __init__(self,raw,progress_path,total,source):
        self.raw=raw; self.progress_path=progress_path; self.total=total; self.source=source; self.buf=''; self.last_pct=-1.0; self.last_write=0.0
    def write(self,text):
        try:self.raw.write(text); self.raw.flush()
        except Exception:pass
        clean=_ANSI_RE.sub('',str(text)).replace('\r','\n'); self.buf=(self.buf+clean)[-8192:]
        matches=_PERCENT_RE.findall(self.buf)
        if matches and _best_download_bytes()<5*1024*1024:
            try:pct=max(0.0,min(100.0,float(matches[-1])))
            except Exception:pct=0.0
            now=time.monotonic()
            if pct>=100 or self.last_pct<0 or pct-self.last_pct>=1 or now-self.last_write>=2:
                self.last_pct=pct; self.last_write=now
                _write_progress(self.progress_path,stage='download',done=0,total=self.total,source=self.source,download_percent=pct,
                                message=f'AI 모델 다운로드 · {self.source} · 파일 준비 {pct:.0f}%')
        return len(text)
    def flush(self):
        try:return self.raw.flush()
        except Exception:return None
    def __getattr__(self,name):return getattr(self.raw,name)


def _reachable(url,timeout=6):
    try:
        req=urllib.request.Request(url,headers={'User-Agent':'TOPTEN-POP/4.4.26'})
        with urllib.request.urlopen(req,timeout=timeout) as r:r.read(1)
        return True
    except Exception:return False


def _walk_text(obj,key=''):
    out=[]; k=(key or '').lower()
    if isinstance(obj,str):
        ss=' '.join(obj.split())
        if ss and len(ss)<=20000 and not ss.startswith('data:image/'):
            if any(x in k for x in ('text','content','markdown','block','rec','label','title')) or len(ss)<800: out.append(ss)
    elif isinstance(obj,dict):
        for kk,v in obj.items():out.extend(_walk_text(v,str(kk)))
    elif isinstance(obj,(list,tuple)):
        for v in obj:out.extend(_walk_text(v,key))
    return out


def _result_text(res):
    parts=[]
    try:parts.extend(_walk_text(getattr(res,'markdown',None),'markdown'))
    except Exception:pass
    try:parts.extend(_walk_text(getattr(res,'json',None),'json'))
    except Exception:pass
    seen=set(); clean=[]
    for ss in parts:
        ss=' '.join(str(ss).split())
        if not ss or ss in seen:continue
        seen.add(ss); clean.append(ss)
    return ' | '.join(clean)[:50000]


def _result_input(res):
    try:
        j=getattr(res,'json',{}) or {}
        if isinstance(j,dict):
            for k in ('input_path','input','path'):
                if j.get(k):return str(j[k])
            di=j.get('data_info') or j.get('dataInfo') or {}
            if isinstance(di,dict):
                for k in ('input_path','input','path'):
                    if di.get(k):return str(di[k])
    except Exception:pass
    return ''


def _local_model_ready():
    p=Path.home()/'.paddlex'/'official_models'/'PaddleOCR-VL-1.6'
    try:return p.is_dir() and _tree_bytes(p)>500*1024*1024
    except Exception:return False


def _create_pipeline(PaddleOCRVL,progress_path,total,source_name,source_env):
    if source_env is None:os.environ.pop('PADDLE_PDX_MODEL_SOURCE',None)
    else:os.environ['PADDLE_PDX_MODEL_SOURCE']=source_env
    if _local_model_ready():os.environ['PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK']='True'
    _write_progress(progress_path,stage='source',done=0,total=total,source=source_name,download_percent=100.0 if _local_model_ready() else 0.0,
                    downloaded_bytes=_best_download_bytes(),total_bytes=EXPECTED_VL_BYTES,speed_bps=0.0,eta_seconds=0 if _local_model_ready() else -1,
                    message=f'AI 모델 캐시 확인 · {source_name}')
    orig_out,orig_err=sys.stdout,sys.stderr
    sys.stdout=_DownloadProgressWriter(orig_out,progress_path,total,source_name); sys.stderr=_DownloadProgressWriter(orig_err,progress_path,total,source_name)
    monitor=_ByteDownloadMonitor(progress_path,total,source_name); monitor.start_monitor()
    try:
        threads=max(2,min(10,int(os.cpu_count() or 4)))
        return PaddleOCRVL(pipeline_version='v1.6',device='cpu',engine='paddle',use_doc_orientation_classify=False,use_doc_unwarping=False,
                           use_layout_detection=False,cpu_threads=threads,enable_mkldnn=True)
    finally:
        monitor.stop_monitor(); sys.stdout,sys.stderr=orig_out,orig_err


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--manifest',required=True); ap.add_argument('--output',required=True); ap.add_argument('--progress',required=True); args=ap.parse_args()
    manifest=json.loads(Path(args.manifest).read_text('utf-8')); tasks=list(manifest.get('tasks') or [])
    Path(args.output).parent.mkdir(parents=True,exist_ok=True); Path(args.progress).parent.mkdir(parents=True,exist_ok=True)
    os.environ.setdefault('FLAGS_allocator_strategy','auto_growth'); os.environ.setdefault('HF_HUB_ETAG_TIMEOUT','8'); os.environ.setdefault('HF_HUB_DOWNLOAD_TIMEOUT','120')
    _write_progress(args.progress,stage='engine_load',done=0,total=len(tasks),source='',message='PaddleOCR-VL 엔진 로딩 중 · 최초 CPU 로딩은 시간이 걸릴 수 있습니다.')
    from paddleocr import PaddleOCRVL
    _write_progress(args.progress,stage='model',done=0,total=len(tasks),source='',message='PaddleOCR-VL 1.6 모델 캐시 확인/준비 중')
    pipeline=None; last_exc=None; selected_source=''
    candidates=[]
    if _local_model_ready(): candidates.append(('로컬 캐시',None))
    elif _reachable('https://huggingface.co',timeout=6): candidates.append(('HuggingFace',None))
    else:_write_progress(args.progress,stage='source',done=0,total=len(tasks),source='HuggingFace',message='HuggingFace 접속 불가 · BOS 공식 미러로 전환')
    if not candidates or candidates[-1][0]!='로컬 캐시':candidates.append(('BOS','BOS'))
    for source_name,source_env in candidates:
        try:
            pipeline=_create_pipeline(PaddleOCRVL,args.progress,len(tasks),source_name,source_env); selected_source=source_name; break
        except Exception as exc:
            last_exc=exc; _write_progress(args.progress,stage='source',done=0,total=len(tasks),source=source_name,message=f'{source_name} 모델 준비 실패 · 다른 공식 소스로 재시도')
            print(f'[AI MODEL SOURCE FAILED] {source_name}: {type(exc).__name__}: {exc}',flush=True)
    if pipeline is None:raise RuntimeError(f'PaddleOCR-VL model init failed: {last_exc}')
    cur=_best_download_bytes(); total_bytes=max(EXPECTED_VL_BYTES,cur)
    _write_progress(args.progress,stage='model_ready',done=0,total=len(tasks),source=selected_source,download_percent=100.0,downloaded_bytes=cur,total_bytes=total_bytes,speed_bps=0.0,eta_seconds=0,message=f'PaddleOCR-VL 1.6 모델 준비 완료 · {selected_source}')
    results=[]; done=0; t0=time.monotonic(); durations=[]; PAGE_TIMEOUT=600
    _write_progress(args.progress,stage='infer_start',done=0,total=len(tasks),source=selected_source,download_percent=100.0,downloaded_bytes=cur,total_bytes=total_bytes,speed_bps=0.0,eta_seconds=0,current_index=1 if tasks else 0,current_elapsed_seconds=0,elapsed_seconds=0,last_page_seconds=0.0,page_eta_seconds=-1,message=f'AI 페이지 분석 시작 · 신규 {len(tasks)}페이지 · 1페이지씩 순차 추론')
    for idx,task in enumerate(tasks,start=1):
        image=str(Path(task['image']).resolve()); page_start=time.monotonic(); stop_evt=threading.Event()
        def heartbeat():
            while not stop_evt.wait(1.0):
                now=time.monotonic(); cur_elapsed=int(now-page_start); all_elapsed=int(now-t0)
                avg=(sum(durations)/len(durations)) if durations else 0.0
                eta=int(avg*(len(tasks)-done)) if avg>0 else -1
                if cur_elapsed>=PAGE_TIMEOUT:
                    _write_progress(args.progress,stage='timeout',done=done,total=len(tasks),source=selected_source,download_percent=100.0,downloaded_bytes=cur,total_bytes=total_bytes,speed_bps=0.0,eta_seconds=0,current_index=idx,current_elapsed_seconds=cur_elapsed,elapsed_seconds=all_elapsed,last_page_seconds=(durations[-1] if durations else 0.0),page_eta_seconds=eta,message=f'페이지 {idx}/{len(tasks)} CPU 추론 10분 초과 · 자동 중단')
                    try: Path(args.output).write_text(json.dumps({'results':results,'timeout_task':task['id']},ensure_ascii=False),encoding='utf-8')
                    except Exception: pass
                    os._exit(124)
                _write_progress(args.progress,stage='infer',done=done,total=len(tasks),source=selected_source,download_percent=100.0,downloaded_bytes=cur,total_bytes=total_bytes,speed_bps=0.0,eta_seconds=0,current_index=idx,current_elapsed_seconds=cur_elapsed,elapsed_seconds=all_elapsed,last_page_seconds=(durations[-1] if durations else 0.0),page_eta_seconds=eta,message=f'페이지 {idx}/{len(tasks)} 분석 중 · 경과 {cur_elapsed//60:02d}:{cur_elapsed%60:02d} · CPU 추론 중')
        hb=threading.Thread(target=heartbeat,daemon=True); hb.start()
        page_parts=[]
        try:
            # Windows x64 CPU: never use PaddleX multi-input queues here. Some PCs
            # stayed forever at 0/N before the first yielded result. Sequential single
            # input inference is slower per batch but predictable and resumable.
            output=pipeline.predict_iter(image,use_queues=False,max_new_tokens=192,max_pixels=650000)
            for res in output:
                txt=_result_text(res)
                if txt: page_parts.append(txt)
        finally:
            stop_evt.set(); hb.join(timeout=2)
        text=' | '.join(x for x in page_parts if x)[:50000]
        page_sec=max(.1,time.monotonic()-page_start); durations.append(page_sec); done+=1
        results.append({'id':task['id'],'image':task['image'],'text':text,'seconds':round(page_sec,2)})
        Path(args.output).write_text(json.dumps({'results':results},ensure_ascii=False),encoding='utf-8')
        # Temporary rendered page is disposable once its extracted text is persisted.
        try: Path(task['image']).unlink(missing_ok=True)
        except Exception: pass
        elapsed=max(.1,time.monotonic()-t0); avg=sum(durations)/len(durations); eta=max(0,int(avg*(len(tasks)-done)))
        _write_progress(args.progress,stage='infer',done=done,total=len(tasks),source=selected_source,download_percent=100.0,downloaded_bytes=cur,total_bytes=total_bytes,speed_bps=0.0,eta_seconds=0,current_index=(idx+1 if idx<len(tasks) else 0),current_elapsed_seconds=0,elapsed_seconds=int(elapsed),last_page_seconds=round(page_sec,2),page_eta_seconds=eta,message=f'페이지 {idx}/{len(tasks)} 완료 · {page_sec:.1f}초 · 평균 {avg:.1f}초 · 남은 예상 {eta//60}분 {eta%60}초')
    Path(args.output).write_text(json.dumps({'results':results},ensure_ascii=False,indent=2),encoding='utf-8')
    _write_progress(args.progress,stage='done',done=done,total=len(tasks),source=selected_source,download_percent=100.0,downloaded_bytes=cur,total_bytes=total_bytes,speed_bps=0.0,eta_seconds=0,current_index=0,current_elapsed_seconds=0,elapsed_seconds=int(time.monotonic()-t0),last_page_seconds=(durations[-1] if durations else 0.0),page_eta_seconds=0,message='AI 페이지 분석 완료')

if __name__=='__main__': main()
