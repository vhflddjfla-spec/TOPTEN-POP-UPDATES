# -*- coding: utf-8 -*-
from __future__ import annotations
import hashlib
import copy
import os, re, sys, time, socket, threading, webbrowser, subprocess, shutil, json, difflib, itertools, urllib.request, urllib.error, urllib.parse, tempfile
from contextlib import contextmanager
from pathlib import Path
from datetime import datetime
from typing import Any
from collections import OrderedDict

from flask import Flask, request, redirect, send_from_directory, render_template_string, jsonify
from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font, Alignment
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.utils import get_column_letter
from PIL import Image, ImageDraw, ImageFont, ImageOps
import fitz
import numpy as np
import cv2
from rapidfuzz import fuzz, process

_PYTESSERACT_IMPORT_ERROR = ''
try:
    import pytesseract
except Exception as exc:
    pytesseract = None
    _PYTESSERACT_IMPORT_ERROR = f'{type(exc).__name__}: {exc}'

ROOT = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parents[1]))
DATA_DIR = ROOT / 'data'
TEMPLATE_DIR = ROOT / 'templates'
PRODUCT_DIR = ROOT / 'product_images'
OUTPUT_DIR = ROOT / 'output'
CACHE_DIR = ROOT / 'cache'
LEGACY_BONUS_DIR = ROOT / 'bonus_pdfs'  # legacy migration fallback only; new PDFs use webhard_sync directly.
# V4.4.38 keeps OCR and AI mappings independently so the main screen can switch
# which engine's result is actually used for POP generation without destroying either set.
LEGACY_BONUS_MAP_FILE = DATA_DIR / 'bonus_page_matches.json'
BONUS_OCR_MAP_FILE = DATA_DIR / 'bonus_page_matches_ocr.json'
BONUS_AI_MAP_FILE = DATA_DIR / 'bonus_page_matches_ai.json'
BONUS_MODE_FILE = DATA_DIR / 'bonus_match_mode.json'
WEBHARD_SYNC_DIR = ROOT / 'webhard_sync'
SYNC_STATE_FILE = DATA_DIR / 'webhard_sync_state.json'
QUEUE_FILE = DATA_DIR / 'generation_queue.json'
OCR_CACHE_FILE = DATA_DIR / 'ocr_page_cache.json'
OCR_LEARN_FILE = DATA_DIR / 'ocr_manual_learning.json'
VISUAL_CHOICE_FILE = DATA_DIR / 'carryover_visual_choices.json'
BONUS_FALLBACK_FILE = DATA_DIR / 'bonus_fallback_choices.json'
LEGACY_BONUS_OVERRIDE_FILE = DATA_DIR / 'bonus_manual_overrides.json'
BONUS_OCR_OVERRIDE_FILE = DATA_DIR / 'bonus_manual_overrides_ocr.json'
BONUS_AI_OVERRIDE_FILE = DATA_DIR / 'bonus_manual_overrides_ai.json'
AI_PAGE_CACHE_FILE = DATA_DIR / 'ai_page_cache.json'
LEGACY_AI_PAGE_CACHE_FILES = [DATA_DIR / f'ai_page_cache_v{v}.json' for v in ('4418','4417','4416','4415')]
AI_RUNTIME_DIR = ROOT / 'runtime_ai'
AI_SITE_DIR = AI_RUNTIME_DIR / 'site-packages'
LOG_DIR = DATA_DIR / 'logs'
AI_LOG_FILE = LOG_DIR / 'ai_engine.log'
AI_RUNTIME_MARKER = DATA_DIR / 'ai_runtime.json'
AI_SINGLE_RESULT_FILE = DATA_DIR / 'ai_single_test_result.json'
AI_REVIEW_FILE = DATA_DIR / 'ai_match_review.json'
AI_NEW_ONLY_STATE_FILE = DATA_DIR / 'ai_new_only_state.json'
AI_WORKER = ROOT / 'ai_page_worker.py'
AI_FAST_WORKER = ROOT / 'ai_fast_ocr_worker.py'
ADULT_SMALL_TEMPLATE = TEMPLATE_DIR / 'TT_ADULT_SMALL.pdf'
SOCKS_PROMO_TEMPLATE = TEMPLATE_DIR / 'TT_SOCKS_4_FOR_10000.pdf'
CLEARANCE_TEMPLATE = TEMPLATE_DIR / 'TT_CLEARANCE.pdf'
PRICE_REDUCTION_MAIN = TEMPLATE_DIR / 'PRICE_REDUCTION_MAIN.png'
PID_FILE = DATA_DIR / 'server.pid'
CURRENT_XLSX = DATA_DIR / 'current_promotion.xlsx'
LAST_NAME = DATA_DIR / 'last_filename.txt'
# V4.4.60 price-policy master: the initial 8/28 full list is installed once,
# then all later HQ change lists are merged into the protected data copy.
PRICE_MASTER_TEMPLATE = ROOT / 'TOPTEN_가격정책_마스터_초기본.xlsx'
PRICE_MASTER_FILE = DATA_DIR / 'TOPTEN_가격정책_마스터.xlsx'
PRICE_MASTER_STATUS_FILE = DATA_DIR / 'price_policy_master_status.json'
PRICE_MASTER_SHEET = '가격정책마스터'
PRICE_CHANGE_INPUT_SHEET = '변경리스트_입력'
PRICE_PERIOD_EDIT_SHEET = '행사기간_수정'
PRICE_HISTORY_SHEET = '변경이력'
_PRICE_MASTER_SCHEMA_READY = False
# R6: live data\TOPTEN_가격정책_마스터.xlsx is the single operational source.
# Price-reduction subtype (신규/추가/유지) is decided from the previous master state + new price.
# R8: saving the workbook does not consume rows. Only the explicit apply button does.
_PRICE_MASTER_AUTO_MTIME = None
_PRICE_MASTER_APPLY_LOCK = threading.Lock()
PRICE_MASTER_R8_MIGRATION_FILE = DATA_DIR / 'price_policy_r8_button_sync_migration.json'
# V5.1 central price-policy distribution. A tiny GitHub manifest is checked only
# at program start / background interval / explicit button, never on page navigation.
CENTRAL_PRICE_MASTER_MANIFEST_URL = os.environ.get(
    'TOPTEN_PRICE_MASTER_MANIFEST_URL',
    'https://raw.githubusercontent.com/vhflddjfla-spec/TOPTEN-POP-UPDATES/refs/heads/main/price_master.json'
)
CENTRAL_PRICE_MASTER_STATUS_FILE = DATA_DIR / 'central_price_master_status.json'
CENTRAL_PRICE_MASTER_BACKUP_DIR = DATA_DIR / 'backups' / 'central_price_master'
CENTRAL_PRICE_MASTER_LOCK = threading.Lock()
CENTRAL_PRICE_MASTER_TIMEOUT_SECONDS = 6
CENTRAL_PRICE_MASTER_CHECK_INTERVAL_SECONDS = 30 * 60
# V5.1.1 store manual. The PDF ships inside the update package, then is copied
# once into protected data\manual on first run. If the local copy is deleted or
# corrupted, the bundled copy is restored automatically. Browser page turns use
# locally cached PNG renders and never rescan the price-policy workbook.
STORE_MANUAL_BUNDLED_FILE = ROOT / 'manual' / 'TOPTEN_POP_V5.1_매장_사용법_가이드.pdf'
STORE_MANUAL_DIR = DATA_DIR / 'manual'
STORE_MANUAL_FILE = STORE_MANUAL_DIR / 'TOPTEN_POP_V5.1_매장_사용법_가이드.pdf'
STORE_MANUAL_PAGE_DIR = STORE_MANUAL_DIR / 'pages'
STORE_MANUAL_STATUS_FILE = STORE_MANUAL_DIR / 'manual_status.json'
STORE_MANUAL_EXPECTED_PAGES = 7
# V4.4.38 central notice-PDF synchronization. Notice PDFs are downloaded only once,
# converted into a compact SKU/category/card index, then the temporary large PDF is removed.
NOTICE_DIR = DATA_DIR / 'notice_sync'
NOTICE_CARD_DIR = NOTICE_DIR / 'cards'
NOTICE_STATE_FILE = NOTICE_DIR / 'state.json'
NOTICE_INDEX_FILE = NOTICE_DIR / 'notice_index.json'
NOTICE_LOG_FILE = LOG_DIR / 'notice_sync.log'
NOTICE_GITHUB_API = os.environ.get(
    'TOPTEN_NOTICE_GITHUB_API',
    'https://api.github.com/repos/vhflddjfla-spec/TOPTEN-POP-UPDATES/contents/notice_pdfs?ref=main'
)
NOTICE_SYNC_INTERVAL_SECONDS = 6 * 60 * 60
NOTICE_MAX_DOWNLOAD_BYTES = 100 * 1024 * 1024
NOTICE_PARSER_VERSION = 3
NOTICE_ZERO_RETRY_SECONDS = 24 * 60 * 60
# V4.4.38 lightweight operational notice. This is separate from program updates and
# from the large notice_pdfs synchronization. Editing GitHub notice.json is enough
# to change what every store sees on the next main-page visit.
SITE_NOTICE_URL = os.environ.get(
    'TOPTEN_SITE_NOTICE_URL',
    'https://raw.githubusercontent.com/vhflddjfla-spec/TOPTEN-POP-UPDATES/refs/heads/main/notice.json'
)
SITE_NOTICE_CACHE_FILE = DATA_DIR / 'site_notice_cache.json'
SITE_NOTICE_FETCH_TTL_SECONDS = 20
RUNTIME_CLEANUP_INTERVAL_SECONDS = 6 * 60 * 60
RUNTIME_LOG_MAX_BYTES = 5 * 1024 * 1024
RUNTIME_LOG_KEEP_BYTES = 1024 * 1024
NOTICE_IMAGE_AUTO_THRESHOLD = 0.84
NOTICE_IMAGE_MARGIN = 0.030
NOTICE_IMAGE_FILENAME_THRESHOLD = 0.72
NOTICE_IMAGE_FILENAME_STRONG = 0.80
NOTICE_CODE_RE = re.compile(r'\b[A-Z]{3}\d[A-Z]{2}\d{4}\b')
NOTICE_DATE_RE = re.compile(r'20\d{2}[-./]\d{2}[-./]\d{2}')
for d in (DATA_DIR,TEMPLATE_DIR,PRODUCT_DIR,OUTPUT_DIR,CACHE_DIR,WEBHARD_SYNC_DIR,AI_RUNTIME_DIR,LOG_DIR,NOTICE_DIR,NOTICE_CARD_DIR): d.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)

_ITEMS_CACHE = None
_CACHE_MTIME = None
_PRODUCT_INDEX = None
_BONUS_MAP_CACHE = {'ocr': None, 'ai': None}
_BONUS_MAP_MTIME = {'ocr': None, 'ai': None}
_RENDER_CACHE = OrderedDict()
_RENDER_CACHE_MAX = 3
_OCR_CACHE = None
_OCR_CACHE_DIRTY = False
_MATCH_SEARCH_CACHE = None
OCR_CACHE_VERSION = 'ocr-v4.4.12-region-index'
MATCH_ALGORITHM_VERSION = 'match-v4.4.58-notice-truth-v3'
OCR_AUTO_THRESHOLD = 0.80
OCR_RECOMMEND_THRESHOLD = 0.52
OCR_MARGIN_THRESHOLD = 0.09
AI_AUTO_THRESHOLD = 0.84
AI_MARGIN_THRESHOLD = 0.06
AI_PAGE_CACHE_VERSION = 'paddleocr-vl-1.6-v4419-timeoutfix1'
TITLE_STRONG_THRESHOLD = 0.78
TITLE_REGION_THRESHOLD = 0.72
TITLE_FILENAME_ONLY_CAP = 0.69

_SITE_NOTICE_LOCK = threading.Lock()
_SITE_NOTICE_RUNTIME = {'at': 0.0, 'data': None}

# Background scan state. Heavy PDF/OCR work never runs inside a browser request.
_SCAN_LOCK = threading.Lock()
_SCAN_STATUS_LOCK = threading.Lock()
_SCAN_CANCEL = threading.Event()
_ACTIVE_AI_PROC_LOCK = threading.Lock()
_ACTIVE_AI_PROC = None
_SCAN_STATUS = {
    'running': False, 'mode': '', 'started_at': '', 'finished_at': '',
    'message': '대기 중', 'error': '', 'processed': 0, 'cancel_requested': False,
    'ai_stage': '', 'ai_download_percent': 0.0, 'ai_download_source': '',
    'ai_downloaded_bytes': 0, 'ai_download_total_bytes': 0,
    'ai_download_speed_bps': 0.0, 'ai_download_eta_seconds': -1,
    'total': 0, 'ai_page_done': 0, 'ai_page_total': 0,
    'ai_page_cached': 0, 'ai_page_new': 0, 'ai_current_page': 0,
    'ai_current_elapsed_seconds': 0, 'ai_elapsed_seconds': 0,
    'ai_page_last_seconds': 0.0, 'ai_page_eta_seconds': -1,
    'ai_fast_done': 0, 'ai_fast_total': 0, 'ai_vl_done': 0, 'ai_vl_total': 0,
    'ai_preview_file': '', 'ai_preview_page': 0, 'ai_preview_code': '',
    'ai_preview_title': '', 'ai_preview_score': 0, 'ai_preview_method': '', 'ai_preview_text': '',
    'ai_preview_page_category':'','ai_preview_item_category':'',
    'ai_preview_seq': '', 'ai_review_count': 0, 'ai_review_status': ''
}


_NOTICE_SYNC_LOCK = threading.Lock()
_NOTICE_STATUS_LOCK = threading.Lock()
_NOTICE_STATUS = {
    'running': False, 'stage': '대기', 'message': '아직 공지 동기화 전', 'error': '',
    'last_sync_at': '', 'remote_count': 0, 'new_files': 0, 'processed_files': 0,
    'indexed_codes': 0, 'applied_matches': 0, 'downloaded_bytes': 0,
    'parse_success_files': 0, 'parse_failed_files': 0, 'retried_files': 0,
    'parser_version': NOTICE_PARSER_VERSION, 'rebuild': False,
}
_NOTICE_INDEX_CACHE = None
_NOTICE_INDEX_MTIME = None
_NOTICE_CARD_HASH_CACHE = None


def _site_notice_date(value):
    text=str(value or '').strip()
    if not text:
        return None
    for fmt in ('%Y-%m-%d','%Y/%m/%d','%Y.%m.%d'):
        try:
            return datetime.strptime(text,fmt).date()
        except Exception:
            pass
    return None


def _normalize_site_notice(raw, source='github'):
    """Normalize public GitHub notice.json without allowing it to inject HTML."""
    if not isinstance(raw,dict):
        return {'active':False,'enabled':False,'source':source}
    level_map={
        'normal':'일반','일반':'일반','info':'일반',
        'important':'중요','중요':'중요','warning':'중요',
        'urgent':'긴급','긴급':'긴급','emergency':'긴급',
    }
    mode_map={
        'once':'1회','1회':'1회',
        'run':'매실행','매실행':'매실행',
        'always':'항상','항상':'항상',
    }
    enabled=bool(raw.get('enabled',False))
    title=str(raw.get('title') or 'TOPTEN POP 공지').strip()[:160]
    message=str(raw.get('message') or '').strip()[:12000]
    notice_id=str(raw.get('id') or '').strip()[:180]
    level=level_map.get(str(raw.get('level') or '').strip().lower(), str(raw.get('level') or '').strip())
    if level not in ('일반','중요','긴급'):
        level='일반'
    show_mode=mode_map.get(str(raw.get('show_mode') or '').strip().lower(), str(raw.get('show_mode') or '').strip())
    if show_mode not in ('1회','매실행','항상'):
        show_mode='항상'
    start=_site_notice_date(raw.get('start_date'))
    end=_site_notice_date(raw.get('end_date'))
    today=datetime.now().date()
    active=enabled and bool(notice_id) and bool(message)
    if start and today < start:
        active=False
    if end and today > end:
        active=False
    return {
        'id':notice_id,
        'enabled':enabled,
        'active':active,
        'title':title,
        'message':message,
        'level':level,
        'start_date':str(raw.get('start_date') or ''),
        'end_date':str(raw.get('end_date') or ''),
        'show_mode':show_mode,
        'allow_hide_today':bool(raw.get('allow_hide_today',True)),
        'source':source,
    }


def _load_site_notice_cache():
    try:
        raw=json.loads(SITE_NOTICE_CACHE_FILE.read_text(encoding='utf-8'))
        payload=raw.get('payload') if isinstance(raw,dict) and 'payload' in raw else raw
        return _normalize_site_notice(payload,'cache')
    except Exception:
        return {'active':False,'enabled':False,'source':'none'}


def get_site_notice(force=False):
    """Fetch the tiny operational notice independently from program updates.

    A short runtime TTL keeps main-page reloads fast. If GitHub is temporarily
    unavailable, the last successfully downloaded notice is used so stores do not
    lose an important announcement just because the network blinked.
    """
    now=time.time()
    with _SITE_NOTICE_LOCK:
        cached=_SITE_NOTICE_RUNTIME.get('data')
        if cached is not None and not force and now-float(_SITE_NOTICE_RUNTIME.get('at') or 0) < SITE_NOTICE_FETCH_TTL_SECONDS:
            return dict(cached)
        try:
            # A harmless query value defeats intermediary raw-content caches after an
            # operator edits notice.json without requiring a program update.
            sep='&' if '?' in SITE_NOTICE_URL else '?'
            url=f"{SITE_NOTICE_URL}{sep}ts={int(now)}"
            req=urllib.request.Request(_notice_ascii_safe_url(url),headers={
                'User-Agent':'TOPTEN-POP/4.4.36',
                'Accept':'application/json,text/plain,*/*',
                'Cache-Control':'no-cache',
                'Pragma':'no-cache',
            })
            with urllib.request.urlopen(req,timeout=8) as r:
                raw_bytes=r.read(256*1024)
            raw=json.loads(raw_bytes.decode('utf-8-sig'))
            data=_normalize_site_notice(raw,'github')
            SITE_NOTICE_CACHE_FILE.write_text(json.dumps({'fetched_at':datetime.now().isoformat(timespec='seconds'),'payload':raw},ensure_ascii=False,indent=2),encoding='utf-8')
        except Exception as exc:
            data=_load_site_notice_cache()
            data['fetch_error']=f'{type(exc).__name__}: {exc}'
        _SITE_NOTICE_RUNTIME['at']=now
        _SITE_NOTICE_RUNTIME['data']=dict(data)
        return data


def _notice_log(message):
    try:
        NOTICE_LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
        with NOTICE_LOG_FILE.open('a', encoding='utf-8') as f:
            f.write(f"[{datetime.now().isoformat(timespec='seconds')}] {message}\n")
    except Exception:
        pass


def _notice_status(**kwargs):
    with _NOTICE_STATUS_LOCK:
        _NOTICE_STATUS.update(kwargs)


def get_notice_status():
    with _NOTICE_STATUS_LOCK:
        out=dict(_NOTICE_STATUS)
    try:
        idx=_load_notice_index()
        out['indexed_codes']=len(idx.get('items') or {})
        out['parser_version']=NOTICE_PARSER_VERSION
        state=_load_notice_state()
        entries=[v for v in (state.get('processed_blobs') or {}).values() if isinstance(v,dict)]
        out['parse_success_files']=sum(1 for v in entries if int(v.get('records') or 0)>0 and bool(v.get('success',True)))
        out['parse_failed_files']=sum(1 for v in entries if not bool(v.get('success', int(v.get('records') or 0)>0)) or int(v.get('records') or 0)<=0)
    except Exception:
        pass
    return out


def _notice_read_json(path, default):
    try:
        raw=json.loads(Path(path).read_text('utf-8'))
        return raw if isinstance(raw,type(default)) else default
    except Exception:
        return default


def _notice_write_json(path, data):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    os.replace(str(tmp),str(path))


def _load_notice_state():
    state=_notice_read_json(NOTICE_STATE_FILE,{})
    if not isinstance(state.get('processed_blobs'),dict): state['processed_blobs']={}
    if not isinstance(state.get('history'),dict): state['history']={}
    state['parser_version']=NOTICE_PARSER_VERSION
    return state


def _notice_entry_needs_parse(entry, force=False, rebuild=False):
    """Return True when a Git blob must be parsed again.

    A SHA alone is not enough: an old parser may have saved zero records and then
    permanently hidden the PDF from future runs. Cache validity is therefore
    SHA + parser version + successful non-zero extraction. Zero-result/failed PDFs
    are retried on manual sync, on parser upgrades, and periodically in the background.
    """
    if rebuild or not isinstance(entry,dict):
        return True
    if int(entry.get('parser_version') or 0) != NOTICE_PARSER_VERSION:
        return True
    records=int(entry.get('records') or 0)
    success=bool(entry.get('success', records>0))
    if success and records>0:
        return False
    if force:
        return True
    stamp=str(entry.get('processed_at') or entry.get('last_attempt_at') or '')
    try:
        dt=datetime.fromisoformat(stamp)
        return (datetime.now()-dt).total_seconds() >= NOTICE_ZERO_RETRY_SECONDS
    except Exception:
        return True


def _load_notice_index(force=False):
    global _NOTICE_INDEX_CACHE,_NOTICE_INDEX_MTIME
    try: mt=NOTICE_INDEX_FILE.stat().st_mtime_ns
    except OSError: mt=-1
    if not force and isinstance(_NOTICE_INDEX_CACHE,dict) and _NOTICE_INDEX_MTIME==mt:
        return _NOTICE_INDEX_CACHE
    raw=_notice_read_json(NOTICE_INDEX_FILE,{})
    if not isinstance(raw.get('items'),dict): raw={'version':3,'parser_version':NOTICE_PARSER_VERSION,'updated_at':'','items':{},'variants':{}}
    if not isinstance(raw.get('variants'),dict): raw['variants']={}
    _NOTICE_INDEX_CACHE=raw; _NOTICE_INDEX_MTIME=mt
    return raw


def _save_notice_index(data):
    global _NOTICE_INDEX_CACHE,_NOTICE_INDEX_MTIME,_NOTICE_CARD_HASH_CACHE
    data['version']=3; data['parser_version']=NOTICE_PARSER_VERSION; data['updated_at']=datetime.now().isoformat(timespec='seconds')
    _notice_write_json(NOTICE_INDEX_FILE,data)
    _NOTICE_INDEX_CACHE=None; _NOTICE_INDEX_MTIME=None; _NOTICE_CARD_HASH_CACHE=None


def _collapse_positions(values,tolerance=0.8):
    vals=sorted(float(v) for v in values)
    groups=[]
    for v in vals:
        if not groups or abs(v-(sum(groups[-1])/len(groups[-1])))>tolerance:
            groups.append([v])
        else:
            groups[-1].append(v)
    return [sum(g)/len(g) for g in groups]


def _notice_table_lines(page):
    xs=[]; ys=[]
    try:
        drawings=page.get_drawings()
    except Exception:
        drawings=[]
    for drawing in drawings:
        for it in drawing.get('items',[]):
            if not it or it[0] != 'l': continue
            a,b=it[1],it[2]
            if abs(a.x-b.x)<0.7 and abs(a.y-b.y)>25: xs.append(float(a.x))
            if abs(a.y-b.y)<0.7 and abs(a.x-b.x)>120: ys.append(float(a.y))
    xs=[x for x in _collapse_positions(xs) if 125<=x<=490]
    ys=_collapse_positions(ys)
    # The official notice uses one label column + five POP columns. Pick the most
    # plausible seven-line sequence instead of relying on exact page coordinates.
    if len(xs)>7:
        best=None
        for start in range(len(xs)-6):
            seq=xs[start:start+7]; gaps=[seq[i+1]-seq[i] for i in range(6)]
            score=abs(gaps[0]-23)+sum(abs(g-63) for g in gaps[1:])
            if best is None or score<best[0]: best=(score,seq)
        xs=best[1] if best else xs[:7]
    return xs,ys


def _notice_row_bounds(lines,y,page_height=842.0):
    below=[v for v in lines if v<=y-0.2]
    above=[v for v in lines if v>=y+0.2]
    return (max(below) if below else 0.0, min(above) if above else float(page_height))


def _notice_text_rect(words,x0,y0,x1,y1):
    rows=[]
    for w in words:
        cx=(float(w[0])+float(w[2]))/2; cy=(float(w[1])+float(w[3]))/2
        if x0<=cx<=x1 and y0<=cy<=y1:
            rows.append((float(w[1]),float(w[0]),str(w[4])))
    rows.sort(key=lambda z:(round(z[0],1),z[1]))
    return ' '.join(z[2] for z in rows)


def _notice_normalize_visual(im):
    # Remove plain outer margins before hashing. Headquarters notice cells and the
    # original Webhard poster can have different amounts of white/neutral padding.
    rgb=im.convert('RGB')
    arr=np.asarray(rgb,dtype=np.int16)
    if arr.ndim!=3 or arr.shape[0]<12 or arr.shape[1]<12: return rgb
    h,w=arr.shape[:2]; k=max(2,min(h,w)//24)
    corners=np.concatenate([arr[:k,:k].reshape(-1,3),arr[:k,-k:].reshape(-1,3),arr[-k:,:k].reshape(-1,3),arr[-k:,-k:].reshape(-1,3)],axis=0)
    bg=np.median(corners,axis=0)
    diff=np.max(np.abs(arr-bg),axis=2)
    mask=diff>20
    ys,xs=np.where(mask)
    if len(xs)>max(20,int(h*w*0.01)):
        x0,x1=int(xs.min()),int(xs.max())+1; y0,y1=int(ys.min()),int(ys.max())+1
        pad=max(2,int(min(h,w)*0.015)); x0=max(0,x0-pad); y0=max(0,y0-pad); x1=min(w,x1+pad); y1=min(h,y1+pad)
        if x1-x0>w*0.30 and y1-y0>h*0.30: rgb=rgb.crop((x0,y0,x1,y1))
    return rgb


def _notice_dhash_image(im):
    # 256-bit difference hash. It is compact and fast enough to compare hundreds of
    # official notice cards against Webhard POP pages without loading the AI model.
    im=_notice_normalize_visual(im)
    gray=ImageOps.autocontrast(im.convert('L')).resize((17,16),Image.Resampling.LANCZOS)
    px=np.asarray(gray,dtype=np.int16)
    bits=(px[:,1:]>px[:,:-1]).reshape(-1)
    val=0
    for bit in bits:
        val=(val<<1)|int(bool(bit))
    return f'{val:064x}'


def _notice_render_card(page,rect):
    clip=fitz.Rect(*rect)
    pix=page.get_pixmap(matrix=fitz.Matrix(2.0,2.0),clip=clip,alpha=False)
    return Image.frombytes('RGB',(pix.width,pix.height),pix.samples)


def _notice_extract_pdf(pdf_path, source_name, source_sha):
    """Parse the official HQ notice table into authoritative SKU -> POP-cell records.

    V3 is tailored to the real HQ format: one label column + five POP columns, with
    category/SKU/production-date rows under each thumbnail. A single POP cell can list
    multiple SKUs separated by slash/comma; those SKUs intentionally share the same
    POP artwork and therefore the same ``cell_id``/card hash.

    Important V3 correction: when the official grid is detected we *do not* scan the
    entire page for fallback SKUs. HQ remarks can mention unrelated style codes, and
    treating remark text as a POP truth row was able to create false notice records.
    Text-only fallback is used only on pages where the official table could not be
    parsed at all.
    """
    records=[]; seen_codes=set(); fallback=[]
    now=datetime.now().isoformat(timespec='seconds')
    gender_scope=''
    with fitz.open(str(pdf_path)) as doc:
        for page_no,page in enumerate(doc):
            words=page.get_text('words') or []
            raw_page_text=page.get_text('text') or ''
            page_text=raw_page_text.upper()

            # The uploaded HQ notice is split into male pages, female pages, and a
            # season/accessory page. Carry the section gender across continuation pages.
            if ('여성' in raw_page_text) or re.search(r"\bW['’]?S\b", page_text):
                gender_scope='여성'
            elif ('남성' in raw_page_text) or re.search(r"\bM['’]?S\b", page_text):
                gender_scope='남성'
            if ('사계절' in raw_page_text) or ('G5/H5' in page_text):
                gender_scope=''

            xs,ys=_notice_table_lines(page)
            page_table_records=0
            if len(xs)>=7 and len(ys)>=3:
                code_labels=[w for w in words if str(w[4]).strip()=='품번']
                cat_labels=[w for w in words if str(w[4]).strip()=='카테고리']
                row_seq=0
                for label in code_labels:
                    ycode=(float(label[1])+float(label[3]))/2
                    cats=[w for w in cat_labels if 0 < ycode-(float(w[1])+float(w[3]))/2 < 28]
                    if not cats: continue
                    cat=max(cats,key=lambda w:(float(w[1])+float(w[3]))/2)
                    ycat=(float(cat[1])+float(cat[3]))/2
                    cat_lo,cat_hi=_notice_row_bounds(ys,ycat,page.rect.height)
                    code_lo,code_hi=_notice_row_bounds(ys,ycode,page.rect.height)
                    older=[v for v in ys if v<cat_lo-0.5]
                    if not older: continue
                    image_top=max(older); image_bottom=cat_lo
                    date_lo=code_hi
                    date_hi=min([v for v in ys if v>date_lo+0.5],default=min(page.rect.height,date_lo+25))
                    row_seq+=1
                    for col in range(5):
                        x0,x1=xs[col+1],xs[col+2]
                        code_text=_notice_text_rect(words,x0,code_lo,x1,code_hi).upper()
                        codes=[]
                        for c in NOTICE_CODE_RE.findall(code_text):
                            if c not in codes: codes.append(c)
                        if not codes: continue
                        category=_notice_text_rect(words,x0,cat_lo,x1,cat_hi).replace('카테고리','').strip()
                        date_text=_notice_text_rect(words,x0,date_lo,x1,date_hi)
                        dates=NOTICE_DATE_RE.findall(date_text)
                        production_date=(dates[0].replace('.','-').replace('/','-') if dates else '')
                        card=_notice_render_card(page,(x0,image_top,x1,image_bottom))
                        dhash=_notice_dhash_image(card)
                        tiny=card.copy(); tiny.thumbnail((420,560),Image.Resampling.LANCZOS)
                        import io
                        bio=io.BytesIO(); tiny.save(bio,'JPEG',quality=84,optimize=True)
                        jpg=bio.getvalue(); digest=hashlib.sha256(jpg).hexdigest()[:28]
                        card_name=f'{digest}.jpg'; card_path=NOTICE_CARD_DIR/card_name
                        if not card_path.exists(): card_path.write_bytes(jpg)
                        cell_id=f'{source_sha}:{page_no+1}:{row_seq}:{col+1}'
                        shared_codes=list(codes)
                        for code in codes:
                            seen_codes.add(code); page_table_records+=1
                            records.append({
                                'code':code,'category':category,'production_date':production_date,
                                'source_name':str(source_name),'source_sha':str(source_sha),
                                'page':page_no+1,'row':row_seq,'column':col+1,'cell_id':cell_id,
                                'shared_codes':shared_codes,'gender_scope':gender_scope,
                                'card_file':card_name,'card_dhash':dhash,
                                'parse_method':'table_v3','parser_version':NOTICE_PARSER_VERSION,
                                'seen_at':now
                            })

            # Only use broad text fallback when this page could not yield any official
            # table cell. This avoids SKUs that appear only inside 비고/annotation text.
            if page_table_records==0:
                page_codes=[]
                for c in NOTICE_CODE_RE.findall(page_text):
                    if c not in page_codes: page_codes.append(c)
                for code in page_codes:
                    if code in seen_codes: continue
                    fallback.append({
                        'code':code,'category':'','production_date':'',
                        'source_name':str(source_name),'source_sha':str(source_sha),
                        'page':page_no+1,'row':0,'column':0,'cell_id':'','shared_codes':[code],
                        'gender_scope':gender_scope,'card_file':'','card_dhash':'',
                        'parse_method':'text_fallback_v3','parser_version':NOTICE_PARSER_VERSION,
                        'seen_at':now
                    })
                    seen_codes.add(code)
    records.extend(fallback)
    return records

def _notice_record_rank(rec):
    date=str(rec.get('production_date') or '')
    date_key=int(re.sub(r'[^0-9]','',date) or 0)
    quality=3 if rec.get('card_dhash') and rec.get('card_file') else (2 if rec.get('category') else 1)
    seen=str(rec.get('seen_at') or '')
    return date_key,quality,seen


def _notice_variant_signature(rec):
    return (
        str(rec.get('production_date') or ''),
        str(rec.get('card_dhash') or ''),
        str(rec.get('category') or ''),
        tuple(rec.get('shared_codes') or []),
        str(rec.get('gender_scope') or ''),
    )


def _notice_active_variants_for_code(code, idx=None):
    code=clean_code(code)
    idx=idx or _load_notice_index()
    variants=(idx.get('variants') or {}).get(code)
    if isinstance(variants,list) and variants:
        return [dict(v) for v in variants if isinstance(v,dict)]
    rec=(idx.get('items') or {}).get(code)
    return [dict(rec)] if isinstance(rec,dict) else []


def _notice_merge_records(records, state):
    """Merge official notice rows while preserving same-date multi-POP variants.

    A SKU can legitimately appear in several POP cells on the same official notice
    (for example a lineup/combined POP plus a single-product POP).  V2 stored only one
    record per SKU, so later cells silently replaced earlier valid artwork.  V3 keeps
    every image-backed variant on the newest production date while retaining one
    canonical ``items[code]`` row for backwards-compatible UI/code paths.
    """
    idx=_load_notice_index(force=True)
    items=dict(idx.get('items') or {})
    variants={k:list(v) for k,v in (idx.get('variants') or {}).items() if isinstance(v,list)}
    changed_codes=set(); history=state.setdefault('history',{})

    by_code={}
    for rec in records:
        code=str(rec.get('code') or '').strip().upper()
        if not NOTICE_CODE_RE.fullmatch(code): continue
        rr=dict(rec); rr['code']=code
        by_code.setdefault(code,[]).append(rr)

        hist=history.setdefault(code,[])
        sig=_notice_variant_signature(rr)
        if not any(_notice_variant_signature(h)==sig for h in hist if isinstance(h,dict)):
            hist.append({k:rr.get(k) for k in (
                'production_date','category','source_name','source_sha','page','row','column','cell_id',
                'shared_codes','gender_scope','card_file','card_dhash','parse_method','seen_at')})
            if len(hist)>60: del hist[:-60]

    for code,new_rows in by_code.items():
        old_rows=_notice_active_variants_for_code(code, {'items':items,'variants':variants})
        pool=old_rows+new_rows
        if not pool: continue
        # Newest dated official artwork is current.  If the newest date contains
        # multiple distinct cells, all of them remain valid choices for that SKU.
        max_date=max((_notice_record_rank(r)[0] for r in pool), default=0)
        dated=[r for r in pool if _notice_record_rank(r)[0]==max_date]
        if max_date==0:
            bestq=max((_notice_record_rank(r)[1] for r in pool), default=0)
            dated=[r for r in pool if _notice_record_rank(r)[1]==bestq]
        uniq=[]; sigs=set()
        for r in sorted(dated,key=lambda x:_notice_record_rank(x),reverse=True):
            sig=_notice_variant_signature(r)
            if sig in sigs: continue
            sigs.add(sig); uniq.append(dict(r))
        # Prefer image-backed canonical row, but do not throw away the other variants.
        canonical=max(uniq,key=lambda r:_notice_record_rank(r))
        before=[_notice_variant_signature(r) for r in old_rows]
        after=[_notice_variant_signature(r) for r in uniq]
        if before!=after or _notice_variant_signature(items.get(code,{}) if isinstance(items.get(code),dict) else {})!=_notice_variant_signature(canonical):
            changed_codes.add(code)
        variants[code]=uniq
        canonical=dict(canonical); canonical['variant_count']=len(uniq)
        items[code]=canonical

    idx['items']=items; idx['variants']=variants; idx['version']=3
    if changed_codes or not NOTICE_INDEX_FILE.exists(): _save_notice_index(idx)
    return len(changed_codes),len(items)


def _notice_ascii_safe_url(url):
    """Return an ASCII-safe HTTP URL without depending on the remote filename.

    GitHub's Contents API can return a raw download_url whose path contains
    Korean, spaces, brackets or other Unicode characters. urllib/http.client
    ultimately requires an ASCII request target on Windows, so a raw Hangul
    filename previously raised UnicodeEncodeError before any bytes were read.
    Encode only URL path/query components while preserving scheme/host and
    already-valid URL delimiters.
    """
    raw = str(url or '').strip()
    if not raw:
        return ''
    parts = urllib.parse.urlsplit(raw)
    # Normalise any existing %XX escapes once, then encode Unicode safely.
    path = urllib.parse.quote(
        urllib.parse.unquote(parts.path),
        safe="/:@-._~!$&'()*+,;="
    )
    query = urllib.parse.quote(
        urllib.parse.unquote(parts.query),
        safe="=&;%:+,/?@-._~"
    )
    fragment = urllib.parse.quote(
        urllib.parse.unquote(parts.fragment),
        safe="=&;%:+,/?@-._~"
    )
    return urllib.parse.urlunsplit((parts.scheme, parts.netloc, path, query, fragment))


def _notice_remote_files():
    req=urllib.request.Request(NOTICE_GITHUB_API,headers={
        'Accept':'application/vnd.github+json','User-Agent':'TOPTEN-POP/4.4.36',
        'X-GitHub-Api-Version':'2026-03-10'
    })
    with urllib.request.urlopen(req,timeout=15) as r:
        raw=json.loads(r.read().decode('utf-8'))
    if isinstance(raw,dict) and isinstance(raw.get('entries'),list): raw=raw['entries']
    if not isinstance(raw,list): return []
    out=[]
    for row in raw:
        if str(row.get('type'))!='file': continue
        name=str(row.get('name') or '')
        if not name.lower().endswith('.pdf'): continue
        sha=str(row.get('sha') or '').strip(); url=str(row.get('download_url') or '').strip(); size=int(row.get('size') or 0)
        if sha and url: out.append({'name':name,'sha':sha,'url':url,'size':size})
    return out


def _notice_download(remote):
    expected=int(remote.get('size') or 0)
    if expected>NOTICE_MAX_DOWNLOAD_BYTES:
        raise ValueError(f"공지 PDF가 100MB를 초과합니다: {remote.get('name')} ({expected/1024/1024:.1f}MB)")
    fd,tmp=tempfile.mkstemp(prefix='topten_notice_',suffix='.pdf',dir=str(CACHE_DIR)); os.close(fd)
    path=Path(tmp); total=0
    try:
        req=urllib.request.Request(_notice_ascii_safe_url(remote['url']),headers={'User-Agent':'TOPTEN-POP/4.4.36'})
        with urllib.request.urlopen(req,timeout=60) as r, path.open('wb') as f:
            while True:
                chunk=r.read(1024*1024)
                if not chunk: break
                total+=len(chunk)
                if total>NOTICE_MAX_DOWNLOAD_BYTES:
                    raise ValueError('공지 PDF 다운로드가 100MB 제한을 초과했습니다.')
                f.write(chunk)
        return path,total
    except Exception:
        try: path.unlink()
        except OSError: pass
        raise


def _notice_hamming_similarity(a,b):
    try:
        x=int(str(a),16)^int(str(b),16)
        return 1.0-(x.bit_count()/256.0)
    except Exception:
        return 0.0


def _notice_hash_groups():
    global _NOTICE_CARD_HASH_CACHE
    idx=_load_notice_index(); sig=str(idx.get('updated_at') or '')
    if isinstance(_NOTICE_CARD_HASH_CACHE,dict) and _NOTICE_CARD_HASH_CACHE.get('sig')==sig:
        return _NOTICE_CARD_HASH_CACHE.get('groups',{})
    groups={}
    codes=set((idx.get('items') or {}).keys()) | set((idx.get('variants') or {}).keys())
    for code in codes:
        for rec in _notice_active_variants_for_code(code,idx):
            h=str(rec.get('card_dhash') or '')
            if len(h)!=64: continue
            row=groups.setdefault(h,[])
            if code not in row: row.append(code)
    _NOTICE_CARD_HASH_CACHE={'sig':sig,'groups':groups}
    return groups


def _notice_variant_for_hash(code, card_hash, idx=None):
    for rec in _notice_active_variants_for_code(code,idx):
        if str(rec.get('card_dhash') or '')==str(card_hash or ''):
            return rec
    rows=_notice_active_variants_for_code(code,idx)
    return rows[0] if rows else {}


def _notice_match_image(im, valid_codes=None):
    groups=_notice_hash_groups()
    if not groups: return [],0.0,0.0,''
    q=_notice_dhash_image(im)
    ranked=[]
    for h,codes in groups.items():
        if valid_codes is not None and not any(c in valid_codes for c in codes): continue
        ranked.append((_notice_hamming_similarity(q,h),h,codes))
    ranked.sort(key=lambda x:-x[0])
    if not ranked: return [],0.0,0.0,''
    best=ranked[0]; second=ranked[1][0] if len(ranked)>1 else 0.0
    if best[0]>=NOTICE_IMAGE_AUTO_THRESHOLD and best[0]-second>=NOTICE_IMAGE_MARGIN:
        return list(best[2]),float(best[0]),float(best[0]-second),str(best[1])
    return [],float(best[0]),float(best[0]-second),str(best[1])


def _notice_match_page_object(page,items):
    valid={clean_code(i.get('code')) for i in items if clean_code(i.get('code'))}
    if not valid or not _notice_hash_groups(): return []
    pix=page.get_pixmap(matrix=fitz.Matrix(0.82,0.82),alpha=False)
    im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples)
    codes,sim,margin,best_hash=_notice_match_image(im,valid)
    if not codes: return []
    mp={clean_code(i.get('code')):i for i in items}
    idx=_load_notice_index()
    out=[]
    for code in codes:
        item=mp.get(code)
        if not item: continue
        rec=_notice_variant_for_hash(code,best_hash,idx)
        # Official section gender + SKU digit rule must never contradict each other.
        scope=str(rec.get('gender_scope') or '')
        ig=_normalize_gender_value(infer_gender_from_code(code,item.get('gender')))
        if scope in ('남성','여성') and ig in ('남성','여성') and scope!=ig:
            continue
        out.append({
            'code':code,'title':str(item.get('title_ko') or ''),'score':round(sim*100),
            'margin':round(margin*100),'grade':'NOTICE-A','needs_manual':False,
            'method':f"본사 공지DB 이미지 정답 · {rec.get('category') or '-'} · 제작 {rec.get('production_date') or '-'}",
            'text':f"NOTICE_TRUTH {code} {rec.get('category') or ''}",
            'suggestions':[],'notice_exact':True,'notice_hash':best_hash,
            'notice_cell_id':str(rec.get('cell_id') or '')
        })
    return out


def _notice_text_relation(text,item):
    code=clean_code(item.get('code')); rows=_notice_active_variants_for_code(code)
    if not rows: return 0.0,False,''
    raw=normalize_product_name(text)
    if not raw: return 0.0,False,''
    best=(0.0,False,'')
    for rec in rows:
        category=normalize_product_name(rec.get('category'))
        if not category: continue
        direct=category in raw
        ratio=fuzz.partial_ratio(category,raw)/100.0 if category and raw else 0.0
        matched=direct or ratio>=0.88
        bonus=0.11 if direct else (0.07 if matched else 0.0)
        if bonus>best[0]: best=(bonus,matched,str(rec.get('category') or ''))
    return best


def _notice_webhard_signature():
    """Small signature used to re-link notice truth when Webhard receives new PDFs."""
    rows=[]
    try:
        for p in sorted(x for x in WEBHARD_SYNC_DIR.rglob('*.pdf') if x.is_file()):
            try:
                st=p.stat(); rows.append(f'{_sync_source_key(p)}|{st.st_size}|{st.st_mtime_ns}')
            except OSError:
                continue
    except Exception:
        return ''
    return hashlib.sha1('\n'.join(rows).encode('utf-8','ignore')).hexdigest()


def _notice_codes_share_official_cell(code_a,code_b,idx=None):
    if clean_code(code_a)==clean_code(code_b): return True
    idx=idx or _load_notice_index()
    a=_notice_active_variants_for_code(code_a,idx); b=_notice_active_variants_for_code(code_b,idx)
    for ra in a:
        ca=str(ra.get('cell_id') or ''); ha=str(ra.get('card_dhash') or '')
        shared={clean_code(x) for x in (ra.get('shared_codes') or [])}
        if clean_code(code_b) in shared and (ca or ha): return True
        for rb in b:
            cb=str(rb.get('cell_id') or ''); hb=str(rb.get('card_dhash') or '')
            if ca and cb and ca==cb: return True
            if len(ha)==64 and ha==hb: return True
    return False


def _notice_page_hash(page):
    pix=page.get_pixmap(matrix=fitz.Matrix(0.82,0.82),alpha=False)
    im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples)
    return _notice_dhash_image(im)


def _notice_candidate_for_code_page(code,item,page_text,page_hash,source_desc,filename_codes,page_no,page_count):
    rows=_notice_active_variants_for_code(code)
    if not rows: return None
    ig=_normalize_gender_value(infer_gender_from_code(code,item.get('gender')))
    pg,pg_reason=_ai_page_gender(page_text)
    sg,sg_reason=_ai_source_gender(source_desc,filename_codes)
    scopes={str(r.get('gender_scope') or '') for r in rows if str(r.get('gender_scope') or '') in ('남성','여성')}
    ng=(next(iter(scopes)) if len(scopes)==1 else '')
    if ig in ('남성','여성'):
        if pg in ('남성','여성') and pg!=ig: return None
        if sg in ('남성','여성') and sg!=ig: return None
        if ng in ('남성','여성') and ng!=ig: return None

    sim=0.0; best_rec={}
    for rec in rows:
        h=str(rec.get('card_dhash') or '')
        if len(h)!=64: continue
        x=_notice_hamming_similarity(page_hash,h)
        if x>sim: sim=x; best_rec=rec

    compact=re.sub(r'[^A-Z0-9]','',str(page_text or '').upper())
    exact=bool(code and code in compact)
    title_score=_ai_title_score(page_text,item)
    raw_norm=normalize_product_name(page_text)
    cat_score=0.0
    for rec in rows:
        cat=normalize_product_name(rec.get('category'))
        if not cat or not raw_norm: continue
        if cat in raw_norm: cat_score=max(cat_score,1.0)
        else: cat_score=max(cat_score,fuzz.partial_ratio(cat,raw_norm)/100.0)
    filename_member=code in {clean_code(x) for x in (filename_codes or [])}
    order_bonus=0.0
    if filename_member and page_count==len(filename_codes) and code in filename_codes:
        try:
            if filename_codes.index(code)==page_no: order_bonus=0.025
        except ValueError:
            pass

    # Composite score.  Official card similarity is dominant; exact page SKU or the
    # actual product title/category can rescue resized/cropped Webhard artwork.
    score=(sim*0.62)+(title_score*0.20)+(cat_score*0.08)+(0.07 if filename_member else 0.0)+order_bonus
    if exact: score=max(score,0.995)
    elif filename_member and sim>=NOTICE_IMAGE_FILENAME_STRONG:
        score=max(score,0.93)
    elif filename_member and sim>=NOTICE_IMAGE_FILENAME_THRESHOLD and (title_score>=0.55 or cat_score>=0.72):
        score=max(score,0.885)
    elif sim>=0.86 and (title_score>=0.48 or cat_score>=0.70):
        score=max(score,0.875)
    elif sim>=0.91:
        score=max(score,0.90)

    accepted = exact or score>=0.865
    if not accepted: return None
    evidence=[]
    if exact: evidence.append('페이지 품번 직접인식')
    if filename_member: evidence.append('파일명 품번')
    if sim: evidence.append(f'공지이미지 {round(sim*100)}%')
    if title_score>=0.55: evidence.append(f'상품명 {round(title_score*100)}%')
    if cat_score>=0.70: evidence.append('공지 카테고리')
    if ng: evidence.append('공지 성별 '+ng)
    if pg: evidence.append(pg_reason)
    return {
        'code':code,'page':page_no,'score':round(score*100,2),'sim':sim,'exact':exact,
        'rec':best_rec or rows[0],'evidence':' · '.join(evidence),'item_gender':ig,
        'page_gender':pg,'source_gender':sg,'source_gender_reason':sg_reason
    }


def _notice_targeted_pdf_matches(pdf_path,items):
    """Use official notice truth + filename roster to map a Webhard PDF precisely.

    Distinct HQ notice cells normally compete one-to-one for pages. Multiple SKUs may
    share a page *only* when the notice itself lists them in the same cell / same POP
    artwork. This is the exact structure used by the uploaded HQ notice.
    """
    by_code={clean_code(i.get('code')):i for i in items if clean_code(i.get('code'))}
    filename_codes=[c for c in extract_filename_codes(Path(pdf_path).name,items) if c in by_code and _notice_active_variants_for_code(c)]
    if not filename_codes: return {}
    source_desc=_source_description(pdf_path,filename_codes); idx=_load_notice_index()
    candidates=[]
    try:
        with fitz.open(str(pdf_path)) as doc:
            page_count=doc.page_count
            for page_no,page in enumerate(doc):
                text=page.get_text('text') or ''
                ph=_notice_page_hash(page)
                for code in filename_codes:
                    cand=_notice_candidate_for_code_page(code,by_code[code],text,ph,source_desc,filename_codes,page_no,page_count)
                    if cand: candidates.append(cand)
    except Exception as exc:
        _notice_log(f'notice targeted compare error {_sync_source_key(pdf_path)}: {exc}')
        return {}

    # Prefer exact/strong evidence globally so one weak SKU cannot steal a page from
    # the SKU whose official thumbnail actually matches it.
    candidates.sort(key=lambda r:(bool(r.get('exact')),float(r.get('score') or 0),float(r.get('sim') or 0)),reverse=True)
    chosen={}; page_codes={}
    for cand in candidates:
        code=cand['code']; page_no=int(cand['page'])
        if code in chosen: continue
        existing=page_codes.get(page_no,[])
        if existing and not all(_notice_codes_share_official_cell(code,x,idx) for x in existing):
            continue
        chosen[code]=cand; page_codes.setdefault(page_no,[]).append(code)
    return chosen

def _notice_apply_to_webhard():
    """Reconcile the official notice truth DB against every current Webhard PDF.

    Priority is manual lock > official notice truth > ordinary AI.  For PDFs whose
    filenames explicitly contain HQ SKUs, V3 first performs notice-aware global page
    assignment.  A page is shared by multiple SKUs only when the official notice puts
    those SKUs in the same POP cell.  Remaining pages use strict visual notice matching.
    """
    mp,items,_,_=items_map()
    if not items or not _notice_hash_groups(): return 0
    ocr=dict(load_bonus_matches(mode='ocr')); ai=dict(load_bonus_matches(mode='ai'))
    om=_load_manual_overrides(mode='ocr'); am=_load_manual_overrides(mode='ai')
    best={}

    for pdf_path in sorted(p for p in WEBHARD_SYNC_DIR.rglob('*.pdf') if p.is_file()):
        source_id=_sync_source_key(pdf_path)

        # 1) Strong path: the Webhard filename explicitly lists official SKUs.  Use
        # official card/category/gender truth to map those codes to pages globally.
        targeted=_notice_targeted_pdf_matches(pdf_path,items)
        for code,cand in targeted.items():
            score=float(cand.get('score') or 0)
            row={
                'code':code,'score':score,'notice_exact':True,
                'method':'본사 공지DB 정답 교차검증 · '+str(cand.get('evidence') or ''),
                'notice_cell_id':str((cand.get('rec') or {}).get('cell_id') or ''),
                'notice_category':str((cand.get('rec') or {}).get('category') or ''),
                'notice_date':str((cand.get('rec') or {}).get('production_date') or ''),
                'notice_sim':round(float(cand.get('sim') or 0)*100,2),
            }
            old=best.get(code)
            if old is None or score>old[0]: best[code]=(score,source_id,int(cand['page']),row)

        # 2) Strong visual fallback for files whose name is generic/abbreviated.
        try:
            with fitz.open(str(pdf_path)) as doc:
                for page_no,page in enumerate(doc):
                    rows=_notice_match_page_object(page,items)
                    for row in rows:
                        code=clean_code(row.get('code')); score=float(row.get('score') or 0)
                        if not code: continue
                        old=best.get(code)
                        if old is None or score>old[0]: best[code]=(score,source_id,page_no,row)
        except Exception as exc:
            _notice_log(f'webhard notice compare error {source_id}: {exc}')

    applied=0; changed=False
    for code,(score,source_id,page_no,row) in best.items():
        # User/manual choice is the only layer allowed to outrank HQ notice truth.
        if code not in om:
            old=ocr.get(code)
            if not (isinstance(old,dict) and str(old.get('source_type'))=='manual'):
                rec={
                    'file':source_id,'source':source_id,'page':page_no,
                    'source_type':'notice_auto','notice_score':round(float(score),2),
                    'notice_method':str(row.get('method') or '본사 공지DB 정답'),
                    'notice_cell_id':str(row.get('notice_cell_id') or ''),
                    'notice_category':str(row.get('notice_category') or ''),
                    'notice_date':str(row.get('notice_date') or ''),
                }
                if old!=rec: ocr[code]=rec; changed=True
        if code not in am:
            old=ai.get(code)
            if not (isinstance(old,dict) and str(old.get('source_type'))=='manual'):
                rec={
                    'file':source_id,'source':source_id,'page':page_no,
                    'source_type':'notice_auto','notice_score':round(float(score),2),
                    'notice_method':str(row.get('method') or '본사 공지DB 정답'),
                    'notice_cell_id':str(row.get('notice_cell_id') or ''),
                    'notice_category':str(row.get('notice_category') or ''),
                    'notice_date':str(row.get('notice_date') or ''),
                }
                if old!=rec:
                    ai[code]=rec; changed=True; applied+=1

    # Once HQ truth finds a real Webhard POP, a previous NEW ARRIVAL/adult-small
    # fallback must no longer hide that official POP.
    fallbacks=_load_bonus_fallback_choices(); fallback_changed=False
    for code in best:
        if code in fallbacks:
            fallbacks.pop(code,None); fallback_changed=True
    if fallback_changed: _save_bonus_fallback_choices(fallbacks)
    if best and changed:
        save_bonus_matches(ocr,mode='ocr'); save_bonus_matches(ai,mode='ai')
        _sync_protected_matches_between_modes(); load_items(force=True)
    return applied


def _notice_sync_once(force=False, local_pdf=None, local_name='', rebuild=False):
    if not _NOTICE_SYNC_LOCK.acquire(blocking=False): return False
    old_index_backup=None
    try:
        # Parser upgrades are rebuilt transactionally once so V2 single-record rows do
        # not linger beside V3 multi-variant/shared-cell truth. If any remote PDF fails,
        # the previous DB is restored exactly as before.
        if local_pdf is None and not rebuild:
            existing=_load_notice_index(force=True)
            if (existing.get('items') or {}) and int(existing.get('parser_version') or 0)<NOTICE_PARSER_VERSION:
                rebuild=True
        _notice_status(running=True,stage='공지 확인',message='공지 PDF 목록 확인 중',error='',new_files=0,
                       processed_files=0,applied_matches=0,downloaded_bytes=0,parse_success_files=0,
                       parse_failed_files=0,retried_files=0,parser_version=NOTICE_PARSER_VERSION,rebuild=bool(rebuild))
        state=_load_notice_state(); changed_total=0; processed=0; downloaded=0; successes=0; failures=0; retried=0
        if local_pdf is not None:
            p=Path(local_pdf); sha='local-'+hashlib.sha256(p.read_bytes()).hexdigest()
            records=_notice_extract_pdf(p,local_name or p.name,sha)
            changed,_=_notice_merge_records(records,state); changed_total+=changed; processed=1
            successes=1 if records else 0; failures=0 if records else 1
            state['processed_blobs'][sha]={
                'name':local_name or p.name,'processed_at':datetime.now().isoformat(timespec='seconds'),
                'records':len(records),'local':True,'success':bool(records),'parser_version':NOTICE_PARSER_VERSION,
                'error':'' if records else '품번 0건 추출'
            }
        else:
            remote=_notice_remote_files(); _notice_status(remote_count=len(remote))
            todo=[]; queued_sha=set()
            for r in remote:
                sha=r['sha']; entry=state['processed_blobs'].get(sha)
                if sha in queued_sha: continue
                if not _notice_entry_needs_parse(entry,force=force,rebuild=rebuild): continue
                if isinstance(entry,dict): retried+=1
                queued_sha.add(sha); todo.append(r)
            _notice_status(new_files=len(todo),retried_files=retried,
                           message=(f'전체 재구축 대상 {len(todo)}개' if rebuild else f'신규/재분석 공지 {len(todo)}개 확인'))

            # Rebuild is transactional: keep the old DB until all downloads/parses finish.
            # If even one file fails, the old DB is restored and the failure is shown.
            if rebuild:
                old_index_backup=json.loads(json.dumps(_load_notice_index(force=True),ensure_ascii=False))
                _save_notice_index({'version':3,'parser_version':NOTICE_PARSER_VERSION,'updated_at':'','items':{},'variants':{}})
                state['history']={}

            for no,row in enumerate(todo,1):
                _notice_status(stage='다운로드/텍스트화',message=f"{no}/{len(todo)} {row['name']}")
                tmp=None; records=[]; err=''
                try:
                    tmp,n=_notice_download(row); downloaded+=n
                    records=_notice_extract_pdf(tmp,row['name'],row['sha'])
                    changed,_=_notice_merge_records(records,state); changed_total+=changed; processed+=1
                    if records: successes+=1
                    else: failures+=1; err='품번 0건 추출'
                except Exception as exc:
                    failures+=1; err=f'{type(exc).__name__}: {exc}'
                    _notice_log(f"parse failed {row.get('name')}: {err}")
                finally:
                    state['processed_blobs'][row['sha']]={
                        'name':row['name'],'size':row.get('size',0),
                        'processed_at':datetime.now().isoformat(timespec='seconds'),
                        'records':len(records),'success':bool(records),'parser_version':NOTICE_PARSER_VERSION,
                        'error':err
                    }
                    if tmp:
                        try: Path(tmp).unlink()
                        except OSError: pass
                    _notice_status(processed_files=processed,parse_success_files=successes,
                                   parse_failed_files=failures,downloaded_bytes=downloaded)

            if rebuild and failures and old_index_backup is not None:
                _save_notice_index(old_index_backup)
                changed_total=0
                _notice_log(f'rebuild rolled back because {failures} PDF(s) failed')

        idx=_load_notice_index(force=True)
        revision_payload={'items':idx.get('items') or {},'variants':idx.get('variants') or {}}
        revision=hashlib.sha1(json.dumps(revision_payload,sort_keys=True,ensure_ascii=False).encode('utf-8')).hexdigest()
        webhard_sig=_notice_webhard_signature()
        applied=0
        # Re-link not only when the notice DB changes, but also whenever Webhard gets
        # a new/replaced PDF. This fixes the old state where a correct notice record
        # existed first and a later Webhard upload never got connected to it.
        if (revision!=state.get('last_applied_revision')) or (webhard_sig!=state.get('last_webhard_signature')):
            _notice_status(stage='번외 적용',message='본사 공지DB ↔ 현재 Webhard 전체 정답 재연결 중')
            applied=_notice_apply_to_webhard()
            state['last_applied_revision']=revision
            state['last_webhard_signature']=webhard_sig
        now=datetime.now().isoformat(timespec='seconds'); state['last_sync_at']=now; state['last_error']=''; state['parser_version']=NOTICE_PARSER_VERSION
        _notice_write_json(NOTICE_STATE_FILE,state)
        if rebuild and failures:
            msg=f'전체 재구축 보류 · 실패 PDF {failures}개 때문에 기존 정답DB 유지 · 성공 {successes}개'
            err=f'분석 실패/0건 PDF {failures}개. 다시 재구축하거나 공지 형식을 확인하세요.'
        else:
            msg=f'공지 동기화 완료 · 신규/수정 품번 {changed_total}개 · 정답DB {len(idx.get("items") or {})}품번 · 직접적용 {applied}개'
            err=('' if failures==0 else f'분석 실패/0건 PDF {failures}개는 다음 동기화에서 재시도됩니다.')
        _notice_status(running=False,stage='완료' if not err else '일부 확인 필요',message=msg,error=err,
                       last_sync_at=now,processed_files=processed,indexed_codes=len(idx.get('items') or {}),
                       applied_matches=applied,downloaded_bytes=downloaded,parse_success_files=successes,
                       parse_failed_files=failures,retried_files=retried,rebuild=False)
        _notice_log(f'sync complete rebuild={rebuild} changed={changed_total} processed={processed} ok={successes} fail={failures} applied={applied} bytes={downloaded}')
        return True
    except urllib.error.HTTPError as exc:
        if old_index_backup is not None: _save_notice_index(old_index_backup)
        msg='GitHub notice_pdfs 폴더를 찾지 못했습니다.' if exc.code==404 else f'GitHub HTTP {exc.code}'
        _notice_status(running=False,stage='오류',message='공지 동기화 실패',error=msg,rebuild=False)
        _notice_log(msg); return False
    except Exception as exc:
        if old_index_backup is not None: _save_notice_index(old_index_backup)
        _notice_status(running=False,stage='오류',message='공지 동기화 실패',error=f'{type(exc).__name__}: {exc}',rebuild=False)
        _notice_log(f'{type(exc).__name__}: {exc}'); return False
    finally:
        _NOTICE_SYNC_LOCK.release()


def start_notice_sync(force=False, rebuild=False):
    if _NOTICE_SYNC_LOCK.locked(): return False
    threading.Thread(target=_notice_sync_once,args=(force,None,'',rebuild),daemon=True,name='notice-sync').start(); return True

def _notice_autosync_loop():
    # Startup check, then a low-frequency check while the store program remains open.
    time.sleep(3)
    while True:
        _notice_sync_once(force=False)
        time.sleep(NOTICE_SYNC_INTERVAL_SECONDS)

class ScanCancelled(Exception):
    pass

def _raise_if_scan_cancelled():
    if _SCAN_CANCEL.is_set():
        raise ScanCancelled('사용자가 매칭 중단을 요청했습니다.')

def request_scan_stop():
    global _ACTIVE_AI_PROC
    _SCAN_CANCEL.set()
    _set_scan_status(cancel_requested=True, message='중단 요청됨 · 현재 처리 중인 작업을 종료하는 중')
    with _ACTIVE_AI_PROC_LOCK:
        proc = _ACTIVE_AI_PROC
        if proc is not None and proc.poll() is None:
            try:
                proc.terminate()
            except Exception:
                pass
    return True

PREVIEW_DPI = 105
PREVIEW_MAX_WIDTH = 900
RENDER_REVISION = '4.4.53-adult-english-socks-template-v1'
POP_LAYOUT_REV = 'v4.4.60-r7-effective-date-titleclean-arrowcenter'

EXTS = ['.pdf','.png','.jpg','.jpeg','.webp']
# Font policy for the TOPTEN adult-small bottom bar.
# Font files are not bundled. The app searches the local fonts folder and Windows Fonts.
FONT_DIR = ROOT / 'fonts'
FONT_KO_NAMES = ['NanumBarunGothic.otf', 'NanumBarunGothic.ttf']
FONT_DIN_REGULAR_NAMES = ['DINPro-Regular.otf', 'DINPro-Regular.ttf']
FONT_DIN_MEDIUM_NAMES = ['DINPro-Medium.otf', 'DINPro-Medium.ttf']
FONT_DIN_BOLD_NAMES = ['DINPro-Bold.otf', 'DINPro-Bold.ttf']
FONT_BOOTSTRAP_STATE_FILE = DATA_DIR / 'font_bootstrap_state.json'


def _font_candidate_roots():
    """Search only local/user-owned locations; no network font download is performed."""
    roots = [
        FONT_DIR,
        ROOT,
        Path('C:/Windows/Fonts'),
        Path.home() / 'AppData/Local/Microsoft/Windows/Fonts',
        Path.home() / 'Downloads',
        Path.home() / 'Desktop',
    ]
    env_root = str(os.environ.get('TOPTEN_FONT_SOURCE') or '').strip()
    if env_root:
        roots.insert(0, Path(env_root))
    # Previous TOPTEN_POP versions are the most useful source during upgrades.
    try:
        for sib in sorted(ROOT.parent.glob('TOPTEN_POP_V*'), reverse=True):
            if sib.resolve() == ROOT.resolve():
                continue
            roots.append(sib / 'fonts')
    except Exception:
        pass
    unique=[]; seen=set()
    for r in roots:
        try: key=str(r.resolve()).lower()
        except Exception: key=str(r).lower()
        if key not in seen:
            seen.add(key); unique.append(r)
    return unique


def _find_local_font(names):
    # Exact-name search first.  Downloads/Desktop get one shallow recursive search
    # because users often keep a font inside a downloaded ZIP-extracted folder.
    for base in _font_candidate_roots():
        for name in names:
            p=base/name
            if p.is_file():
                return p
        if base in (Path.home()/'Downloads', Path.home()/'Desktop') and base.exists():
            try:
                wanted={n.lower() for n in names}
                for p in base.glob('*'):
                    if p.is_file() and p.name.lower() in wanted:
                        return p
                    if p.is_dir():
                        for q in p.glob('*'):
                            if q.is_file() and q.name.lower() in wanted:
                                return q
            except Exception:
                pass
    return None


def _bootstrap_font_to_local(names, canonical_name):
    """Keep the program self-contained by copying an already-owned local font.

    Existing fonts/ is never overwritten/deleted by updates. If the font already
    exists in another TOPTEN_POP version, Windows Fonts, LocalAppData Fonts,
    Downloads/Desktop, it is copied into this version's fonts folder automatically.
    The source extension is preserved (.otf stays .otf, .ttf stays .ttf).
    """
    FONT_DIR.mkdir(parents=True, exist_ok=True)
    existing = _find_local_font(names)
    if existing is None:
        return None
    try:
        if existing.parent.resolve() == FONT_DIR.resolve():
            return existing
    except Exception:
        pass
    stem = Path(canonical_name).stem
    suffix = existing.suffix.lower() if existing.suffix.lower() in ('.otf','.ttf') else Path(canonical_name).suffix
    target = FONT_DIR / f'{stem}{suffix}'
    try:
        if not target.exists():
            shutil.copy2(existing, target)
        return target if target.exists() else existing
    except Exception:
        return existing


def _record_font_bootstrap_state(mapping):
    try:
        safe={k:(str(v) if v else '') for k,v in mapping.items()}
        FONT_BOOTSTRAP_STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
        FONT_BOOTSTRAP_STATE_FILE.write_text(json.dumps({
            'updated_at': datetime.now().isoformat(timespec='seconds'),
            'fonts': safe,
            'policy': 'program/fonts -> previous TOPTEN folders -> Windows/local user fonts -> fallback',
        }, ensure_ascii=False, indent=2), encoding='utf-8')
    except Exception:
        pass


def resolve_font_file(names):
    candidates = []
    for name in names:
        candidates.extend([
            FONT_DIR / name,
            Path('C:/Windows/Fonts') / name,
            Path.home() / 'AppData/Local/Microsoft/Windows/Fonts' / name,
        ])
    for path in candidates:
        if path.exists():
            return path
    return None

# V4.4.38: auto-localize all known required fonts when a copy already exists on
# this PC or in a previous TOPTEN_POP version. In particular DINPro-Regular is
# automatically pulled into fonts/ when available, without requiring Windows install.
_bootstrap_font_to_local(FONT_KO_NAMES, 'NanumBarunGothic.otf')
_bootstrap_font_to_local(FONT_DIN_REGULAR_NAMES, 'DINPro-Regular.otf')
_bootstrap_font_to_local(FONT_DIN_MEDIUM_NAMES, 'DINPro-Medium.otf')
_bootstrap_font_to_local(FONT_DIN_BOLD_NAMES, 'DINPro-Bold.otf')

FONT_KO = resolve_font_file(FONT_KO_NAMES)
FONT_DIN_REGULAR = resolve_font_file(FONT_DIN_REGULAR_NAMES)
FONT_DIN_MEDIUM = resolve_font_file(FONT_DIN_MEDIUM_NAMES)
FONT_DIN_BOLD = resolve_font_file(FONT_DIN_BOLD_NAMES)
# Only the English subtitle uses Regular. If Regular genuinely does not exist on
# the PC, keep output usable with Medium but surface the missing-font warning.
FONT_DIN_REGULAR_EFFECTIVE = FONT_DIN_REGULAR or FONT_DIN_MEDIUM
_record_font_bootstrap_state({
    'NanumBarunGothic': FONT_KO,
    'DINPro-Regular': FONT_DIN_REGULAR,
    'DINPro-Medium': FONT_DIN_MEDIUM,
    'DINPro-Bold': FONT_DIN_BOLD,
})

DPI = 300
MM_TO_PX = DPI / 25.4
# The original TOPTEN visual PDFs are A4 masters intended to print at 100%.
A4_W_MM = 210.0
A4_H_MM = 297.0
# The acrylic case was re-measured in store. To prevent the finished print from
# being about 10 mm too tall for the physical holder, the final cut height is
# set to 235 mm while preserving the 210 mm A4 width.
# The original NEW ARRIVAL artwork begins 32 mm from the A4 top edge.
CUT_TOP_MM = 32.0
CUT_H_MM = 235.0
CUT_BOTTOM_MM = CUT_TOP_MM + CUT_H_MM
# Bottom bar uses the re-measured physical height of 44 mm and covers the final
# 44 mm of the finished POP.
BAR_H_MM = 44.0
BAR_TOP_MM = CUT_BOTTOM_MM - BAR_H_MM
VISUAL_VISIBLE_H_MM = BAR_TOP_MM - CUT_TOP_MM
A4_W_PX = round(A4_W_MM * MM_TO_PX)
A4_H_PX = round(A4_H_MM * MM_TO_PX)
POP_W_PX = A4_W_PX
POP_H_PX = round(CUT_H_MM * MM_TO_PX)
BAR_H_PX = round(BAR_H_MM * MM_TO_PX)
CUT_TOP_PX = round(CUT_TOP_MM * MM_TO_PX)
BAR_TOP_PX = round(BAR_TOP_MM * MM_TO_PX)

def pt_px(pt: float) -> int:
    return max(1, round(pt * DPI / 72.0))


HTML = r'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>TOPTEN POP 자동화</title><style>
*{box-sizing:border-box}body{margin:0;background:#f3f5f7;font-family:Malgun Gothic,Arial,sans-serif;color:#161616}.wrap{max-width:1560px;margin:auto;padding:24px}.top{background:#0d255f;color:white;padding:20px 24px;border-radius:12px;display:flex;justify-content:space-between;align-items:center}.top h1{margin:0;font-size:25px}.top small{opacity:.85}.panel{background:white;border-radius:12px;padding:18px;margin-top:16px;box-shadow:0 2px 10px #00000010}.row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.btn{border:0;border-radius:7px;padding:10px 16px;font-weight:700;cursor:pointer;background:#102c73;color:white;text-decoration:none;display:inline-block}.red{background:#e30613}.gray{background:#555}.green{background:#26734d}.orange{background:#b55d00}.search{padding:10px;border:1px solid #bbb;border-radius:7px;min-width:320px}.stats{display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin-top:12px}.stat{background:#f7f8fa;padding:12px;border-radius:8px;text-align:center}.stat b{font-size:22px;color:#102c73}.layout{display:grid;grid-template-columns:minmax(700px,1.55fr) minmax(410px,.85fr);gap:16px;margin-top:16px}.tablebox{max-height:650px;overflow:auto;border:1px solid #ddd}table{width:100%;border-collapse:collapse;font-size:13px}th,td{padding:9px;border-bottom:1px solid #e2e2e2;text-align:center;white-space:nowrap}th{position:sticky;top:0;background:#edf1f7;z-index:2}.left{text-align:left;max-width:280px;overflow:hidden;text-overflow:ellipsis}.sale{color:#e30613;font-weight:700}.badge{padding:3px 8px;border-radius:12px;color:white;font-size:11px}.b-sale{background:#e30613}.b-normal{background:#555}.b-policy-price{background:#c90017}.b-policy-period{background:#df192d}.b-policy-normal{background:#4e5661}.policy-summary{margin-top:10px;padding:10px 12px;border-radius:8px;background:#fff5f5;border:1px solid #f1c8cc;font-size:13px}.preview{min-height:440px;text-align:center;background:#f7f7f7;border-radius:8px;padding:12px}.preview img{max-width:100%;max-height:590px;box-shadow:0 3px 15px #0003;background:white}.detail{text-align:left;background:white;margin-top:10px;padding:12px;border-radius:8px;line-height:1.7}.muted{color:#777}.warn{color:#c00;font-weight:700}.queue{border:2px solid #dbe2f0;background:#fbfcff}.queue-list{max-height:245px;overflow:auto;border:1px solid #ddd;border-radius:7px;background:white}.queue-item{display:grid;grid-template-columns:28px 110px 1fr;gap:7px;align-items:center;padding:9px;border-bottom:1px solid #eee;font-size:13px}.queue-empty{padding:20px;text-align:center;color:#777}.loading{opacity:.55;pointer-events:none}.toast{position:fixed;right:24px;bottom:24px;background:#111;color:#fff;padding:12px 18px;border-radius:8px;display:none;z-index:20}.site-notice-open{display:none}.notice-overlay{position:fixed;inset:0;background:#0008;display:none;align-items:center;justify-content:center;padding:18px;z-index:9999}.notice-overlay.show{display:flex}.notice-dialog{width:min(620px,96vw);background:white;border-radius:16px;box-shadow:0 18px 60px #0007;overflow:hidden}.notice-head{padding:18px 22px;color:white;background:#2456a6;display:flex;align-items:center;justify-content:space-between;gap:12px}.notice-head.중요{background:#b76500}.notice-head.긴급{background:#c81d2b}.notice-title{font-size:21px;font-weight:900}.notice-level{font-size:13px;font-weight:900;background:#fff2;padding:5px 9px;border:1px solid #fff5;border-radius:999px}.notice-body{padding:23px 24px;font-size:16px;line-height:1.75;white-space:pre-wrap;word-break:keep-all}.notice-period{padding:0 24px 14px;color:#777;font-size:12px}.notice-actions{display:flex;gap:9px;justify-content:flex-end;flex-wrap:wrap;padding:15px 20px;background:#f5f6f8;border-top:1px solid #e5e5e5}.notice-actions button{border:0;border-radius:8px;padding:11px 16px;font-weight:800;cursor:pointer}.notice-ok{background:#102c73;color:white}.notice-hide{background:#555;color:white}@media(max-width:1050px){.layout{grid-template-columns:1fr}.stats{grid-template-columns:repeat(2,1fr)}}
</style><script>
function allcheck(x){document.querySelectorAll('#productForm input[name=codes]').forEach(e=>e.checked=x.checked)}
function checkedCodes(){return [...document.querySelectorAll('#productForm input[name=codes]:checked')].map(e=>e.value)}
function toast(t){let e=document.getElementById('toast');e.textContent=t;e.style.display='block';setTimeout(()=>e.style.display='none',1800)}
async function setVisualChoice(code,choice){let body=new URLSearchParams({code,choice});let r=await fetch('/api/visual-choice',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body});return await r.json()}
async function resolveVisualChoices(codes,force=false){if(!codes.length)return true;let qs=new URLSearchParams();codes.forEach(c=>qs.append('code',c));if(force)qs.set('force','1');let r=await fetch('/api/visual-choice-required?'+qs.toString());let d=await r.json();for(let i of (d.items||[])){let useBonus=confirm(`[${i.code}] ${i.title_ko}\n\n이월상품에 연결된 번외 POP가 있습니다.\n\n확인: 번외 POP 사용`);await setVisualChoice(i.code,'bonus')}return true}
async function changeVisualChoice(code){await resolveVisualChoices([code],true);await preview(code)}
async function preview(code){let box=document.getElementById('previewBox');box.classList.add('loading');try{let r=await fetch('/api/item/'+encodeURIComponent(code));let d=await r.json();document.getElementById('pv').src='/preview/'+encodeURIComponent(code)+'?v='+(d.preview_version||'1');document.getElementById('detail').innerHTML=`<b>${d.code}</b> · 시즌 ${d.season||d.season_letter||'-'}<br>상품명: ${d.title_ko}<br>정상가: ${d.normal_fmt}<br>할인가: <span class="sale">${d.sale_fmt}</span> · 할인율: <b>${d.discount_percent_fmt||'-'}</b><br>프로모션: ${d.promotion||'-'}<br>가격정책: <b>${d.price_policy||'미분류'}</b><br>행사기간: ${d.price_policy==='기간한정'?(d.date_range||'-'):'-'}<br>비주얼: ${d.visual_status}`}finally{box.classList.remove('loading')}}
async function queueAction(url,codes=[]){let body=new URLSearchParams();codes.forEach(c=>body.append('codes',c));let r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body});let d=await r.json();renderQueue(d.items||[]);return d}
async function addCheckedToQueue(){let c=checkedCodes();if(!c.length){toast('체크한 품번이 없습니다.');return}let d=await queueAction('/queue/add',c);toast(d.added+'개를 생성 목록에 추가했습니다.');}
async function removeQueueChecked(){let c=[...document.querySelectorAll('#queueList input[name=qcodes]:checked')].map(e=>e.value);if(!c.length){toast('삭제할 품번을 선택하세요.');return}await queueAction('/queue/remove',c);toast('목록에서 삭제했습니다.');}
async function clearQueue(){if(confirm('생성할 POP 목록을 모두 비울까요?')){await queueAction('/queue/clear');toast('목록을 비웠습니다.')}}
function renderQueue(items){let q=document.getElementById('queueList'),count=document.getElementById('queueCount');count.textContent=items.length;if(!items.length){q.innerHTML='<div class="queue-empty">체크한 상품을 목록에 추가하면 여기에 쌓입니다.</div>';return}q.innerHTML=items.map(i=>`<label class="queue-item"><input type="checkbox" name="qcodes" value="${i.code}"><b>${i.code}</b><span>${i.title_ko}</span></label>`).join('')}
async function generateQueue(){let codes=[...document.querySelectorAll('#queueList input[name=qcodes]')].map(e=>e.value);let count=codes.length;if(!count){toast('생성 목록이 비어 있습니다.');return}if(!confirm(count+'개 POP를 한꺼번에 생성할까요?'))return;let btn=document.getElementById('queueGenerate');btn.disabled=true;btn.textContent='생성 중...';try{let r=await fetch('/queue/generate',{method:'POST'});let d=await r.json();renderQueue(d.items||[]);toast(d.generated+'개 생성 완료');setTimeout(()=>location.reload(),700)}finally{btn.disabled=false;btn.textContent='목록 전체 POP 생성'}}
async function generateImmediate(mode){let form=document.getElementById('productForm');let codes=mode==='all'?[...form.querySelectorAll('input[name=codes]')].map(e=>e.value):checkedCodes();if(!codes.length){toast('생성할 품번이 없습니다.');return}let hidden=document.createElement('input');hidden.type='hidden';hidden.name='mode';hidden.value=mode;form.appendChild(hidden);form.submit()}
let _siteNotice=null;
function _noticeToday(){let d=new Date(),m=String(d.getMonth()+1).padStart(2,'0'),day=String(d.getDate()).padStart(2,'0');return `${d.getFullYear()}-${m}-${day}`}
function _noticeStorageKey(prefix,id){return `topten_pop_${prefix}_${String(id||'').replace(/[^0-9A-Za-z_.-]/g,'_')}`}
function closeSiteNotice(){document.getElementById('siteNoticeOverlay')?.classList.remove('show')}
function hideSiteNoticeToday(){if(!_siteNotice)return;localStorage.setItem(_noticeStorageKey('notice_hide_today',_siteNotice.id),_noticeToday());closeSiteNotice()}
function _noticeSuppressed(n){
  if(!n||!n.active)return true;
  if(localStorage.getItem(_noticeStorageKey('notice_hide_today',n.id))===_noticeToday())return true;
  if(n.show_mode==='1회'&&localStorage.getItem(_noticeStorageKey('notice_seen',n.id))==='1')return true;
  if(n.show_mode==='매실행'&&sessionStorage.getItem(_noticeStorageKey('notice_run_seen',n.id))==='1')return true;
  return false;
}
function showSiteNotice(force=false){
  let n=_siteNotice;if(!n||!n.active)return;
  if(!force&&_noticeSuppressed(n))return;
  let head=document.getElementById('siteNoticeHead');head.classList.remove('일반','중요','긴급');head.classList.add(n.level||'일반');
  document.getElementById('siteNoticeTitle').textContent=n.title||'TOPTEN POP 공지';
  document.getElementById('siteNoticeLevel').textContent=(n.level||'일반')+' 공지';
  document.getElementById('siteNoticeMessage').textContent=n.message||'';
  let period=[];if(n.start_date)period.push(n.start_date);if(n.end_date)period.push(n.end_date);document.getElementById('siteNoticePeriod').textContent=period.length?('공지 기간 · '+period.join(' ~ ')):'';
  document.getElementById('siteNoticeHideToday').style.display=n.allow_hide_today?'inline-block':'none';
  document.getElementById('siteNoticeOverlay').classList.add('show');
  if(n.show_mode==='1회')localStorage.setItem(_noticeStorageKey('notice_seen',n.id),'1');
  if(n.show_mode==='매실행')sessionStorage.setItem(_noticeStorageKey('notice_run_seen',n.id),'1');
}
async function loadSiteNotice(){
  try{
    let r=await fetch('/api/site-notice?ts='+Date.now(),{cache:'no-store'});let n=await r.json();_siteNotice=n;
    let b=document.getElementById('siteNoticeOpen');if(b)b.style.display=(n&&n.active)?'inline-block':'none';
    if(n&&n.active)showSiteNotice(false);
  }catch(e){}
}
document.addEventListener('DOMContentLoaded',()=>{loadSiteNotice()});
</script></head><body><div class="wrap">
<div class="top"><div><h1>TOPTEN 완전 자동 POP · V5.1.1 <span style="font-size:14px;font-weight:600;color:#666;margin-left:10px">Made By. 포항장성점 김대영</span></h1><small>엑셀 업로드 · 품번 이미지 자동 매칭 · 가격인하=번외→PPT · 기간한정=번외→성인소형 · 정상가=번외→NEW ARRIVAL · 자동업데이트 지원 · 적용일 예약반영 · 가격인하 자동판정 · 중앙 GitHub 가격정책 자동배포</small></div><b>{{loaded_name}}</b></div>{% if missing_fonts %}<div class="panel warn">필수 폰트 미설치: {{missing_fonts|join(', ')}}<br>Windows에 설치하거나 fonts 폴더에 복사한 뒤 RUN.cmd를 다시 실행하세요.</div>{% endif %}
<div class="panel"><div class="row" style="margin-bottom:12px"><a class="btn orange" href="/bonus-ai">AI 번외 매칭 관리</a><a class="btn" href="/sync">웹하드 다운로드 폴더</a><a class="btn green" href="/notice">공지 PDF 자동동기화</a><a class="btn green" href="/manual">📘 POP 자동화 매뉴얼</a><button id="siteNoticeOpen" type="button" class="btn orange site-notice-open" onclick="showSiteNotice(true)">🔔 운영 공지</button></div>
<div style="background:#eef3fb;border:1px solid #cad5ea;border-radius:10px;padding:14px;margin-bottom:14px"><div class="row" style="justify-content:space-between"><div><b style="font-size:17px">AI 번외 매칭 전용</b><div class="muted" style="margin-top:5px">2026년 10월 1일부터 전 매장 AI 번외 매칭만 사용합니다. 기존 수동고정과 공지 PDF 정답매칭은 그대로 보호됩니다.</div></div></div><div class="row" style="margin-top:10px"><span><b>현재 적용:</b> AI 번외 매칭</span><span class="muted">AI 저장 {{ai_match_count}}개</span></div><div class="row" style="margin-top:10px"><form method="post" action="/bonus-ai/rematch-main" onsubmit="return confirm('AI 전체 재매칭을 시작할까요? 현재 적용된 AI 결과는 새 결과를 확정할 때까지 유지됩니다. 수동고정은 보호되고 기존 페이지 캐시는 재사용합니다.')"><button class="btn orange">AI 전체 재매칭 실행</button></form><span class="muted">수동고정/공지 정답은 항상 유지됩니다.</span></div></div>
<form action="/upload" method="post" enctype="multipart/form-data" class="row"><input type="file" name="excel" accept=".xlsx,.xlsm" required><button class="btn">프로모션 엑셀 적용 + 마스터 자동동기화</button><span class="muted">현재 활성 행사기간: <b>{{date_range or '-'}}</b></span></form>
<div style="margin-top:12px;background:#eef7f1;border:1px solid #c7dfcf;border-radius:10px;padding:13px"><div class="row" style="justify-content:space-between"><div><b style="font-size:16px">가격정책 마스터 · GitHub 중앙배포</b> · 기준 <b>{{master_count}}</b>품번<br><span class="muted">V5.1은 프로그램 시작 시 1회, 이후 30분 간격으로 작은 price_master.json만 확인합니다. SHA256이 달라진 경우에만 새 마스터를 내려받아 검증 → 기존 원장 백업 → 원자적 교체합니다. 검색/새로고침/화면이동에서는 GitHub나 변경리스트를 확인하지 않습니다.</span></div><a class="btn green" href="/price-master/download">현재 마스터 다운로드</a></div><div class="row" style="margin-top:10px"><form action="/price-master/central-sync" method="post"><button class="btn">GitHub 가격정책 최신화</button></form><form action="/price-master/apply-live" method="post"><button class="btn green">변경리스트 반영 (오늘 도래분만)</button></form><form action="/price-master/upload" method="post" enctype="multipart/form-data"><input type="file" name="master" accept=".xlsx,.xlsm" required> <button class="btn orange">관리용 마스터 직접 적용</button></form></div><div style="margin-top:9px"><b>중앙 마스터:</b> {{central_master_status.remote_version or '-'}} · <span class="{{'muted' if central_master_status.ok else 'warn'}}">{{central_master_status.message or '확인 전'}}</span>{% if central_master_status.last_checked %} · 마지막 확인 {{central_master_status.last_checked}}{% endif %}<br><span class="{{'muted' if master_status.ok else 'warn'}}">로컬 상태: {{master_status.message or '마스터 준비 완료'}}{% if master_status.updated_at %} · {{master_status.updated_at}}{% endif %}</span></div></div>
<div class="policy-summary"><b>가격정책 자동인식</b> · 감지열 <b>{{policy_column_name or '미검출'}}</b> · 가격인하 <b>{{price_reduction_count}}</b> · 기간한정 <b>{{period_limited_count}}</b> · 정상가 <b>{{policy_normal_count}}</b> · 미분류 <b>{{policy_unknown_count}}</b><br><span class="muted">적용 규칙: 가격인하=번외 1순위 → 가격인하 POP 2순위 · 기간한정=번외 1순위 → 성인소형 2순위 · 정상가=번외 1순위 → NEW ARRIVAL 2순위 · 특별가격 POP 미사용</span></div>
<div class="stats"><div class="stat"><b>{{items|length}}</b><br>전체 상품</div><div class="stat"><b>{{normal_count}}</b><br>정상가</div><div class="stat"><b>{{sale_count}}</b><br>할인가</div><div class="stat"><b>{{matched_count}}</b><br>이미지 매칭</div><div class="stat"><b>{{missing_count}}</b><br>이미지 미매칭</div></div></div>
<div class="layout"><div class="panel" style="margin-top:0"><form method="get" action="/" class="row"><input class="search" name="q" value="{{q}}" placeholder="품번 또는 상품명 검색"><button class="btn">검색</button><a href="/" class="btn gray">초기화</a></form>
<form id="productForm" action="/generate" method="post"><div class="row" style="justify-content:space-between;margin:14px 0"><label><input type="checkbox" onclick="allcheck(this)"> 전체선택</label><div><button type="button" onclick="addCheckedToQueue()" class="btn orange">체크 상품을 생성 목록에 추가</button> <button type="button" onclick="generateImmediate('selected')" class="btn red">선택 POP 즉시 생성</button> <button type="button" onclick="generateImmediate('all')" class="btn green">검색결과 전체 생성</button></div></div>
<div class="tablebox"><table><thead><tr><th></th><th>가격정책</th><th>품번</th><th>성별/조닝</th><th>상품명</th><th>정상가</th><th>할인가</th><th>할인율</th><th>프로모션</th><th>정책 원문</th><th>이미지</th></tr></thead><tbody>{% for i in items %}<tr onclick="preview('{{i.code}}')" style="cursor:pointer"><td onclick="event.stopPropagation()"><input type="checkbox" name="codes" value="{{i.code}}"></td><td><span class="badge {{'b-policy-price' if i.price_policy=='가격인하' else ('b-policy-period' if i.price_policy=='기간한정' else 'b-policy-normal')}}">{{i.price_policy or '미분류'}}</span></td><td><b>{{i.code}}</b></td><td>{{i.gender}} / {{i.zone}}</td><td class="left">{{i.title_ko}}</td><td>{{i.normal_fmt}}</td><td class="sale">{{i.sale_fmt}}</td><td>{{i.discount_percent_fmt}}</td><td class="left">{{i.promotion or '-'}}</td><td class="left">{{i.price_policy_raw or i.price_policy or '미분류'}}</td><td>{{i.visual_status}}</td></tr>{% endfor %}</tbody></table></div></form></div>
<div><div class="panel queue" style="margin-top:0"><div class="row" style="justify-content:space-between"><h3 style="margin:0">생성할 POP 목록 (<span id="queueCount">{{queue_items|length}}</span>)</h3><button id="queueGenerate" class="btn red" onclick="generateQueue()">목록 전체 POP 생성</button></div><p class="muted">검색을 바꿔도 목록은 유지되며, 프로그램을 껐다 켜도 저장됩니다. 일괄 생성이 끝난 품번은 목록에서 자동 삭제됩니다.</p><div id="queueList" class="queue-list">{% for i in queue_items %}<label class="queue-item"><input type="checkbox" name="qcodes" value="{{i.code}}"><b>{{i.code}}</b><span>{{i.title_ko}}</span></label>{% else %}<div class="queue-empty">체크한 상품을 목록에 추가하면 여기에 쌓입니다.</div>{% endfor %}</div><div class="row" style="margin-top:10px"><button class="btn gray" onclick="removeQueueChecked()">선택 삭제</button><button class="btn gray" onclick="clearQueue()">목록 전체 비우기</button></div></div>
<div class="panel" style="margin-top:16px"><h3>POP 미리보기 / 상품 정보</h3><div id="previewBox" class="preview"><img id="pv" src="{{initial_preview}}"><div id="detail" class="detail">목록의 상품을 클릭하면 상품명, 가격, 프로모션 내용과 POP가 표시됩니다.</div></div></div></div></div>
{% if generated %}<div class="panel"><h3>생성 완료</h3><div class="row">{% for f in generated %}<a class="btn" href="/output/{{f}}" target="_blank">{{f}}</a>{% endfor %}</div></div>{% endif %}
</div><div id="siteNoticeOverlay" class="notice-overlay" role="dialog" aria-modal="true"><div class="notice-dialog"><div id="siteNoticeHead" class="notice-head 일반"><div id="siteNoticeTitle" class="notice-title">TOPTEN POP 공지</div><div id="siteNoticeLevel" class="notice-level">일반 공지</div></div><div id="siteNoticeMessage" class="notice-body"></div><div id="siteNoticePeriod" class="notice-period"></div><div class="notice-actions"><button id="siteNoticeHideToday" type="button" class="notice-hide" onclick="hideSiteNoticeToday()">오늘 다시 보지 않기</button><button type="button" class="notice-ok" onclick="closeSiteNotice()">확인</button></div></div></div><div id="toast" class="toast"></div></body></html>'''

def font(path, size:int, fallback_bold=False):
    candidates = []
    if path:
        candidates.append(Path(path))
    if fallback_bold:
        candidates.extend([Path('C:/Windows/Fonts/arialbd.ttf'), Path('C:/Windows/Fonts/malgunbd.ttf')])
    else:
        candidates.extend([Path('C:/Windows/Fonts/arial.ttf'), Path('C:/Windows/Fonts/malgun.ttf')])
    candidates.append(Path('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf' if fallback_bold else '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
    for p in candidates:
        try:
            if p.exists():
                return ImageFont.truetype(str(p), size)
        except Exception:
            pass
    return ImageFont.load_default()

def missing_required_fonts():
    missing = []
    if FONT_KO is None: missing.append('NanumBarunGothic.otf')
    if FONT_DIN_REGULAR is None: missing.append('DINPro-Regular.otf')
    if FONT_DIN_MEDIUM is None: missing.append('DINPro-Medium.otf')
    if FONT_DIN_BOLD is None: missing.append('DINPro-Bold.otf')
    return missing

def n(v):
    try:
        if v in (None,''): return 0
        return int(float(str(v).replace(',','')))
    except:return 0

def clean_code(v): return re.sub(r'[^A-Z0-9_-]','',str(v or '').strip().upper())

def infer_gender_from_code(code, fallback=''):
    """Infer TOPTEN gender from the first digit of the final four digits.

    Store rule:
      1xxx = 남성, 2xxx = 여성, 3xxx = 공용.
    The product-code rule has priority over the promotion Excel gender value.
    If a code does not end in four digits or the first digit is not 1/2/3,
    preserve the supplied fallback value.
    """
    normalized = clean_code(code)
    match = re.search(r'(\d{4})$', normalized)
    if not match:
        return str(fallback or '').strip()
    return {'1': '남성', '2': '여성', '3': '공용'}.get(
        match.group(1)[0], str(fallback or '').strip()
    )


def clean_display_product_title(value):
    """Remove only the store-facing gender/common prefix from the visible Korean title.

    The source master text is left untouched; POP/UI output uses the cleaned title.
    Examples: '공용) 투포켓 크로스백' -> '투포켓 크로스백'.
    """
    text=re.sub(r'\s+',' ',str(value or '').strip())
    return re.sub(r'^(?:공용|남성|여성)\s*\)\s*','',text, count=1).strip()


PRICE_POLICY_VALUES = ('정상가', '기간한정', '가격인하')


def normalize_price_policy(value):
    """Normalize the 8/28+ TOPTEN price-policy classification.

    Current business mapping supplied by the store:
      ① 가격 유지 / ② 신규 가격인하 / ③ 추가 가격인하 -> 가격인하
      ④ 기간한정 -> 기간한정
      ⑤ 정상가 -> 정상가
    Circled numerals, dates, spaces and explanatory parentheses are ignored.
    """
    raw = str(value or '').strip()
    if not raw:
        return ''
    compact = re.sub(r'\s+', '', raw)
    compact = compact.replace('期間限定', '기간한정')
    if '기간한정' in compact or '기간한정할인' in compact:
        return '기간한정'
    # 가격인하 관련 문구가 직접 있으면 가장 강한 근거다.
    if '가격인하' in compact or '가격하향' in compact:
        return '가격인하'
    # 이번 공지의 ① "가격 유지"는 기존 인하가격 유지 대상이므로 가격인하로 분류한다.
    if '가격유지' in compact:
        return '가격인하'
    if '정상가' in compact or '정상가격' in compact:
        return '정상가'
    return ''


AUTO_POLICY_WORDS = ('자동', '자동판정', '자동 판단', '자동분류', '자동 분류')


def _is_auto_policy_request(value):
    raw=str(value or '').strip()
    if not raw:
        return True
    compact=re.sub(r'\s+','',raw)
    return compact in {re.sub(r'\s+','',x) for x in AUTO_POLICY_WORDS}


def _infer_policy_from_prices(normal_price, sale_price):
    """Infer only the broad policy when the input row asks for automatic judgment.

    기간한정 remains explicit because dates alone must not silently create/cancel a promotion.
    For ordinary price rows, 조정가 < 정상가 => 가격인하, otherwise => 정상가.
    """
    normal=n(normal_price)
    sale=n(sale_price)
    if normal<=0 or sale<=0:
        return ''
    return '가격인하' if sale < normal else '정상가'


def _infer_price_reduction_transition(existing_policy, existing_price, normal_price, new_price, has_existing=True):
    """Classify 신규/추가/유지 from the stored baseline, never from the typed label alone.

    During 기간한정 callers pass the *return baseline* as existing_policy/existing_price,
    so a new permanent reduction can be queued behind the temporary promotion safely.
    """
    existing_policy=normalize_price_policy(existing_policy)
    old=n(existing_price)
    normal=n(normal_price)
    new=n(new_price)
    if not has_existing or existing_policy!='가격인하' or old<=0:
        return '신규 가격인하'
    if new<=0:
        return '가격 유지'
    if new < old:
        return '추가 가격인하'
    if abs(new-old) < 0.000001:
        return '가격 유지'
    if normal>0 and new < normal:
        return '가격인하 가격조정'
    return '가격인하'


def _money_text(value):
    v=n(value)
    if v<=0:
        return '-'
    try:
        return f'{int(round(v)):,}원'
    except Exception:
        return str(value)



def _style_workflow_header(ws, cell_range):
    fill=PatternFill('solid', fgColor='163A63')
    font=Font(color='FFFFFF', bold=True, size=10)
    align=Alignment(horizontal='center', vertical='center', wrap_text=True)
    for row in ws[cell_range]:
        for cell in row:
            cell.fill=fill; cell.font=font; cell.alignment=align


def _ensure_price_master_workflow_schema_in_wb(wb):
    """Add the V4.4.60 change-input workflow sheets without touching master rows."""
    changed=False
    specs={
        PRICE_CHANGE_INPUT_SHEET:[
            '적용일','구분','품번','상품명','상품영문','정상가','조정가','프로모션 내용',
            '정책/변경내용','행사시작일','행사종료일','처리상태','처리일','처리메모'
        ],
        PRICE_PERIOD_EDIT_SHEET:[
            '품번','새 행사시작일','새 행사종료일','변경사유','처리상태','처리일','처리메모'
        ],
        PRICE_HISTORY_SHEET:[
            '처리일시','적용일','작업유형','구분','품번','상품명','이전정책','이전가격',
            '새정책','새가격','행사시작일','행사종료일','기간종료후정책','기간종료후가격',
            '원본내용','원본파일','처리메모'
        ],
    }
    widths={
        PRICE_CHANGE_INPUT_SHEET:[12,10,16,28,34,12,12,26,18,13,13,12,18,34],
        PRICE_PERIOD_EDIT_SHEET:[16,15,15,30,12,18,34],
        PRICE_HISTORY_SHEET:[18,12,16,10,16,28,13,12,13,12,13,13,16,14,26,30,34],
    }
    for name,headers in specs.items():
        if name not in wb.sheetnames:
            ws=wb.create_sheet(name); changed=True
        else:
            ws=wb[name]
        for c,h in enumerate(headers,1):
            if not str(ws.cell(1,c).value or '').strip():
                ws.cell(1,c).value=h; changed=True
        _style_workflow_header(ws, f'A1:{get_column_letter(len(headers))}1')
        ws.freeze_panes='A2'
        for c,w in enumerate(widths[name],1):
            ws.column_dimensions[get_column_letter(c)].width=w
        # Apply number formats only to a small entry area; newly pasted Excel rows inherit usable values anyway.
        if name==PRICE_CHANGE_INPUT_SHEET:
            for r in range(2,202):
                ws.cell(r,1).number_format='yyyy-mm-dd'; ws.cell(r,10).number_format='yyyy-mm-dd'; ws.cell(r,11).number_format='yyyy-mm-dd'
                ws.cell(r,13).number_format='yyyy-mm-dd hh:mm'; ws.cell(r,6).number_format='#,##0'; ws.cell(r,7).number_format='#,##0'
            # Keep the 기존 당해/이월 validation and upgrade the policy dropdown in-place.
            policy_validation_updated=False
            for dv in list(ws.data_validations.dataValidation):
                try:
                    sq=str(dv.sqref or '')
                except Exception:
                    sq=''
                if 'I2:I1000' in sq or 'I2:I5000' in sq:
                    dv.formula1='"자동판정,가격 유지,신규 가격인하,추가 가격인하,가격인하,기간한정,정상가"'
                    dv.allow_blank=True
                    policy_validation_updated=True
            if not ws.data_validations.dataValidation:
                dv1=DataValidation(type='list', formula1='"당해,이월"', allow_blank=True)
                ws.add_data_validation(dv1); dv1.add('B2:B1000')
            if not policy_validation_updated:
                dv2=DataValidation(type='list', formula1='"자동판정,가격 유지,신규 가격인하,추가 가격인하,가격인하,기간한정,정상가"', allow_blank=True)
                ws.add_data_validation(dv2); dv2.add('I2:I5000')
        elif name==PRICE_PERIOD_EDIT_SHEET:
            for r in range(2,202):
                ws.cell(r,2).number_format='yyyy-mm-dd'; ws.cell(r,3).number_format='yyyy-mm-dd'; ws.cell(r,6).number_format='yyyy-mm-dd hh:mm'
        else:
            for r in range(2,202):
                ws.cell(r,1).number_format='yyyy-mm-dd hh:mm'; ws.cell(r,2).number_format='yyyy-mm-dd'
                ws.cell(r,8).number_format='#,##0'; ws.cell(r,10).number_format='#,##0'; ws.cell(r,11).number_format='yyyy-mm-dd'; ws.cell(r,12).number_format='yyyy-mm-dd'; ws.cell(r,14).number_format='#,##0'
    return changed


def ensure_price_master_workflow_schema(force=False):
    global _PRICE_MASTER_SCHEMA_READY
    if _PRICE_MASTER_SCHEMA_READY and not force:
        return True
    if not PRICE_MASTER_FILE.exists():
        return False
    try:
        wb=load_workbook(PRICE_MASTER_FILE)
        changed=_ensure_price_master_workflow_schema_in_wb(wb)
        if changed:
            tmp=PRICE_MASTER_FILE.with_suffix('.schema.tmp.xlsx')
            wb.save(tmp); wb.close(); os.replace(tmp,PRICE_MASTER_FILE)
        else:
            wb.close()
        _PRICE_MASTER_SCHEMA_READY=True
        return True
    except Exception as exc:
        _write_price_master_status({'ok':False,'message':f'마스터 입력시트 구성 실패: {exc}','updated_at':datetime.now().isoformat(timespec='seconds')})
        return False



def _price_master_header_ok(path):
    """Return True only when the workbook has the columns load_items requires."""
    path = Path(path)
    if not path.exists():
        return False
    wb = None
    try:
        wb = load_workbook(path, data_only=True, read_only=True)
        ws = wb[PRICE_MASTER_SHEET] if PRICE_MASTER_SHEET in wb.sheetnames else wb.active
        for row in itertools.islice(ws.iter_rows(values_only=True), 40):
            vals = [str(v or '').strip() for v in row]
            if any(x in vals for x in ('스타일', '품번')) and '정상가' in vals:
                return True
        return False
    except Exception:
        return False
    finally:
        try:
            if wb is not None:
                wb.close()
        except Exception:
            pass

def ensure_price_master_file():
    """Install the 8/28 initial master once. The data copy survives later updates."""
    global _PRICE_MASTER_SCHEMA_READY
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        if not PRICE_MASTER_FILE.exists() and PRICE_MASTER_TEMPLATE.exists():
            shutil.copy2(PRICE_MASTER_TEMPLATE, PRICE_MASTER_FILE)
            _PRICE_MASTER_SCHEMA_READY=False
            _write_price_master_status({
                'ok': True, 'message': '8/28 최초 가격정책 마스터를 설치했습니다.',
                'updated_at': datetime.now().isoformat(timespec='seconds'),
                'source': PRICE_MASTER_TEMPLATE.name,
            })
        if PRICE_MASTER_FILE.exists():
            ensure_price_master_workflow_schema()
    except Exception as exc:
        _write_price_master_status({'ok': False, 'message': f'마스터 설치 실패: {exc}', 'updated_at': datetime.now().isoformat(timespec='seconds')})
    return PRICE_MASTER_FILE.exists()


def _write_price_master_status(data):
    try:
        PRICE_MASTER_STATUS_FILE.parent.mkdir(parents=True, exist_ok=True)
        PRICE_MASTER_STATUS_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    except Exception:
        pass


def get_price_master_status():
    ensure_price_master_file()
    try:
        data=json.loads(PRICE_MASTER_STATUS_FILE.read_text(encoding='utf-8')) if PRICE_MASTER_STATUS_FILE.exists() else {}
    except Exception:
        data={}
    if PRICE_MASTER_FILE.exists():
        data.setdefault('ok', True)
        data['exists']=True
        try: data['file_mtime']=datetime.fromtimestamp(PRICE_MASTER_FILE.stat().st_mtime).isoformat(timespec='seconds')
        except Exception: pass
    else:
        data['exists']=False
    return data


def _central_sha256(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):
            h.update(chunk)
    return h.hexdigest().lower()


def _write_central_price_master_status(data):
    try:
        CENTRAL_PRICE_MASTER_STATUS_FILE.parent.mkdir(parents=True,exist_ok=True)
        old={}
        if CENTRAL_PRICE_MASTER_STATUS_FILE.exists():
            try: old=json.loads(CENTRAL_PRICE_MASTER_STATUS_FILE.read_text(encoding='utf-8'))
            except Exception: old={}
        if isinstance(old,dict): old.update(data or {})
        else: old=dict(data or {})
        CENTRAL_PRICE_MASTER_STATUS_FILE.write_text(json.dumps(old,ensure_ascii=False,indent=2),encoding='utf-8')
    except Exception:
        pass


def get_central_price_master_status():
    try:
        data=json.loads(CENTRAL_PRICE_MASTER_STATUS_FILE.read_text(encoding='utf-8')) if CENTRAL_PRICE_MASTER_STATUS_FILE.exists() else {}
    except Exception:
        data={}
    data.setdefault('ok',True)
    data.setdefault('message','중앙 마스터 확인 전')
    return data


def _central_validate_master(path):
    if not _price_master_header_ok(path):
        raise ValueError('중앙 가격정책 마스터의 필수 헤더를 찾지 못했습니다.')
    wb=load_workbook(path,data_only=False,read_only=False)
    try:
        ws,header_row,h=_find_master_sheet_and_headers(wb,require_rows=True)
        required=('품번','상품명','상품영문','정상가','조정가','가격정책')
        missing=[x for x in required if x not in h]
        if missing:
            raise ValueError('필수 열 누락: '+', '.join(missing))
        valid=0
        for r in range(header_row+1,min(ws.max_row,header_row+250)+1):
            if clean_code(ws.cell(r,h['품번']).value):
                valid+=1
                if valid>=3: break
        if valid<1:
            raise ValueError('유효한 품번 행이 없습니다.')
    finally:
        wb.close()
    return True


def sync_central_price_master(force=False,source='manual'):
    """Atomically replace the live master from GitHub when its SHA256 changes.

    Order is download -> SHA256 -> workbook validation -> backup -> os.replace.
    A failure therefore never deletes the current store master.
    """
    global _PRICE_MASTER_SCHEMA_READY
    if not CENTRAL_PRICE_MASTER_LOCK.acquire(blocking=False):
        return {'ok':True,'changed':False,'message':'중앙 가격정책 확인이 이미 진행 중입니다.'}
    now=datetime.now().isoformat(timespec='seconds')
    tmp=None
    try:
        ensure_price_master_file()
        req=urllib.request.Request(CENTRAL_PRICE_MASTER_MANIFEST_URL,headers={'User-Agent':'TOPTEN-POP/5.1'})
        with urllib.request.urlopen(req,timeout=CENTRAL_PRICE_MASTER_TIMEOUT_SECONDS) as response:
            manifest=json.loads(response.read().decode('utf-8-sig'))
        remote_version=str(manifest.get('master_version') or manifest.get('version') or '').strip()
        url=str(manifest.get('download_url') or manifest.get('url') or '').strip()
        expected=str(manifest.get('sha256') or '').lower().replace(' ','').strip()
        if not remote_version:
            raise ValueError('price_master.json에 master_version이 없습니다.')
        if not url:
            raise ValueError('price_master.json에 download_url이 없습니다.')
        if not re.fullmatch(r'[0-9a-f]{64}',expected):
            raise ValueError('price_master.json의 sha256이 없거나 올바르지 않습니다.')
        live_hash=_central_sha256(PRICE_MASTER_FILE) if PRICE_MASTER_FILE.exists() else ''
        if live_hash==expected and not force:
            state={'ok':True,'changed':False,'message':'중앙 가격정책 최신 상태','remote_version':remote_version,'sha256':expected,'last_checked':now,'source':source}
            _write_central_price_master_status(state)
            return state
        CACHE_DIR.mkdir(parents=True,exist_ok=True)
        fd,tmp_name=tempfile.mkstemp(prefix='central_price_master_',suffix='.xlsx',dir=str(CACHE_DIR)); os.close(fd)
        tmp=Path(tmp_name)
        req=urllib.request.Request(url,headers={'User-Agent':'TOPTEN-POP/5.1'})
        with urllib.request.urlopen(req,timeout=max(CENTRAL_PRICE_MASTER_TIMEOUT_SECONDS,15)) as response, tmp.open('wb') as out:
            shutil.copyfileobj(response,out)
        actual=_central_sha256(tmp)
        if actual!=expected:
            raise ValueError(f'중앙 마스터 SHA256 불일치: expected={expected} actual={actual}')
        _central_validate_master(tmp)
        backup_name='TOPTEN_가격정책_마스터_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.xlsx'
        backup_path=None
        if PRICE_MASTER_FILE.exists():
            CENTRAL_PRICE_MASTER_BACKUP_DIR.mkdir(parents=True,exist_ok=True)
            backup_path=CENTRAL_PRICE_MASTER_BACKUP_DIR/backup_name
            shutil.copy2(PRICE_MASTER_FILE,backup_path)
        PRICE_MASTER_FILE.parent.mkdir(parents=True,exist_ok=True)
        os.replace(tmp,PRICE_MASTER_FILE); tmp=None
        _PRICE_MASTER_SCHEMA_READY=False
        ensure_price_master_workflow_schema(force=True)
        for old in CACHE_DIR.glob('preview_fast_*'):
            try: old.unlink()
            except OSError: pass
        try: load_items(force=True)
        except Exception: pass
        # Keep only the most recent 12 automatic backups.
        try:
            backups=sorted(CENTRAL_PRICE_MASTER_BACKUP_DIR.glob('TOPTEN_가격정책_마스터_*.xlsx'),key=lambda p:p.stat().st_mtime,reverse=True)
            for p in backups[12:]:
                try: p.unlink()
                except OSError: pass
        except Exception: pass
        state={'ok':True,'changed':True,'message':f'중앙 가격정책 {remote_version} 적용 완료','remote_version':remote_version,'sha256':expected,'last_checked':now,'last_updated':now,'backup':backup_path.name if backup_path else '','source':source}
        _write_central_price_master_status(state)
        _write_price_master_status({'ok':True,'message':state['message'],'source':'GitHub 중앙 마스터','updated_at':now})
        return state
    except Exception as exc:
        state={'ok':False,'changed':False,'message':f'중앙 가격정책 확인/적용 실패: {type(exc).__name__}: {exc}','last_checked':now,'source':source}
        _write_central_price_master_status(state)
        return state
    finally:
        try:
            if tmp is not None and Path(tmp).exists(): Path(tmp).unlink()
        except Exception: pass
        CENTRAL_PRICE_MASTER_LOCK.release()


def _central_price_master_loop():
    while True:
        time.sleep(CENTRAL_PRICE_MASTER_CHECK_INTERVAL_SECONDS)
        try: sync_central_price_master(force=False,source='background')
        except Exception: pass


def _master_date(value):
    if value is None or value == '':
        return None
    if isinstance(value, datetime):
        return value.date()
    if hasattr(value, 'year') and hasattr(value, 'month') and hasattr(value, 'day'):
        try: return datetime(int(value.year), int(value.month), int(value.day)).date()
        except Exception: pass
    text=str(value).strip()
    if not text:
        return None
    for fmt in ('%Y-%m-%d','%Y/%m/%d','%Y.%m.%d','%m/%d','%m-%d'):
        try:
            d=datetime.strptime(text,fmt)
            if fmt.startswith('%m'):
                d=d.replace(year=datetime.now().year)
            return d.date()
        except Exception:
            pass
    return None


def _master_date_range_text(start_value, end_value):
    s=_master_date(start_value); e=_master_date(end_value)
    if s and e:
        return f'{s.month}/{s.day} ~ {e.month}/{e.day}'
    if s:
        return f'{s.month}/{s.day}'
    return ''


def _period_dates_from_range(text):
    pairs=_extract_date_pairs(text)
    if len(pairs) < 2:
        return None, None
    y=datetime.now().year
    (m1,d1),(m2,d2)=pairs[0],pairs[1]
    try:
        start=datetime(y,m1,d1)
        end_year=y+1 if (m2,d2) < (m1,d1) else y
        end=datetime(end_year,m2,d2)
        return start,end
    except Exception:
        return None,None


def _find_master_sheet_and_headers(wb, require_rows=False):
    candidates=[]
    if PRICE_MASTER_SHEET in wb.sheetnames:
        candidates.append(wb[PRICE_MASTER_SHEET])
    candidates.extend(ws for ws in wb.worksheets if ws not in candidates)
    for ws in candidates:
        for r in range(1,min(ws.max_row,25)+1):
            vals=[str(ws.cell(r,c).value or '').strip() for c in range(1,ws.max_column+1)]
            if '품번' in vals and '가격정책' in vals and '정상가' in vals and ('조정가' in vals or '할인가' in vals):
                headers={v:i+1 for i,v in enumerate(vals) if v}
                if require_rows and ws.max_row <= r:
                    continue
                return ws,r,headers
    raise ValueError('가격정책 마스터 헤더(품번/정상가/조정가/가격정책)를 찾지 못했습니다.')


def _extract_price_policy_sync_rows(source_path, source_name=''):
    """Read only explicit HQ changes from an uploaded promotion workbook."""
    wb=load_workbook(source_path,data_only=True,read_only=True)
    try:
        active_rows=list(wb.active.iter_rows(values_only=True))
        global_range=detect_workbook_date_range(wb,active_rows,source_name)
        range_start,range_end=_period_dates_from_range(global_range)
        out=[]
        for ws in wb.worksheets:
            rows=list(ws.iter_rows(values_only=True))
            header_idx=None; headers=[]
            for ridx,row in enumerate(rows[:50]):
                vals=[str(v or '').strip() for v in row]
                if any(x in vals for x in ('스타일','품번')) and any(x in vals for x in ('정상가','조정가','할인가')):
                    header_idx=ridx; headers=vals; break
            if header_idx is None:
                continue
            def ci(*names):
                for name in names:
                    if name in headers: return headers.index(name)
                return None
            code_col=ci('스타일','품번')
            policy_col,policy_col_name=find_price_policy_column(rows,header_idx,headers,code_col)
            cols={
                'code':code_col,'title_ko':ci('상품명'),'title_en':ci('상품명(영문)','영문명'),
                'normal':ci('정상가'),'sale':ci('조정가','할인가'),'promo':ci('프로모션 내용','비고'),
                'change':ci('가격변동'),
            }
            season='이월' if '이월' in ws.title else ('당해' if '당해' in ws.title else '')
            for row in rows[header_idx+1:]:
                def rv(key):
                    c=cols.get(key); return row[c] if c is not None and c < len(row) else None
                code=clean_code(rv('code'))
                if not code:
                    continue
                raw=''; policy=''
                if policy_col is not None and policy_col < len(row):
                    raw=str(row[policy_col] or '').strip(); policy=normalize_price_policy(raw)
                if not policy:
                    for value in row:
                        cand=normalize_price_policy(value)
                        if cand:
                            raw=str(value or '').strip(); policy=cand; break
                # A later HQ delta file can omit unchanged rows. Only explicit policy rows
                # are allowed to change the persistent master.
                if not policy:
                    continue
                out.append({
                    'season':season,'code':code,
                    'title_ko':str(rv('title_ko') or '').strip(),
                    'title_en':str(rv('title_en') or '').strip(),
                    'normal_raw':rv('normal'),'sale_raw':rv('sale'),
                    'normal':n(rv('normal')),'sale':n(rv('sale')),
                    'promo':str(rv('promo') or '').strip(),
                    'price_change':n(rv('change')),
                    'policy':policy,'raw_policy':raw,
                    'event_start':range_start if policy=='기간한정' else None,
                    'event_end':range_end if policy=='기간한정' else None,
                    'source_sheet':ws.title,'policy_column':policy_col_name,
                })
        return out,global_range
    finally:
        wb.close()


def _master_header_map(ws, header_row=1):
    return {str(ws.cell(header_row,c).value or '').strip():c for c in range(1,ws.max_column+1) if str(ws.cell(header_row,c).value or '').strip()}


def _history_append(ws, values):
    # Preformatted blank rows must not push history to row 2001+. Find the last row with real values.
    row=ws.max_row
    check_cols=max(1,min(ws.max_column,len(values)))
    while row>1 and not any(ws.cell(row,c).value not in (None,'') for c in range(1,check_cols+1)):
        row-=1
    row+=1
    for c,v in enumerate(values,1):
        ws.cell(row,c).value=v
    return row


def _master_baseline(ws,row,h):
    old_policy=normalize_price_policy(ws.cell(row,h['가격정책']).value)
    old_normal=n(ws.cell(row,h['정상가']).value)
    old_sale=n(ws.cell(row,h['조정가']).value)
    old_base_policy=normalize_price_policy(ws.cell(row,h['기간종료후정책']).value)
    old_base_price=n(ws.cell(row,h['기간종료후가격']).value)
    if old_policy=='기간한정':
        base_policy=old_base_policy or ('정상가' if old_sale>=old_normal and old_normal>0 else '가격인하')
        base_price=old_base_price or (old_normal if base_policy=='정상가' else old_sale)
    else:
        base_policy=old_policy or ('정상가' if old_sale>=old_normal and old_normal>0 else '가격인하')
        base_price=old_normal if base_policy=='정상가' else old_sale
    return old_policy,old_normal,old_sale,base_policy,base_price


def _apply_policy_change_to_master_row(ws,row,h,rec,reference_date=None):
    """Apply one announced policy change while preserving a scheduled/active period overlay.

    R6 rule: 신규/추가/가격유지는 not trusted from the typed label. For every
    permanent 가격인하 row, the subtype is recalculated from the previous master
    baseline and the new 조정가. This also works behind an active 기간한정 overlay.
    """
    old_policy,old_normal,old_sale,base_policy,base_price=_master_baseline(ws,row,h)
    old_start=_master_date(ws.cell(row,h['행사시작일']).value)
    old_end=_master_date(ws.cell(row,h['행사종료일']).value)
    old_return_policy=normalize_price_policy(ws.cell(row,h['기간종료후정책']).value)
    old_return_price=n(ws.cell(row,h['기간종료후가격']).value)

    incoming_policy=normalize_price_policy(rec.get('policy'))
    incoming_normal=n(rec.get('normal')) or old_normal
    incoming_sale=n(rec.get('sale'))
    ref=reference_date or rec.get('apply_date') or datetime.now().date()
    if isinstance(ref,datetime): ref=ref.date()
    if not hasattr(ref,'year'): ref=datetime.now().date()

    had_existing=bool(old_policy or old_normal>0 or old_sale>0 or old_return_policy or old_return_price>0)
    decision=incoming_policy or ''
    if incoming_policy=='가격인하':
        decision=_infer_price_reduction_transition(
            base_policy,base_price,incoming_normal,incoming_sale or base_price,had_existing
        )

    preserve_period=(old_policy=='기간한정' and old_end is not None and ref <= old_end and incoming_policy in ('가격인하','정상가'))

    if rec.get('season'):
        ws.cell(row,h['구분']).value=rec['season']
    if rec.get('title_ko'):
        ws.cell(row,h['상품명']).value=rec['title_ko']
    if rec.get('title_en'):
        ws.cell(row,h['상품영문']).value=rec['title_en']
    if rec.get('normal_raw') not in (None,'') or rec.get('normal'):
        ws.cell(row,h['정상가']).value=rec.get('normal_raw') if rec.get('normal_raw') not in (None,'') else incoming_normal
    if rec.get('promo') not in (None,''):
        ws.cell(row,h['프로모션 내용']).value=rec.get('promo')

    raw_label=str(rec.get('raw_policy') or '').strip()
    typed_mismatch=(incoming_policy=='가격인하' and raw_label and raw_label not in ('가격인하','자동판정') and decision not in raw_label)
    typed_note=f" · 입력 '{raw_label}' → 마스터 기준 재판정" if typed_mismatch else ''
    note=''
    if incoming_policy=='기간한정':
        # Existing normal/price-reduction policy becomes the return baseline.
        if old_policy=='기간한정':
            return_policy=old_return_policy or base_policy
            return_price=old_return_price or base_price
        else:
            return_policy=base_policy
            return_price=base_price
        if not return_policy:
            candidate=incoming_sale or incoming_normal
            return_policy='정상가' if incoming_normal>0 and candidate>=incoming_normal else '가격인하'
            return_price=incoming_normal if return_policy=='정상가' else candidate
        ws.cell(row,h['가격정책']).value='기간한정'
        if incoming_sale>0:
            ws.cell(row,h['조정가']).value=rec.get('sale_raw') if rec.get('sale_raw') not in (None,'') else incoming_sale
        if rec.get('event_start') is not None: ws.cell(row,h['행사시작일']).value=rec['event_start']
        if rec.get('event_end') is not None: ws.cell(row,h['행사종료일']).value=rec['event_end']
        ws.cell(row,h['기간종료후정책']).value=return_policy
        ws.cell(row,h['기간종료후가격']).value=return_price
        decision='기간한정'
        note=f'기간한정 적용 · 종료후 {return_policy} {_money_text(return_price)}'
    elif preserve_period:
        # Do not cancel a temporary period-limited promotion. Change only its return baseline.
        if incoming_policy=='정상가':
            new_base_price=incoming_normal
            decision='정상가'
        else:
            new_base_price=incoming_sale or base_price or old_sale
        ws.cell(row,h['기간종료후정책']).value=incoming_policy
        ws.cell(row,h['기간종료후가격']).value=new_base_price
        if incoming_policy=='가격인하':
            note=f'자동판정: {decision}{typed_note} · 기간한정 유지 · 종료후 기준 {_money_text(base_price)} → {_money_text(new_base_price)}'
        else:
            note=f'기간한정 유지 · 종료후 정상가 {_money_text(new_base_price)}로 갱신'
    else:
        ws.cell(row,h['가격정책']).value=incoming_policy
        if incoming_policy=='정상가':
            ws.cell(row,h['조정가']).value=incoming_normal
            decision='정상가'
            note=f'정상가 기준정책 반영 · {_money_text(incoming_normal)}'
        elif incoming_policy=='가격인하':
            new_sale=incoming_sale or base_price or old_sale
            if new_sale>0: ws.cell(row,h['조정가']).value=rec.get('sale_raw') if rec.get('sale_raw') not in (None,'') else new_sale
            if decision=='가격 유지':
                note=f'자동판정: 가격 유지{typed_note} · {_money_text(new_sale)} 유지'
            else:
                before_price=base_price if base_price>0 else (old_sale if old_sale>0 else incoming_normal)
                note=f'자동판정: {decision}{typed_note} · {_money_text(before_price)} → {_money_text(new_sale)}'
        ws.cell(row,h['행사시작일']).value=None
        ws.cell(row,h['행사종료일']).value=None
        ws.cell(row,h['기간종료후정책']).value=None
        ws.cell(row,h['기간종료후가격']).value=None

    if '원본정책문구' in h: ws.cell(row,h['원본정책문구']).value=rec.get('raw_policy') or decision or incoming_policy
    if '최종동기화일' in h: ws.cell(row,h['최종동기화일']).value=datetime.now()
    if '원본파일' in h: ws.cell(row,h['원본파일']).value=str(rec.get('source_name') or '')
    return {
        'old_policy':old_policy,'old_price':old_sale,'old_start':old_start,'old_end':old_end,
        'new_policy':normalize_price_policy(ws.cell(row,h['가격정책']).value),
        'new_price':n(ws.cell(row,h['조정가']).value),
        'event_start':_master_date(ws.cell(row,h['행사시작일']).value),
        'event_end':_master_date(ws.cell(row,h['행사종료일']).value),
        'return_policy':normalize_price_policy(ws.cell(row,h['기간종료후정책']).value),
        'return_price':n(ws.cell(row,h['기간종료후가격']).value),
        'decision':decision,
        'note':note,
    }


def _ensure_required_master_columns(ws,header_row,h):
    required=['구분','품번','상품명','상품영문','정상가','조정가','프로모션 내용','가격정책','행사시작일','행사종료일','기간종료후정책','기간종료후가격','원본정책문구','최종동기화일','원본파일']
    for name in required:
        if name not in h:
            col=ws.max_column+1
            ws.cell(header_row,col).value=name
            h[name]=col
    return h


def _build_master_code_rows(ws,h,header_row):
    out={}
    for r in range(header_row+1,ws.max_row+1):
        code=clean_code(ws.cell(r,h['품번']).value)
        if code: out[code]=r
    return out


def _copy_previous_master_row_style(ws,row,header_row):
    if row-1 <= header_row: return
    for c in range(1,ws.max_column+1):
        src=ws.cell(row-1,c); dst=ws.cell(row,c)
        if src.has_style: dst._style=copy.copy(src._style)
        if src.number_format: dst.number_format=src.number_format
        if src.alignment: dst.alignment=copy.copy(src.alignment)
        if src.protection: dst.protection=copy.copy(src.protection)


def _price_master_pending_summary(master_path):
    """Count pending rows and distinguish future reservations from rows due today.

    R7: a 변경리스트 row with a future 적용일 stays pending and must not modify
    the live master until that local calendar date arrives.
    """
    path=Path(master_path)
    result={'pending':0,'changes':0,'period_edits':0,'due':0,'scheduled':0}
    if not path.exists(): return result
    wb=None
    today=datetime.now().date()
    try:
        wb=load_workbook(path,data_only=False,read_only=True)
        for sheet_name,status_header,bucket,max_cols in (
            (PRICE_CHANGE_INPUT_SHEET,'처리상태','changes',14),
            (PRICE_PERIOD_EDIT_SHEET,'처리상태','period_edits',7),
        ):
            if sheet_name not in wb.sheetnames: continue
            ws=wb[sheet_name]
            hdr=[str(v or '').strip() for v in next(ws.iter_rows(min_row=1,max_row=1,values_only=True),())]
            try: status_idx=hdr.index(status_header)
            except ValueError: status_idx=(11 if sheet_name==PRICE_CHANGE_INPUT_SHEET else 4)
            try: apply_idx=hdr.index('적용일') if sheet_name==PRICE_CHANGE_INPUT_SHEET else None
            except ValueError: apply_idx=0 if sheet_name==PRICE_CHANGE_INPUT_SHEET else None
            for row in ws.iter_rows(min_row=2,values_only=True):
                vals=list(row[:max_cols])
                if not any(str(v or '').strip() for v in vals): continue
                status=str(vals[status_idx] if status_idx < len(vals) else '' or '').strip()
                if status.startswith('처리완료'): continue
                result[bucket]+=1; result['pending']+=1
                if sheet_name==PRICE_CHANGE_INPUT_SHEET:
                    apply_date=_master_date(vals[apply_idx] if apply_idx is not None and apply_idx < len(vals) else None)
                    if apply_date and apply_date>today:
                        result['scheduled']+=1
                    else:
                        result['due']+=1
                else:
                    result['due']+=1
        return result
    finally:
        try:
            if wb is not None: wb.close()
        except Exception: pass


def _apply_live_price_master_inputs(trigger='자동동기화'):
    """Atomically consume pending rows from the protected live master itself."""
    global _PRICE_MASTER_AUTO_MTIME, _PRICE_MASTER_SCHEMA_READY
    ensure_price_master_file()
    if not PRICE_MASTER_FILE.exists():
        return {'processed':0,'errors':1,'added':0,'duplicates':0,'message':'실사용 가격정책 마스터가 없습니다.'}
    pending=_price_master_pending_summary(PRICE_MASTER_FILE)
    if not pending.get('pending'):
        try: _PRICE_MASTER_AUTO_MTIME=PRICE_MASTER_FILE.stat().st_mtime_ns
        except Exception: pass
        return {'processed':0,'errors':0,'added':0,'duplicates':0,'pending':0,'message':'처리할 변경행이 없습니다.'}
    if not _PRICE_MASTER_APPLY_LOCK.acquire(blocking=False):
        return {'processed':0,'errors':0,'added':0,'duplicates':0,'pending':pending['pending'],'message':'가격정책 마스터 적용 작업이 이미 진행 중입니다.'}
    tmp=DATA_DIR / 'price_policy_master_live_apply.tmp.xlsx'
    try:
        try:
            shutil.copy2(PRICE_MASTER_FILE,tmp)
        except PermissionError as exc:
            raise PermissionError('가격정책 마스터가 Excel에서 열려 있습니다. 저장 후 Excel을 닫고 다시 새로고침해 주세요.') from exc
        result=apply_price_master_embedded_inputs(tmp,f'폴더 실사용 마스터 · {trigger}')
        # Validate the processed copy before replacing the live source.
        test=load_workbook(tmp,data_only=False,read_only=True)
        try:
            ws,header_row,h=_find_master_sheet_and_headers(test,require_rows=True)
            required=('품번','상품명','상품영문','정상가','조정가','프로모션 내용','가격정책','행사시작일','행사종료일','기간종료후정책','기간종료후가격')
            missing=[x for x in required if x not in h]
            if missing: raise ValueError('필수 열 누락: '+', '.join(missing))
        finally:
            test.close()
        # Keep a rolling safety copy before live replacement.
        bdir=ROOT/'backups'/'price_master_live'
        bdir.mkdir(parents=True,exist_ok=True)
        stamp=datetime.now().strftime('%Y%m%d_%H%M%S')
        backup=bdir/f'TOPTEN_가격정책_마스터_before_{stamp}.xlsx'
        try: shutil.copy2(PRICE_MASTER_FILE,backup)
        except Exception: backup=None
        try:
            os.replace(tmp,PRICE_MASTER_FILE)
        except PermissionError as exc:
            raise PermissionError('가격정책 마스터가 Excel에서 열려 있어 결과를 저장할 수 없습니다. Excel을 완전히 닫고 새로고침해 주세요.') from exc
        _PRICE_MASTER_SCHEMA_READY=True
        _PRICE_MASTER_AUTO_MTIME=PRICE_MASTER_FILE.stat().st_mtime_ns
        msg=f"변경리스트 수동반영 완료 · 실제반영 {result.get('processed',0)}건"
        if result.get('duplicates'): msg+=f" · 중복 {result['duplicates']}건 정리"
        if result.get('added'): msg+=f" · 신규 품번 {result['added']}건"
        if result.get('errors'): msg+=f" · 확인필요 {result['errors']}건"
        _write_price_master_status({'ok':result.get('errors',0)==0,'message':msg,'source':PRICE_MASTER_FILE.name,'updated_at':datetime.now().isoformat(timespec='seconds')})
        result['message']=msg; result['backup']=str(backup) if backup else ''
        return result
    except Exception as exc:
        try:
            if tmp.exists(): tmp.unlink()
        except Exception: pass
        msg=f'변경리스트 수동반영 실패: {exc}'
        _write_price_master_status({'ok':False,'message':msg,'source':PRICE_MASTER_FILE.name,'updated_at':datetime.now().isoformat(timespec='seconds')})
        return {'processed':0,'errors':1,'added':0,'duplicates':0,'pending':pending.get('pending',0),'message':msg}
    finally:
        _PRICE_MASTER_APPLY_LOCK.release()


def _auto_apply_live_price_master_inputs():
    """Apply saved rows, including reservations that become due without an Excel re-save."""
    global _PRICE_MASTER_AUTO_MTIME
    ensure_price_master_file()
    if not PRICE_MASTER_FILE.exists(): return None
    try: mtime=PRICE_MASTER_FILE.stat().st_mtime_ns
    except Exception: return None
    pending=_price_master_pending_summary(PRICE_MASTER_FILE)
    if not pending.get('pending'):
        _PRICE_MASTER_AUTO_MTIME=mtime
        return None
    # If the workbook itself did not change, re-enter only when a reserved row has
    # reached its 적용일. This is what makes a list pasted days early turn on by date.
    if _PRICE_MASTER_AUTO_MTIME == mtime and not pending.get('due'):
        return None
    result=_apply_live_price_master_inputs('적용일 자동판정' if pending.get('due') else '저장후 새로고침')
    # On failure (most commonly Excel still holding the file), do not memorize mtime;
    # a later request after Excel closes will retry automatically.
    if result.get('errors'):
        _PRICE_MASTER_AUTO_MTIME=None
    return result



def _repair_premature_future_rows_r8_once():
    """One-time R8 migration for rows that R6 may have applied before their 적용일.

    R6 consumed every pending row immediately. R7 added the future-date gate, but a row
    already marked 처리완료 by R6 was no longer revisited. R8 restores the state recorded
    in 변경이력, changes those future input rows back to 예약대기, and then switches the
    product to button-only processing.
    """
    if PRICE_MASTER_R8_MIGRATION_FILE.exists():
        return {'repaired':0,'skipped':0,'already':True}
    if not PRICE_MASTER_FILE.exists():
        return {'repaired':0,'skipped':0,'no_master':True}
    wb=None
    tmp=DATA_DIR/'price_policy_r8_future_repair.tmp.xlsx'
    today=datetime.now().date()
    repaired=0; skipped=0
    try:
        wb=load_workbook(PRICE_MASTER_FILE)
        _ensure_price_master_workflow_schema_in_wb(wb)
        ws,header_row,h=_find_master_sheet_and_headers(wb)
        h=_ensure_required_master_columns(ws,header_row,h)
        code_rows=_build_master_code_rows(ws,h,header_row)
        cws=wb[PRICE_CHANGE_INPUT_SHEET]; ch=_master_header_map(cws,1)
        hist=wb[PRICE_HISTORY_SHEET]; hh=_master_header_map(hist,1)

        # Build history candidates. Process future inputs newest first so chained
        # reductions (10/01 then 10/15) unwind cleanly back to today's real state.
        hist_by_key={}
        for hr in range(2,hist.max_row+1):
            code=clean_code(hist.cell(hr,hh.get('품번',5)).value)
            ad=_master_date(hist.cell(hr,hh.get('적용일',2)).value)
            if code and ad and ad>today:
                hist_by_key.setdefault((code,ad),[]).append(hr)
        candidates=[]
        for r in range(2,cws.max_row+1):
            code=clean_code(cws.cell(r,ch.get('품번',3)).value)
            ad=_master_date(cws.cell(r,ch.get('적용일',1)).value)
            status=str(cws.cell(r,ch.get('처리상태',12)).value or '').strip()
            if code and ad and ad>today and status.startswith('처리완료'):
                candidates.append((ad,r,code))
        candidates.sort(key=lambda x:(x[0],x[1]),reverse=True)
        used_hist=set()

        for ad,r,code in candidates:
            mr=code_rows.get(code)
            hrs=[x for x in hist_by_key.get((code,ad),[]) if x not in used_hist]
            if mr is None or not hrs:
                cws.cell(r,ch.get('처리상태',12)).value='예약대기'
                cws.cell(r,ch.get('처리일',13)).value=None
                cws.cell(r,ch.get('처리메모',14)).value=f'R8 예약복구: {ad.isoformat()} 적용 예정 · 과거이력 미확인으로 현재 마스터 값은 유지'
                skipped+=1
                continue
            # The latest matching history row belongs to the latest processing of this input.
            hr=max(hrs); used_hist.add(hr)
            # Safety: if a later history entry for the same SKU has already become effective
            # today/past, do not roll that legitimate later state backward automatically.
            later_due=False
            for lhr in range(hr+1,hist.max_row+1):
                if clean_code(hist.cell(lhr,hh.get('품번',5)).value)!=code:
                    continue
                lad=_master_date(hist.cell(lhr,hh.get('적용일',2)).value)
                ltype=str(hist.cell(lhr,hh.get('작업유형',3)).value or '').strip()
                if ltype.startswith('R8 '):
                    continue
                if lad is None or lad<=today:
                    later_due=True; break
            if later_due:
                cws.cell(r,ch.get('처리상태',12)).value='예약대기'
                cws.cell(r,ch.get('처리일',13)).value=None
                cws.cell(r,ch.get('처리메모',14)).value=f'R8 예약복구 확인필요 · {ad.isoformat()} 이전 조기반영 뒤 다른 현재/과거 변경이 있어 자동롤백 보류'
                skipped+=1
                continue
            old_policy=normalize_price_policy(hist.cell(hr,hh.get('이전정책',7)).value)
            old_price=n(hist.cell(hr,hh.get('이전가격',8)).value)
            current_policy=normalize_price_policy(ws.cell(mr,h['가격정책']).value)
            current_price=n(ws.cell(mr,h['조정가']).value)

            if old_policy and old_policy!='기간한정':
                ws.cell(mr,h['가격정책']).value=old_policy
                if old_price>0: ws.cell(mr,h['조정가']).value=old_price
                ws.cell(mr,h['행사시작일']).value=None
                ws.cell(mr,h['행사종료일']).value=None
                ws.cell(mr,h['기간종료후정책']).value=None
                ws.cell(mr,h['기간종료후가격']).value=None
            elif old_policy=='기간한정':
                # A future permanent reduction behind an already active period overlay changes
                # only the return baseline. Recover that baseline from the previous history row.
                prev_rows=[]
                for phr in range(2,hr):
                    if clean_code(hist.cell(phr,hh.get('품번',5)).value)==code:
                        prev_rows.append(phr)
                prev=prev_rows[-1] if prev_rows else None
                if prev:
                    rp=normalize_price_policy(hist.cell(prev,hh.get('기간종료후정책',13)).value)
                    rv=n(hist.cell(prev,hh.get('기간종료후가격',14)).value)
                    if rp: ws.cell(mr,h['기간종료후정책']).value=rp
                    if rv>0: ws.cell(mr,h['기간종료후가격']).value=rv
                # Keep the active period price/policy itself untouched.
            else:
                skipped+=1

            if '원본정책문구' in h: ws.cell(mr,h['원본정책문구']).value=f'R8 미래 적용 예약 복구 · {ad.isoformat()}'
            if '최종동기화일' in h: ws.cell(mr,h['최종동기화일']).value=datetime.now()
            if '원본파일' in h: ws.cell(mr,h['원본파일']).value='R8 미래 적용 조기반영 복구'
            cws.cell(r,ch.get('처리상태',12)).value='예약대기'
            cws.cell(r,ch.get('처리일',13)).value=None
            cws.cell(r,ch.get('처리메모',14)).value=f'R8 복구완료 · {ad.isoformat()} 이후 수동반영 버튼에서 자동판정'
            _history_append(hist,[
                datetime.now(),None,'R8 미래적용 롤백',ws.cell(mr,h['구분']).value,code,ws.cell(mr,h['상품명']).value,
                current_policy,current_price,normalize_price_policy(ws.cell(mr,h['가격정책']).value),n(ws.cell(mr,h['조정가']).value),
                _master_date(ws.cell(mr,h['행사시작일']).value),_master_date(ws.cell(mr,h['행사종료일']).value),
                normalize_price_policy(ws.cell(mr,h['기간종료후정책']).value),n(ws.cell(mr,h['기간종료후가격']).value),
                'R6/R7 이전 조기반영 자동복구','R8 migration',f'{ad.isoformat()} 미래 적용행을 예약대기로 되돌림'
            ])
            repaired+=1

        # Save only when something was actually changed; keep a safety backup either way when candidates exist.
        if candidates:
            bdir=ROOT/'backups'/'price_master_r8_migration'; bdir.mkdir(parents=True,exist_ok=True)
            stamp=datetime.now().strftime('%Y%m%d_%H%M%S')
            backup=bdir/f'TOPTEN_가격정책_마스터_before_R8_{stamp}.xlsx'
            shutil.copy2(PRICE_MASTER_FILE,backup)
            wb.save(tmp); wb.close(); wb=None
            os.replace(tmp,PRICE_MASTER_FILE)
        marker={
            'applied_at':datetime.now().isoformat(timespec='seconds'),'today':today.isoformat(),
            'future_completed_found':len(candidates),'repaired':repaired,'skipped':skipped,
            'mode':'button_only'
        }
        PRICE_MASTER_R8_MIGRATION_FILE.write_text(json.dumps(marker,ensure_ascii=False,indent=2),encoding='utf-8')
        if candidates:
            _write_price_master_status({
                'ok':skipped==0,
                'message':f'R8 미래 적용 조기반영 복구 · 예약복구 {repaired}건'+(f' · 확인필요 {skipped}건' if skipped else ''),
                'source':PRICE_MASTER_FILE.name,'updated_at':datetime.now().isoformat(timespec='seconds')
            })
        return marker
    except PermissionError as exc:
        # Do not write the marker so next launch retries after Excel is closed.
        try:
            if wb is not None: wb.close()
        except Exception: pass
        try:
            if tmp.exists(): tmp.unlink()
        except Exception: pass
        _write_price_master_status({'ok':False,'message':'R8 예약복구 보류: 가격정책 마스터 Excel을 닫고 프로그램을 다시 실행해 주세요.','source':PRICE_MASTER_FILE.name,'updated_at':datetime.now().isoformat(timespec='seconds')})
        return {'repaired':0,'skipped':0,'retry':True,'error':str(exc)}
    except Exception as exc:
        try:
            if wb is not None: wb.close()
        except Exception: pass
        try:
            if tmp.exists(): tmp.unlink()
        except Exception: pass
        _write_price_master_status({'ok':False,'message':f'R8 미래 적용 예약복구 실패: {exc}','source':PRICE_MASTER_FILE.name,'updated_at':datetime.now().isoformat(timespec='seconds')})
        return {'repaired':0,'skipped':0,'error':str(exc)}
    finally:
        try:
            if wb is not None: wb.close()
        except Exception: pass


def apply_price_master_embedded_inputs(master_path, source_name=''):
    """Consume unprocessed rows from 변경리스트_입력 / 행사기간_수정 inside a master file."""
    wb=load_workbook(master_path)
    _ensure_price_master_workflow_schema_in_wb(wb)
    ws,header_row,h=_find_master_sheet_and_headers(wb)
    h=_ensure_required_master_columns(ws,header_row,h)
    code_rows=_build_master_code_rows(ws,h,header_row)
    hist=wb[PRICE_HISTORY_SHEET]
    now=datetime.now()
    processed=0; errors=0; added=0; duplicates=0
    seen_change_inputs={}
    seen_period_inputs={}

    cws=wb[PRICE_CHANGE_INPUT_SHEET]
    ch=_master_header_map(cws,1)
    for r in range(2,cws.max_row+1):
        code=clean_code(cws.cell(r,ch.get('품번',3)).value)
        row_has_any=any(str(cws.cell(r,c).value or '').strip() for c in range(1,min(cws.max_column,14)+1))
        if not row_has_any: continue
        status=str(cws.cell(r,ch.get('처리상태',12)).value or '').strip()
        if status.startswith('처리완료'): continue
        if not code:
            cws.cell(r,ch.get('처리상태',12)).value='오류'; cws.cell(r,ch.get('처리메모',14)).value='품번 없음'; errors+=1; continue
        raw=str(cws.cell(r,ch.get('정책/변경내용',9)).value or '').strip()
        row=code_rows.get(code)
        input_normal=n(cws.cell(r,ch.get('정상가',6)).value)
        input_sale=n(cws.cell(r,ch.get('조정가',7)).value)
        existing_normal=n(ws.cell(row,h['정상가']).value) if row is not None else 0
        effective_normal=input_normal or existing_normal
        event_start=_master_date(cws.cell(r,ch.get('행사시작일',10)).value)
        event_end=_master_date(cws.cell(r,ch.get('행사종료일',11)).value)
        auto_request=_is_auto_policy_request(raw)
        policy=normalize_price_policy(raw)
        if auto_request:
            if event_start or event_end:
                cws.cell(r,ch.get('처리상태',12)).value='오류'; cws.cell(r,ch.get('처리메모',14)).value='기간한정은 정책/변경내용에 기간한정을 선택해 주세요.'; errors+=1; continue
            policy=_infer_policy_from_prices(effective_normal,input_sale)
            if not policy:
                cws.cell(r,ch.get('처리상태',12)).value='오류'; cws.cell(r,ch.get('처리메모',14)).value='자동판정은 정상가와 새 조정가가 필요합니다.'; errors+=1; continue
            raw='자동판정'
        if not policy:
            cws.cell(r,ch.get('처리상태',12)).value='오류'; cws.cell(r,ch.get('처리메모',14)).value='정책/변경내용 확인 필요'; errors+=1; continue
        if policy=='기간한정' and (not event_start or not event_end):
            cws.cell(r,ch.get('처리상태',12)).value='오류'; cws.cell(r,ch.get('처리메모',14)).value='기간한정은 시작일/종료일 필수'; errors+=1; continue
        if event_start and event_end and event_start > event_end:
            cws.cell(r,ch.get('처리상태',12)).value='오류'; cws.cell(r,ch.get('처리메모',14)).value='행사 시작일이 종료일보다 늦음'; errors+=1; continue
        apply_date=_master_date(cws.cell(r,ch.get('적용일',1)).value)
        # R7 effective-date gate: valid future rows are stored as reservations only.
        # They are re-evaluated automatically on/after 적용일, even if the workbook
        # has not been edited again. No master row is created/changed before then.
        if apply_date and apply_date > datetime.now().date():
            cws.cell(r,ch.get('처리상태',12)).value='예약대기'
            cws.cell(r,ch.get('처리일',13)).value=None
            cws.cell(r,ch.get('처리메모',14)).value=f'{apply_date.isoformat()} 00:00부터 자동판정/반영 예정'
            continue
        promo_text=str(cws.cell(r,ch.get('프로모션 내용',8)).value or '').strip()
        dedupe_key=(code,apply_date,policy,effective_normal,input_sale,event_start,event_end,promo_text)
        if dedupe_key in seen_change_inputs:
            first_row=seen_change_inputs[dedupe_key]
            cws.cell(r,ch.get('처리상태',12)).value='처리완료(중복)'
            cws.cell(r,ch.get('처리일',13)).value=now
            cws.cell(r,ch.get('처리메모',14)).value=f'동일 입력 중복 · {first_row}행 적용값 사용'
            duplicates+=1
            continue
        seen_change_inputs[dedupe_key]=r
        if row is None:
            row=ws.max_row+1; code_rows[code]=row; added+=1
            _copy_previous_master_row_style(ws,row,header_row)
            ws.cell(row,h['품번']).value=code
        rec={
            'season':str(cws.cell(r,ch.get('구분',2)).value or '').strip(),
            'code':code,
            'title_ko':str(cws.cell(r,ch.get('상품명',4)).value or '').strip(),
            'title_en':str(cws.cell(r,ch.get('상품영문',5)).value or '').strip(),
            'normal_raw':cws.cell(r,ch.get('정상가',6)).value,
            'sale_raw':cws.cell(r,ch.get('조정가',7)).value,
            'normal':effective_normal,
            'sale':input_sale,
            'promo':str(cws.cell(r,ch.get('프로모션 내용',8)).value or '').strip(),
            'policy':policy,'raw_policy':raw,
            'event_start':event_start,'event_end':event_end,
            'apply_date':apply_date,
            'source_name':source_name or Path(master_path).name,
        }
        result=_apply_policy_change_to_master_row(ws,row,h,rec,reference_date=rec['apply_date'])
        _history_append(hist,[
            now,rec['apply_date'],result.get('decision') or raw or policy,ws.cell(row,h['구분']).value,code,ws.cell(row,h['상품명']).value,
            result['old_policy'],result['old_price'],result['new_policy'],result['new_price'],
            result['event_start'],result['event_end'],result['return_policy'],result['return_price'],
            raw,source_name or Path(master_path).name,result['note']
        ])
        cws.cell(r,ch.get('처리상태',12)).value='처리완료'
        cws.cell(r,ch.get('처리일',13)).value=now
        cws.cell(r,ch.get('처리메모',14)).value=result['note']
        processed+=1

    pws=wb[PRICE_PERIOD_EDIT_SHEET]
    ph=_master_header_map(pws,1)
    for r in range(2,pws.max_row+1):
        code=clean_code(pws.cell(r,ph.get('품번',1)).value)
        row_has_any=any(str(pws.cell(r,c).value or '').strip() for c in range(1,min(pws.max_column,7)+1))
        if not row_has_any: continue
        status=str(pws.cell(r,ph.get('처리상태',5)).value or '').strip()
        if status.startswith('처리완료'): continue
        if not code or code not in code_rows:
            pws.cell(r,ph.get('처리상태',5)).value='오류'; pws.cell(r,ph.get('처리메모',7)).value='마스터에서 품번을 찾지 못함'; errors+=1; continue
        mr=code_rows[code]
        if normalize_price_policy(ws.cell(mr,h['가격정책']).value)!='기간한정':
            pws.cell(r,ph.get('처리상태',5)).value='오류'; pws.cell(r,ph.get('처리메모',7)).value='현재 기간한정 품번이 아님'; errors+=1; continue
        old_s=_master_date(ws.cell(mr,h['행사시작일']).value); old_e=_master_date(ws.cell(mr,h['행사종료일']).value)
        new_s=_master_date(pws.cell(r,ph.get('새 행사시작일',2)).value) or old_s
        new_e=_master_date(pws.cell(r,ph.get('새 행사종료일',3)).value) or old_e
        if not new_s or not new_e:
            pws.cell(r,ph.get('처리상태',5)).value='오류'; pws.cell(r,ph.get('처리메모',7)).value='수정할 행사기간이 없음'; errors+=1; continue
        if new_s>new_e:
            pws.cell(r,ph.get('처리상태',5)).value='오류'; pws.cell(r,ph.get('처리메모',7)).value='새 시작일이 종료일보다 늦음'; errors+=1; continue
        reason=str(pws.cell(r,ph.get('변경사유',4)).value or '').strip()
        dedupe_key=(code,new_s,new_e,reason)
        if dedupe_key in seen_period_inputs:
            first_row=seen_period_inputs[dedupe_key]
            pws.cell(r,ph.get('처리상태',5)).value='처리완료(중복)'
            pws.cell(r,ph.get('처리일',6)).value=now
            pws.cell(r,ph.get('처리메모',7)).value=f'동일 기간수정 중복 · {first_row}행 적용값 사용'
            duplicates+=1
            continue
        seen_period_inputs[dedupe_key]=r
        ws.cell(mr,h['행사시작일']).value=new_s; ws.cell(mr,h['행사종료일']).value=new_e
        if '최종동기화일' in h: ws.cell(mr,h['최종동기화일']).value=now
        if '원본파일' in h: ws.cell(mr,h['원본파일']).value=source_name or Path(master_path).name
        note=f'행사기간 {old_s or "-"}~{old_e or "-"} → {new_s}~{new_e}'
        _history_append(hist,[
            now,None,'행사기간 수정',ws.cell(mr,h['구분']).value,code,ws.cell(mr,h['상품명']).value,
            '기간한정',n(ws.cell(mr,h['조정가']).value),'기간한정',n(ws.cell(mr,h['조정가']).value),
            new_s,new_e,normalize_price_policy(ws.cell(mr,h['기간종료후정책']).value),n(ws.cell(mr,h['기간종료후가격']).value),
            reason,source_name or Path(master_path).name,note
        ])
        pws.cell(r,ph.get('처리상태',5)).value='처리완료'; pws.cell(r,ph.get('처리일',6)).value=now; pws.cell(r,ph.get('처리메모',7)).value=note
        processed+=1

    # Expand main master table if present; input tables are intentionally left as fixed entry grids.
    try:
        for table in ws.tables.values():
            table.ref=f'A{header_row}:{get_column_letter(ws.max_column)}{ws.max_row}'
            break
    except Exception:
        pass
    wb.save(master_path); wb.close()
    return {'processed':processed,'errors':errors,'added':added,'duplicates':duplicates}


def sync_price_master_from_xlsx(source_path, source_name=''):
    """Merge only announced HQ changes into the persistent master, never deleting old SKUs."""
    global _PRICE_MASTER_SCHEMA_READY
    ensure_price_master_file()
    if not PRICE_MASTER_FILE.exists():
        raise FileNotFoundError('가격정책 마스터 파일이 없습니다.')
    changes,date_range=_extract_price_policy_sync_rows(source_path,source_name)
    if not changes:
        raise ValueError('업로드 파일에서 가격정책 변경 품번을 찾지 못했습니다.')
    wb=load_workbook(PRICE_MASTER_FILE)
    _ensure_price_master_workflow_schema_in_wb(wb)
    ws,header_row,h=_find_master_sheet_and_headers(wb)
    h=_ensure_required_master_columns(ws,header_row,h)
    code_rows=_build_master_code_rows(ws,h,header_row)
    hist=wb[PRICE_HISTORY_SHEET]
    updated=0; added=0; now=datetime.now()
    for rec in changes:
        code=rec['code']
        row=code_rows.get(code)
        if row is None:
            row=ws.max_row+1; code_rows[code]=row; added+=1
            _copy_previous_master_row_style(ws,row,header_row)
            ws.cell(row,h['품번']).value=code
        rec['source_name']=str(source_name or Path(source_path).name)
        result=_apply_policy_change_to_master_row(ws,row,h,rec)
        _history_append(hist,[
            now,None,result.get('decision') or rec.get('raw_policy') or rec.get('policy'),ws.cell(row,h['구분']).value,code,ws.cell(row,h['상품명']).value,
            result['old_policy'],result['old_price'],result['new_policy'],result['new_price'],result['event_start'],result['event_end'],
            result['return_policy'],result['return_price'],rec.get('raw_policy') or rec.get('policy'),rec['source_name'],result['note']
        ])
        updated+=1
    try:
        for table in ws.tables.values():
            table.ref=f'A{header_row}:{get_column_letter(ws.max_column)}{ws.max_row}'
            break
    except Exception:
        pass
    tmp=PRICE_MASTER_FILE.with_suffix('.tmp.xlsx')
    wb.save(tmp); wb.close(); os.replace(tmp,PRICE_MASTER_FILE)
    _PRICE_MASTER_SCHEMA_READY=True
    status={
        'ok':True,'message':f'{updated}개 변경 품번 자동동기화 완료' + (f' · 신규 {added}개' if added else ''),
        'updated':updated,'added':added,'date_range':date_range,
        'source':str(source_name or Path(source_path).name),'updated_at':now.isoformat(timespec='seconds')
    }
    _write_price_master_status(status)
    return status


def find_price_policy_column(rows, header_idx, header_values, code_col):
    """Find the price-policy column by CONTENT, not by a fixed Excel letter.

    This allows Q -> S -> W etc. on future promotion sheets. The winning column is
    the one with the most recognized policy cells and the richest policy variety.
    """
    if header_idx is None or not rows:
        return None, ''
    max_cols = max((len(r) for r in rows[: min(len(rows), header_idx + 400)]), default=0)
    candidates=[]
    policy_header_words=('가격정책','가격 정책','정책구분','가격구분','운영구분','가격운영','가격유형')
    for c in range(max_cols):
        recognized=0; nonempty=0; kinds=set()
        for row in rows[header_idx+1: header_idx+401]:
            if code_col is not None:
                code = clean_code(row[code_col] if code_col < len(row) else '')
                if not code:
                    continue
            v = row[c] if c < len(row) else None
            if str(v or '').strip(): nonempty += 1
            pol=normalize_price_policy(v)
            if pol:
                recognized += 1; kinds.add(pol)
        header=str(header_values[c] if c < len(header_values) else '').strip()
        header_compact=re.sub(r'\s+','',header)
        header_bonus=25 if any(re.sub(r'\s+','',w) in header_compact for w in policy_header_words) else 0
        # Require evidence from actual item rows unless the header is explicit.
        if recognized < 2 and not header_bonus:
            continue
        ratio = recognized / max(1, nonempty)
        score = recognized * 6 + len(kinds) * 18 + int(ratio * 20) + header_bonus
        candidates.append((score, recognized, len(kinds), ratio, -c, c, header))
    if not candidates:
        return None, ''
    candidates.sort(reverse=True)
    best=candidates[0]
    return best[5], (best[6] or f'{best[5]+1}열')



def build_workbook_price_policy_map(wb):
    """Build a SKU -> normalized policy map from every worksheet.

    Future files may move the policy column or use a helper sheet. We therefore scan
    every sheet for a style-code column and a content-detected policy column instead
    of trusting Q (or any fixed letter). Direct explicit policy text wins.
    """
    result={}
    source={}
    for ws in wb.worksheets:
        try:
            rows=list(ws.iter_rows(values_only=True))
        except Exception:
            continue
        header_idx=None; header_values=[]; code_col=None
        for ridx,row in enumerate(rows[:50]):
            vals=[str(v or '').strip() for v in row]
            for code_name in ('스타일','품번'):
                if code_name in vals:
                    header_idx=ridx; header_values=vals; code_col=vals.index(code_name); break
            if header_idx is not None: break
        if header_idx is None or code_col is None:
            # Helper sheets often have no official header. Find the column with the
            # most style-code-looking values and then scan each row for policy text.
            max_cols=max((len(r) for r in rows[:500]),default=0)
            best=None
            for c in range(max_cols):
                hits=sum(1 for row in rows[:500] if c < len(row) and re.fullmatch(r'[A-Z]{3}\d[A-Z]{2}\d{4}', clean_code(row[c])))
                if best is None or hits>best[0]: best=(hits,c)
            if not best or best[0] < 3: continue
            code_col=best[1]; header_idx=0; header_values=['']*max_cols
        policy_col,policy_name=find_price_policy_column(rows,header_idx,header_values,code_col)
        for row in rows[header_idx+1:]:
            code=clean_code(row[code_col] if code_col < len(row) else '')
            if not re.fullmatch(r'[A-Z]{3}\d[A-Z]{2}\d{4}',code): continue
            pol=''; raw=''
            if policy_col is not None and policy_col < len(row):
                raw=str(row[policy_col] or '').strip(); pol=normalize_price_policy(raw)
            if not pol:
                # Row-level fallback catches moved/merged columns without forcing a letter.
                for v in row:
                    cand=normalize_price_policy(v)
                    if cand:
                        pol=cand; raw=str(v or '').strip(); break
            if pol:
                result[code]=pol
                source[code]=f'{ws.title}:{policy_name or (str(policy_col+1)+"열" if policy_col is not None else "행검색")}:{raw}'
    return result,source

# TOPTEN manual product-category table (품종 대/소) supplied by store manual.
# The large-category code is directly usable as a hard matching rail.  In TOPTEN style
# codes seen in this project, the first alphabetic letter after the season digit is the
# manual large-category code (e.g. MSG2TS1002 -> T, MBG5PT1906 -> P).  The following
# letter is NOT assumed to be the manual small-category code; small category is inferred
# from the Korean/English product wording instead.
BREED_LARGE_LABELS = {
    'J':'점퍼','C':'코트','K':'자켓','V':'조끼','L':'레더','W':'우븐 셔츠',
    'T':'니트 셔츠','E':'스웨터','O':'원피스','P':'팬츠','D':'데님','R':'스커트',
    'U':'언더웨어','A':'소품(ACC)'
}
BREED_SMALL_LABELS = {
    'J': {'J':'점퍼','P':'패딩점퍼'},
    'C': {'G':'싱글코트','B':'더블코트'},
    'K': {'G':'싱글자켓','B':'더블자켓','P':'패딩자켓'},
    'V': {'P':'패딩 베스트'},
    'L': {'K':'가죽자켓','J':'가죽점퍼','V':'가죽조끼'},
    'W': {'C':'캐주얼셔츠','B':'블라우스'},
    'T': {'C':'오픈형(CARDIGAN)','R':'라운드','V':'V-넥','T':'T-에리','L':'민소매','H':'후드T','S':'VEST'},
    'E': {'C':'오픈형(CARDIGAN)','R':'라운드','V':'V-넥','T':'T-에리','L':'민소매','S':'VEST'},
    'O': {'O':'원피스'},
    'P': {'P':'팬츠(일반)','H':'반바지'},
    'D': {'P':'데님팬츠','H':'데님반바지','S':'데님스커트'},
    'R': {'L':'Long 스커트','S':'Short 스커트'},
    'U': {'T':'TOP','P':'BOTTOM'},
    'A': {'B':'가방','L':'벨트','C':'모자','S':'신발','T':'타이','M':'머플러','F':'스카프','V':'장갑','P':'지갑','J':'쥬얼리','Y':'양말','Z':'기타'},
}
BREED_LARGE_CODES = set(BREED_LARGE_LABELS)


def _breed_large_from_style_code(code):
    """Read the manual 품종 대 code from a TOPTEN style code when structurally clear.

    Examples from the user's real files:
      MSG2TS1002 -> T (니트 셔츠)
      MBG5PT1906 -> P (팬츠)
    Only the large category is decoded from SKU.  Small category is never guessed from
    the second letter because the supplied manual does not establish that mapping.
    """
    c=clean_code(code)
    m=re.search(r'\d([JCKVLWTEOPDRUA])[A-Z]\d{4}$',c)
    return m.group(1) if m and m.group(1) in BREED_LARGE_CODES else ''


def _breed_text_blob(text):
    return ' '.join(str(text or '').upper().replace('_',' ').split())


def _breed_category_from_text(text):
    """Infer manual 품종 대/소 candidates from visible Korean/English wording.

    Returns candidate large codes because some words (notably CARDIGAN/VEST) are shared
    by 니트 셔츠(T) and 스웨터(E).  Ambiguous wording is intentionally kept ambiguous
    rather than forced into one category.
    """
    raw=_breed_text_blob(text)
    compact=re.sub(r'\s+','',raw)
    large=[]; small=[]; evidence=[]
    def add_large(*codes):
        for c in codes:
            if c in BREED_LARGE_CODES and c not in large: large.append(c)
    def add_small(code):
        if code and code not in small: small.append(code)

    # ACC first: these nouns are highly specific and should not be confused with apparel.
    acc_rules=[
        ('B',(r'가방',r'백(?:\s|$)',r'\bBAG\b')),('L',(r'벨트',r'\bBELT\b')),
        ('C',(r'모자',r'캡(?:\s|$)',r'\bHAT\b',r'\bCAP\b')),('S',(r'신발',r'슈즈',r'\bSHOES?\b',r'\bSNEAKERS?\b')),
        ('T',(r'넥타이',r'\bTIE\b')),('M',(r'머플러',r'\bMUFFLER\b')),('F',(r'스카프',r'\bSCARF\b')),
        ('V',(r'장갑',r'\bGLOVES?\b')),('P',(r'지갑',r'\bWALLET\b')),('J',(r'쥬얼리',r'주얼리',r'\bJEWELRY\b',r'\bJEWELLERY\b')),
        ('Y',(r'양말',r'\bSOCKS?\b')),
    ]
    for sc,pats in acc_rules:
        if any(re.search(p,raw,re.I) for p in pats):
            add_large('A'); add_small(sc); evidence.append(BREED_SMALL_LABELS['A'][sc]); return {'large':large,'small':small,'evidence':evidence,'strength':3}

    # Leather outranks generic jacket/jumper/vest.
    if re.search(r'가죽|레더|\bLEATHER\b',raw,re.I):
        add_large('L'); evidence.append('레더/가죽')
        if re.search(r'자켓|재킷|\bJACKET\b|\bBLAZER\b',raw,re.I): add_small('K')
        elif re.search(r'점퍼|\bJUMPER\b',raw,re.I): add_small('J')
        elif re.search(r'조끼|\bVEST\b',raw,re.I): add_small('V')
        return {'large':large,'small':small,'evidence':evidence,'strength':3}

    # Denim outranks generic pants/skirt.
    if re.search(r'데님|\bDENIM\b|\bJEANS?\b',raw,re.I):
        add_large('D'); evidence.append('데님')
        if re.search(r'스커트|\bSKIRT\b',raw,re.I): add_small('S')
        elif re.search(r'반바지|쇼츠|숏팬츠|\bSHORTS?\b',raw,re.I): add_small('H')
        elif re.search(r'팬츠|바지|\bPANTS?\b|\bTROUSERS?\b|\bJEANS?\b',raw,re.I): add_small('P')
        return {'large':large,'small':small,'evidence':evidence,'strength':3}

    # Underwear.
    if re.search(r'언더웨어|속옷|\bUNDERWEAR\b|\bBRA\b|브라|팬티|드로즈|\bBRIEFS?\b|\bBOXERS?\b',raw,re.I):
        add_large('U'); evidence.append('언더웨어')
        if re.search(r'브라|브라탑|캐미|\bBRA\b|\bTOP\b',raw,re.I): add_small('T')
        if re.search(r'팬티|드로즈|\bBRIEFS?\b|\bBOXERS?\b|\bBOTTOM\b',raw,re.I): add_small('P')
        return {'large':large,'small':small,'evidence':evidence,'strength':3}

    # One-piece.
    if re.search(r'원피스|\bONE\s*PIECE\b|\bDRESS\b',raw,re.I):
        return {'large':['O'],'small':['O'],'evidence':['원피스'],'strength':3}

    # Coat / jumper / jacket / padded vest.
    if re.search(r'코트|\bCOAT\b',raw,re.I):
        add_large('C'); evidence.append('코트')
        if re.search(r'더블|\bDOUBLE\b',raw,re.I): add_small('B')
        elif re.search(r'싱글|\bSINGLE\b',raw,re.I): add_small('G')
        return {'large':large,'small':small,'evidence':evidence,'strength':3}
    if re.search(r'패딩\s*(?:베스트|조끼)|(?:베스트|조끼).*패딩|\bPADDED\s+VEST\b|\bPUFFER\s+VEST\b',raw,re.I):
        return {'large':['V'],'small':['P'],'evidence':['패딩 베스트'],'strength':3}
    if re.search(r'점퍼|\bJUMPER\b|\bBLOUSON\b',raw,re.I):
        add_large('J'); evidence.append('점퍼')
        if re.search(r'패딩|푸퍼|\bPADDED\b|\bPUFFER\b',raw,re.I): add_small('P')
        else: add_small('J')
        return {'large':large,'small':small,'evidence':evidence,'strength':3}
    if re.search(r'자켓|재킷|\bJACKET\b|\bBLAZER\b',raw,re.I):
        add_large('K'); evidence.append('자켓')
        if re.search(r'패딩|푸퍼|\bPADDED\b|\bPUFFER\b',raw,re.I): add_small('P')
        elif re.search(r'더블|\bDOUBLE\b',raw,re.I): add_small('B')
        elif re.search(r'싱글|\bSINGLE\b',raw,re.I): add_small('G')
        return {'large':large,'small':small,'evidence':evidence,'strength':3}

    # Woven shirt. Avoid T-shirt/tee wording.
    if re.search(r'블라우스|\bBLOUSE\b',raw,re.I):
        return {'large':['W'],'small':['B'],'evidence':['블라우스'],'strength':3}
    if re.search(r'우븐\s*셔츠|캐주얼\s*셔츠|\bWOVEN\s+SHIRT\b|\bCASUAL\s+SHIRT\b',raw,re.I):
        return {'large':['W'],'small':['C'],'evidence':['우븐/캐주얼 셔츠'],'strength':3}
    if ('셔츠' in raw or re.search(r'\bSHIRT\b',raw,re.I)) and not re.search(r'티셔츠|T\s*-?\s*SHIRT|TEE',raw,re.I):
        add_large('W'); add_small('C'); evidence.append('셔츠'); return {'large':large,'small':small,'evidence':evidence,'strength':2}

    # Sweater / knit-shirt family. CARDIGAN and VEST are shared by T/E in the manual.
    explicit_sweater=bool(re.search(r'스웨터|\bSWEATER\b|\bPULLOVER\b',raw,re.I))
    explicit_knit=bool(re.search(r'니트\s*셔츠|\bKNIT\s*SHIRT\b',raw,re.I))
    if explicit_sweater: add_large('E'); evidence.append('스웨터')
    elif explicit_knit: add_large('T'); evidence.append('니트 셔츠')
    elif re.search(r'가디건|CARDIGAN|\bVEST\b|베스트',raw,re.I): add_large('T','E'); evidence.append('가디건/베스트 공통')
    elif re.search(r'티셔츠|티\s*\(|그래픽\s*티|\bT\s*-?\s*SHIRT\b|\bTEE\b|후드T|후드\s*티',raw,re.I): add_large('T'); evidence.append('티셔츠/후드T')
    if large and set(large).issubset({'T','E'}):
        if re.search(r'가디건|CARDIGAN|오픈형',raw,re.I): add_small('C')
        elif re.search(r'V\s*[- ]?넥|V\s*NECK|브이넥',raw,re.I): add_small('V')
        elif re.search(r'라운드|ROUND\s*NECK|CREW\s*NECK',raw,re.I): add_small('R')
        elif re.search(r'T\s*[- ]?에리|T\s*COLLAR',raw,re.I): add_small('T')
        elif re.search(r'민소매|슬리브리스|SLEEVELESS|TANK\s*TOP',raw,re.I): add_small('L')
        elif re.search(r'후드T|후드\s*티|HOOD',raw,re.I): add_small('H')
        elif re.search(r'\bVEST\b|베스트',raw,re.I): add_small('S')
        return {'large':large,'small':small,'evidence':evidence,'strength':3 if len(large)==1 else 2}

    # Pants / skirt. Denim already handled above.
    if re.search(r'팬츠|바지|\bPANTS?\b|\bTROUSERS?\b|\bSLACKS?\b',raw,re.I):
        add_large('P'); evidence.append('팬츠')
        if re.search(r'반바지|쇼츠|숏팬츠|\bSHORTS?\b|BERMUDA',raw,re.I): add_small('H')
        else: add_small('P')
        return {'large':large,'small':small,'evidence':evidence,'strength':3}
    if re.search(r'스커트|\bSKIRT\b',raw,re.I):
        add_large('R'); evidence.append('스커트')
        if re.search(r'롱|LONG|맥시|MAXI',raw,re.I): add_small('L')
        elif re.search(r'숏|SHORT|미니|MINI',raw,re.I): add_small('S')
        return {'large':large,'small':small,'evidence':evidence,'strength':3}

    return {'large':[],'small':[],'evidence':[],'strength':0}


def _item_breed_category(item):
    text=' '.join(str(item.get(k) or '') for k in ('title_ko','title_en','zone','promotion'))
    cat=_breed_category_from_text(text)
    direct=_breed_large_from_style_code(item.get('code'))
    if direct:
        # SKU large code is the authoritative manual category; retain small-type text
        # only when the textual family is compatible or ambiguous.
        if cat['large'] and direct not in cat['large']:
            small=[]
        else:
            small=list(cat['small'])
        cat={'large':[direct],'small':small,'evidence':['SKU 품종대 '+direct+' '+BREED_LARGE_LABELS[direct]]+list(cat['evidence']),'strength':3}
    return cat


def _page_breed_category(page_text,source_desc=''):
    page=_breed_category_from_text(page_text)
    src=_breed_category_from_text(source_desc)
    # Page wording is primary.  Folder/file wording only resolves an ambiguity or fills
    # a missing category; it cannot override a clear page category.
    if page['large']:
        if len(page['large'])>1 and src['large']:
            inter=[c for c in page['large'] if c in src['large']]
            if inter:
                page=dict(page); page['large']=inter; page['evidence']=page['evidence']+['파일/폴더 품종 보조']
        return page
    if src['large']:
        out=dict(src); out['strength']=min(2,int(src.get('strength') or 0)); out['evidence']=['파일/폴더 '+x for x in src.get('evidence',[])]
        return out
    return page


def _breed_label(cat):
    if not isinstance(cat,dict) or not cat.get('large'): return '미확인'
    ls='/'.join(f"{c} {BREED_LARGE_LABELS.get(c,c)}" for c in cat.get('large',[]))
    ss=[]
    for sc in cat.get('small',[]):
        labels=[]
        for lc in cat.get('large',[]):
            lab=BREED_SMALL_LABELS.get(lc,{}).get(sc)
            if lab and lab not in labels: labels.append(lab)
        ss.append(f"{sc} {'/'.join(labels) if labels else ''}".strip())
    return ls + ((' · 소 '+', '.join(ss)) if ss else '')


def _manual_breed_relation(page_text,item,source_desc=''):
    """Return (adjustment, hard_conflict, page_cat, item_cat, reason)."""
    pc=_page_breed_category(page_text,source_desc)
    ic=_item_breed_category(item)
    pls=set(pc.get('large') or []); ils=set(ic.get('large') or [])
    if pls and ils and not pls.intersection(ils):
        return -1.0,True,pc,ic,f"품종대 불일치: 페이지 {_breed_label(pc)} / 품번 {_breed_label(ic)}"
    adj=0.0; notes=[]
    if pls and ils and pls.intersection(ils):
        adj+=0.085; notes.append('품종대 일치')
    pss=set(pc.get('small') or []); iss=set(ic.get('small') or [])
    if pss and iss and pss.intersection(iss):
        adj+=0.035; notes.append('품종소 일치')
    elif pss and iss and pls and ils and pls.intersection(ils):
        # Small category is inferred from wording, so mismatch is a penalty rather than
        # a hard reject. Large category remains the authoritative safety rail.
        adj-=0.025; notes.append('품종소 불일치')
    return adj,False,pc,ic,' · '.join(notes) if notes else '품종 단서 없음'


def normalize_date_range(value):
    """Convert common Excel/promotion period formats to M/D ~ M/D."""
    if value is None:
        return ''
    if isinstance(value, datetime):
        return f'{value.month}/{value.day}'
    text = str(value).strip()
    if not text:
        return ''
    text = re.sub(r'^.*?기간\s*[:：]?\s*', '', text)
    text = text.replace('～', '~').replace('−', '-').replace('–', '-').replace('—', '-')
    # Korean month/day, slash, dot, or dash date forms. Ignore a leading year.
    pairs = []
    patterns = [
        r'(?:(?:20\d{2})[./-])?(\d{1,2})[./-](\d{1,2})',
        r'(\d{1,2})\s*월\s*(\d{1,2})\s*일?',
    ]
    for pattern in patterns:
        pairs = re.findall(pattern, text)
        if len(pairs) >= 2:
            break
    if len(pairs) >= 2:
        (m1,d1),(m2,d2)=pairs[0],pairs[1]
        return f'{int(m1)}/{int(d1)} ~ {int(m2)}/{int(d2)}'
    # A single date is still displayed cleanly.
    if len(pairs) == 1:
        m,d=pairs[0]
        return f'{int(m)}/{int(d)}'
    return re.sub(r'\s+', ' ', text).strip()

def _extract_date_pairs(value):
    """Return valid (month, day) pairs from flexible promotion date text."""
    if value is None:
        return []
    if isinstance(value, datetime):
        return [(value.month, value.day)]
    text = str(value).strip()
    if not text:
        return []
    text = text.replace('～', '~').replace('−', '-').replace('–', '-').replace('—', '-')
    # Convert Korean month/day notation first so mixed forms also work.
    text = re.sub(r'(\d{1,2})\s*월\s*(\d{1,2})\s*일?', r'\1/\2', text)
    pairs = []
    for m, d in re.findall(r'(?:(?:20\d{2})[./-])?(\d{1,2})[./-](\d{1,2})', text):
        try:
            m_i, d_i = int(m), int(d)
        except Exception:
            continue
        if 1 <= m_i <= 12 and 1 <= d_i <= 31:
            pairs.append((m_i, d_i))
    return pairs


def detect_workbook_date_range(wb, active_rows=None, source_name=''):
    """Find the promotion period anywhere in the workbook, not at a fixed row/column.

    The promotion team's note block can move far below the item table in future files,
    so this scans every worksheet's used cells and scores explicit period wording above
    incidental date pairs. A filename such as 0828_0917 remains the final fallback.
    """
    candidates = []
    order = 0

    def consider(value, sheet_idx=0, row_idx=0, col_idx=0, row_join=False):
        nonlocal order
        if value is None:
            return
        raw = str(value).strip()
        if not raw:
            return
        pairs = _extract_date_pairs(value)
        if len(pairs) < 2:
            return
        (m1,d1),(m2,d2)=pairs[0],pairs[1]
        normalized=f'{m1}/{d1} ~ {m2}/{d2}'
        compact=re.sub(r'\s+','',raw)
        score=40
        if re.search(r'행사\s*기간', raw): score += 120
        if re.search(r'기간\s*[:：]', raw): score += 115
        if re.search(r'기간\s*(동안|내|한정)', raw): score += 105
        if '기간한정' in compact: score += 95
        if '~' in raw or '-' in raw or '～' in raw or '–' in raw: score += 10
        if row_join: score += 8
        if sheet_idx == 0: score += 5
        # Prefer concise notice cells over huge concatenated rows when scores tie.
        length_penalty=min(30, len(raw)//80)
        score -= length_penalty
        candidates.append((score, -order, normalized, raw[:240]))
        order += 1

    # Active sheet is already materialized by load_items; inspect all of it first.
    if active_rows is not None:
        for r_idx, row in enumerate(active_rows):
            for c_idx, value in enumerate(row):
                consider(value, 0, r_idx, c_idx, False)
            # Catch start/end dates stored in separate cells on the same row.
            joined=' | '.join(str(v).strip() for v in row if v not in (None,''))
            consider(joined, 0, r_idx, 0, True)

    # Then inspect every other worksheet. No hard-coded Q/S/W column or row limit.
    try:
        active_title = wb.active.title
        other_idx = 1
        for sheet in wb.worksheets:
            if sheet.title == active_title:
                continue
            for r_idx, row in enumerate(sheet.iter_rows(values_only=True)):
                for c_idx, value in enumerate(row):
                    consider(value, other_idx, r_idx, c_idx, False)
                joined=' | '.join(str(v).strip() for v in row if v not in (None,''))
                consider(joined, other_idx, r_idx, 0, True)
            other_idx += 1
    except Exception:
        pass

    if candidates:
        candidates.sort(reverse=True)
        return candidates[0][2]

    # Final safety net: filename 0828_0917 / 0828-0917 / similar.
    name=str(source_name or '')
    m=re.search(r'(?<!\d)(\d{2})(\d{2})[^0-9]?(\d{2})(\d{2})(?!\d)', name)
    if m:
        try:
            m1,d1,m2,d2=(int(m.group(i)) for i in range(1,5))
            if 1 <= m1 <= 12 and 1 <= m2 <= 12 and 1 <= d1 <= 31 and 1 <= d2 <= 31:
                return f'{m1}/{d1} ~ {m2}/{d2}'
        except Exception:
            pass
    return ''


def detect_sheet(ws):
    header=None; cols={}
    aliases={'code':['스타일','품번'],'title_ko':['상품명'],'title_en':['상품명(영문)','영문명'],'gender':['성별'],'zone':['조닝','종류'],'color':['컬러'],'normal':['정상가'],'sale':['조정가','할인가'],'promotion':['프로모션 내용'],'season':['시즌']}
    for r in range(1,min(ws.max_row,40)+1):
        vals=[str(ws.cell(r,c).value or '').strip() for c in range(1,ws.max_column+1)]
        if any(x in vals for x in ['스타일','품번']) and '정상가' in vals:
            header=r
            for key,names in aliases.items():
                for name in names:
                    if name in vals:
                        if key=='title_ko' and name=='상품명' and vals.count(name)>1: pass
                        cols[key]=vals.index(name)+1; break
            # explicit columns for this TOPTEN format
            if '상품명(영문)' in vals: cols['title_en']=vals.index('상품명(영문)')+1
            if '프로모션 내용' in vals: cols['promotion']=vals.index('프로모션 내용')+1
            break
    if not header: raise ValueError('헤더 행을 찾지 못했습니다. 품번/스타일과 정상가 열이 필요합니다.')
    return header,cols

def detect_date(ws):
    pats=[]
    for r in range(1,min(ws.max_row,20)+1):
      for c in range(1,min(ws.max_column,20)+1):
        s=str(ws.cell(r,c).value or '').strip()
        if '기간' in s or re.search(r'\d{1,2}월\s*\d{1,2}',s): pats.append(s)
    if not pats:return ''
    s=pats[0]
    s=re.sub(r'^.*?기간\s*[:：]?\s*','',s)
    s=re.sub(r'\s+',' ',s).strip()
    return s

def build_product_index():
    global _PRODUCT_INDEX
    index = {}
    if PRODUCT_DIR.exists():
        for p in PRODUCT_DIR.iterdir():
            if not p.is_file() or p.suffix.lower() not in EXTS:
                continue
            stem = clean_code(p.stem)
            base = re.split(r'[_-]', stem, maxsplit=1)[0]
            for key in {stem, base}:
                if key:
                    index.setdefault(key, []).append(p)
    for key, files in index.items():
        files.sort(key=lambda p: (EXTS.index(p.suffix.lower()), len(p.name)))
    _PRODUCT_INDEX = index
    return index

def find_visual(code):
    index = _PRODUCT_INDEX if _PRODUCT_INDEX is not None else build_product_index()
    code = clean_code(code)
    files = index.get(code, [])
    return files[0] if files else None

def normalize_product_name(text):
    """Normalize OCR/product names while keeping meaningful item words."""
    text = str(text or '').upper()
    text = re.sub(r'\([^)]*\)|\[[^]]*\]', ' ', text)
    text = re.sub(r'\d[\d,]*\s*원', ' ', text)
    text = re.sub(
        r'남성|여성|공용|키즈|정상가|할인가|기간한정|NEW\s*ARRIVAL|TOPTEN|탑텐|'
        r'봄|여름|가을|겨울|SPRING|SUMMER|FALL|WINTER|시즌|컬러|COLOR',
        ' ', text
    )
    return re.sub(r'[^0-9A-Z가-힣]+', '', text)


def _load_ocr_learning():
    try:
        raw = json.loads(OCR_LEARN_FILE.read_text('utf-8')) if OCR_LEARN_FILE.exists() else {}
        return raw if isinstance(raw, dict) else {}
    except Exception:
        return {}


def _save_ocr_learning(data):
    OCR_LEARN_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


def _learn_ocr_mapping(ocr_text, code):
    key = normalize_product_name(ocr_text)
    code = clean_code(code)
    if len(key) < 3 or not code:
        return
    data = _load_ocr_learning()
    data[key] = {'code': code, 'updated_at': datetime.now().isoformat(timespec='seconds')}
    _save_ocr_learning(data)


def _learned_code_for_text(ocr_text):
    norm = normalize_product_name(ocr_text)
    if not norm:
        return ''
    data = _load_ocr_learning()
    rec = data.get(norm)
    if isinstance(rec, dict) and rec.get('code'):
        return clean_code(rec['code'])
    best_code = ''
    best_score = 0.0
    for key, value in data.items():
        if not isinstance(value, dict) or not value.get('code'):
            continue
        score = difflib.SequenceMatcher(None, key, norm).ratio()
        if key in norm or norm in key:
            score = max(score, 0.94)
        if score > best_score:
            best_score, best_code = score, clean_code(value['code'])
    return best_code if best_score >= 0.90 else ''


def _remove_ocr_learning(codes=None, clear_all=False):
    if clear_all:
        _save_ocr_learning({})
        return
    targets = set(clean_code(c) for c in (codes or []) if clean_code(c))
    if not targets:
        return
    data = _load_ocr_learning()
    next_data = {
        key: value for key, value in data.items()
        if not isinstance(value, dict) or clean_code(value.get('code')) not in targets
    }
    if next_data != data:
        _save_ocr_learning(next_data)


def _normalize_bonus_mode(mode=None):
    mode=str(mode or '').strip().lower()
    return mode if mode in ('ocr','ai') else 'ocr'


def _bonus_map_file(mode=None):
    return BONUS_AI_MAP_FILE if _normalize_bonus_mode(mode)=='ai' else BONUS_OCR_MAP_FILE


def _bonus_override_file(mode=None):
    return BONUS_AI_OVERRIDE_FILE if _normalize_bonus_mode(mode)=='ai' else BONUS_OCR_OVERRIDE_FILE


def _read_json_dict(path):
    try:
        raw=json.loads(path.read_text('utf-8')) if path.exists() else {}
        return raw if isinstance(raw,dict) else {}
    except Exception:
        return {}


def _ensure_bonus_mode_storage():
    """One-time, lossless migration from the old shared mapping files.

    Legacy shared-mapping releases used one bonus_page_matches.json for both OCR and AI. We copy
    that legacy state into both independent stores once so switching engines can never
    make an existing mapping disappear during the upgrade.
    """
    legacy=_read_json_dict(LEGACY_BONUS_MAP_FILE)
    for path in (BONUS_OCR_MAP_FILE,BONUS_AI_MAP_FILE):
        if not path.exists():
            path.write_text(json.dumps(legacy,ensure_ascii=False,indent=2),encoding='utf-8')
    legacy_overrides=_read_json_dict(LEGACY_BONUS_OVERRIDE_FILE)
    for path in (BONUS_OCR_OVERRIDE_FILE,BONUS_AI_OVERRIDE_FILE):
        if not path.exists():
            path.write_text(json.dumps(legacy_overrides,ensure_ascii=False,indent=2),encoding='utf-8')
    if not BONUS_MODE_FILE.exists():
        # If a previous AI review was already confirmed, keep the user's current AI
        # workflow active; otherwise retain the traditional OCR behavior.
        mode='ocr'
        try:
            review=_read_json_dict(AI_REVIEW_FILE)
            if int(review.get('confirmed_count') or 0)>0: mode='ai'
        except Exception:
            pass
        BONUS_MODE_FILE.write_text(json.dumps({'mode':mode,'updated_at':datetime.now().isoformat(timespec='seconds')},ensure_ascii=False,indent=2),encoding='utf-8')


def get_bonus_match_mode():
    # V4.4.54 (2026-10-01): store-facing legacy OCR mode is retired.
    # Keep the legacy mapping files untouched for rollback/history, but POP generation always uses AI.
    _ensure_bonus_mode_storage()
    data=_read_json_dict(BONUS_MODE_FILE)
    if str(data.get('mode') or '').strip().lower() != 'ai':
        BONUS_MODE_FILE.write_text(json.dumps({'mode':'ai','updated_at':datetime.now().isoformat(timespec='seconds')},ensure_ascii=False,indent=2),encoding='utf-8')
    return 'ai'


def set_bonus_match_mode(mode):
    # Compatibility endpoint: any old client/form is pinned to AI instead of re-enabling legacy OCR.
    mode='ai'
    _ensure_bonus_mode_storage()
    BONUS_MODE_FILE.write_text(json.dumps({'mode':mode,'updated_at':datetime.now().isoformat(timespec='seconds')},ensure_ascii=False,indent=2),encoding='utf-8')
    load_items(force=True)
    return mode


def load_bonus_matches(force=False, mode=None):
    global _BONUS_MAP_CACHE, _BONUS_MAP_MTIME
    _ensure_bonus_mode_storage()
    mode=_normalize_bonus_mode(mode or get_bonus_match_mode())
    path=_bonus_map_file(mode)
    try:
        mtime=path.stat().st_mtime_ns if path.exists() else -1
    except OSError:
        mtime=-1
    if not force and _BONUS_MAP_CACHE.get(mode) is not None and _BONUS_MAP_MTIME.get(mode)==mtime:
        return _BONUS_MAP_CACHE[mode]
    data=_read_json_dict(path)
    _BONUS_MAP_CACHE[mode]=data; _BONUS_MAP_MTIME[mode]=mtime
    return data


def save_bonus_matches(data, mode=None):
    global _BONUS_MAP_CACHE, _BONUS_MAP_MTIME
    _ensure_bonus_mode_storage()
    mode=_normalize_bonus_mode(mode or get_bonus_match_mode())
    path=_bonus_map_file(mode)
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    _BONUS_MAP_CACHE[mode]=data
    try:_BONUS_MAP_MTIME[mode]=path.stat().st_mtime_ns
    except OSError:_BONUS_MAP_MTIME[mode]=None


def _load_manual_overrides(mode=None):
    _ensure_bonus_mode_storage()
    mode=_normalize_bonus_mode(mode or get_bonus_match_mode())
    return _read_json_dict(_bonus_override_file(mode))


def _save_manual_overrides(data, mode=None):
    _ensure_bonus_mode_storage()
    mode=_normalize_bonus_mode(mode or get_bonus_match_mode())
    _bonus_override_file(mode).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')


def _set_manual_override(code, source_id, page, mode=None):
    mode=_normalize_bonus_mode(mode or get_bonus_match_mode())
    code=clean_code(code); source_id=_normalize_webhard_rel(source_id)
    if not code or not source_id:return
    data=_load_manual_overrides(mode)
    data[code]={'file':source_id,'source':source_id,'page':int(page),'updated_at':datetime.now().isoformat(timespec='seconds')}
    _save_manual_overrides(data,mode)


def _shared_manual_override(code):
    """Return the newest valid manual bonus choice across OCR/AI stores.

    V4.4.37 treats a user's PDF/page correction as a global truth, not an engine-specific
    suggestion. This prevents switching OCR/AI from making a manually fixed SKU fall back
    to NEW ARRIVAL/adult-small again.
    """
    code=clean_code(code)
    if not code: return None
    rows=[]
    for mode in ('ocr','ai'):
        rec=_load_manual_overrides(mode).get(code)
        if not isinstance(rec,dict): continue
        source_id=_normalize_webhard_rel(rec.get('source') or rec.get('file') or '')
        if not source_id or not _resolve_webhard_pdf(source_id): continue
        row=dict(rec); row['file']=source_id; row['source']=source_id; row['source_type']='manual'
        rows.append((str(rec.get('updated_at') or ''), mode, row))
    if not rows: return None
    rows.sort(key=lambda x:(x[0],x[1]), reverse=True)
    return rows[0][2]


def _drop_fallback_without_refresh(code):
    code=clean_code(code)
    data=_load_bonus_fallback_choices()
    if code in data:
        data.pop(code,None)
        _save_bonus_fallback_choices(data)
        return True
    return False


def _set_shared_manual_bonus(code, source_id, page):
    """Persist one manual correction into both OCR and AI stores atomically enough for UI use."""
    code=clean_code(code); source_id=_normalize_webhard_rel(source_id)
    if not code or not source_id or not _resolve_webhard_pdf(source_id): return False
    _drop_fallback_without_refresh(code)
    rec={'file':source_id,'source':source_id,'page':int(page),'source_type':'manual'}
    for mode in ('ocr','ai'):
        data=dict(load_bonus_matches(mode=mode)); data[code]=dict(rec)
        save_bonus_matches(data,mode=mode)
        _set_manual_override(code,source_id,int(page),mode=mode)
    load_items(force=True)
    return True


def _sync_protected_matches_between_modes():
    """Keep manual + official-notice truth identical in OCR/AI stores.

    Engine auto guesses remain separate. Only user manual locks and strict notice-image
    matches are mirrored so changing the preferred engine can never look like a reset.
    """
    ocr=dict(load_bonus_matches(mode='ocr')); ai=dict(load_bonus_matches(mode='ai'))
    changed=False
    codes=set(ocr)|set(ai)|set(_load_manual_overrides('ocr'))|set(_load_manual_overrides('ai'))
    for code in codes:
        code=clean_code(code)
        manual=_shared_manual_override(code)
        if manual:
            for data in (ocr,ai):
                if data.get(code)!=manual:
                    data[code]=dict(manual); changed=True
            continue
        candidates=[]
        for rec in (ocr.get(code),ai.get(code)):
            if isinstance(rec,dict) and str(rec.get('source_type') or '')=='notice_auto' and _resolve_webhard_pdf(_bonus_source_id(rec)):
                candidates.append(rec)
        if candidates:
            best=max(candidates,key=lambda r:int(r.get('notice_score') or 0))
            for data in (ocr,ai):
                cur=data.get(code)
                if not (isinstance(cur,dict) and str(cur.get('source_type') or '')=='manual') and cur!=best:
                    data[code]=dict(best); changed=True
    if changed:
        save_bonus_matches(ocr,mode='ocr'); save_bonus_matches(ai,mode='ai')
    return changed


def _remove_manual_overrides(codes=None, filename='', clear_all=False, mode=None):
    mode=_normalize_bonus_mode(mode or get_bonus_match_mode())
    data=_load_manual_overrides(mode)
    if clear_all:
        _save_manual_overrides({},mode); return
    targets={clean_code(c) for c in (codes or []) if clean_code(c)}
    filename=_normalize_webhard_rel(filename)
    out={}
    for code,rec in data.items():
        remove=(clean_code(code) in targets) if targets else False
        if filename and _bonus_source_id(rec)==filename: remove=True
        if not remove: out[code]=rec
    if out!=data:_save_manual_overrides(out,mode)


def _normalize_webhard_rel(value):
    """Return a safe POSIX path relative to webhard_sync, or ''."""
    raw = str(value or '').strip().replace('\\', '/').lstrip('/')
    if not raw:
        return ''
    p = Path(raw)
    if p.is_absolute() or not p.parts or any(part in ('', '.', '..') for part in p.parts):
        return ''
    return p.as_posix()

def _resolve_webhard_pdf(value):
    """Resolve a mapping identifier to a PDF under webhard_sync.

    Legacy bonus_pdfs is only a fallback if legacy migration was interrupted.
    """
    rel = _normalize_webhard_rel(value)
    if rel:
        try:
            base = WEBHARD_SYNC_DIR.resolve()
            path = (WEBHARD_SYNC_DIR / Path(rel)).resolve()
            if base in path.parents and path.is_file() and path.suffix.lower() == '.pdf':
                return path
        except Exception:
            pass
    legacy_name = Path(str(value or '')).name
    legacy = LEGACY_BONUS_DIR / legacy_name
    if legacy.is_file() and legacy.suffix.lower() == '.pdf':
        return legacy
    return None

def _bonus_source_id(rec):
    if not isinstance(rec, dict):
        return ''
    return _normalize_webhard_rel(rec.get('source') or rec.get('file') or '')

def bonus_visual_for(code):
    code=clean_code(code)
    # V4.4.37 priority: user manual truth > deliberate fallback lock > selected engine auto.
    # A manual correction is global across OCR/AI, so engine switching can never hide it.
    manual=_shared_manual_override(code)
    if manual:
        source_id=_bonus_source_id(manual)
        path=_resolve_webhard_pdf(source_id or manual.get('file',''))
        if path and path.exists():
            return f"{path}::page={int(manual.get('page',0))}"
    if get_bonus_fallback_choice(code):
        return None
    rec = load_bonus_matches().get(code)
    if not rec:
        return None
    source_id = _bonus_source_id(rec)
    path = _resolve_webhard_pdf(source_id or rec.get('file',''))
    return f"{path}::page={int(rec.get('page',0))}" if path and path.exists() else None

def season_letter_from_code(code):
    """TOPTEN style codes use the third alphabetic character as the season letter.

    Example: MSG2PP2501 -> G. 2026 = G, 2027 = H; E/F are carryover seasons.
    """
    code = clean_code(code)
    match = re.match(r'^[A-Z]{2}([A-Z])', code)
    return match.group(1) if match else ''


def is_carryover_code(code):
    return season_letter_from_code(code) in {'E', 'F'}


_SEASON_TOKEN_RE = re.compile(r'(?<![A-Z0-9])([A-Z])\s*[-_.]?\s*([0-9]{1,2})(?![A-Z0-9])', re.I)


def _normalize_season_token(value):
    """Return a compact TOPTEN season token such as F2/G2/G3 when visible."""
    raw=str(value or '').upper().strip()
    m=_SEASON_TOKEN_RE.search(raw)
    if m:
        return f'{m.group(1).upper()}{int(m.group(2))}'
    # Excel may occasionally contain only a season letter. Keep it as weak metadata,
    # but explicit filename tokens such as F2 are compared only to full tokens.
    m=re.search(r'(?<![A-Z])([A-Z])(?![A-Z])', raw)
    return m.group(1).upper() if m else ''


def _season_token_from_code(code):
    """Derive F2/G2/G3 style season from the style-code prefix when possible."""
    c=clean_code(code)
    m=re.match(r'^[A-Z]{2}([A-Z])([0-9])', c)
    return f'{m.group(1)}{m.group(2)}' if m else season_letter_from_code(c)


def _item_season_tokens(item):
    vals=[]
    explicit=_normalize_season_token(item.get('season'))
    derived=_season_token_from_code(item.get('code'))
    for x in (explicit,derived):
        if x and x not in vals: vals.append(x)
    return vals


def _source_season_tokens(pdf_path):
    """Extract explicit season markers from PDF filename/path. Filename is authoritative.

    Example: `0314_F2 티셔츠 POP.pdf` => {'F2'}.  When this exists, G2/G3 items
    are excluded before title similarity can promote them.
    """
    try:
        source=_sync_source_key(Path(pdf_path))
    except Exception:
        source=str(pdf_path or '')
    # Strongest evidence is the actual PDF filename. Parent folders are supplemental.
    name=Path(str(source).replace('\\','/')).name
    hits=[]
    for text in (name, str(source)):
        for m in _SEASON_TOKEN_RE.finditer(str(text).upper()):
            tok=f'{m.group(1).upper()}{int(m.group(2))}'
            if tok not in hits: hits.append(tok)
        if hits: break
    return hits


_ITEM_TYPE_RULES = [
    ('탱크탑', (r'탱크\s*탑', r'TANK\s*TOP')),
    ('슬리브리스', (r'슬리브리스', r'SLEEVELESS')),
    ('티셔츠', (r'티\s*셔츠', r'반팔\s*티', r'긴팔\s*티', r'\bT\s*-?\s*SHIRT\b', r'\bTSHIRT\b', r'\bTEE\b')),
    ('스웨터', (r'스웨터', r'\bSWEATER\b', r'\bKNIT\b')),
    ('가디건', (r'가디건', r'\bCARDIGAN\b')),
    ('셔츠', (r'(?<!티)셔츠', r'\bSHIRT\b')),
    ('팬츠', (r'팬츠', r'바지', r'슬랙스', r'\bPANTS\b', r'\bSLACKS\b', r'\bTROUSER')),
    ('스커트', (r'스커트', r'\bSKIRT\b')),
    ('원피스', (r'원피스', r'\bDRESS\b')),
    ('자켓', (r'자켓', r'재킷', r'\bJACKET\b')),
    ('점퍼', (r'점퍼', r'\bJUMPER\b', r'\bBLOUSON\b')),
]


def _extract_item_types(text):
    raw=str(text or '').upper()
    out=[]
    for label,pats in _ITEM_TYPE_RULES:
        if any(re.search(p,raw,re.I) for p in pats): out.append(label)
    return out


def _source_item_types(pdf_path):
    try: source=_sync_source_key(Path(pdf_path))
    except Exception: source=str(pdf_path or '')
    # Filename wording like `F2 티셔츠` is strong scope metadata.
    return _extract_item_types(Path(str(source).replace('\\','/')).name)


def _item_type_tokens(item):
    out=[]
    for value in (item.get('title_ko'),item.get('title_en'),item.get('zone')):
        for t in _extract_item_types(value):
            if t not in out: out.append(t)
    return out


def _season_relation(source_seasons,item):
    """Return (ok, bonus, note). Explicit full season mismatch is a hard reject."""
    src=[x for x in (source_seasons or []) if re.fullmatch(r'[A-Z][0-9]{1,2}',str(x or '').upper())]
    its=_item_season_tokens(item)
    full=[x for x in its if re.fullmatch(r'[A-Z][0-9]{1,2}',x)]
    if not src: return True,0.0,'시즌 단서 없음'
    if full and not set(src).intersection(full):
        return False,-1.0,f'PDF 시즌 {"/".join(src)} ≠ 품번 시즌 {"/".join(full)}'
    if set(src).intersection(full):
        return True,0.055,f'시즌 {next(iter(set(src).intersection(full)))} 일치'
    # No reliable item season: keep reviewable but never reward it.
    return True,0.0,f'PDF 시즌 {"/".join(src)} · 품번 시즌 확인불가'


def _type_relation(source_types,item):
    """Return (ok, bonus, note) using compatible retail item families.

    Filename class is strong, but not naively exact: `기타 스웨터` PDFs can contain
    cardigan pages, so sweater/cardigan share the KNIT family. Likewise tee/tank/
    sleeveless share a TOP family. Cross-family errors such as `티셔츠` -> `팬츠`
    are hard rejected when both sides are explicit.
    """
    src=list(source_types or [])
    its=_item_type_tokens(item)
    if not src: return True,0.0,'품종 단서 없음'
    if not its: return True,0.0,f'PDF 품종 {"/".join(src)} · 상품 품종 확인불가'
    fam={
        '티셔츠':'TOP','탱크탑':'TOP','슬리브리스':'TOP',
        '스웨터':'KNIT','가디건':'KNIT',
        '팬츠':'PANTS','셔츠':'SHIRT','스커트':'SKIRT','원피스':'DRESS',
        '자켓':'OUTER','점퍼':'OUTER',
    }
    exact=set(src).intersection(its)
    if exact:
        return True,0.035,f'품종 {next(iter(exact))} 일치'
    sf={fam.get(x,x) for x in src}; inf={fam.get(x,x) for x in its}
    compatible=sf.intersection(inf)
    if compatible:
        return True,0.018,f'품종군 호환 {"/".join(src)} ↔ {"/".join(its)}'
    return False,-1.0,f'PDF 품종 {"/".join(src)} ≠ 상품 품종 {"/".join(its)}'


def _load_visual_choices():
    try:
        data = json.loads(VISUAL_CHOICE_FILE.read_text('utf-8')) if VISUAL_CHOICE_FILE.exists() else {}
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _save_visual_choices(data):
    VISUAL_CHOICE_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


def _load_bonus_fallback_choices():
    return _read_json_dict(BONUS_FALLBACK_FILE)


def _save_bonus_fallback_choices(data):
    BONUS_FALLBACK_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


def get_bonus_fallback_choice(code):
    code=clean_code(code)
    rec=_load_bonus_fallback_choices().get(code)
    if not isinstance(rec,dict): return ''
    choice=str(rec.get('choice') or '').strip().lower()
    return choice if choice in {'new_arrival','adult_small'} else ''


def set_bonus_fallback_choice(code, choice):
    code=clean_code(code); choice=str(choice or '').strip().lower()
    if not code or choice not in {'new_arrival','adult_small'}: return False
    data=_load_bonus_fallback_choices()
    data[code]={'choice':choice,'locked_at':datetime.now().isoformat(timespec='seconds')}
    _save_bonus_fallback_choices(data)
    load_items(force=True)
    return True


def clear_bonus_fallback_choice(code):
    code=clean_code(code)
    data=_load_bonus_fallback_choices()
    if code in data:
        data.pop(code,None); _save_bonus_fallback_choices(data); load_items(force=True)
        return True
    return False


def _exact_bonus_evidence(result, code):
    code=clean_code(code)
    if not code: return False
    # A fallback lock is released automatically only by the style code actually
    # visible on the PDF page. Filename membership alone can be a stale multi-SKU list.
    return bool(result.get('notice_exact')) or _code_present_in_text(result.get('text') or '', code)


def _bonus_record_signature(code):
    rec = load_bonus_matches().get(clean_code(code))
    if not isinstance(rec, dict):
        return ''
    source_id = _bonus_source_id(rec)
    return f"{source_id}|{int(rec.get('page', 0))}" if source_id else ''


def get_carryover_visual_choice(code):
    code = clean_code(code)
    current_sig = _bonus_record_signature(code)
    if not current_sig:
        return ''
    rec = _load_visual_choices().get(code)
    if not isinstance(rec, dict) or rec.get('bonus_signature') != current_sig:
        return ''
    choice = str(rec.get('choice') or '')
    return choice if choice in {'bonus', 'clearance'} else ''


def set_carryover_visual_choice(code, choice):
    code = clean_code(code)
    choice = str(choice or '').strip().lower()
    if not code or choice not in {'bonus', 'clearance'}:
        return False
    sig = _bonus_record_signature(code)
    if not sig:
        return False
    data = _load_visual_choices()
    data[code] = {
        'choice': choice,
        'bonus_signature': sig,
        'updated_at': datetime.now().isoformat(timespec='seconds')
    }
    _save_visual_choices(data)
    load_items(force=True)
    return True


def _gender_template_page(gender, template_kind):
    gender = str(gender or '').strip()
    if template_kind == 'clearance':
        return {'공용': 0, '남성': 1, '여성': 2}.get(gender, 0)
    # Official TT_소형 POP.pptx: page 1=공용, page 2=남성, page 3=여성.
    return {'공용': 0, '남성': 1, '여성': 2}.get(gender, 0)


def _template_visual(template_path, page):
    return f"{template_path}::page={int(page)}"


def _parse_multibuy_promo(promotion_text, code='', zone='', title_ko=''):
    """Recognize only the approved socks 4-for-10,000 promotion.

    Real promotion sheets may store only "4장 10,000원" in the promotion cell.
    Therefore socks identity is confirmed independently from the style code/category:
      - TOPTEN accessory small-code AY, or
      - zone/title text containing 양말/삭스/SOCK.
    This prevents unrelated 4-item promotions from using the socks POP.
    """
    raw = str(promotion_text or '').strip()
    if not raw:
        return None
    compact = re.sub(r'\s+', '', raw).replace(',', '')
    if '4장' not in compact:
        return None
    price_ok = ('10000' in compact) or ('1만원' in compact) or ('4장만원' in compact)
    if not price_ok:
        return None

    code_n = clean_code(code)
    context = re.sub(r'\s+', '', f'{zone} {title_ko} {raw}').upper()
    code_is_socks = bool(re.search(r'^[A-Z]{3}\dAY\d{4}$', code_n))
    text_is_socks = ('양말' in context) or ('삭스' in context) or ('SOCK' in context)
    if not (code_is_socks or text_is_socks):
        return None
    return {
        'qty': 4,
        'unit': '장',
        'label': '4장',
        'price': 10000,
        'price_fmt': '10,000',
        'raw': raw,
        'template': 'socks_4_for_10000',
    }


def resolve_item_visual(code, gender, is_discount, discount_percent=0.0, promotion='', price_policy='', zone='', title_ko=''):
    """Apply the final 8/28+ routing rules.

    - 가격인하: matched bonus PDF first, otherwise the supplied red PPT-based price-reduction POP.
    - 기간한정: matched bonus PDF first, otherwise adult-small by code gender.
    - 정상가: matched bonus PDF first, otherwise NEW ARRIVAL.
    - Socks 4-for-10,000 is the only normal-policy exception and uses adult-small promo.
    - SPECIAL PRICE / clearance is retired and is never selected.
    """
    code=clean_code(code)
    gender=infer_gender_from_code(code,gender) or '공용'
    bonus=bonus_visual_for(code)
    carryover=is_carryover_code(code)
    season=season_letter_from_code(code)
    policy=normalize_price_policy(price_policy)
    try: discount_percent=float(discount_percent or 0.0)
    except Exception: discount_percent=0.0
    promo_offer=_parse_multibuy_promo(promotion,code=code,zone=zone,title_ko=title_ko)
    result={
        'season_letter':season,'is_carryover':carryover,'bonus_available':bool(bonus),
        'requires_bonus_choice':False,'bonus_choice':'','price_policy':policy,
        'price_policy_mode':bool(policy),'gender':gender,
        'discount_percent':round(discount_percent,1),
        'discount_percent_fmt':(f'{discount_percent:.1f}%'.replace('.0%','%') if is_discount else '-'),
        'promo_offer':promo_offer or {},'fallback_choice':get_bonus_fallback_choice(code),
    }

    # V4.4.49: 가격인하도 번외 PDF가 있으면 번외를 1순위로 사용한다.
    # 번외가 없을 때만 본사 가격인하 POP(PPT 시안)로 생성한다.
    if policy=='가격인하':
        if bonus:
            result.update({'visual_mode':'standard_overlay','visual':bonus,
                           'visual_status':'가격인하 · 번외 PDF 1순위'})
        else:
            result.update({'visual_mode':'price_reduction','visual':str(PRICE_REDUCTION_MAIN),
                           'visual_status':'가격인하 · 번외 없음 · 가격인하 POP 2순위 · 행사기간 미표시'})
        return result

    # 4장 10,000원 양말 프로모션은 정상가 분류여도 승인된 전용 POP를 사용한다.
    if promo_offer and policy!='기간한정':
        page=_gender_template_page(gender,'adult_small')
        result.update({'visual_mode':'promo_offer','visual':_template_visual(SOCKS_PROMO_TEMPLATE,page),
                       'visual_status':f'{policy or "프로모션"} · 양말 4장 10,000원 공식시안 · {gender}'})
        return result

    if policy=='기간한정':
        if bonus:
            result.update({'visual_mode':'standard_overlay','visual':bonus,
                           'visual_status':'기간한정 · 번외 PDF 1순위'})
        else:
            page=_gender_template_page(gender,'adult_small')
            result.update({'visual_mode':'adult_small','visual':_template_visual(ADULT_SMALL_TEMPLATE,page),
                           'visual_status':'기간한정 · 번외 없음 · 성인소형 2순위'})
        return result

    if policy=='정상가':
        if bonus:
            result.update({'visual_mode':'standard_overlay','visual':bonus,
                           'visual_status':'정상가 · 번외 PDF 1순위'})
        else:
            result.update({'visual_mode':'standard_overlay','visual':str(TEMPLATE_DIR/'NEW_ARRIVAL.pdf'),
                           'visual_status':'정상가 · 번외 없음 · NEW ARRIVAL 2순위'})
        return result

    # Old/unknown spreadsheet fallback. SPECIAL PRICE is still never used.
    # We preserve the useful old behavior only as bonus -> adult-small for discounted,
    # NEW ARRIVAL for non-discounted. The UI labels this as 미분류 so it cannot be
    # confused with the new three-way policy.
    if promo_offer:
        page=_gender_template_page(gender,'adult_small')
        result.update({'visual_mode':'promo_offer','visual':_template_visual(SOCKS_PROMO_TEMPLATE,page),
                       'visual_status':f'미분류 · 양말 4장 10,000원 공식시안 · {gender}'})
        return result
    if is_discount:
        if bonus:
            result.update({'visual_mode':'standard_overlay','visual':bonus,'visual_status':'미분류 · 번외 PDF'})
        else:
            page=_gender_template_page(gender,'adult_small')
            result.update({'visual_mode':'adult_small','visual':_template_visual(ADULT_SMALL_TEMPLATE,page),'visual_status':'미분류 · 성인소형 POP'})
    else:
        result.update({'visual_mode':'standard_overlay','visual':str(TEMPLATE_DIR/'NEW_ARRIVAL.pdf'),'visual_status':'미분류 · NEW ARRIVAL'})
    return result

def extract_filename_codes(filename, items):
    """Extract known product codes from a PDF filename, preserving filename order.

    V4.4.55 also URL-decodes names first (``%20`` etc.). Some Webhard downloads keep
    escaped spaces in the physical filename, and the old compacting step turned ``%20``
    into a literal ``20`` between SKU tokens. Decoding first makes the filename roster
    deterministic without changing any PDF bytes or user data.
    """
    raw_name = urllib.parse.unquote(str(filename or ''))
    stem = Path(raw_name).stem.upper()
    compact = re.sub(r'[^A-Z0-9]', '', stem)
    found = []
    seen = set()
    for item in items:
        code = clean_code(item.get('code'))
        code_compact = re.sub(r'[^A-Z0-9]', '', code)
        if not code_compact or code_compact in seen:
            continue
        pos = compact.find(code_compact)
        if pos >= 0:
            found.append((pos, -len(code_compact), code))
            seen.add(code_compact)
    found.sort()
    return [code for _, __, code in found]

def _item_by_code(items):
    return {clean_code(i.get('code')): i for i in items if clean_code(i.get('code'))}


def _saved_runtime_path(filename):
    try:
        p = DATA_DIR / filename
        return p.read_text('utf-8', errors='ignore').strip().strip('"') if p.exists() else ''
    except Exception:
        return ''


def _find_tesseract_executable():
    """Locate the exact Tesseract selected by the V4.4.37 bootstrap first."""
    env = os.environ.get('TESSERACT_CMD', '').strip()
    candidates = [
        _saved_runtime_path('tesseract_path.txt'),
        env,
        shutil.which('tesseract') or '',
        r'C:\Program Files\Tesseract-OCR\tesseract.exe',
        r'C:\Program Files (x86)\Tesseract-OCR\tesseract.exe',
        str(Path.home() / 'AppData/Local/Programs/Tesseract-OCR/tesseract.exe'),
    ]
    for candidate in candidates:
        if candidate and Path(candidate).exists():
            return str(Path(candidate))
    return ''


def _find_tessdata_dir():
    """Locate the exact verified OCR language directory selected by bootstrap."""
    program_data = os.environ.get('ProgramData', r'C:\ProgramData')
    local_appdata = os.environ.get('LOCALAPPDATA', '')
    candidates = [
        _saved_runtime_path('tessdata_path.txt'),
        os.environ.get('TOPTEN_TESSDATA_DIR', '').strip(),
        os.environ.get('TESSDATA_PREFIX', '').strip(),
        str(Path(program_data) / 'TOPTEN_POP' / 'tessdata') if program_data else '',
        str(Path(local_appdata) / 'TOPTEN_POP' / 'tessdata') if local_appdata else '',
        str(ROOT / 'ocr_tessdata'),
        str(ROOT / 'bootstrap_assets' / 'tessdata'),
        str(DATA_DIR / 'downloaded_tessdata'),
    ]
    for candidate in candidates:
        if not candidate:
            continue
        p = Path(candidate)
        if p.is_dir() and all((p / f'{lang}.traineddata').exists() for lang in ('kor','eng','osd')):
            return str(p)
    return ''


def _tessdata_config():
    path = _find_tessdata_dir()
    return f'--tessdata-dir "{path}"' if path else ''


def _decode_tesseract_console(data):
    """Decode Tesseract console output safely on Korean/legacy Windows code pages.

    Some Windows builds emit localized diagnostics in CP949/ANSI even though
    pytesseract assumes UTF-8 for ``--version``/``--list-langs``.  OCR text
    files themselves remain UTF-8; this helper is only for console metadata.
    """
    if data is None:
        return ''
    if isinstance(data, str):
        return data
    encodings = ['utf-8']
    try:
        import locale
        preferred = locale.getpreferredencoding(False)
        if preferred:
            encodings.append(preferred)
    except Exception:
        pass
    if os.name == 'nt':
        encodings.extend(['cp949', 'mbcs'])
    encodings.extend(['utf-8-sig', 'latin-1'])
    seen = set()
    for enc in encodings:
        key = str(enc).lower()
        if key in seen:
            continue
        seen.add(key)
        try:
            return data.decode(enc)
        except (UnicodeDecodeError, LookupError):
            continue
    return data.decode('utf-8', errors='replace')


def _safe_tesseract_metadata(cmd, tessdata_dir=''):
    """Read Tesseract version/languages without pytesseract's UTF-8-only decoder."""
    version_proc = subprocess.run(
        [cmd, '--version'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        stdin=subprocess.DEVNULL, timeout=20, check=False
    )
    version_output = _decode_tesseract_console(version_proc.stdout)
    if version_proc.returncode != 0:
        raise RuntimeError(f'Tesseract --version 실패: {version_output.strip()[:180]}')
    first = next((line.strip() for line in version_output.splitlines() if line.strip()), '')
    version = first.replace('tesseract', '').strip() or first or 'unknown'

    args = [cmd]
    if tessdata_dir:
        args += ['--tessdata-dir', tessdata_dir]
    args += ['--list-langs']
    langs_proc = subprocess.run(
        args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        stdin=subprocess.DEVNULL, timeout=30, check=False
    )
    langs_output = _decode_tesseract_console(langs_proc.stdout)
    if langs_proc.returncode not in (0, 1):
        raise RuntimeError(f'Tesseract --list-langs 실패: {langs_output.strip()[:180]}')
    langs = sorted({line.strip() for line in langs_output.splitlines()
                    if re.fullmatch(r'[A-Za-z0-9_+-]+', line.strip())
                    and not line.lower().startswith('list of available')})
    return version, langs


def _patch_pytesseract_console_decode():
    """Make pytesseract error decoding tolerant of Korean Windows ANSI output."""
    if pytesseract is None:
        return
    try:
        module = pytesseract.pytesseract
        def _safe_get_errors(error_bytes):
            return ' '.join(_decode_tesseract_console(error_bytes).splitlines()).strip()
        module.get_errors = _safe_get_errors
    except Exception:
        pass


def ocr_engine_status():
    """Return a truthful OCR status and retry a delayed pytesseract import."""
    global pytesseract, _PYTESSERACT_IMPORT_ERROR
    if pytesseract is None:
        try:
            import importlib
            pytesseract = importlib.import_module('pytesseract')
            _PYTESSERACT_IMPORT_ERROR = ''
        except Exception as exc:
            _PYTESSERACT_IMPORT_ERROR = f'{type(exc).__name__}: {exc}'
            return False, f'pytesseract 불러오기 실패: {_PYTESSERACT_IMPORT_ERROR[:140]}'
    cmd = _find_tesseract_executable()
    if not cmd:
        return False, 'Tesseract 실행파일을 찾지 못함 (설치 경로 또는 TESSERACT_CMD 확인)'
    try:
        pytesseract.pytesseract.tesseract_cmd = cmd
        _patch_pytesseract_console_decode()
        tessdata_dir = _find_tessdata_dir()
        version, langs = _safe_tesseract_metadata(cmd, tessdata_dir)
        if 'kor' not in langs:
            return False, f'한국어 OCR 데이터(kor) 없음 · 감지 언어: {", ".join(langs) or "없음"}'
        return True, f'정상 · Tesseract {version} · 언어: {", ".join(langs)}'
    except Exception as exc:
        return False, f'Tesseract 연결 오류: {type(exc).__name__}: {str(exc)[:140]}'


def _load_ocr_cache():
    global _OCR_CACHE
    if _OCR_CACHE is not None:
        return _OCR_CACHE
    try:
        _OCR_CACHE = json.loads(OCR_CACHE_FILE.read_text('utf-8')) if OCR_CACHE_FILE.exists() else {}
    except Exception:
        _OCR_CACHE = {}
    return _OCR_CACHE


def _save_ocr_cache():
    global _OCR_CACHE_DIRTY
    if not _OCR_CACHE_DIRTY:
        return
    OCR_CACHE_FILE.write_text(json.dumps(_load_ocr_cache(), ensure_ascii=False, indent=2), encoding='utf-8')
    _OCR_CACHE_DIRTY = False


def _ocr_cache_key(pdf_path, page_no):
    p = Path(pdf_path)
    st = p.stat()
    return hashlib.sha1(f'{p.resolve()}|{st.st_size}|{st.st_mtime_ns}|{page_no}|{OCR_CACHE_VERSION}'.encode('utf-8', errors='ignore')).hexdigest()


def _prepare_ocr_image(page, dpi=220):
    """Render one PDF page once and enhance text with OpenCV.

    V4.4.37 keeps OCR preprocessing deterministic so the page cache can be reused
    across Excel uploads.  OpenCV improves contrast on coloured/low-contrast POPs.
    """
    pix = page.get_pixmap(matrix=fitz.Matrix(dpi/72, dpi/72), alpha=False, colorspace=fitz.csRGB)
    rgb = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width, 3)
    gray_raw = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    # Plain autocontrast keeps black text on coloured title bars intact.
    from PIL import ImageEnhance, ImageOps
    plain = ImageOps.autocontrast(Image.fromarray(gray_raw), cutoff=1)
    plain = ImageEnhance.Contrast(plain).enhance(1.45)
    plain = plain.resize((int(plain.width*1.20), int(plain.height*1.20)), Image.Resampling.BICUBIC)
    # Binary copy is used only for cheap layout detection/lower-page OCR.
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    enhanced = clahe.apply(gray_raw)
    enhanced = cv2.resize(enhanced, None, fx=1.20, fy=1.20, interpolation=cv2.INTER_CUBIC)
    _, binary = cv2.threshold(enhanced, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    return plain, Image.fromarray(binary)


def _ocr_one_image(im, psm=11):
    config = f'--oem 3 --psm {int(psm)} -c preserve_interword_spaces=1 ' + _tessdata_config()
    try:
        text = pytesseract.image_to_string(im, lang='kor+eng', config=config)
    except Exception:
        return ''
    return re.sub(r'\s+', ' ', str(text or '')).strip()


def _detect_two_column_layout(binary: Image.Image) -> bool:
    """Cheap visual test for a real centre gutter.

    It is intentionally conservative.  A false split is worse than doing one extra
    full-page match; multiple filename codes still force left/right OCR because many
    headquarters POPs are explicit multi-product layouts.
    """
    arr = np.asarray(binary.convert('L'))
    if arr.ndim != 2 or arr.shape[1] < 500 or arr.shape[0] < 500:
        return False
    h, w = arr.shape
    # Ignore very top/bottom decorative bands. Text/visual columns generally occupy
    # the central 70% of these POP pages.
    roi = arr[int(h*0.16):int(h*0.88), :]
    ink = (roi < 210).mean(axis=0)
    lo, hi = int(w*0.36), int(w*0.64)
    if hi <= lo:
        return False
    center = ink[lo:hi]
    if center.size == 0:
        return False
    # Smooth into ~1% width windows and look for a vertical low-ink gutter.
    k = max(5, int(w*0.012))
    kernel = np.ones(k, dtype=np.float32) / k
    smooth = np.convolve(center.astype(np.float32), kernel, mode='same')
    valley = float(smooth.min())
    left_density = float(np.median(ink[int(w*0.08):int(w*0.33)]))
    right_density = float(np.median(ink[int(w*0.67):int(w*0.92)]))
    side = max(0.001, min(left_density, right_density))
    return valley <= max(0.012, side * 0.42)


def _crop_relative(im: Image.Image, x0, y0, x1, y1):
    w, h = im.size
    return im.crop((max(0, int(w*x0)), max(0, int(h*y0)), min(w, int(w*x1)), min(h, int(h*y1))))


def ocr_pdf_page_analysis(pdf_path, page_no, page=None, force=False, force_split=False):
    """OCR a page into reusable semantic regions.

    V4.4.37 checks the page cache *before* asking Tesseract for status.  On a 400-PDF
    rematch this avoids hundreds of needless tesseract --version/--list-langs launches.
    The OCR image is rendered again only for a truly new/changed page or explicit retry.
    """
    global _OCR_CACHE_DIRTY
    key = _ocr_cache_key(pdf_path, page_no)
    cache = _load_ocr_cache()
    rec = cache.get(key)
    if isinstance(rec, dict) and rec.get('regions') and not force:
        regions = dict(rec.get('regions') or {})
        regions.setdefault('split', bool(rec.get('split')))
        regions['combined'] = re.sub(r'\s+', ' ', ' '.join(str(regions.get(k,'') or '') for k in ('full','lower','left','right'))).strip()
        return regions
    ok, _ = ocr_engine_status()
    if not ok:
        return {'full':'', 'lower':'', 'left':'', 'right':'', 'split':False, 'combined':''}
    own_doc = None
    try:
        if page is None:
            own_doc = fitz.open(str(pdf_path))
            page = own_doc.load_page(page_no)
        gray, binary = _prepare_ocr_image(page)
        full = _ocr_one_image(gray, 11)
        lower_img = _crop_relative(binary, 0.0, 0.45, 1.0, 0.97)
        lower = _ocr_one_image(lower_img, 11)
        split = bool(force_split or _detect_two_column_layout(binary))
        left = right = ''
        if split:
            # TOPTEN headquarters POPs place product names in a band below the photos.
            # A narrow gray-image crop avoids model/photo clutter and is dramatically
            # better at separating two products on one page (e.g. left vest/right cardigan).
            left_img = _crop_relative(gray, 0.00, 0.64, 0.51, 0.83)
            right_img = _crop_relative(gray, 0.49, 0.64, 1.00, 0.83)
            left = _ocr_one_image(left_img, 6)
            right = _ocr_one_image(right_img, 6)
        regions = {'full':full, 'lower':lower, 'left':left, 'right':right, 'split':split}
        regions['combined'] = re.sub(r'\s+', ' ', ' '.join(x for x in (full,lower,left,right) if x)).strip()
        cache[key] = {
            'text': regions['combined'], 'regions': {k:v for k,v in regions.items() if k != 'combined'},
            'split': split, 'at': datetime.now().isoformat(timespec='seconds')
        }
        _OCR_CACHE_DIRTY = True
        _save_ocr_cache()
        return regions
    except Exception:
        return {'full':'', 'lower':'', 'left':'', 'right':'', 'split':False, 'combined':''}
    finally:
        if own_doc is not None:
            own_doc.close()


def ocr_pdf_page(pdf_path, page_no, page=None, force=False):
    """Compatibility wrapper used by older routes."""
    return ocr_pdf_page_analysis(pdf_path, page_no, page=page, force=force).get('combined','')


def _title_tokens(text):
    cleaned = str(text or '').upper()
    cleaned = re.sub(r'NEW\s*ARRIVAL|정상가|할인가|기간한정|TOPTEN|탑텐|POP|F\d+', ' ', cleaned)
    return [t for t in re.findall(r'[0-9A-Z가-힣]+', cleaned) if len(t) >= 2]


def _filename_description(filename, filename_codes):
    text = Path(str(filename or '')).stem
    for code in filename_codes or []:
        text = re.sub(re.escape(str(code)), ' ', text, flags=re.I)
    text = re.sub(r'(^|[^0-9])\d{3,4}([^0-9]|$)', ' ', text)
    text = re.sub(r'\bF\d+\b|\bPOP\b|기타', ' ', text, flags=re.I)
    text = re.sub(r'[_\-(),\[\]]+', ' ', text).strip()
    if len(normalize_product_name(text)) < 4:
        return ''
    return text


_GENERIC_META_TOKENS = {
    '남성','여성','공용','키즈','여류','남류','라인업','기타','상품','제품','소재','기능','데일리','기본','베이직',
    '티','티셔츠','반팔','긴팔','탱크탑','탱크','슬리브리스','스웨터','가디건','팬츠','바지','슬랙스','셔츠','블라우스',
    '자켓','재킷','점퍼','아우터','원피스','스커트','셋업','세트','코튼','그래픽','립','리브','쿨링','컴포트',
    'MEN','WOMEN','UNISEX','KIDS','LINEUP','BASIC','DAILY','COTTON','GRAPHIC','TEE','TSHIRT','SHIRT','PANTS',
    'SLACKS','SWEATER','CARDIGAN','TANK','TOP','SETUP','SET','COOLING','COMFORT','AIR'
}


def _semantic_tokens(text):
    out=[]
    for tok in _title_tokens(text):
        t=tok.upper()
        if t in _GENERIC_META_TOKENS:
            continue
        if re.fullmatch(r'\d+', t):
            continue
        if len(t) < 2:
            continue
        out.append(t)
    return out


def _item_anchor_tokens(item):
    toks=[]
    for value in (item.get('title_ko'), item.get('title_en')):
        for t in _semantic_tokens(value):
            if t not in toks:
                toks.append(t)
    return toks[:8]


def _source_anchor_tokens(source_desc):
    toks=[]
    for t in _semantic_tokens(source_desc):
        if t not in toks:
            toks.append(t)
    return toks[:8]


def _anchor_relation(source_desc, item):
    """Return (match, hard_conflict, source_anchors, item_anchors).

    Folder/file names often carry the strongest product-line clue (e.g. 쿨에어).
    Generic item words like 탱크탑 are intentionally excluded.  This prevents a HOTSTUFF
    tank top from being auto-linked to a COOL AIR lineup just because both say 탱크탑.
    """
    src=_source_anchor_tokens(source_desc)
    it=_item_anchor_tokens(item)
    if not src or not it:
        return False, False, src, it
    def same(a,b):
        aa=normalize_product_name(a); bb=normalize_product_name(b)
        if not aa or not bb: return False
        return aa==bb or aa in bb or bb in aa or fuzz.ratio(aa,bb)>=88
    matched=any(same(a,b) for a in src for b in it)
    # Only call it a hard conflict when metadata has a small, clear set of line anchors.
    # Broad descriptive filenames with many tokens do not receive a hard negative.
    conflict=(not matched and len(src) <= 3 and len(it) <= 5)
    return matched, conflict, src, it


def _source_description(pdf_path, filename_codes):
    try:
        source_id=_sync_source_key(Path(pdf_path))
    except Exception:
        source_id=Path(pdf_path).name
    parts=[]
    for part in Path(str(source_id).replace('\\','/')).parts:
        cleaned=_filename_description(part, filename_codes)
        if cleaned:
            parts.append(cleaned)
    return ' '.join(parts).strip()


def _match_search_index(items):
    global _MATCH_SEARCH_CACHE
    sig=hashlib.sha1('|'.join(
        f"{clean_code(i.get('code'))}:{i.get('title_ko','')}:{i.get('title_en','')}:{i.get('gender','')}:{i.get('zone','')}:{_breed_large_from_style_code(i.get('code'))}"
        for i in items
    ).encode('utf-8',errors='ignore')).hexdigest()
    if isinstance(_MATCH_SEARCH_CACHE,dict) and _MATCH_SEARCH_CACHE.get('sig')==sig:
        return _MATCH_SEARCH_CACHE
    choices={}
    anchors={}
    for idx,item in enumerate(items):
        title=' '.join(x for x in (
            normalize_product_name(item.get('title_ko')),
            normalize_product_name(item.get('title_en'))
        ) if x).strip()
        if title:
            choices[idx]=title
        anchors[idx]=_item_anchor_tokens(item)
    _MATCH_SEARCH_CACHE={'sig':sig,'choices':choices,'anchors':anchors}
    return _MATCH_SEARCH_CACHE


def _filename_scope_items(items, filename_codes):
    allowed = {clean_code(c) for c in (filename_codes or []) if clean_code(c)}
    if not allowed:
        return []
    return [i for i in items if clean_code(i.get('code')) in allowed]


def _fast_candidate_items(region_text, items, filename_codes=None, source_desc='', limit=28):
    """Fast retrieval with TOPTEN manual 품종대 gating before expensive fuzzy scoring.

    Filename SKU membership still never implies page order.  A clear page/product manual
    large-category mismatch is removed early; unknown categories remain eligible so OCR
    errors cannot make the candidate set empty.
    """
    page_cat=_page_breed_category(region_text,source_desc)
    page_large=set(page_cat.get('large') or [])
    def breed_filter(rows):
        rows=list(rows)
        if not page_large:
            return rows
        good=[]; unknown=[]
        for it in rows:
            ic=_item_breed_category(it); il=set(ic.get('large') or [])
            if il and il.intersection(page_large): good.append(it)
            elif not il: unknown.append(it)
        # Known matching category first; retain unknowns as safe fallback.
        return good+unknown if good else rows

    scoped=_filename_scope_items(items, filename_codes)
    if scoped:
        return breed_filter(scoped)
    idx=_match_search_index(items)
    query=normalize_product_name(f'{source_desc} {region_text}')
    selected=[]; seen=set()
    if query and idx['choices']:
        try:
            hits=process.extract(query, idx['choices'], scorer=fuzz.WRatio,
                                 limit=min(int(limit)*2,len(idx['choices'])), score_cutoff=30)
        except Exception:
            hits=[]
        for _,__,item_idx in hits:
            if item_idx in seen: continue
            seen.add(item_idx); selected.append(items[item_idx])
    src=set(_source_anchor_tokens(source_desc))
    if src:
        for item_idx,toks in idx['anchors'].items():
            if item_idx in seen: continue
            if src.intersection(toks):
                seen.add(item_idx); selected.append(items[item_idx])
                if len(selected)>=limit*2: break
    selected=breed_filter(selected)
    if selected:
        return selected[:max(limit,1)]
    fallback=breed_filter(items)
    return fallback[:min(len(fallback),max(limit,1))]
def _cluster_candidate_codes(items, filename_codes):
    scoped = _filename_scope_items(items, filename_codes)
    groups = []
    for item in scoped:
        title = normalize_product_name(item.get('title_ko') or item.get('title_en') or '')
        placed = False
        for group in groups:
            gtitle = group['title']
            similar = bool(title and gtitle and (title == gtitle or fuzz.ratio(title, gtitle) >= 92))
            if similar:
                group['items'].append(item); placed=True; break
        if not placed:
            groups.append({'title': title, 'items': [item]})
    return groups


def _rapid_title_score(source_text, title):
    source = normalize_product_name(source_text)
    target = normalize_product_name(title)
    if not source or not target or len(target) < 2:
        return 0.0
    if target in source:
        return 0.99 if len(target) >= 5 else 0.92
    ratio = fuzz.ratio(target, source) / 100.0
    partial = fuzz.partial_ratio(target, source) / 100.0
    wratio = fuzz.WRatio(target, source) / 100.0
    score = max(ratio * 0.92, partial * 0.90, wratio * 0.94)
    if len(target) <= 4:
        score = min(score, 0.84)
    return max(0.0, min(1.0, score))


def _title_match_score(ocr_text, item):
    raw = str(ocr_text or '')
    best = 0.0
    for title in (item.get('title_ko'), item.get('title_en')):
        best = max(best, _rapid_title_score(raw, title))
    return best


def _context_bonus(text, item):
    raw = str(text or '').upper()
    bonus = 0.0
    gender = str(item.get('gender') or '').strip()
    zone = str(item.get('zone') or '').strip()
    if gender and gender.upper() in raw:
        bonus += 0.025
    if zone:
        zone_tokens = [t for t in _title_tokens(zone) if len(t) >= 2]
        if zone_tokens and any(t in raw for t in zone_tokens):
            bonus += 0.02
    return bonus


def _score_items_hybrid(region_text, items, filename_codes=None, source_desc='', limit=None, page_hint_code=''):
    allowed = set(clean_code(c) for c in (filename_codes or []) if clean_code(c))
    learned = _learned_code_for_text(region_text)
    scope_items = _fast_candidate_items(region_text, items, filename_codes, source_desc, limit=30)
    if learned and all(clean_code(i.get('code')) != learned for i in scope_items):
        learned_item = next((i for i in items if clean_code(i.get('code')) == learned), None)
        if learned_item is not None:
            scope_items = list(scope_items) + [learned_item]
    scope_size = len(scope_items)
    scored = []
    for item in scope_items:
        code = clean_code(item.get('code'))
        title_score = _title_match_score(region_text, item)
        source_title = _title_match_score(source_desc, item) if source_desc else 0.0
        anchor_match, anchor_conflict, src_anchors, item_anchors = _anchor_relation(source_desc, item)
        filename_bonus = 0.10 if code in allowed else 0.0
        page_order = bool(page_hint_code and code == clean_code(page_hint_code))
        pg,ig,gender_adj,gender_reason=_ai_gender_relation(region_text,item)
        breed_adj,breed_conflict,page_breed,item_breed,breed_reason=_manual_breed_relation(region_text,item,source_desc)
        notice_bonus,notice_match,notice_category=_notice_text_relation(region_text,item)
        score = max(title_score, source_title * 0.92)
        if gender_adj < 0 or breed_conflict:
            score = 0.0
        else:
            score += filename_bonus + _context_bonus(region_text, item) + gender_adj + breed_adj + notice_bonus
            if anchor_match: score += 0.13
            if page_order: score += 0.08
        if anchor_conflict:
            score=min(score,0.49)
        score=min(1.0,max(0.0,score))
        learned_candidate = bool(learned and code == learned and gender_adj >= 0 and not breed_conflict)
        if learned_candidate:
            score = max(score, 0.97); anchor_conflict=False
        scored.append({
            'score': float(score), 'title_score': float(title_score),
            'filename_title_score': float(source_title), 'item': item,
            'filename_candidate': code in allowed, 'scope_size': scope_size,
            'learned_candidate': learned_candidate, 'anchor_match':anchor_match,
            'anchor_conflict':anchor_conflict, 'source_anchors':src_anchors,
            'item_anchors':item_anchors, 'page_order_candidate':page_order,
            'gender_conflict': gender_adj < 0, 'gender_reason': gender_reason,
            'breed_conflict': breed_conflict, 'breed_reason': breed_reason,
            'page_breed': page_breed, 'item_breed': item_breed, 'notice_match':notice_match, 'notice_category':notice_category,
        })
    scored.sort(key=lambda x: (
        x.get('gender_conflict',False), x.get('breed_conflict',False), x.get('anchor_conflict',False),
        -x['score'], -x['title_score'], clean_code(x['item'].get('code'))
    ))
    return scored if limit is None else scored[:limit]
def _suggestions_from_hybrid(scored, limit=3):
    out=[]
    for x in scored[:limit]:
        item=x['item']
        out.append({
            'code':clean_code(item.get('code')), 'title':str(item.get('title_ko') or ''),
            'score':round(x['score']*100),'gender':_ai_item_gender(item) or '-',
            'category':_breed_label(_item_breed_category(item)),
        })
    return out
def _code_present_in_text(text, code):
    compact_text = re.sub(r'[^A-Z0-9]', '', str(text or '').upper())
    compact_code = re.sub(r'[^A-Z0-9]', '', clean_code(code).upper())
    return bool(compact_code and compact_code in compact_text)


def _present_codes(text, codes):
    found=[]
    for code in codes:
        c=clean_code(code)
        if c and _code_present_in_text(text,c) and c not in found:
            found.append(c)
    return found


def _unique_present_code(text, codes):
    present=_present_codes(text,codes)
    return present[0] if len(present)==1 else ''


def _grade_candidate(best, second_score, exact_page_code=False):
    if not best:
        return False, 'E', 0.0
    score=float(best.get('score') or 0); title=float(best.get('title_score') or 0)
    source_title=float(best.get('filename_title_score') or 0)
    margin=max(0.0, score-float(second_score or 0)); scope_size=int(best.get('scope_size') or 0)
    if best.get('gender_conflict') or best.get('breed_conflict'):
        return False,'D',margin
    if best.get('learned_candidate') or exact_page_code:
        return True,'A',margin
    if best.get('anchor_conflict'):
        return False,'D',margin
    anchor=bool(best.get('anchor_match')); page_order=bool(best.get('page_order_candidate'))
    if best.get('filename_candidate'):
        # Filename code means this style belongs to the PDF; it never means "pick the first code".
        # Weak title/path corroboration is enough, while a line conflict above blocks it.
        if scope_size <= 1:
            if title>=0.42 or source_title>=0.56 or anchor:
                return True,'B',margin
        else:
            if title>=0.56 and margin>=0.02: return True,'A',margin
            if title>=0.45 and margin>=0.03: return True,'B',margin
            if page_order and (title>=0.35 or source_title>=0.45 or anchor): return True,'B',margin
            if anchor and title>=0.36: return True,'B',margin
        return (False,'C',margin) if score>=0.50 else (False,'D',margin)
    # No code in filename: require strong visible title, but path-line agreement can lower
    # the threshold safely. This is where HOTSTUFF vs COOL AIR is explicitly guarded.
    if anchor and title>=0.62 and margin>=0.025: return True,'A',margin
    if title>=0.76 and margin>=0.04: return True,'A',margin
    if title>=0.68 and margin>=0.07: return True,'B',margin
    return (False,'C',margin) if score>=0.52 else (False,'E',margin)

def _build_result(page_no, region_name, region_text, scored, filename_codes, exact_code=''):
    by_code={clean_code(x['item'].get('code')):x for x in scored}
    best = by_code.get(clean_code(exact_code)) if exact_code else (scored[0] if scored else None)
    if best is None:
        return {
            'page':page_no,'page_label':page_no+1,'text':region_text[:220], 'code':'','title':'','score':0,
            'method':f'{region_name} · 판독 부족','needs_manual':True,'filename_codes':filename_codes,
            'suggestions':_suggestions_from_hybrid(scored,3),'margin':0,'grade':'E'
        }
    second=max((x['score'] for x in scored if clean_code(x['item'].get('code')) != clean_code(best['item'].get('code'))), default=0.0)
    exact=bool(exact_code and clean_code(best['item'].get('code'))==clean_code(exact_code))
    auto, grade, margin=_grade_candidate(best,second,exact_page_code=exact)
    item=best['item']; code=clean_code(item.get('code'))
    recommended=bool((auto or (best['score'] >= 0.60 and margin >= 0.06)) and not best.get('anchor_conflict') and not best.get('gender_conflict') and not best.get('breed_conflict'))
    signals=[]
    if exact: signals.append('페이지 내부 품번')
    if best['title_score']>=0.50: signals.append('상품명 OCR')
    if best.get('filename_candidate'): signals.append('파일명 품번 포함')
    if best.get('filename_title_score',0)>=0.55: signals.append('폴더/파일 상품명')
    if best.get('anchor_match'): signals.append('제품라인 일치')
    if best.get('page_order_candidate'): signals.append('페이지순서 보조')
    if best.get('gender_conflict'): signals.append('성별 충돌 차단')
    if best.get('breed_conflict'): signals.append('품종대 충돌 차단')
    elif best.get('page_breed',{}).get('large') and best.get('item_breed',{}).get('large'): signals.append('품종코드 일치')
    if best.get('anchor_conflict'): signals.append('제품라인 충돌 차단')
    method=f'{region_name} · ' + (' + '.join(signals) if signals else '유사도 후보') + f' · {grade}급'
    return {
        'page':page_no,'page_label':page_no+1,'text':region_text[:220],
        'code':code if recommended else '', 'title':str(item.get('title_ko') or '') if recommended else '',
        'score':round(best['score']*100),'method':method,'needs_manual':not auto,
        'filename_codes':filename_codes,'suggestions':_suggestions_from_hybrid(scored,3),
        'margin':round(margin*100),'grade':grade,
    }


def _expand_shared_title_group(result, scored, groups, region_text, region_name, filename_codes):
    """Expand one confident OCR decision to all filename codes sharing that same title.

    Example: a headquarters POP filename can list 3 style codes that all correspond to
    the same displayed product name.  Mapping only one of them is incomplete; mapping all
    of them is safe only when the visible title supports that shared title cluster.
    """
    if not result or result.get('needs_manual') or not result.get('code'):
        return [result] if result else []
    code = clean_code(result.get('code'))
    group = next((g for g in groups if any(clean_code(i.get('code')) == code for i in g.get('items', []))), None)
    if not group or len(group.get('items', [])) <= 1:
        return [result]
    # Require OCR evidence for the shared product title.  The filename list alone never expands.
    best_title = max((_title_match_score(region_text, i) for i in group['items']), default=0.0)
    if best_title < 0.50:
        return [result]
    out = []
    for item in group['items']:
        c = clean_code(item.get('code'))
        base = next((x for x in scored if clean_code(x['item'].get('code')) == c), None)
        if base is None:
            continue
        clone = dict(result)
        clone['code'] = c
        clone['title'] = str(item.get('title_ko') or '')
        clone['score'] = round(max(float(base.get('score') or 0), best_title) * 100)
        clone['needs_manual'] = False
        clone['grade'] = 'B'
        clone['method'] = f'{region_name} · 상품명 OCR + 파일명 공통상품 다중품번 · B급'
        clone['suggestions'] = _suggestions_from_hybrid(scored, 3)
        out.append(clone)
    return out or [result]


def _dedupe_page_results(results):
    """Keep the strongest row for each code while allowing multiple codes per page."""
    by_code={}
    blanks=[]
    for r in results:
        code=clean_code(r.get('code'))
        if not code:
            blanks.append(r); continue
        old=by_code.get(code)
        key=(not r.get('needs_manual'), int(r.get('score') or 0), int(r.get('margin') or 0))
        old_key=(not old.get('needs_manual'), int(old.get('score') or 0), int(old.get('margin') or 0)) if old else None
        if old is None or key>old_key:
            by_code[code]=r
    kept=list(by_code.values())
    kept.sort(key=lambda r:(int(r.get('page',0)), -int(r.get('score') or 0), clean_code(r.get('code'))))
    if kept:
        return kept
    return blanks[:1]


def _visible_shared_filename_items(region_text, filename_codes, by_code, source_desc, min_title=0.50):
    """Return filename-roster items that have strong visible-title evidence on one page.

    Multiple returned items are allowed to share the same PDF page. This handles official
    POPs that intentionally advertise two or more related SKUs on one sheet. A product-line
    conflict still blocks sharing.
    """
    out=[]
    seen=set()
    for raw in filename_codes or []:
        code=clean_code(raw)
        if not code or code in seen: continue
        item=by_code.get(code)
        if not item: continue
        _, conflict, _, _ = _anchor_relation(source_desc,item)
        if conflict: continue
        title_score=_title_match_score(region_text,item)
        if title_score >= float(min_title):
            out.append((item,float(title_score)))
            seen.add(code)
    return out


def _explicit_single_page_shared_items(filename_codes, by_code, source_desc):
    """Single-page PDF + several explicit filename SKUs means one shared official POP.

    The filename itself is an explicit roster supplied by HQ. We still reject a roster item
    when folder/file product-line evidence strongly conflicts with that item.
    """
    out=[]; seen=set()
    for raw in filename_codes or []:
        code=clean_code(raw)
        if not code or code in seen: continue
        item=by_code.get(code)
        if not item: continue
        _, conflict, _, _ = _anchor_relation(source_desc,item)
        if conflict: continue
        out.append(item); seen.add(code)
    return out


def match_pdf_pages(pdf_path, items, force_ocr=False):
    """V4.4.37 fast path-aware matcher.

    Key changes:
    - all filename codes are membership candidates; the first code is never privileged;
    - folder names are evidence (e.g. 쿨에어) and conflicting product lines are blocked;
    - cached OCR is read without launching Tesseract metadata checks;
    - PDFs without codes search only a RapidFuzz top-N shortlist, not the whole Excel;
    - when filename-code count equals page count, order is only a small tie-breaker;
    - page sharing is evidence-driven: notice truth / exact codes / multiple visible titles may map several SKUs to one page;
    - a single-page PDF whose filename explicitly lists several SKUs is treated as one shared official POP unless product-line evidence conflicts.
    """
    results=[]; by_code=_item_by_code(items)
    filename_codes=extract_filename_codes(Path(pdf_path).name, items)
    source_desc=_source_description(pdf_path,filename_codes)
    filename_groups=_cluster_candidate_codes(items,filename_codes)
    doc=fitz.open(str(pdf_path))
    try:
        for page_no in range(doc.page_count):
            _raise_if_scan_cancelled()
            page=doc.load_page(page_no)
            notice_rows=_notice_match_page_object(page,items)
            if notice_rows:
                for nr in notice_rows:
                    nr.update({'page':page_no,'page_label':page_no+1,'filename_codes':filename_codes})
                results.extend(notice_rows)
                continue
            embedded=re.sub(r'\s+',' ',page.get_text('text') or '').strip()
            # Only force split when one page really contains several different title groups.
            force_split=bool(doc.page_count==1 and len(filename_groups)>1)
            analysis=ocr_pdf_page_analysis(pdf_path,page_no,page=page,force=force_ocr,force_split=force_split)
            combined=re.sub(r'\s+',' ',f"{embedded} {analysis.get('combined','')}").strip()
            page_results=[]
            page_hint=(filename_codes[page_no] if len(filename_codes)>1 and len(filename_codes)==doc.page_count else '')

            exact_codes=_present_codes(combined,[i.get('code') for i in items])
            for exact in exact_codes:
                if exact not in by_code: continue
                scored=_score_items_hybrid(combined,items,filename_codes,source_desc,page_hint_code=page_hint)
                page_results.append(_build_result(page_no,'전체 페이지',combined,scored,filename_codes,exact_code=exact))

            split=bool(analysis.get('split')); used_groups=set()
            if split:
                region_rows=[]
                for label,key in (('좌측 상품영역','left'),('우측 상품영역','right')):
                    rtext=str(analysis.get(key) or '').strip()
                    if len(normalize_product_name(rtext))<3: continue
                    scored=_score_items_hybrid(rtext,items,filename_codes,source_desc,page_hint_code=page_hint)
                    if not scored: continue
                    top=float(scored[0].get('score') or 0); second=float(scored[1].get('score') or 0) if len(scored)>1 else 0.0
                    region_rows.append((top-second,top,label,rtext,scored))
                region_rows.sort(key=lambda x:(-x[0],-x[1]))
                for _,__,label,rtext,scored0 in region_rows:
                    scored=list(scored0)
                    if used_groups and filename_groups:
                        blocked=set()
                        for gi in used_groups:
                            blocked.update(clean_code(i.get('code')) for i in filename_groups[gi]['items'])
                        filtered=[x for x in scored if clean_code(x['item'].get('code')) not in blocked]
                        if filtered: scored=filtered
                    r=_build_result(page_no,label,rtext,scored,filename_codes)
                    if r.get('score',0)<42: continue
                    code=clean_code(r.get('code')); gi=None
                    if code and filename_groups:
                        gi=next((idx for idx,g in enumerate(filename_groups) if any(clean_code(i.get('code'))==code for i in g['items'])),None)
                    expanded=_expand_shared_title_group(r,scored,filename_groups,rtext,label,filename_codes)
                    # Never expand a group through a product-line conflict.
                    expanded=[x for x in expanded if x]
                    page_results.extend(expanded)
                    if gi is not None and any(not x.get('needs_manual') for x in expanded): used_groups.add(gi)

            base_text=' '.join(x for x in (embedded,analysis.get('full',''),analysis.get('lower','')) if x).strip()

            # Shared-page exception for multi-page PDFs: if two or more filename SKUs have
            # strong visible product-title evidence on THIS page, keep all of them on this page.
            # This is intentionally evaluated before the normal one-to-one fallback.
            visible_shared=_visible_shared_filename_items(base_text,filename_codes,by_code,source_desc,min_title=0.50)
            if len(visible_shared)>=2:
                for item,title_score in visible_shared:
                    code=clean_code(item.get('code'))
                    page_results.append({
                        'page':page_no,'page_label':page_no+1,'text':base_text[:220],
                        'code':code,'title':str(item.get('title_ko') or ''),
                        'score':round(max(title_score,0.76)*100),
                        'method':'페이지공유 · 복수 상품명 확인 + 파일명 품번 멤버십 · B급',
                        'needs_manual':False,'filename_codes':filename_codes,
                        'suggestions':[],'margin':100,'grade':'B'
                    })

            confident={clean_code(r.get('code')) for r in page_results if r.get('code') and not r.get('needs_manual')}
            if not confident or not split:
                scored=_score_items_hybrid(base_text,items,filename_codes,source_desc,page_hint_code=page_hint)
                exact=_unique_present_code(base_text,[i.get('code') for i in items])
                r=_build_result(page_no,'전체/하단 상품명',base_text,scored,filename_codes,exact_code=exact)
                page_results.extend(_expand_shared_title_group(r,scored,filename_groups,base_text,'전체/하단 상품명',filename_codes))

            # Important shared-POP rule: if a one-page filename explicitly lists several
            # style codes and they form the same title group, keep every style. This fixes
            # old "first code wins" behaviour without trusting unrelated codes.
            if doc.page_count==1 and filename_codes and filename_groups:
                for group in filename_groups:
                    if len(group.get('items',[]))<=1: continue
                    group_title=max((_title_match_score(base_text,i) for i in group['items']),default=0.0)
                    safe=[]
                    for item in group['items']:
                        anchor_match,conflict,_,_=_anchor_relation(source_desc,item)
                        src_title=_title_match_score(source_desc,item)
                        if not conflict and (group_title>=0.42 or src_title>=0.48 or anchor_match):
                            safe.append(item)
                    if len(safe)>=2:
                        for item in safe:
                            code=clean_code(item.get('code'))
                            page_results.append({
                                'page':page_no,'page_label':page_no+1,'text':base_text[:220],
                                'code':code,'title':str(item.get('title_ko') or ''),
                                'score':round(max(group_title,0.70)*100),
                                'method':'단일페이지 · 파일명 다중품번 멤버십 + 공통상품명 검증 · B급',
                                'needs_manual':False,'filename_codes':filename_codes,
                                'suggestions':[],'margin':100,'grade':'B'
                            })

            # V4.4.56: official one-sheet shared POP. If the PDF has exactly one page and
            # its filename explicitly lists several known SKUs, every non-conflicting roster
            # SKU may use that same page even when their individual product titles differ
            # (e.g. a cardigan + mock-neck sweater "line-up" POP). This is the only broad
            # exception to the normal one-page/one-SKU fallback.
            if doc.page_count==1 and len(filename_codes)>=2:
                shared_roster=_explicit_single_page_shared_items(filename_codes,by_code,source_desc)
                if len(shared_roster)>=2:
                    for item in shared_roster:
                        code=clean_code(item.get('code'))
                        page_results.append({
                            'page':page_no,'page_label':page_no+1,'text':base_text[:220],
                            'code':code,'title':str(item.get('title_ko') or ''),
                            'score':78,
                            'method':'단일페이지 · 파일명 명시 다중품번 공용POP · B급',
                            'needs_manual':False,'filename_codes':filename_codes,
                            'suggestions':[],'margin':100,'grade':'B'
                        })

            deduped=_dedupe_page_results(page_results)
            autos=[r for r in deduped if r.get('code') and not r.get('needs_manual')]
            if autos:
                results.extend(deduped)
            else:
                useful=[r for r in deduped if int(r.get('score') or 0)>=48]
                if useful:
                    useful.sort(key=lambda r:(-int(r.get('score') or 0),-int(r.get('margin') or 0)))
                    results.append(useful[0])
                elif deduped:
                    results.append(deduped[0])
    finally:
        doc.close()
    return results


# ---------------- V4.4.37 PaddleOCR-VL 1.6 page AI engine ----------------
_AI_CACHE = None
_AI_CACHE_DIRTY = False


def _ai_worker_env():
    env=os.environ.copy()
    env['TOPTEN_AI_SITE']=str(AI_SITE_DIR)
    env['PYTHONNOUSERSITE']='1'
    env.pop('PADDLE_PDX_MODEL_SOURCE',None)
    env.setdefault('HF_HUB_ETAG_TIMEOUT','8')
    env.setdefault('HF_HUB_DOWNLOAD_TIMEOUT','120')
    # Once the official model cache is complete, skip the remote source connectivity
    # check. This avoids the old 8-20 second status/import waits on every page load.
    try:
        model_dir=Path.home()/'.paddlex'/'official_models'/'PaddleOCR-VL-1.6'
        if model_dir.is_dir() and sum(p.stat().st_size for p in model_dir.rglob('*') if p.is_file()) > 500*1024*1024:
            env['PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK']='True'
    except Exception:
        pass
    return env


def _ai_installed_versions():
    """Read package metadata without importing Paddle/PaddleOCR.

    Importing Paddle just to paint the status line can take longer than the old
    subprocess timeout on CPU-only Windows PCs. Matching itself is the real runtime
    test; the status page must stay instant and non-blocking.
    """
    versions={}
    try:
        for dist in __import__('importlib.metadata',fromlist=['distributions']).distributions(path=[str(AI_SITE_DIR)]):
            name=str(dist.metadata.get('Name') or '').strip().lower().replace('_','-')
            if name in ('paddlepaddle','paddleocr'):
                versions[name]=str(dist.version)
    except Exception:
        pass
    return versions


def _ai_probe_light():
    if not AI_SITE_DIR.exists(): return False, 'AI 전용 런타임 미설치'
    versions=_ai_installed_versions()
    has_paddle=(AI_SITE_DIR/'paddle').is_dir() and bool(versions.get('paddlepaddle'))
    has_ocr=(AI_SITE_DIR/'paddleocr').is_dir() and bool(versions.get('paddleocr'))
    if not has_paddle or not has_ocr:
        missing=[]
        if not has_paddle: missing.append('PaddlePaddle')
        if not has_ocr: missing.append('PaddleOCR')
        return False, 'AI 런타임 구성 누락: '+', '.join(missing)
    return True, f"paddle={versions.get('paddlepaddle','?')}; paddleocr={versions.get('paddleocr','?')}"


def _ai_model_cache_info():
    candidates=[
        Path.home()/'.paddlex'/'official_models'/'PaddleOCR-VL-1.6',
        AI_RUNTIME_DIR/'models'/'PaddleOCR-VL-1.6',
    ]
    best=None; best_size=0
    for p in candidates:
        if not p.is_dir(): continue
        try: size=sum(x.stat().st_size for x in p.rglob('*') if x.is_file())
        except Exception: size=0
        if size>best_size: best,best_size=p,size
    return best,best_size


def ai_engine_status():
    ok,msg=_ai_probe_light()
    if not ok: return False,msg
    model_dir,model_bytes=_ai_model_cache_info()
    if model_dir and model_bytes>500*1024*1024:
        return True,'정상 · PP-OCRv5 Korean FAST + PaddleOCR-VL 1.6 정밀 fallback · '+msg+' · VL 모델 캐시 준비됨'
    return True,'런타임 정상 · PP-OCRv5 Korean FAST 우선 · PaddleOCR-VL 1.6은 애매한 페이지만 사용 · '+msg


def _pip_to_ai(args, log):
    log.parent.mkdir(parents=True,exist_ok=True)
    cmd=[sys.executable,'-m','pip','install','--disable-pip-version-check','--no-warn-script-location','--upgrade','--target',str(AI_SITE_DIR),'--retries','3','--timeout','120']+list(args)
    with log.open('a',encoding='utf-8',errors='replace') as f:
        f.write('\n$ '+' '.join(cmd)+'\n'); f.flush()
        return subprocess.call(cmd,stdout=f,stderr=subprocess.STDOUT,env=os.environ.copy())


def _ai_has_package_dir(name):
    return (AI_SITE_DIR/name).exists() or any(AI_SITE_DIR.glob(name.replace('-','_')+'-*.dist-info'))


def ensure_ai_runtime():
    _raise_if_scan_cancelled()
    AI_RUNTIME_DIR.mkdir(parents=True,exist_ok=True)
    AI_SITE_DIR.mkdir(parents=True,exist_ok=True)
    LOG_DIR.mkdir(parents=True,exist_ok=True)
    ok,msg=_ai_probe_light()
    if ok:
        AI_RUNTIME_MARKER.write_text(json.dumps({'version':'4.4.36','engine':'PP-OCRv5 Korean FAST + PaddleOCR-VL-1.6 fallback','ready_at':datetime.now().isoformat(),'probe':msg},ensure_ascii=False,indent=2),encoding='utf-8')
        return True,msg

    if not AI_LOG_FILE.exists():
        AI_LOG_FILE.write_text('TOPTEN POP V4.4.37 AI runtime install/repair log\n',encoding='utf-8')
    else:
        with AI_LOG_FILE.open('a',encoding='utf-8',errors='replace') as f:
            f.write('\n--- V4.4.37 runtime repair '+datetime.now().isoformat()+' ---\n')

    versions=_ai_installed_versions()
    if not _ai_has_package_dir('paddle') or versions.get('paddlepaddle')!='3.2.1':
        _set_scan_status(message='AI 엔진 1/2 · PaddlePaddle CPU 설치/복구 중')
        rc=_pip_to_ai(['paddlepaddle==3.2.1','-i','https://www.paddlepaddle.org.cn/packages/stable/cpu/'],AI_LOG_FILE)
        if rc!=0: return False,'PaddlePaddle 설치 실패 · data/logs/ai_engine.log 확인'
    else:
        _set_scan_status(message='AI 엔진 1/2 · 기존 PaddlePaddle 재사용')

    versions=_ai_installed_versions()
    if not _ai_has_package_dir('paddleocr') or versions.get('paddleocr')!='3.7.0':
        _set_scan_status(message='AI 엔진 2/2 · PaddleOCR 3.7.0 / VL 1.6 설치·복구 중')
        rc=_pip_to_ai(['paddleocr[doc-parser]==3.7.0'],AI_LOG_FILE)
        if rc!=0: return False,'PaddleOCR 설치 실패 · data/logs/ai_engine.log 확인'
    else:
        _set_scan_status(message='AI 엔진 2/2 · 기존 PaddleOCR 3.7.0 재사용')

    _raise_if_scan_cancelled()
    ok,msg=_ai_probe_light()
    if ok:
        AI_RUNTIME_MARKER.write_text(json.dumps({'version':'4.4.36','engine':'PP-OCRv5 Korean FAST + PaddleOCR-VL-1.6 fallback','ready_at':datetime.now().isoformat(),'probe':msg},ensure_ascii=False,indent=2),encoding='utf-8')
        return True,msg
    return False,'AI 런타임 구성 확인 실패 · '+str(msg).replace('\n',' ')[:350]+' · data/logs/ai_engine.log 확인'


def _load_ai_cache():
    global _AI_CACHE, _AI_CACHE_DIRTY
    if _AI_CACHE is not None: return _AI_CACHE
    raw={}
    if AI_PAGE_CACHE_FILE.exists():
        try: raw=json.loads(AI_PAGE_CACHE_FILE.read_text('utf-8'))
        except Exception: raw={}
    if not isinstance(raw,dict): raw={}
    pages=raw.get('pages') if isinstance(raw.get('pages'),dict) else {}
    # One-time consolidation of V4.4.15~18 versioned caches into one permanent cache.
    for source in LEGACY_AI_PAGE_CACHE_FILES:
        if not source.exists(): continue
        try: old=json.loads(source.read_text('utf-8'))
        except Exception: old={}
        if isinstance(old,dict) and isinstance(old.get('pages'),dict):
            for k,v in old['pages'].items():
                if k not in pages and isinstance(v,dict) and str(v.get('text') or '').strip(): pages[k]=v
    raw={'_version':AI_PAGE_CACHE_VERSION,'pages':pages}
    _AI_CACHE=raw; _AI_CACHE_DIRTY=True
    _save_ai_cache()
    for source in LEGACY_AI_PAGE_CACHE_FILES:
        try: source.unlink(missing_ok=True)
        except Exception: pass
    return raw


def _save_ai_cache():
    global _AI_CACHE_DIRTY
    if _AI_CACHE is None or not _AI_CACHE_DIRTY: return
    AI_PAGE_CACHE_FILE.write_text(json.dumps(_AI_CACHE,ensure_ascii=False,indent=2),encoding='utf-8')
    _AI_CACHE_DIRTY=False


def _ai_cache_key(pdf_path,page_no):
    p=Path(pdf_path); st=p.stat()
    try: rel=_sync_source_key(p)
    except Exception: rel=p.name
    raw=f'{AI_PAGE_CACHE_VERSION}|{rel}|{st.st_size}|{st.st_mtime_ns}|{int(page_no)}'
    return hashlib.sha1(raw.encode('utf-8',errors='ignore')).hexdigest()


def _render_ai_page(pdf_path,page_no):
    """Render a CPU-friendly page image for the VL model.

    TOPTEN POP pages are posters, not dense books. 1100px width preserves the
    gender/product-name text while cutting the visual-token workload versus the
    old 1500px render. Existing temporary renders are resized in place.
    """
    key=_ai_cache_key(pdf_path,page_no); out=CACHE_DIR/f'ai_page_{key}.jpg'
    if out.exists():
        try:
            im=Image.open(out).convert('RGB')
            if im.width>1100:
                h=max(1,round(im.height*1100/im.width)); im=im.resize((1100,h),Image.Resampling.LANCZOS)
                im.save(out,'JPEG',quality=88,optimize=True)
            return out
        except Exception:
            try: out.unlink(missing_ok=True)
            except Exception: pass
    with fitz.open(str(pdf_path)) as doc:
        page=doc.load_page(page_no)
        pix=page.get_pixmap(matrix=fitz.Matrix(1.6,1.6),alpha=False)
        im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples)
        if im.width>1100:
            h=max(1,round(im.height*1100/im.width)); im=im.resize((1100,h),Image.Resampling.LANCZOS)
        im.save(out,'JPEG',quality=88,optimize=True)
    return out


def _collect_fast_tasks(pdfs):
    """Only pages with no extracted text need the fast Korean OCR first pass."""
    cache=_load_ai_cache()['pages']; tasks=[]; meta={}; cached=0; total_pages=0
    for pdf in pdfs:
        try:
            with fitz.open(str(pdf)) as doc: pc=doc.page_count
            total_pages+=pc
            for pno in range(pc):
                key=_ai_cache_key(pdf,pno); meta[key]=(pdf,pno)
                rec=cache.get(key)
                if isinstance(rec,dict) and str(rec.get('text') or '').strip():
                    cached+=1; continue
                img=_render_ai_page(pdf,pno)
                tasks.append({'id':key,'image':str(img)})
        except Exception: continue
    return tasks,meta,cached,total_pages


def _collect_vl_fallback_tasks(pdfs,items,eligible_keys=None):
    """Use the 0.9B VL model only for newly analyzed ambiguous pages.

    On a repeated full re-match, unchanged pages that already have any cached AI/OCR
    text are *decision-cache only*: they are never sent back through OCR/VL just
    because the current Excel produced an ambiguous score. This is the critical
    V4.4.37 fix that makes repeated matching a fast re-decision instead of a second
    expensive inference pass. Changed/new PDF pages get new cache keys and are still
    analyzed normally.
    """
    tasks=[]; meta={}; vl_ready=0; fast_confident=0; total_pages=0
    eligible=None if eligible_keys is None else {str(x) for x in eligible_keys}
    for pdf in pdfs:
        try:
            with fitz.open(str(pdf)) as doc: pc=doc.page_count
            total_pages+=pc
            for pno in range(pc):
                key=_ai_cache_key(pdf,pno); meta[key]=(pdf,pno)
                eng=_ai_page_engine(pdf,pno)
                txt=_ai_page_text(pdf,pno)
                if eng.startswith('PaddleOCR-VL') and txt.strip():
                    vl_ready+=1; _cleanup_ai_render(pdf,pno); continue
                if txt.strip() and _fast_page_is_confident(pdf,pno,items):
                    fast_confident+=1; _cleanup_ai_render(pdf,pno); continue
                # Re-match mode may restrict VL to pages created by this run only.
                # Existing cached FAST text is reused as-is and only SKU/page scoring
                # is recomputed. This prevents the same 400 PDFs being inferred again.
                if eligible is not None and key not in eligible:
                    _cleanup_ai_render(pdf,pno); continue
                # Empty text or newly-produced ambiguous FAST OCR: escalate this page.
                img=_render_ai_page(pdf,pno)
                tasks.append({'id':key,'image':str(img)})
        except Exception: continue
    return tasks,meta,vl_ready,fast_confident,total_pages


def _ai_cache_coverage(pdfs):
    """Return (cached_pages, total_pages, current_keys) for unchanged-PDF reuse."""
    pages=_load_ai_cache().get('pages',{})
    cached=0; total=0; keys=set()
    for pdf in pdfs:
        try:
            with fitz.open(str(pdf)) as doc: pc=doc.page_count
            for pno in range(pc):
                total+=1; key=_ai_cache_key(pdf,pno); keys.add(key)
                rec=pages.get(key)
                if isinstance(rec,dict) and str(rec.get('text') or '').strip(): cached+=1
        except Exception:
            continue
    return cached,total,keys


def _cleanup_stale_ai_job_artifacts():
    """Remove only transient worker files from prior stopped/crashed AI jobs."""
    work=DATA_DIR/'ai_jobs'
    try:
        if work.is_dir(): shutil.rmtree(work)
    except Exception:
        pass
    try:
        for img in CACHE_DIR.glob('ai_page_*.jpg'):
            try: img.unlink()
            except Exception: pass
    except Exception:
        pass


def _prune_ai_cache_to_current(current_keys):
    """Drop cache records for deleted/changed PDFs after a successful full scan."""
    global _AI_CACHE_DIRTY
    try:
        cache=_load_ai_cache(); pages=cache.get('pages',{})
        keep={k:v for k,v in pages.items() if k in current_keys}
        if len(keep)!=len(pages):
            cache['pages']=keep; _AI_CACHE_DIRTY=True; _save_ai_cache()
    except Exception:
        pass



def _ingest_ai_worker_output(output_path, task_meta=None, items=None, default_engine='PaddleOCR-VL-1.6', preview_method='AI 후보 분석'):
    """Persist each completed page immediately and optionally publish a live candidate preview."""
    global _AI_CACHE_DIRTY
    if not output_path.exists(): return 0
    try: rows=json.loads(output_path.read_text('utf-8')).get('results') or []
    except Exception: return 0
    pages=_load_ai_cache()['pages']; added=0
    for row in rows:
        key=str(row.get('id') or ''); txt=' '.join(str(row.get('text') or '').split())
        if key and txt:
            engine=str(row.get('engine') or default_engine)
            prev=pages.get(key)
            if not isinstance(prev,dict) or str(prev.get('text') or '')!=txt or str(prev.get('engine') or '')!=engine:
                pages[key]={'text':txt,'engine':engine,'saved_at':datetime.now().isoformat(),'seconds':row.get('seconds')}
                _AI_CACHE_DIRTY=True; added+=1
            if task_meta and items and key in task_meta:
                pdf,pno=task_meta[key]
                # Save first, then use the exact same final scoring logic for preview.
                if _AI_CACHE_DIRTY: _save_ai_cache()
                _set_live_preview(pdf,pno,items,preview_method)
    if added: _save_ai_cache()
    return len(rows)



def _run_ai_worker(tasks, cached_base=0, page_total=None, task_meta=None, items=None):
    if not tasks: return True,''
    stamp=str(int(time.time()*1000)); work=DATA_DIR/'ai_jobs'; work.mkdir(parents=True,exist_ok=True)
    manifest=work/f'{stamp}_manifest.json'; output=work/f'{stamp}_out.json'; progress=work/f'{stamp}_progress.json'
    manifest.write_text(json.dumps({'tasks':tasks},ensure_ascii=False),encoding='utf-8')
    cmd=[sys.executable,'-S',str(AI_WORKER),'--manifest',str(manifest),'--output',str(output),'--progress',str(progress)]
    with AI_LOG_FILE.open('a',encoding='utf-8',errors='replace') as log:
        log.write('\nAI WORKER: '+' '.join(cmd)+'\n'); log.flush()
        global _ACTIVE_AI_PROC
        proc=subprocess.Popen(cmd,env=_ai_worker_env(),stdout=log,stderr=subprocess.STDOUT)
        with _ACTIVE_AI_PROC_LOCK: _ACTIVE_AI_PROC=proc
        last_output_count=0; rc=None
        try:
            while proc.poll() is None:
                # Save pages as soon as the worker writes them. A stop/restart therefore
                # resumes from the last completed page instead of starting over.
                try:
                    cnt=_ingest_ai_worker_output(output,task_meta,items,'PaddleOCR-VL-1.6','VL 정밀 후보')
                    if cnt>last_output_count: last_output_count=cnt
                except Exception: pass
                if _SCAN_CANCEL.is_set():
                    try: proc.terminate()
                    except Exception: pass
                    try: proc.wait(timeout=6)
                    except Exception:
                        try: proc.kill()
                        except Exception: pass
                    _ingest_ai_worker_output(output,task_meta,items,'PaddleOCR-VL-1.6','VL 정밀 후보')
                    raise ScanCancelled('AI 페이지 분석이 사용자 요청으로 중단되었습니다.')
                try:
                    pr=json.loads(progress.read_text('utf-8')) if progress.exists() else {}
                    msg=str(pr.get('message') or 'PaddleOCR-VL 1.6 모델/페이지 분석 중')
                    stage=str(pr.get('stage') or ''); source=str(pr.get('source') or '')
                    try: pct=float(pr.get('download_percent') or 0.0)
                    except Exception: pct=0.0
                    pct=max(0.0,min(100.0,pct))
                    worker_done=int(pr.get('done') or 0); total_display=int(page_total or (cached_base+len(tasks)))
                    _set_scan_status(message=msg,ai_stage=stage,ai_download_percent=pct,ai_download_source=source,
                        ai_downloaded_bytes=int(pr.get('downloaded_bytes') or 0),
                        ai_download_total_bytes=int(pr.get('total_bytes') or 0),
                        ai_download_speed_bps=float(pr.get('speed_bps') or 0.0),
                        ai_download_eta_seconds=int(pr.get('eta_seconds') if pr.get('eta_seconds') is not None else -1),
                        ai_page_done=min(total_display,cached_base+worker_done),ai_page_total=total_display,
                        ai_page_cached=cached_base,ai_page_new=len(tasks),
                        ai_current_page=int(pr.get('current_index') or 0),
                        ai_current_elapsed_seconds=int(pr.get('current_elapsed_seconds') or 0),
                        ai_elapsed_seconds=int(pr.get('elapsed_seconds') or 0),
                        ai_page_last_seconds=float(pr.get('last_page_seconds') or 0.0),
                        ai_page_eta_seconds=int(pr.get('page_eta_seconds') if pr.get('page_eta_seconds') is not None else -1),
                        ai_vl_done=worker_done,ai_vl_total=len(tasks))
                except Exception: pass
                time.sleep(1)
            rc=proc.returncode
        finally:
            _ingest_ai_worker_output(output,task_meta,items,'PaddleOCR-VL-1.6','VL 정밀 후보')
            with _ACTIVE_AI_PROC_LOCK:
                if _ACTIVE_AI_PROC is proc: _ACTIVE_AI_PROC=None
    if rc!=0:
        if rc==124: return False,'AI 페이지 CPU 추론이 10분 이상 응답하지 않아 자동 중단됨 · 완료 페이지는 캐시에 저장됨'
        return False,f'AI 페이지 분석 프로세스 실패(code={rc}) · 완료 페이지는 캐시에 저장됨 · data/logs/ai_engine.log 확인'
    _ingest_ai_worker_output(output,task_meta,items,'PaddleOCR-VL-1.6','VL 정밀 후보')
    for p in (manifest,output,progress):
        try: p.unlink(missing_ok=True)
        except Exception: pass
    try:
        if work.is_dir() and not any(work.iterdir()): work.rmdir()
    except Exception: pass
    return True,''


def _run_fast_worker(tasks, cached_base=0, page_total=None, task_meta=None, items=None):
    if not tasks: return True,''
    stamp='fast_'+str(int(time.time()*1000)); work=DATA_DIR/'ai_jobs'; work.mkdir(parents=True,exist_ok=True)
    manifest=work/f'{stamp}_manifest.json'; output=work/f'{stamp}_out.json'; progress=work/f'{stamp}_progress.json'
    manifest.write_text(json.dumps({'tasks':tasks},ensure_ascii=False),encoding='utf-8')
    cmd=[sys.executable,'-S',str(AI_FAST_WORKER),'--manifest',str(manifest),'--output',str(output),'--progress',str(progress)]
    with AI_LOG_FILE.open('a',encoding='utf-8',errors='replace') as log:
        log.write('\nFAST OCR WORKER: '+' '.join(cmd)+'\n'); log.flush()
        global _ACTIVE_AI_PROC
        proc=subprocess.Popen(cmd,env=_ai_worker_env(),stdout=log,stderr=subprocess.STDOUT)
        with _ACTIVE_AI_PROC_LOCK: _ACTIVE_AI_PROC=proc
        rc=None
        try:
            while proc.poll() is None:
                try: _ingest_ai_worker_output(output,task_meta,items,'PP-OCRv5 Korean FAST','빠른 OCR 1차 후보')
                except Exception: pass
                if _SCAN_CANCEL.is_set():
                    try: proc.terminate()
                    except Exception: pass
                    try: proc.wait(timeout=6)
                    except Exception:
                        try: proc.kill()
                        except Exception: pass
                    _ingest_ai_worker_output(output,task_meta,items,'PP-OCRv5 Korean FAST','빠른 OCR 1차 후보')
                    raise ScanCancelled('빠른 AI OCR이 사용자 요청으로 중단되었습니다.')
                try:
                    pr=json.loads(progress.read_text('utf-8')) if progress.exists() else {}
                    done=int(pr.get('done') or 0); total_display=int(page_total or (cached_base+len(tasks)))
                    _set_scan_status(message=str(pr.get('message') or 'PP-OCRv5 Korean FAST 분석 중'),ai_stage='fast_ocr',
                        ai_page_done=min(total_display,cached_base+done),ai_page_total=total_display,
                        ai_fast_done=done,ai_fast_total=len(tasks),ai_current_page=int(pr.get('current_index') or 0),
                        ai_current_elapsed_seconds=int(pr.get('current_elapsed_seconds') or 0),
                        ai_elapsed_seconds=int(pr.get('elapsed_seconds') or 0),
                        ai_page_last_seconds=float(pr.get('last_page_seconds') or 0.0),
                        ai_page_eta_seconds=int(pr.get('page_eta_seconds') if pr.get('page_eta_seconds') is not None else -1))
                except Exception: pass
                time.sleep(.6)
            rc=proc.returncode
        finally:
            _ingest_ai_worker_output(output,task_meta,items,'PP-OCRv5 Korean FAST','빠른 OCR 1차 후보')
            with _ACTIVE_AI_PROC_LOCK:
                if _ACTIVE_AI_PROC is proc: _ACTIVE_AI_PROC=None
    if rc!=0:
        return False,f'빠른 AI OCR 프로세스 실패(code={rc}) · data/logs/ai_engine.log 확인'
    for p in (manifest,output,progress):
        try: p.unlink(missing_ok=True)
        except Exception: pass
    return True,''


def _ai_page_text(pdf_path,page_no):
    rec=_load_ai_cache()['pages'].get(_ai_cache_key(pdf_path,page_no))
    return str(rec.get('text') or '') if isinstance(rec,dict) else ''


def _ai_page_engine(pdf_path,page_no):
    rec=_load_ai_cache()['pages'].get(_ai_cache_key(pdf_path,page_no))
    return str(rec.get('engine') or '') if isinstance(rec,dict) else ''


def _cleanup_ai_render(pdf_path,page_no):
    try:
        (CACHE_DIR/f'ai_page_{_ai_cache_key(pdf_path,page_no)}.jpg').unlink(missing_ok=True)
    except Exception:
        pass



def _load_ai_review():
    try:
        raw=json.loads(AI_REVIEW_FILE.read_text('utf-8')) if AI_REVIEW_FILE.exists() else {}
        if not isinstance(raw,dict): raw={}
    except Exception:
        raw={}
    raw.setdefault('rows',[])
    return raw


def _save_ai_review(data):
    AI_REVIEW_FILE.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    try:
        _set_scan_status(ai_review_count=len(data.get('rows') or []),ai_review_status=str(data.get('status') or ''))
    except Exception:
        pass


def _start_ai_review(total_pdfs=0,total_pages=0,scope='full'):
    data={
        'version':'4.4.36','session_id':datetime.now().strftime('%Y%m%d_%H%M%S'),
        'status':'running','started_at':datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'finished_at':'','message':'AI 전체 매칭 분석 중','total_pdfs':int(total_pdfs or 0),
        'total_pages':int(total_pages or 0),'rows':[],'scanned_files':[],'confirmed_at':'','confirmed_count':0,
        'scope':str(scope or 'full')
    }
    _save_ai_review(data)
    return data


def _review_row_id(source_id,page,code=''):
    raw=f'{_normalize_webhard_rel(source_id)}|{int(page)}|{clean_code(code)}'
    return hashlib.sha1(raw.encode('utf-8')).hexdigest()[:18]


def _stage_ai_review_preview(source_id,page,code,title,score,method,text):
    """Persist a provisional row while OCR/VL is running.

    It is intentionally marked provisional and is never committed by the
    'AI 자동 매칭 확정' button. Final PDF assignment replaces provisional rows.
    """
    try:
        data=_load_ai_review()
        if data.get('status')!='running': return
        source_id=_normalize_webhard_rel(source_id)
        if not source_id: return
        rows=list(data.get('rows') or [])
        # Do not overwrite a finalized row for this page.
        if any(r.get('file')==source_id and int(r.get('page',-1))==int(page) and r.get('final') for r in rows):
            return
        rows=[r for r in rows if not (r.get('file')==source_id and int(r.get('page',-1))==int(page) and not r.get('final'))]
        rows.append({
            'id':_review_row_id(source_id,page,'preview'),'file':source_id,'page':int(page),
            'page_label':int(page)+1,'proposed_code':clean_code(code),'selected_code':clean_code(code),
            'title':str(title or ''),'score':int(score or 0),'margin':0,'method':str(method or ''),
            'text':str(text or '')[:1200],'needs_manual':True,'status':'provisional',
            'final':False,'suggestions':[],'saved_at':datetime.now().isoformat(timespec='seconds')
        })
        data['rows']=rows
        _save_ai_review(data)
    except Exception:
        pass


def _stage_ai_review_results(source_id,results):
    """Replace provisional rows for one PDF with its final staged assignments."""
    data=_load_ai_review(); source_id=_normalize_webhard_rel(source_id)
    scanned=list(data.get('scanned_files') or [])
    if source_id and source_id not in scanned: scanned.append(source_id)
    data['scanned_files']=scanned
    rows=[r for r in (data.get('rows') or []) if r.get('file')!=source_id]
    for r in results or []:
        code=clean_code(r.get('code'))
        row={
            'id':_review_row_id(source_id,r.get('page',0),code or 'none'),
            'file':source_id,'page':int(r.get('page',0)),'page_label':int(r.get('page',0))+1,
            'proposed_code':code,'selected_code':code,'title':str(r.get('title') or ''),
            'score':int(r.get('score') or 0),'margin':int(r.get('margin') or 0),
            'method':str(r.get('method') or ''),'text':str(r.get('text') or '')[:1400],
            'needs_manual':bool(r.get('needs_manual') or not code),
            'status':'manual_required' if (r.get('needs_manual') or not code) else 'auto_proposed',
            'page_gender':str(r.get('page_gender') or ''),'item_gender':str(r.get('item_gender') or ''),
            'source_gender':str(r.get('source_gender') or ''),'source_gender_reason':str(r.get('source_gender_reason') or ''),
            'filename_authoritative':bool(r.get('filename_authoritative')),
            'final':True,'suggestions':list(r.get('suggestions') or [])[:6],
            'saved_at':datetime.now().isoformat(timespec='seconds')
        }
        rows.append(row)
    data['rows']=rows; data['status']='running'
    _save_ai_review(data)


def _finalize_ai_review(status,message=''):
    try:
        data=_load_ai_review()
        if not data: return
        data['status']=str(status or 'completed')
        data['finished_at']=datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        if message: data['message']=str(message)
        _save_ai_review(data)
    except Exception:
        pass


def _publish_ai_preview(source_id,page_one_based,code='',title='',score=0,method='',text='',stage_review=True):
    """Publish image + candidate as one atomic preview generation.

    The browser uses ai_preview_seq to preload the image and only then swaps both
    image and candidate text together. This prevents an old image being shown with
    a newly-polled SKU candidate.
    """
    seq=str(time.time_ns())
    page_cat=_breed_label(_page_breed_category(text,'')) if text else ''
    item_cat=''
    c=clean_code(code)
    if c:
        try:
            it=next((x for x in load_items() if clean_code(x.get('code'))==c),None)
            if it: item_cat=_breed_label(_item_breed_category(it))
        except Exception:
            item_cat=''
    _set_scan_status(ai_preview_file=_normalize_webhard_rel(source_id),ai_preview_page=int(page_one_based or 0),
        ai_preview_code=c,ai_preview_title=str(title or ''),ai_preview_score=int(score or 0),
        ai_preview_method=str(method or ''),ai_preview_text=str(text or '')[:650],
        ai_preview_page_category=page_cat,ai_preview_item_category=item_cat,ai_preview_seq=seq)
    if stage_review and int(page_one_based or 0)>0:
        _stage_ai_review_preview(source_id,int(page_one_based)-1,code,title,score,method,text)


def _fast_page_top_candidate(pdf_path,page_no,items):
    """Return a provisional candidate for live UI and fast/VL gating.

    This uses the same hard gender gate and title/context scoring as final assignment,
    but only for one page. It never treats filename style-code order as page order.
    """
    text=_ai_page_text(pdf_path,page_no)
    if not text.strip(): return None
    filename_codes=extract_filename_codes(Path(pdf_path).name,items)
    source_desc=_source_description(pdf_path,filename_codes)
    source_seasons=_source_season_tokens(pdf_path)
    source_types=_source_item_types(pdf_path)
    groups,_=_ai_group_candidates(pdf_path,items,[text])
    ranked=[]
    for g in groups:
        sc,it,exact,meta=_ai_group_page_score(text,g,source_desc,filename_codes,source_seasons,source_types)
        if it and sc>0:
            ranked.append((sc,it,exact,meta))
    ranked.sort(key=lambda x:-x[0])
    if not ranked: return None
    best=ranked[0]; second=ranked[1][0] if len(ranked)>1 else 0.0
    sc,it,exact,meta=best
    pg,ig,reason=(meta or ('','',''))
    return {
        'code':clean_code(it.get('code')),'title':str(it.get('title_ko') or ''),
        'score':round(sc*100),'margin':round((sc-second)*100),'exact':bool(exact),
        'page_gender':pg or '미확인','item_gender':ig or _ai_item_gender(it) or '미확인',
        'reason':reason or '', 'text':text[:650]
    }


def _fast_page_is_confident(pdf_path,page_no,items):
    """Conservative gate: only skip the heavy VL model when FAST OCR is clear."""
    rec=_fast_page_top_candidate(pdf_path,page_no,items)
    if not rec: return False
    if rec['exact']: return True
    # Strong title/context score + a real margin. Same-title shared style groups are
    # already grouped by gender, so this does not force one style code by filename order.
    if rec['score']>=93 and rec['margin']>=7: return True
    if rec['score']>=90 and rec['margin']>=10 and rec['page_gender']!='미확인': return True
    return False


def _set_live_preview(pdf_path,page_no,items,method):
    try:
        rec=_fast_page_top_candidate(pdf_path,page_no,items)
        sid=_sync_source_key(Path(pdf_path))
        if rec:
            _publish_ai_preview(sid,int(page_no)+1,rec['code'],rec['title'],rec['score'],method,rec.get('text',''),stage_review=True)
        else:
            _publish_ai_preview(sid,int(page_no)+1,'','후보 계산 중',0,method,_ai_page_text(pdf_path,page_no)[:650],stage_review=True)
    except Exception:
        pass


def _normalize_gender_value(value):
    raw=str(value or '').strip().upper().replace(' ', '')
    if raw in ('남성','남자','MEN','MENS','MALE','MAN'): return '남성'
    if raw in ('여성','여자','WOMEN','WOMENS','FEMALE','WOMAN'): return '여성'
    if raw in ('공용','남녀공용','UNISEX','UNI'): return '공용'
    return ''


def _ai_item_gender(item):
    # Store product-code rule is authoritative whenever the final-four digit rule applies.
    return _normalize_gender_value(infer_gender_from_code(clean_code(item.get('code')), item.get('gender')))


def _ai_source_gender(source_desc='', filename_codes=None):
    """Infer a hard source-level gender guard from the HQ filename/path roster.

    The final-four SKU rule is authoritative: 1xxx=male, 2xxx=female, 3xxx=unisex.
    When every explicit filename SKU agrees on one male/female gender, candidates of
    the opposite gender are rejected even when page OCR misses the tiny gender badge.
    A path/filename gender word is used as a second source cue. Mixed male+female
    sources intentionally return unknown so shared official POPs remain possible.
    """
    genders=[]
    for code in filename_codes or []:
        g=_normalize_gender_value(infer_gender_from_code(clean_code(code),''))
        if g in ('남성','여성') and g not in genders: genders.append(g)
    roster_gender=genders[0] if len(genders)==1 else ''

    raw=urllib.parse.unquote(str(source_desc or ''))
    up=raw.upper()
    male=bool(re.search(r'(?<!여)남성|\bMEN(?:\'S)?\b|\bMALE\b',up,re.I))
    female=bool(re.search(r'여성|\bWOMEN(?:\'S)?\b|\bFEMALE\b',up,re.I))
    path_gender='남성' if male and not female else ('여성' if female and not male else '')

    if roster_gender and path_gender and roster_gender!=path_gender:
        return '', '파일명 품번성별/경로성별 혼합'
    if roster_gender:
        return roster_gender, '파일명 품번 성별 '+roster_gender
    if path_gender:
        return path_gender, 'PDF 경로/파일명 성별 '+path_gender
    return '', '출처 성별 미확인'


def _ai_page_gender(text):
    """Return explicit page gender from AI-extracted visible text/captions.

    Visible labels such as 남성/여성 or MEN/WOMEN are decisive.  A PaddleOCR-VL
    description such as '남성 모델' is accepted only as a secondary page cue.  If both
    male and female cues are present, the page is treated as mixed/unknown so no hard
    gender rejection is applied.
    """
    raw=' '.join(str(text or '').split())
    up=raw.upper()
    # FAST OCR stores a dedicated lower gender-label zone. Prefer that tiny badge over
    # narrative copy/model descriptions elsewhere on the page.
    try:
        gender_zone=_ai_evidence_sections(raw)[3]
    except Exception:
        gender_zone=''
    gz=str(gender_zone or '').upper()
    gz_m=bool(re.search(r'(?<!여)남성|\bMEN(?:\'S)?\b|\bMALE\b',gz,re.I))
    gz_f=bool(re.search(r'여성|\bWOMEN(?:\'S)?\b|\bFEMALE\b',gz,re.I))
    if gz_m and not gz_f: return '남성','하단 성별라벨 남성'
    if gz_f and not gz_m: return '여성','하단 성별라벨 여성'
    if gz_m and gz_f: return '','하단 성별라벨 남녀혼합'
    if re.search(r'\bUNISEX\b|남녀\s*공용|공용',gz,re.I): return '공용','하단 성별라벨 공용'
    male_patterns=(r'(?<!여)남성',r'남자\s*모델',r'남성\s*모델',r'\bMEN(?:\'S)?\b',r'\bMALE\b',r'\bMAN\s+MODEL\b')
    female_patterns=(r'여성',r'여자\s*모델',r'여성\s*모델',r'\bWOMEN(?:\'S)?\b',r'\bFEMALE\b',r'\bWOMAN\s+MODEL\b')
    male=any(re.search(p,up,re.I) for p in male_patterns)
    female=any(re.search(p,up,re.I) for p in female_patterns)
    # TOPTEN page text sometimes uses 남류/여류 in captions or folder-derived AI text.
    male = male or ('남류' in raw)
    female = female or ('여류' in raw)
    if male and not female: return '남성','페이지 남성 표기/모델 단서'
    if female and not male: return '여성','페이지 여성 표기/모델 단서'
    if male and female: return '','남녀 혼합/복수 단서'
    if re.search(r'\bUNISEX\b|남녀\s*공용|공용',up,re.I): return '공용','페이지 공용 표기'
    return '','성별 표기 없음'


def _ai_gender_relation(page_text,item):
    pg,evidence=_ai_page_gender(page_text)
    ig=_ai_item_gender(item)
    # Explicit opposite genders are a hard reject. Unisex remains eligible but does
    # not outrank an exact gender-specific SKU merely because the title is identical.
    if pg in ('남성','여성') and ig in ('남성','여성') and pg!=ig:
        return pg,ig,-1.0,evidence+' · 품번성별 불일치'
    if pg in ('남성','여성') and ig==pg:
        return pg,ig,0.075,evidence+' · 품번성별 일치'
    if pg in ('남성','여성') and ig=='공용':
        return pg,ig,0.005,evidence+' · 공용 후보'
    if pg=='공용' and ig=='공용':
        return pg,ig,0.035,evidence+' · 공용 일치'
    return pg,ig,0.0,evidence


def _ai_context_score(page_text,item):
    """Small corroborating score from item type/zone/promotion descriptors.

    Product name remains the dominant signal.  This context only helps distinguish
    same/similar titles after gender gating; generic words cannot create an automatic
    match by themselves.
    """
    raw=' '.join(str(page_text or '').split())
    page_tokens=set(_semantic_tokens(raw))
    if not page_tokens: return 0.0
    item_tokens=[]
    for val in (item.get('zone'), item.get('promotion')):
        for tok in _semantic_tokens(val):
            if tok not in item_tokens: item_tokens.append(tok)
    if not item_tokens: return 0.0
    hits=sum(1 for t in item_tokens if t in page_tokens)
    return min(0.055, hits*0.018)


def _ai_item_page_score(page_text,item,source_desc='',filename_codes=None,source_seasons=None,source_types=None):
    pg,ig,gender_adj,gender_reason=_ai_gender_relation(page_text,item)
    if gender_adj < 0:
        return 0.0, False, pg, ig, gender_reason
    sg,source_gender_reason=_ai_source_gender(source_desc,filename_codes)
    # Final-four SKU gender and a single-gender filename roster are hard constraints.
    # This specifically prevents a male HQ bonus page from ever auto-linking to a
    # female 2xxx SKU (and vice versa) when the small badge was missed by OCR.
    if sg in ('남성','여성') and ig in ('남성','여성') and sg!=ig:
        return 0.0, False, pg, ig, source_gender_reason+' · 품번성별 불일치'
    source_gender_adj=0.045 if (sg in ('남성','여성') and ig==sg) else 0.0
    season_ok,season_adj,season_reason=_season_relation(source_seasons,item)
    if not season_ok:
        return 0.0, False, pg, ig, gender_reason+' · '+season_reason
    type_ok,type_adj,type_reason=_type_relation(source_types,item)
    if not type_ok:
        return 0.0, False, pg, ig, gender_reason+' · '+season_reason+' · '+type_reason
    breed_adj,breed_conflict,page_breed,item_breed,breed_reason=_manual_breed_relation(page_text,item,source_desc)
    if breed_conflict:
        return 0.0, False, pg, ig, gender_reason+' · '+season_reason+' · '+type_reason+' · '+breed_reason
    s=_ai_title_score(page_text,item)
    code=clean_code(item.get('code'))
    compact=re.sub(r'[^A-Z0-9]','',str(page_text).upper())
    exact=bool(code and code in compact)
    if exact: s=1.0
    allowed={clean_code(c) for c in (filename_codes or []) if clean_code(c)}
    if code in allowed: s=min(1.0,s+0.018)
    am,conf,_,_=_anchor_relation(source_desc,item)
    if am: s=min(1.0,s+0.03)
    notice_bonus,notice_match,notice_category=_notice_text_relation(page_text,item)
    s=min(1.0,s+gender_adj+source_gender_adj+season_adj+type_adj+breed_adj+_ai_context_score(page_text,item)+notice_bonus)
    if conf and s<0.92: s=min(s,0.57)
    if pg in ('남성','여성') and ig=='공용' and not exact:
        s=min(s,0.69)
    # If both the page and source gender are unknown, a gender-specific SKU cannot be
    # auto-confirmed from title similarity alone unless the SKU is explicitly listed.
    if not pg and not sg and ig in ('남성','여성') and not exact and code not in allowed:
        s=min(s,0.81)
    reason=' · '.join(x for x in (gender_reason,source_gender_reason,season_reason,type_reason,breed_reason,('공지DB '+notice_category if notice_match else '')) if x)
    return max(0.0,min(1.0,s)), exact, pg, ig, reason
def _ai_evidence_sections(text):
    """Split optional FAST OCR layout markers without breaking old AI cache rows.

    V4.4.37 FAST OCR can preserve the lower product-title area and English lines
    from the *same page image*. Old cached rows do not have these markers, so the
    full text remains a valid fallback and no expensive re-OCR is forced.
    """
    raw=' '.join(str(text or '').split())
    def part(tag,next_tags):
        marker='['+tag+']'
        if marker not in raw: return ''
        x=raw.split(marker,1)[1]
        stops=[x.find('['+t+']') for t in next_tags if ('['+t+']') in x]
        stops=[i for i in stops if i>=0]
        if stops: x=x[:min(stops)]
        return x.strip(' |')
    title=part('TITLE_ZONE',('ENGLISH_TEXT','GENDER_TEXT'))
    eng=part('ENGLISH_TEXT',('GENDER_TEXT',))
    gender=part('GENDER_TEXT',())
    full=raw.split('[TITLE_ZONE]',1)[0].replace('[FULL_TEXT]','').strip(' |') if '[TITLE_ZONE]' in raw else raw.replace('[FULL_TEXT]','').strip(' |')
    return full,title,eng,gender

def _ai_title_score(text,item):
    full,title_zone,english_zone,_=_ai_evidence_sections(text)
    full_n=normalize_product_name(full)
    title_n=normalize_product_name(title_zone)
    english_n=normalize_product_name(english_zone)
    ko=normalize_product_name(item.get('title_ko'))
    en=normalize_product_name(item.get('title_en'))

    def score_one(needle, hay, exact_cap, partial_w, wratio_w):
        if not needle or not hay: return 0.0
        out=0.0
        if needle in hay:
            out=max(out, exact_cap if len(needle)>=4 else min(exact_cap,0.94))
        out=max(out, fuzz.partial_ratio(needle,hay)/100.0*partial_w, fuzz.WRatio(needle,hay)/100.0*wratio_w)
        return out

    # Product-name area comes from OCR boxes on the actual rendered PDF page and is
    # stronger than generic bullet-copy text. Korean and English are scored separately
    # so a shared Korean name can be disambiguated by the English line when available.
    ko_zone=score_one(ko,title_n,1.0,0.985,0.975)
    en_zone=score_one(en,title_n or english_n,0.997,0.985,0.975)
    ko_full=score_one(ko,full_n,0.992,0.95,0.93)
    en_full=score_one(en,full_n,0.988,0.95,0.93)
    best=max(ko_zone,en_zone,ko_full,en_full)
    ko_best=max(ko_zone,ko_full); en_best=max(en_zone,en_full)
    if ko_best>=0.78 and en_best>=0.78:
        best=min(1.0,best+0.025)
    code=clean_code(item.get('code'))
    if code and code in re.sub(r'[^A-Z0-9]','',str(text).upper()): best=1.0
    return min(1.0,best)


def _ai_group_candidates(pdf_path,items,page_texts):
    filename_codes=extract_filename_codes(Path(pdf_path).name,items)
    source_seasons=_source_season_tokens(pdf_path)
    source_types=_source_item_types(pdf_path)
    # F2/G2/G3 etc. in the PDF filename is scope metadata, not a soft score.
    # Filter the candidate universe *before* fuzzy title retrieval so a G2/G3 SKU can
    # never win an F2 PDF just because the product title looks similar.
    scoped_items=[]
    for item in items:
        sok,_,_=_season_relation(source_seasons,item)
        tok,_,_=_type_relation(source_types,item)
        if sok and tok: scoped_items.append(item)
    candidate_universe=scoped_items if (source_seasons or source_types) else list(items)
    source_desc=_source_description(pdf_path,filename_codes)
    source_gender,_source_gender_reason=_ai_source_gender(source_desc,filename_codes)
    if source_gender in ('남성','여성'):
        candidate_universe=[i for i in candidate_universe if _ai_item_gender(i) in (source_gender,'공용','')]
    scoped=_filename_scope_items(candidate_universe,filename_codes)
    if scoped:
        base=scoped
    else:
        # No code list: take top fuzzy candidates from each AI page, then merge.
        idx=_match_search_index(candidate_universe); ids=[]
        for txt in page_texts:
            q=normalize_product_name(txt)
            if not q: continue
            try: hits=process.extract(q,idx['choices'],scorer=fuzz.WRatio,limit=min(40,len(idx['choices'])),score_cutoff=25)
            except Exception: hits=[]
            ids.extend(h[2] for h in hits)
        seen=set(); base=[]
        for ix in ids:
            if ix in seen: continue
            seen.add(ix); base.append(candidate_universe[ix])
        if not base: base=list(candidate_universe[:100])
    groups=[]
    for item in base:
        title=normalize_product_name(item.get('title_ko') or item.get('title_en') or '') or clean_code(item.get('code'))
        gender=_ai_item_gender(item)
        breed_large=tuple(_item_breed_category(item).get('large') or [])
        # Same title is still a different assignment group when gender or manual
        # 품종대 differs. This prevents same-name pants/sweater or male/female cross-linking.
        found=next((g for g in groups if gender==g['gender'] and breed_large==g.get('breed_large',()) and (title==g['title'] or (title and g['title'] and fuzz.ratio(title,g['title'])>=94))),None)
        if found: found['items'].append(item)
        else: groups.append({'title':title,'gender':gender,'breed_large':breed_large,'items':[item]})
    return groups,filename_codes


def _ai_group_page_score(page_text,group,source_desc,filename_codes,source_seasons=None,source_types=None):
    best=0.0; best_item=None; exact=False; meta=None
    for item in group['items']:
        s,is_exact,pg,ig,reason=_ai_item_page_score(page_text,item,source_desc,filename_codes,source_seasons,source_types)
        if s>best:
            best=s; best_item=item; exact=is_exact; meta=(pg,ig,reason)
    return best,best_item,exact,meta


def _hungarian_max(weights):
    # Rectangular max-weight assignment. Returns list of (row, col).
    if not weights or not weights[0]: return []
    n=len(weights); m=len(weights[0]); trans=False
    a=weights
    if n>m:
        trans=True; a=[list(x) for x in zip(*weights)]; n,m=m,n
    maxv=max(max(r) for r in a) if a else 0.0
    cost=[[maxv-v for v in row] for row in a]
    u=[0.0]*(n+1); v=[0.0]*(m+1); p=[0]*(m+1); way=[0]*(m+1)
    for i in range(1,n+1):
        p[0]=i; j0=0; minv=[float('inf')]*(m+1); used=[False]*(m+1)
        while True:
            used[j0]=True; i0=p[j0]; delta=float('inf'); j1=0
            for j in range(1,m+1):
                if used[j]: continue
                cur=cost[i0-1][j-1]-u[i0]-v[j]
                if cur<minv[j]: minv[j]=cur; way[j]=j0
                if minv[j]<delta: delta=minv[j]; j1=j
            for j in range(m+1):
                if used[j]: u[p[j]]+=delta; v[j]-=delta
                else: minv[j]-=delta
            j0=j1
            if p[j0]==0: break
        while True:
            j1=way[j0]; p[j0]=p[j1]; j0=j1
            if j0==0: break
    pairs=[]
    for j in range(1,m+1):
        if p[j]: pairs.append((p[j]-1,j-1))
    if trans: return [(c,r) for r,c in pairs]
    return pairs


def _ai_filename_roster_match(pdf_path, items, page_texts, source_desc, source_seasons, source_types, filename_codes):
    """Resolve headquarters PDFs whose filename lists exactly one SKU per page.

    A common Webhard convention is ``...SKU1, SKU2, SKU3, SKU4....pdf`` with the PDF
    containing the same number of pages. V4.4.54 allowed independently strong groups to
    choose the same page, so page 2 could be assigned to two SKUs while page 1/SKU1 was
    left unmatched. This helper makes that roster a one-to-one assignment problem.

    Filename order is a tie-breaker, not a blind override: hard gender/season/type/manual
    breed conflicts still block automatic confirmation. This keeps false positives out
    while guaranteeing that two filename SKUs cannot consume the same page.
    """
    pc=len(page_texts)
    codes=[]
    seen=set()
    for c in filename_codes or []:
        c=clean_code(c)
        if c and c not in seen:
            seen.add(c); codes.append(c)
    if pc < 2 or len(codes) != pc:
        return []
    by_code=_item_by_code(items)
    if any(c not in by_code for c in codes):
        return []

    weights=[]; details=[]
    for ci,code in enumerate(codes):
        item=by_code[code]; row=[]; drow=[]
        for p,txt in enumerate(page_texts):
            score,exact,pg,ig,reason=_ai_item_page_score(txt,item,source_desc,codes,source_seasons,source_types)
            title_score=_ai_title_score(txt,item)
            # Explicit list order is only a moderate tie-breaker. A clearly better title
            # page can still win when HQ page order differs from the filename list.
            weight=float(score)
            if weight>0 and p==ci:
                weight=min(1.0,weight+0.085)
            row.append(weight)
            drow.append((float(score),bool(exact),pg,ig,reason,float(title_score)))
        weights.append(row); details.append(drow)

    pairs=_hungarian_max(weights)
    if len(pairs) != len(codes):
        return []
    source_gender,source_gender_reason=_ai_source_gender(source_desc,codes)
    results=[]
    for ci,p in pairs:
        code=codes[ci]; item=by_code[code]
        score,exact,pg,ig,reason,title_score=details[ci][p]
        season_ok,_,_=_season_relation(source_seasons,item)
        type_ok,_,_=_type_relation(source_types,item)
        _,breed_conflict,_,_,_=_manual_breed_relation(page_texts[p],item,source_desc)
        _,_,gender_adj,_=_ai_gender_relation(page_texts[p],item)
        sg,_=_ai_source_gender(source_desc,codes)
        source_gender_conflict=bool(sg in ('남성','여성') and _ai_item_gender(item) in ('남성','여성') and sg!=_ai_item_gender(item))
        hard_conflict=bool(gender_adj<0 or source_gender_conflict or not season_ok or not type_ok or breed_conflict)
        order_match=(p==ci)
        # Filename roster + unique page assignment is headquarters-supplied evidence.
        # With no hard conflict, page order itself is enough when OCR is weak; when pages
        # are shuffled, require modest visible-title/page score support.
        auto=bool(not hard_conflict and (exact or order_match or score>=0.48 or title_score>=0.42))
        evidence=['파일명 품번목록 1:1 페이지배정']
        if order_match: evidence.append('파일명 순서 일치')
        if exact: evidence.append('페이지 내부 품번')
        if title_score>=0.42: evidence.append('상품명 AI 확인')
        if hard_conflict: evidence.append('하드 충돌로 자동확정 차단')
        results.append({
            'page':p,'page_label':p+1,'text':page_texts[p][:900],
            'code':code,'title':str(item.get('title_ko') or ''),
            'score':round(max(score,title_score)*100),'margin':0,
            'grade':'AI-A' if auto else 'AI-C',
            'method':f'{(_ai_page_engine(pdf_path,p) or "AI")} · '+ ' + '.join(evidence) + (f' · {reason}' if reason else ''),
            'needs_manual':not auto,'filename_codes':codes,
            'suggestions':[{'code':code,'title':str(item.get('title_ko') or ''),'score':round(max(score,title_score)*100),'gender':_ai_item_gender(item) or '-','season':'/'.join(_item_season_tokens(item)) or '-','category':_breed_label(_item_breed_category(item))}],
            'page_gender':pg,'item_gender':ig,'source_gender':source_gender,'source_gender_reason':source_gender_reason,
            'filename_authoritative':auto,
            'filename_roster':True,
        })
    results.sort(key=lambda r:(int(r.get('page',0)), clean_code(r.get('code'))))
    return results


def _ai_recover_filename_codes(pdf_path, items, page_texts, source_desc, source_seasons, source_types, filename_codes, results):
    """Recover explicit filename SKUs omitted by the normal AI grouping/threshold pass.

    This is intentionally narrow: only SKUs literally listed in the Webhard filename are
    eligible. It never searches arbitrary Excel rows and never overrides hard category,
    gender, season or product-type conflicts.
    """
    represented={clean_code(r.get('code')) for r in (results or []) if clean_code(r.get('code'))}
    by_code=_item_by_code(items); pc=len(page_texts); added=[]
    codes=[clean_code(c) for c in (filename_codes or []) if clean_code(c)]
    source_gender,source_gender_reason=_ai_source_gender(source_desc,codes)
    for ci,code in enumerate(codes):
        if code in represented or code not in by_code: continue
        item=by_code[code]; ranked=[]
        for p,txt in enumerate(page_texts):
            score,exact,pg,ig,reason=_ai_item_page_score(txt,item,source_desc,codes,source_seasons,source_types)
            title_score=_ai_title_score(txt,item)
            season_ok,_,_=_season_relation(source_seasons,item)
            type_ok,_,_=_type_relation(source_types,item)
            _,breed_conflict,_,_,_=_manual_breed_relation(txt,item,source_desc)
            _,_,gender_adj,_=_ai_gender_relation(txt,item)
            sg,_=_ai_source_gender(source_desc,codes)
            source_gender_conflict=bool(sg in ('남성','여성') and _ai_item_gender(item) in ('남성','여성') and sg!=_ai_item_gender(item))
            hard=bool(gender_adj<0 or source_gender_conflict or not season_ok or not type_ok or breed_conflict)
            if hard: continue
            order_bonus=0.07 if len(codes)==pc and p==ci else 0.0
            ranked.append((max(float(score),float(title_score))+order_bonus,p,float(score),float(title_score),bool(exact),pg,ig,reason))
        if not ranked: continue
        ranked.sort(reverse=True,key=lambda x:x[0])
        _,p,score,title_score,exact,pg,ig,reason=ranked[0]
        single_file=(len(codes)==1)
        auto=bool(exact or (single_file and (score>=0.38 or title_score>=0.34)) or (score>=0.58 and title_score>=0.42))
        if not auto and max(score,title_score)<0.34:
            continue
        added.append({
            'page':p,'page_label':p+1,'text':page_texts[p][:900],
            'code':code,'title':str(item.get('title_ko') or ''),
            'score':round(max(score,title_score)*100),'margin':0,'grade':'AI-B' if auto else 'AI-C',
            'method':f'{(_ai_page_engine(pdf_path,p) or "AI")} · 파일명 품번 누락복구 · 상품명/페이지 재검증' + (f' · {reason}' if reason else ''),
            'needs_manual':not auto,'filename_codes':codes,
            'suggestions':[{'code':code,'title':str(item.get('title_ko') or ''),'score':round(max(score,title_score)*100),'gender':_ai_item_gender(item) or '-','season':'/'.join(_item_season_tokens(item)) or '-','category':_breed_label(_item_breed_category(item))}],
            'page_gender':pg,'item_gender':ig,'source_gender':source_gender,'source_gender_reason':source_gender_reason,
            'filename_authoritative':auto,
            'filename_recovery':True,
        })
    return list(results or [])+added


def match_pdf_pages_ai(pdf_path,items):
    filename_codes=extract_filename_codes(Path(pdf_path).name,items)
    notice_direct={}
    with fitz.open(str(pdf_path)) as doc:
        pc=doc.page_count
        for p in range(pc):
            rows=_notice_match_page_object(doc.load_page(p),items)
            if rows:
                for r in rows: r.update({'page':p,'page_label':p+1,'filename_codes':filename_codes})
                notice_direct[p]=rows
    page_texts=[_ai_page_text(pdf_path,p) for p in range(pc)]
    source_desc=_source_description(pdf_path,filename_codes)
    source_seasons=_source_season_tokens(pdf_path)
    source_types=_source_item_types(pdf_path)

    # Headquarters multi-page PDFs commonly list one SKU per page in the filename.
    # Resolve these as a unique one-to-one roster before the generic clustering pass so
    # two SKUs can no longer steal the same page (the MSG4JP1401 class of miss).
    roster=_ai_filename_roster_match(pdf_path,items,page_texts,source_desc,source_seasons,source_types,filename_codes)
    if roster:
        if notice_direct:
            direct_pages=set(notice_direct)
            roster=[r for r in roster if int(r.get('page',0)) not in direct_pages]
            for rows in notice_direct.values(): roster.extend(rows)
        roster.sort(key=lambda r:(int(r.get('page',0)), bool(r.get('needs_manual')), -int(r.get('score',0)), clean_code(r.get('code'))))
        return roster

    groups,filename_codes=_ai_group_candidates(pdf_path,items,page_texts)
    if not groups:
        return _ai_recover_filename_codes(pdf_path,items,page_texts,source_desc,source_seasons,source_types,filename_codes,[])
    matrix=[]; details=[]
    for g in groups:
        row=[]; drow=[]
        for txt in page_texts:
            sc,it,exact,meta=_ai_group_page_score(txt,g,source_desc,filename_codes,source_seasons,source_types)
            row.append(sc); drow.append((it,exact,meta))
        matrix.append(row); details.append(drow)
    assigned={}; strong=set()
    # First: independent strong evidence. Multiple real products can still share one
    # page, but opposite-gender groups have already been hard-rejected.
    for gi,row in enumerate(matrix):
        order=sorted(range(pc),key=lambda p:row[p],reverse=True)
        if not order: continue
        p=order[0]; best=row[p]; second=row[order[1]] if len(order)>1 else 0.0; margin=best-second
        it,exact,meta=details[gi][p]
        title_score=_ai_title_score(page_texts[p],it) if it else 0.0
        visible_title=bool(it and title_score>=0.94)
        if exact or (best>=0.87 and margin>=0.09) or (visible_title and best>=0.91):
            assigned[gi]=(p,best,margin,'AI 페이지 강한증거'); strong.add(gi)
    # Second: ambiguous groups use global page assignment, solving shuffled page order.
    rem=[i for i in range(len(groups)) if i not in strong]
    if rem and pc:
        pairs=_hungarian_max([matrix[i] for i in rem])
        for rr,p in pairs:
            gi=rem[rr]; best=matrix[gi][p]
            if best<0.50: continue
            others=[matrix[gi][x] for x in range(pc) if x!=p]
            margin=best-(max(others) if others else 0.0)
            assigned[gi]=(p,best,margin,'AI 전역 페이지 배정')
    results=[]
    for gi,g in enumerate(groups):
        if gi not in assigned: continue
        p,score,margin,method=assigned[gi]
        page_text=page_texts[p]
        ranked=[]
        for item in g['items']:
            s,exact,pg,ig,reason=_ai_item_page_score(page_text,item,source_desc,filename_codes,source_seasons,source_types)
            if s<=0: continue
            ranked.append((s,item,exact,pg,ig,reason))
        ranked.sort(key=lambda x:-x[0])
        top=ranked[0] if ranked else None
        top_item=top[1] if top else None
        exact=bool(top and top[2])
        pg=top[3] if top else _ai_page_gender(page_text)[0]
        top_score=float(top[0] if top else 0.0)
        title_score=_ai_title_score(page_text,top_item) if top_item else 0.0
        top_code=clean_code(top_item.get('code')) if top_item else ''
        filename_member=bool(top_code and top_code in {clean_code(x) for x in filename_codes})
        anchor_match=bool(top_item and _anchor_relation(source_desc,top_item)[0])
        item_breed=_item_breed_category(top_item) if top_item else {'large':[]}
        page_breed=_page_breed_category(page_text,source_desc) if top_item else {'large':[]}
        breed_match=bool(item_breed.get('large') and page_breed.get('large') and set(item_breed.get('large') or []).intersection(page_breed.get('large') or []))
        source_gender,source_gender_reason=_ai_source_gender(source_desc,filename_codes)
        gender_match=bool(top_item and pg in ('남성','여성','공용') and _ai_item_gender(top_item)==pg)
        source_gender_match=bool(top_item and source_gender in ('남성','여성') and _ai_item_gender(top_item)==source_gender)
        corroborators=sum(bool(x) for x in (filename_member,anchor_match,breed_match,gender_match,source_gender_match))
        locked=bool(top_code and get_bonus_fallback_choice(top_code))
        filename_single_authoritative=bool(filename_member and len(filename_codes)==1 and pc==1 and top_score>0)
        # Exact filename membership on a one-page/one-SKU headquarters PDF is authoritative
        # unless a hard relation already zeroed the score. This also lets a newly arrived
        # real bonus PDF replace an old NEW ARRIVAL/adult-small fallback lock.
        gender_specific=bool(top_item and _ai_item_gender(top_item) in ('남성','여성'))
        gender_evidence=bool(pg in ('남성','여성') or source_gender in ('남성','여성') or filename_member or exact)
        auto=bool(top_item and (
            exact or filename_single_authoritative or (not locked and score>=AI_AUTO_THRESHOLD and margin>=AI_MARGIN_THRESHOLD
                      and top_score>=0.82 and title_score>=0.74 and corroborators>=2
                      and (not gender_specific or gender_evidence))
        ))
        # Expand shared style codes only within the already gender-separated group.
        # This fixes the old bug where a male page could auto-connect a female style
        # simply because both had exactly the same title.
        selected_items=[]
        if auto and score>=0.87:
            for item in g['items']:
                rel=_ai_gender_relation(page_text,item)
                _,breed_conflict,_,_,_=_manual_breed_relation(page_text,item,source_desc)
                if rel[2]>=0 and not breed_conflict and (not pg or _ai_item_gender(item) in (pg,'공용','')):
                    selected_items.append(item)
        elif top_item:
            selected_items=[top_item]
        for item in selected_items:
            suggestions=[]
            for row in ranked[:4]:
                ss,it,_,spg,sig,sreason=row
                suggestions.append({'code':clean_code(it.get('code')),'title':it.get('title_ko',''),'score':round(ss*100),'gender':_ai_item_gender(it) or '-', 'season':'/'.join(_item_season_tokens(it)) or '-', 'category':_breed_label(_item_breed_category(it))})
            _,ig,_,gender_reason=_ai_gender_relation(page_text,item)
            gender_note=f' · 페이지성별 {pg or "미확인"} / 품번성별 {ig or "미확인"}'
            season_note=(f' · PDF시즌 {"/".join(source_seasons)} / 품번시즌 {"/".join(_item_season_tokens(item)) or "미확인"}' if source_seasons else '')
            type_note=(f' · PDF품종 {"/".join(source_types)}' if source_types else '')
            page_cat_label=_breed_label(_page_breed_category(page_text,source_desc))
            item_cat_label=_breed_label(_item_breed_category(item))
            breed_note=f' · 매뉴얼품종 {page_cat_label} → {item_cat_label}'
            lock_note=(' · 대체POP 고정중(정확품번 전까지 자동확정 금지)' if locked and not exact else '')
            results.append({
                'page':p,'page_label':p+1,'text':page_text[:900],
                'code':clean_code(item.get('code')),'title':str(item.get('title_ko') or ''),
                'score':round(score*100),'margin':round(margin*100),'grade':'AI-A' if auto else 'AI-C',
                'method':f'{(_ai_page_engine(pdf_path,p) or "AI")} · {method}{gender_note}{season_note}{type_note}{breed_note}{lock_note}', 'needs_manual':not auto,
                'filename_codes':filename_codes,'suggestions':suggestions,'page_gender':pg,'item_gender':ig,
                'source_gender':source_gender,'source_gender_reason':source_gender_reason,
                'filename_authoritative':bool(filename_single_authoritative),
            })
    # If a page has no confident assignment, expose one best gender-compatible manual candidate.
    represented={int(r['page']) for r in results}
    for p in range(pc):
        if p in represented: continue
        best=None
        for gi,g in enumerate(groups):
            s=matrix[gi][p]; it=details[gi][p][0]
            if it and s>0 and (best is None or s>best[0]): best=(s,it,gi)
        if best and best[0]>=0.35:
            sc,it,gi=best; pg,ig,_,_=_ai_gender_relation(page_texts[p],it)
            source_gender,source_gender_reason=_ai_source_gender(source_desc,filename_codes)
            results.append({'page':p,'page_label':p+1,'text':page_texts[p][:900],'code':clean_code(it.get('code')),'title':it.get('title_ko',''),'score':round(sc*100),'margin':0,'grade':'AI-C','method':f'{(_ai_page_engine(pdf_path,p) or "AI")} · 수동확인 후보 · 페이지성별 {pg or "미확인"} / 품번성별 {ig or "미확인"}','needs_manual':True,'filename_codes':filename_codes,'page_gender':pg,'item_gender':ig,'source_gender':source_gender,'source_gender_reason':source_gender_reason,'suggestions':[{'code':clean_code(it.get('code')),'title':it.get('title_ko',''),'score':round(sc*100),'gender':ig or '-','category':_breed_label(_item_breed_category(it))}]})
    results=_ai_recover_filename_codes(pdf_path,items,page_texts,source_desc,source_seasons,source_types,filename_codes,results)
    if notice_direct:
        direct_pages=set(notice_direct)
        results=[r for r in results if int(r.get('page',0)) not in direct_pages]
        for rows in notice_direct.values(): results.extend(rows)
    results.sort(key=lambda r:(int(r.get('page',0)), bool(r.get('needs_manual')), -int(r.get('score',0)), clean_code(r.get('code'))))
    return results


def _reserve_ai_job(mode,message):
    """Reserve UI state before the worker thread starts so the button never looks dead."""
    with _SCAN_STATUS_LOCK:
        if _SCAN_STATUS.get('running'):
            return False
        _SCAN_CANCEL.clear()
        _SCAN_STATUS.update({
            'running':True,'mode':mode,'started_at':datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'finished_at':'','message':message,'error':'','processed':0,'total':0,
            'cancel_requested':False,'ai_stage':'queued','ai_download_percent':0.0,
            'ai_download_source':'','ai_downloaded_bytes':0,'ai_download_total_bytes':0,
            'ai_download_speed_bps':0.0,'ai_download_eta_seconds':-1,
            'ai_page_done':0,'ai_page_total':0,'ai_page_cached':0,'ai_page_new':0,
            'ai_current_page':0,'ai_current_elapsed_seconds':0,'ai_elapsed_seconds':0,
            'ai_page_last_seconds':0.0,'ai_page_eta_seconds':-1,
            'ai_fast_done':0,'ai_fast_total':0,'ai_vl_done':0,'ai_vl_total':0,
            'ai_preview_file':'','ai_preview_page':0,'ai_preview_code':'','ai_preview_title':'',
            'ai_preview_score':0,'ai_preview_method':'','ai_preview_text':'','ai_preview_page_category':'','ai_preview_item_category':'','ai_preview_seq':'',
            'ai_review_count':0,'ai_review_status':'running',
        })
    return True


def _ai_pdf_signature(pdf):
    try:
        st=Path(pdf).stat()
        return f'{st.st_size}:{st.st_mtime_ns}'
    except Exception:
        return ''


def _load_ai_new_only_state():
    try:
        raw=json.loads(AI_NEW_ONLY_STATE_FILE.read_text('utf-8')) if AI_NEW_ONLY_STATE_FILE.exists() else {}
        if not isinstance(raw,dict): raw={}
    except Exception:
        raw={}
    raw.setdefault('known',{})
    return raw


def _save_ai_new_only_state(state):
    try:
        AI_NEW_ONLY_STATE_FILE.write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf-8')
    except Exception:
        pass


def _seed_ai_new_only_state(pdfs):
    """Seed V4.4.58 without treating every historical Webhard PDF as newly uploaded.

    PDFs that already have complete AI page cache are considered historical on the
    first run. Existing uncached PDFs remain visible as new candidates. After the seed,
    file signatures -- not cache existence -- decide new/changed status, so merely
    running a one-PDF test does not make a new file disappear from this queue.
    """
    state=_load_ai_new_only_state()
    if state.get('seeded_at'):
        return state
    known={}
    for pdf in pdfs or []:
        try:
            cached,total,_=_ai_cache_coverage([pdf])
            if total>0 and cached==total:
                sid=_sync_source_key(Path(pdf)); sig=_ai_pdf_signature(pdf)
                if sid and sig: known[sid]=sig
        except Exception:
            pass
    state['known']=known
    state['seeded_at']=datetime.now().isoformat(timespec='seconds')
    _save_ai_new_only_state(state)
    return state


def _ai_new_or_changed_pdfs(pdfs):
    """Return PDFs not yet acknowledged by the V4.4.58 new-only workflow.

    Path + size + mtime signature catches both newly uploaded files and replacements.
    The processed set is independent of the page OCR cache, so a single-PDF test does
    not accidentally hide a newly uploaded PDF from the new-only confirmation button.
    """
    pdfs=list(pdfs or [])
    state=_seed_ai_new_only_state(pdfs)
    known=state.get('known') or {}
    out=[]
    for pdf in pdfs:
        sid=_sync_source_key(Path(pdf)); sig=_ai_pdf_signature(pdf)
        if sid and sig and str(known.get(sid) or '')!=sig:
            out.append(pdf)
    return out


def _mark_ai_new_only_processed(pdfs):
    state=_load_ai_new_only_state(); known=dict(state.get('known') or {})
    for pdf in pdfs or []:
        sid=_sync_source_key(Path(pdf)); sig=_ai_pdf_signature(pdf)
        if sid and sig: known[sid]=sig
    state['known']=known; state['seeded_at']=state.get('seeded_at') or datetime.now().isoformat(timespec='seconds')
    state['last_processed_at']=datetime.now().isoformat(timespec='seconds')
    _save_ai_new_only_state(state)


def _run_ai_new_only_job():
    if not _SCAN_LOCK.acquire(blocking=False):
        _set_scan_status(running=False,finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),message='새 번외 AI 매칭 시작 실패',error='다른 매칭 작업이 이미 실행 중입니다.')
        return False
    try:
        _cleanup_stale_ai_job_artifacts()
        items=load_items(force=False)[0]
        if not items: raise RuntimeError('프로모션 Excel 상품 데이터가 없습니다. 먼저 Excel을 적용하세요.')
        all_pdfs=sorted((p for p in WEBHARD_SYNC_DIR.rglob('*') if p.is_file() and p.suffix.lower()=='.pdf'),key=lambda p:_sync_source_key(p))
        pdfs=_ai_new_or_changed_pdfs(all_pdfs)
        if not pdfs:
            _set_scan_status(running=False,mode='새 번외만 AI 후보확정',finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),message='새로 업로드되거나 변경된 번외 PDF가 없습니다.',error='',processed=0,total=0,ai_stage='done')
            return True

        cached_before,total_pages,_=_ai_cache_coverage(pdfs)
        _set_scan_status(running=True,mode='새 번외만 AI 후보확정',message=f'신규/변경 PDF {len(pdfs)}개만 분석 시작',error='',processed=0,total=len(pdfs),ai_stage='cache_check',ai_page_total=total_pages,ai_page_done=cached_before,ai_page_cached=cached_before,ai_page_new=max(0,total_pages-cached_before))
        _start_ai_review(len(pdfs),total_pages,scope='new_only')

        ok,msg=ensure_ai_runtime()
        if not ok: raise RuntimeError(msg)
        fast_tasks,fast_meta,cached_pages,total_review_pages=_collect_fast_tasks(pdfs)
        new_fast_keys={str(t.get('id') or '') for t in fast_tasks if str(t.get('id') or '')}
        _set_scan_status(ai_stage='fast_ocr',ai_fast_total=len(fast_tasks),ai_page_total=total_review_pages,ai_page_cached=cached_pages,ai_page_done=cached_pages,message=f'새 번외 FAST 분석 · PDF {len(pdfs)}개 · 신규/변경 페이지 {len(fast_tasks)}개')
        if fast_tasks:
            ok,msg=_run_fast_worker(fast_tasks,cached_base=cached_pages,page_total=total_review_pages,task_meta=fast_meta,items=items)
            if not ok: raise RuntimeError(msg)
        vl_tasks,vl_meta,vl_ready,fast_confident,_=_collect_vl_fallback_tasks(pdfs,items,eligible_keys=new_fast_keys)
        _set_scan_status(ai_stage='vl_select',ai_vl_total=len(vl_tasks),message=f'새 번외 FAST 판정 완료 · 빠른 확정 {fast_confident} · VL 정밀검증 {len(vl_tasks)}페이지')
        if vl_tasks:
            ok,msg=_run_ai_worker(vl_tasks,cached_base=max(0,total_review_pages-len(vl_tasks)),page_total=total_review_pages,task_meta=vl_meta,items=items)
            if not ok: raise RuntimeError(msg)

        state=load_sync_state(); total_auto=0; total_manual=0
        for idx,pdf in enumerate(pdfs,start=1):
            _raise_if_scan_cancelled(); sid=_sync_source_key(pdf)
            _set_scan_status(message=f'새 번외 후보확정 {idx}/{len(pdfs)} · {sid[:70]}',processed=idx-1,total=len(pdfs),ai_stage='assign')
            try:
                results=match_pdf_pages_ai(pdf,items)
                _stage_ai_review_results(sid,results)
                auto=sum(1 for r in results if r.get('code') and not r.get('needs_manual'))
                manual=sum(1 for r in results if r.get('needs_manual') or not r.get('code'))
                total_auto+=auto; total_manual+=manual
                rec=state.setdefault(sid,{})
                rec.update({'relative_path':sid,'source_file':sid,'status':'auto_matched' if results and manual==0 else 'manual_required','auto_count':auto,'manual_count':manual,'ai_engine':'PP-OCRv5 Korean FAST + PaddleOCR-VL 1.6 fallback','analysis_context':AI_PAGE_CACHE_VERSION,'detected_at':datetime.now().strftime('%Y-%m-%d %H:%M:%S')})
            except Exception as exc:
                rec=state.setdefault(sid,{})
                rec.update({'relative_path':sid,'source_file':sid,'status':'error','error':f'{type(exc).__name__}: {exc}'[:300]})
        save_sync_state(state)
        _finalize_ai_review('completed',f'새 번외만 후보 계산 완료 · 자동확정 후보 {total_auto}개 · 수동확인 {total_manual}개 · 기존 번외 매칭은 재계산하지 않음')
        applied,notice_applied=_commit_ai_review_auto(activate=True,apply_notice=True)
        _mark_ai_new_only_processed(pdfs)
        _set_scan_status(running=False,finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),message=f'새 번외만 AI 후보확정 완료 · 신규 자동적용 {applied}개 · 공지 정답 직접연동 {notice_applied}개 · 수동확인 {total_manual}개 · 기존 매칭 유지',processed=len(pdfs),total=len(pdfs),error='',ai_stage='done',ai_download_percent=100.0)
    except ScanCancelled:
        _finalize_ai_review('stopped','새 번외 매칭이 중단되었습니다. 기존 확정 매칭은 그대로 유지됩니다.')
        _set_scan_status(running=False,finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),message='새 번외 AI 매칭 중단 · 기존 매칭 유지',error='',cancel_requested=False)
    except Exception as exc:
        _finalize_ai_review('error',f'{type(exc).__name__}: {exc}'[:300])
        _set_scan_status(running=False,finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),message='새 번외 AI 매칭 오류 · 기존 매칭 유지',error=f'{type(exc).__name__}: {exc}'[:500],cancel_requested=False)
    finally:
        _SCAN_LOCK.release()
    return True


def start_ai_new_only_job():
    if not _reserve_ai_job('새 번외만 AI 후보확정','새로 업로드되거나 변경된 번외 PDF만 찾아 AI 후보확정을 시작합니다. 기존 PDF/기존 매칭은 재계산하지 않습니다.'):
        return False
    try:
        threading.Thread(target=_run_ai_new_only_job,daemon=True).start()
        return True
    except Exception as exc:
        _set_scan_status(running=False,message='새 번외 AI 매칭 시작 실패',error=f'{type(exc).__name__}: {exc}'[:300])
        return False


def _run_ai_full_rematch_job():
    if not _SCAN_LOCK.acquire(blocking=False):
        _set_scan_status(running=False,finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),message='AI 전체 매칭 시작 실패',error='다른 매칭 작업이 이미 실행 중입니다.')
        return False
    current_cache_keys=set()
    try:
        _cleanup_stale_ai_job_artifacts()
        _set_scan_status(running=True,mode='AI FAST 전체 재매칭 V4.4.37',message='기존 AI 분석 캐시 확인 중',error='',processed=0,total=0,cancel_requested=False,ai_stage='cache_check',ai_page_done=0,ai_page_total=0,ai_page_cached=0,ai_page_new=0,ai_current_page=0,ai_current_elapsed_seconds=0,ai_elapsed_seconds=0,ai_page_last_seconds=0.0,ai_page_eta_seconds=-1,ai_fast_done=0,ai_fast_total=0,ai_vl_done=0,ai_vl_total=0)
        items=load_items(force=False)[0]
        if not items: raise RuntimeError('프로모션 Excel 상품 데이터가 없습니다. 먼저 Excel을 적용하세요.')
        pdfs=sorted((p for p in WEBHARD_SYNC_DIR.rglob('*') if p.is_file() and p.suffix.lower()=='.pdf'),key=lambda p:_sync_source_key(p))
        if not pdfs: raise RuntimeError('webhard_sync에서 PDF를 찾지 못했습니다.')

        cached_before,total_review_pages,current_cache_keys=_ai_cache_coverage(pdfs)
        _set_scan_status(total=len(pdfs),ai_page_total=total_review_pages,ai_page_done=cached_before,ai_page_cached=cached_before,ai_page_new=max(0,total_review_pages-cached_before),message=f'AI 캐시 확인 · PDF {len(pdfs)}개 / 페이지 {total_review_pages}개 · 재사용 {cached_before} · 신규/변경 {max(0,total_review_pages-cached_before)}')

        # IMPORTANT V4.4.37: do NOT clear currently-applied AI mappings here.
        # Re-matching is staged in the review store while the old confirmed mapping
        # remains live. Cancel/error therefore never makes the image-match count drop.
        # Old auto links are replaced atomically only when the user presses
        # 'AI 자동 매칭 확정'. Manual links remain protected throughout.
        _start_ai_review(len(pdfs),total_review_pages,scope='full')

        missing_pages=max(0,total_review_pages-cached_before)
        if missing_pages:
            _set_scan_status(message=f'신규/변경 페이지 {missing_pages}개 발견 · AI 런타임 확인 중',ai_stage='runtime')
            ok,msg=ensure_ai_runtime()
            if not ok: raise RuntimeError(msg)

            # Stage 1: OCR only pages with no current cache key/text.
            fast_tasks,fast_meta,cached_pages,total_pages=_collect_fast_tasks(pdfs)
            new_fast_keys={str(t.get('id') or '') for t in fast_tasks if str(t.get('id') or '')}
            _set_scan_status(total=len(pdfs),ai_page_total=total_pages,ai_page_done=cached_pages,ai_page_cached=cached_pages,ai_page_new=len(fast_tasks),ai_fast_total=len(fast_tasks),message=f'FAST 1차 분석 · 캐시 {cached_pages}페이지 재사용 · 신규/변경 {len(fast_tasks)}페이지')
            if fast_tasks:
                ok,msg=_run_fast_worker(fast_tasks,cached_base=cached_pages,page_total=total_pages,task_meta=fast_meta,items=items)
                if not ok: raise RuntimeError(msg)

            # Stage 2: heavy VL only for pages that were newly FAST-analyzed *this run*.
            # Existing ambiguous cache is reused on repeated matching instead of being
            # inferred again and again.
            vl_tasks,vl_meta,vl_ready,fast_confident,_=_collect_vl_fallback_tasks(pdfs,items,eligible_keys=new_fast_keys)
            _set_scan_status(ai_stage='vl_select',ai_vl_total=len(vl_tasks),ai_vl_done=0,ai_fast_done=len(fast_tasks),
                message=f'신규 페이지 FAST 판정 완료 · 빠른 확정 {fast_confident} · 기존 VL {vl_ready} · 신규 VL 정밀검증 {len(vl_tasks)}페이지')
            if vl_tasks:
                ok,msg=_run_ai_worker(vl_tasks,cached_base=max(0,total_pages-len(vl_tasks)),page_total=total_pages,task_meta=vl_meta,items=items)
                if not ok: raise RuntimeError(msg)
            else:
                _set_scan_status(message='신규 VL 정밀검증 0페이지 · 품번 재배정 시작',ai_stage='assign',ai_vl_done=0,ai_vl_total=0)
        else:
            # True repeat-rematch fast path: no package import, OCR, model load or VL.
            _set_scan_status(ai_stage='assign',ai_page_done=total_review_pages,ai_page_total=total_review_pages,ai_page_cached=total_review_pages,ai_page_new=0,ai_fast_total=0,ai_fast_done=0,ai_vl_total=0,ai_vl_done=0,
                message=f'기존 AI 분석 캐시 {total_review_pages}페이지 100% 재사용 · OCR/VL 재분석 0 · 현재 Excel 기준 품번 재배정만 실행')

        # Stage review results. Existing confirmed AI mappings remain live until confirm.
        state=load_sync_state(); total_auto=0; total_manual=0
        for idx,pdf in enumerate(pdfs,start=1):
            _raise_if_scan_cancelled(); sid=_sync_source_key(pdf)
            _set_scan_status(message=f'캐시 기반 최종 품번 재배정 {idx}/{len(pdfs)} · {sid[:70]}',processed=idx-1,total=len(pdfs),ai_stage='assign')
            try:
                results=match_pdf_pages_ai(pdf,items)
                _stage_ai_review_results(sid,results)
                if results:
                    r=sorted(results,key=lambda x:(bool(x.get('needs_manual')),-int(x.get('score',0))))[0]
                    _publish_ai_preview(sid,int(r.get('page',0))+1,r.get('code',''),r.get('title',''),int(r.get('score',0)),('수동확인 후보' if r.get('needs_manual') else '최종 자동매칭 후보'),str(r.get('text') or '')[:650],stage_review=False)
                auto=sum(1 for r in results if r.get('code') and not r.get('needs_manual'))
                manual=sum(1 for r in results if r.get('needs_manual') or not r.get('code'))
                total_auto+=auto; total_manual+=manual
                rec=state.setdefault(sid,{}); rec.update({'relative_path':sid,'source_file':sid,'status':'auto_matched' if results and manual==0 else 'manual_required','auto_count':auto,'manual_count':manual,'ai_engine':'PP-OCRv5 Korean FAST + PaddleOCR-VL 1.6 fallback','analysis_context':AI_PAGE_CACHE_VERSION,'detected_at':datetime.now().strftime('%Y-%m-%d %H:%M:%S')})
                try:
                    with fitz.open(str(pdf)) as d:
                        for pno in range(d.page_count): _cleanup_ai_render(pdf,pno)
                except Exception: pass
            except Exception as exc:
                rec=state.setdefault(sid,{}); rec.update({'relative_path':sid,'source_file':sid,'status':'error','error':f'{type(exc).__name__}: {exc}'[:300]})
        save_sync_state(state)
        _prune_ai_cache_to_current(current_cache_keys)
        reuse_note=(' · 기존 페이지 AI 재분석 0' if missing_pages==0 else f' · 신규/변경 {missing_pages}페이지만 분석')
        staged_msg=f'AI 재매칭 계산 완료 · 자동확정 후보 {total_auto}개 · 수동확인 {total_manual}개{reuse_note} · 자동확정/공지 정답을 실제 매칭에 적용 중'
        _finalize_ai_review('completed',staged_msg)
        applied,notice_applied=_commit_ai_review_auto(activate=True,apply_notice=True)
        _mark_ai_new_only_processed(pdfs)
        done_msg=f'AI 전체 재매칭 완료 · AI 자동적용 {applied}개 · 공지 정답 직접연동 {notice_applied}개 · 수동확인 {total_manual}개{reuse_note} · 현재 적용 엔진 AI'
        _set_scan_status(running=False,finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),message=done_msg,processed=len(pdfs),total=len(pdfs),error='',ai_stage='done',ai_download_percent=100.0)
    except ScanCancelled:
        _finalize_ai_review('stopped','AI 재매칭이 중단되었습니다. 기존에 확정·적용된 AI 번외 매칭은 그대로 유지됩니다. 중단 전 계산된 새 후보만 결과/검토 화면에 남습니다.')
        _set_scan_status(running=False,finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),message='AI 재매칭 중단 완료 · 기존 적용 결과 유지 · 새 후보는 결과/검토에서 확인 가능',error='',cancel_requested=False)
    except Exception as exc:
        _finalize_ai_review('error',f'{type(exc).__name__}: {exc}'[:300])
        _set_scan_status(running=False,finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),message='AI 재매칭 오류 · 기존 적용 결과는 유지됨',error=f'{type(exc).__name__}: {exc}'[:500],cancel_requested=False)
    finally:
        _SCAN_LOCK.release()
    return True

def _run_ai_single_job(source_id):
    if not _SCAN_LOCK.acquire(blocking=False):
        _set_scan_status(running=False,finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),message='AI 단일 PDF 테스트 시작 실패',error='다른 매칭 작업이 이미 실행 중입니다.')
        return False
    try:
        _set_scan_status(running=True,mode='AI FAST 단일 PDF 테스트',message='AI 런타임 확인 중',error='',processed=0,total=1,cancel_requested=False,ai_stage='runtime',ai_page_done=0,ai_page_total=0,ai_page_cached=0,ai_page_new=0,ai_current_page=0,ai_current_elapsed_seconds=0,ai_elapsed_seconds=0,ai_page_last_seconds=0.0,ai_page_eta_seconds=-1,ai_fast_done=0,ai_fast_total=0,ai_vl_done=0,ai_vl_total=0)
        ok,msg=ensure_ai_runtime()
        if not ok: raise RuntimeError(msg)
        pdf=_resolve_webhard_pdf(source_id)
        if not pdf: raise RuntimeError('선택한 PDF를 찾을 수 없습니다.')
        items=load_items(force=False)[0]
        if not items: raise RuntimeError('프로모션 Excel 상품 데이터가 없습니다. 먼저 Excel을 적용하세요.')
        fast_tasks,fast_meta,cached_pages,one_pages=_collect_fast_tasks([pdf])
        _set_scan_status(total=1,ai_page_total=one_pages,ai_page_done=cached_pages,ai_page_cached=cached_pages,ai_page_new=len(fast_tasks),ai_fast_total=len(fast_tasks),message=f'선택 PDF FAST 1차 분석 · 전체 {one_pages}페이지 · 캐시 {cached_pages} · 신규 {len(fast_tasks)}')
        if fast_tasks:
            ok,msg=_run_fast_worker(fast_tasks,cached_base=cached_pages,page_total=one_pages,task_meta=fast_meta,items=items)
            if not ok: raise RuntimeError(msg)
        vl_tasks,vl_meta,vl_ready,fast_confident,_=_collect_vl_fallback_tasks([pdf],items)
        _set_scan_status(ai_stage='vl_select',ai_vl_total=len(vl_tasks),message=f'FAST 판정 · 빠른 확정 {fast_confident} · 기존 VL {vl_ready} · VL 정밀검증 {len(vl_tasks)}페이지')
        if vl_tasks:
            ok,msg=_run_ai_worker(vl_tasks,cached_base=max(0,one_pages-len(vl_tasks)),page_total=one_pages,task_meta=vl_meta,items=items)
            if not ok: raise RuntimeError(msg)
        results=match_pdf_pages_ai(pdf,items)
        if results:
            r=sorted(results,key=lambda x:(bool(x.get('needs_manual')),-int(x.get('score',0))))[0]
            _publish_ai_preview(source_id,int(r.get('page',0))+1,r.get('code',''),r.get('title',''),int(r.get('score',0)),('수동확인 후보' if r.get('needs_manual') else '최종 자동매칭 후보'),str(r.get('text') or '')[:650],stage_review=False)
        AI_SINGLE_RESULT_FILE.write_text(json.dumps({'filename':source_id,'results':results,'saved_at':datetime.now().isoformat()},ensure_ascii=False,indent=2),encoding='utf-8')
        try:
            with fitz.open(str(pdf)) as d:
                for pno in range(d.page_count): _cleanup_ai_render(pdf,pno)
        except Exception: pass
        _set_scan_status(running=False,finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),message=f'단일 PDF AI FAST 테스트 완료 · 결과 {len(results)}개',processed=1,total=1,error='',ai_stage='done',ai_download_percent=100.0)
    except ScanCancelled:
        _set_scan_status(running=False,finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),message='단일 PDF AI 테스트 중단 완료',error='',cancel_requested=False)
    except Exception as exc:
        _set_scan_status(running=False,finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),message='단일 PDF AI 테스트 오류',error=f'{type(exc).__name__}: {exc}'[:500],cancel_requested=False)
    finally:
        _SCAN_LOCK.release()
    return True


def start_ai_single_job(source_id):
    if not _reserve_ai_job('AI 단일 PDF 테스트','AI 단일 테스트 시작 요청 접수 · 작업 준비 중'):
        return False
    try:
        threading.Thread(target=_run_ai_single_job,args=(source_id,),daemon=True).start()
        return True
    except Exception as exc:
        _set_scan_status(running=False,message='AI 단일 테스트 시작 실패',error=f'{type(exc).__name__}: {exc}'[:300])
        return False


def start_ai_full_rematch_job():
    if not _reserve_ai_job('AI FAST 전체 재매칭 V4.4.37','AI 전체 재매칭 시작 요청 접수 · 기존 적용 결과는 유지하고, 변경된 페이지만 분석하며 기존 페이지는 캐시로 재판정합니다.'):
        return False
    try:
        threading.Thread(target=_run_ai_full_rematch_job,daemon=True).start()
        return True
    except Exception as exc:
        _set_scan_status(running=False,message='AI 전체 매칭 시작 실패',error=f'{type(exc).__name__}: {exc}'[:300])
        return False

AI_MATCH_HTML=r"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AI 페이지 매칭 V5.1</title><style>body{font-family:Malgun Gothic,Arial;margin:0;background:#f3f5f7}.wrap{max-width:1200px;margin:auto;padding:24px}.panel{background:#fff;padding:18px;border-radius:12px;margin-bottom:16px}.btn{background:#102c73;color:#fff;border:0;border-radius:7px;padding:10px 15px;text-decoration:none;font-weight:700;cursor:pointer;display:inline-block}.green{background:#26734d}.gray{background:#555}.orange{background:#a85a00}.red{background:#c51f2c}.ok{color:#16753d;font-weight:700}.bad{color:#c00;font-weight:700}.muted{color:#666}.status{padding:12px;background:#eef3fb;border-radius:8px;line-height:1.7}.rule{background:#eef7f1;padding:13px;border-radius:8px;line-height:1.8}.progress-wrap{margin-top:12px;padding:10px;background:#fff;border-radius:8px;border:1px solid #d8dfeb}.progress-track{height:20px;background:#e4e8ef;border-radius:10px;overflow:hidden;margin-top:6px}.progress-bar{height:100%;width:0%;background:#26734d;transition:width .25s ease}.metrics{display:flex;gap:18px;flex-wrap:wrap;margin-top:8px}.metrics span{background:#f4f6f9;padding:5px 9px;border-radius:6px}.live{display:grid;grid-template-columns:230px 1fr;gap:16px;align-items:start}.live img{width:220px;max-height:310px;object-fit:contain;border:1px solid #ccd2da;background:#f5f5f5;border-radius:7px}.score{font-size:24px;font-weight:800;color:#126535}@media(max-width:700px){.live{grid-template-columns:1fr}.live img{width:100%;max-width:300px}}</style></head><body><div class="wrap"><div class="panel"><a class="btn gray" href="/">← 메인 화면</a> <a class="btn" href="/sync">웹하드 상태</a><h2>AI 페이지 매칭 엔진 · V4.4.60</h2><p><b>AI 엔진:</b> <span class="{{'ok' if ai_ok else 'bad'}}">{{ai_status}}</span></p><div class="rule"><b>V5.1 성별 하드게이트 + 신규만 후보확정:</b> 모든 신규 페이지를 0.9B VL로 바로 돌리지 않습니다.<br>① <b>PP-OCRv5 Korean Mobile</b>로 한글/영문/남성·여성/상품명을 빠르게 읽음 → ② Excel 상품명·영문명·성별·부가설명과 즉시 비교 → ③ 확실한 페이지는 바로 캐시/매칭 → ④ <b>애매한 페이지만 PaddleOCR-VL 1.6</b> 정밀검증 → ⑤ 파일명 품번 순서는 후보군일 뿐 페이지 순서로 사용하지 않음 → <b>파일명에 F2/G2/G3 같은 시즌이 있으면 동일 시즌만 후보 허용</b> → 파일명 품종 + 매뉴얼 품종대/소(J/C/K/V/L/W/T/E/O/P/D/R/U/A)를 교차검증하고 명확한 품종대 불일치는 자동차단 → ⑥ <b>정확 품번 직접인식 또는 84% 이상 + 페이지 후보차 6%p 이상 + 강한 상품명 + 복수 교차근거일 때만 자동확정</b> → ⑦ 결과는 검토창에도 저장 → ⑧ 전체 재매칭 완료 시 고신뢰 자동확정과 공지 PDF 정답연동을 실제 이미지 매칭에 자동 반영 → ⑨ 수동고정은 항상 보호. → ⑩ <b>남성/여성 하드게이트:</b> 페이지 성별라벨·파일명 품번 성별·품번 끝4자리 규칙 중 명확한 성별이 반대면 자동확정 금지.</div><p class="muted">기존에 이미 PaddleOCR‑VL로 분석된 페이지는 그대로 재사용합니다. 새 페이지도 FAST 결과가 충분하면 VL 모델을 로딩하지 않으므로 CPU PC에서 준비/추론 시간을 크게 줄이는 구조입니다.</p><button id="aiStartBtn" class="btn green" type="button" onclick="startFullAi()" {{'disabled' if scan.running else ''}}>AI 전체 재매칭 시작</button> <button id="aiNewBtn" class="btn orange" type="button" onclick="startNewOnlyAi()" {{'disabled' if scan.running else ''}}>새 번외만 AI 후보확정 ({{new_only_count}})</button> <button id="aiStopBtn" class="btn red" type="button" onclick="stopMatching()" {{'' if scan.running else 'disabled'}}>AI 매칭 중단</button><div class="muted" style="margin-top:9px">새 번외만 후보확정은 AI 캐시에 없는 신규/변경 PDF만 분석하고 기존 번외 매칭은 재계산하지 않습니다.</div><hr style="margin:18px 0"><h3>먼저 PDF 1개만 시험</h3><form method="post" action="/bonus-ai/test-one"><input id="aiPdfSearch" list="aipdfs" name="filename" style="padding:9px;min-width:520px" placeholder="webhard_sync PDF 검색/선택" autocomplete="off" required><datalist id="aipdfs">{% for f in all_pdfs %}<option value="{{f}}">{% endfor %}</datalist> <button class="btn orange">선택 PDF만 AI FAST 테스트</button></form><p><a id="reviewBtn" class="btn green" href="/bonus-ai/review" style="{{'' if review_ready else 'display:none'}}">AI 매칭 결과/검토 <span id="reviewCount">{{review_count}}</span>개</a> <span id="reviewHint" class="muted">{{'완료 후 자동적용됩니다. 필요하면 결과를 검토/수정하세요.' if review_ready else ''}}</span></p><p id="singleResultWrap" style="{{'' if single_ready else 'display:none'}}"><a class="btn green" href="/bonus-ai/result">마지막 단일 PDF 결과 보기</a></p></div><div class="panel"><h3>작업 상태</h3><div class="status"><div style="margin-bottom:8px"><span id="aiRunBadge" style="font-weight:800;padding:5px 9px;border-radius:999px;background:#e7ebf1;color:#444">{{'● AI 매칭 실행 중' if scan.running else '대기'}}</span></div><b id="scanMode">{{scan.mode or '대기'}}</b><br><span id="scanMessage">{{scan.message}}</span><br><span id="scanError" class="bad">{{scan.error or ''}}</span><div id="scanTimes" class="muted"></div><div id="aiOverallBox" class="progress-wrap" style="display:none"><div><b id="aiOverallLabel">AI 작업 진행 중</b></div><div class="progress-track"><div id="aiOverallBar" class="progress-bar"></div></div><div class="metrics"><span>PDF: <b id="aiPdfProgress">0/0</b></span><span>전체 페이지: <b id="aiPageProgress">0/0</b></span><span>캐시: <b id="aiCachedProgress">0</b></span><span>FAST: <b id="aiFastProgress">0/0</b></span><span>VL 정밀: <b id="aiVlProgress">0/0</b></span></div><div class="metrics"><span>현재 페이지: <b id="aiCurrentPage">-</b></span><span>현재 경과: <b id="aiCurrentElapsed">-</b></span><span>최근 페이지: <b id="aiLastPageTime">-</b></span><span>남은 예상: <b id="aiPageEta">-</b></span><span>전체 경과: <b id="aiElapsed">-</b></span></div></div><div id="aiDownloadBox" class="progress-wrap" style="display:none"><div>VL 모델 소스: <b id="aiDownloadSource">-</b> · <b id="aiDownloadPercent">0.00%</b></div><div class="progress-track"><div id="aiDownloadBar" class="progress-bar"></div></div><div class="metrics"><span>받은 용량: <b id="aiDownloadBytes">-</b></span><span>속도: <b id="aiDownloadSpeed">-</b></span><span>남은 예상시간: <b id="aiDownloadEta">-</b></span></div></div></div></div><div class="panel" id="livePreviewBox"><h3>실시간 매칭 미리보기</h3><div class="live"><img id="livePreviewImg" style="display:none"><div><div><b>번외 PDF:</b> <span id="liveFile">대기 중</span> <span id="livePage"></span></div><div style="margin-top:8px"><b>현재 후보:</b> <span id="liveCode">-</span> · <span id="liveTitle">-</span></div><div class="score" id="liveScore">-</div><div><b>판정:</b> <span id="liveMethod">-</span></div><div><b>매뉴얼 품종:</b> <span id="livePageCategory">-</span> → <span id="liveItemCategory">-</span></div><div class="muted" id="liveText" style="margin-top:9px;max-height:110px;overflow:auto"></div></div></div></div><div class="panel"><h3>AI 페이지 캐시</h3><p>저장된 AI 분석 페이지: <b id="aiCacheCount">{{cache_count}}</b>개</p><p class="muted">페이지가 변경되지 않으면 FAST/VL 분석을 다시 하지 않습니다.</p></div></div><script>
function fmtBytes(n){n=Number(n||0);if(!n)return '-';const u=['B','KB','MB','GB'];let i=0;while(n>=1024&&i<u.length-1){n/=1024;i++;}return n.toFixed(i>=2?2:1)+' '+u[i];} function fmtSpeed(n){return Number(n||0)>0?fmtBytes(n)+'/s':'-';} function fmtEta(sec){sec=Number(sec);if(!Number.isFinite(sec)||sec<0)return '-';if(sec<=1)return '완료';let m=Math.ceil(sec/60);if(m<60)return '약 '+m+'분';return '약 '+Math.floor(m/60)+'시간 '+(m%60)+'분';} function fmtClock(sec){sec=Math.max(0,Math.floor(Number(sec||0)));let h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60),ss=sec%60;return (h?h+'시간 ':'')+(m?m+'분 ':'')+ss+'초';} function previewUrl(file,page,seq){if(!file||!page)return '';return '/bonus/page-preview/'+file.split('/').map(encodeURIComponent).join('/')+'/'+(Number(page)-1)+'?live='+(seq||'1');}
let requestedPreviewSeq=''; let shownPreviewSeq='';
function renderLiveAtomic(d){const f=d.ai_preview_file||'',pg=Number(d.ai_preview_page||0),seq=String(d.ai_preview_seq||[f,pg,d.ai_preview_code||'',d.ai_preview_method||''].join('|'));if(!f||!pg){return;}if(seq===requestedPreviewSeq||seq===shownPreviewSeq)return;requestedPreviewSeq=seq;const u=previewUrl(f,pg,seq),pre=new Image();const commit=()=>{if(requestedPreviewSeq!==seq)return;const im=document.getElementById('livePreviewImg');im.src=u;im.style.display='block';im.dataset.u=u;document.getElementById('liveFile').textContent=f;document.getElementById('livePage').textContent=' · '+pg+'페이지';document.getElementById('liveCode').textContent=d.ai_preview_code||'-';document.getElementById('liveTitle').textContent=d.ai_preview_title||'-';document.getElementById('liveScore').textContent=Number(d.ai_preview_score||0)?(d.ai_preview_score+'%'):'-';document.getElementById('liveMethod').textContent=d.ai_preview_method||'-';document.getElementById('livePageCategory').textContent=d.ai_preview_page_category||'-';document.getElementById('liveItemCategory').textContent=d.ai_preview_item_category||'-';document.getElementById('liveText').textContent=d.ai_preview_text||'';shownPreviewSeq=seq;};pre.onload=commit;pre.onerror=commit;pre.src=u;}
async function refreshStatus(){try{const r=await fetch('/api/scan-status',{cache:'no-store'});const d=await r.json(),running=!!d.running,stage=d.ai_stage||'';document.getElementById('scanMode').textContent=d.mode||'대기';document.getElementById('scanMessage').textContent=d.message||'';document.getElementById('scanError').textContent=d.error||'';document.getElementById('scanTimes').textContent=d.started_at?('시작 '+d.started_at+(d.finished_at?' · 완료 '+d.finished_at:'')+' · 처리 '+(d.processed||0)+(d.total?' / '+d.total:'')):'';document.getElementById('aiStopBtn').disabled=!running;document.getElementById('aiStartBtn').disabled=running;const nb=document.getElementById('aiNewBtn');if(nb)nb.disabled=running;const badge=document.getElementById('aiRunBadge');badge.textContent=running?'● AI 매칭 실행 중':(d.error?'오류 발생':(d.finished_at?'완료':'대기'));badge.style.background=running?'#dff3e6':(d.error?'#ffe3e3':'#e7ebf1');badge.style.color=running?'#126535':(d.error?'#b00020':'#444');if(typeof d.ai_cache_count!=='undefined')document.getElementById('aiCacheCount').textContent=d.ai_cache_count;if(d.single_ready)document.getElementById('singleResultWrap').style.display='block';const pDone=Number(d.processed||0),pTotal=Number(d.total||0),aDone=Number(d.ai_page_done||0),aTotal=Number(d.ai_page_total||0);document.getElementById('aiOverallBox').style.display=(running||stage==='assign')?'block':'none';document.getElementById('aiPdfProgress').textContent=pDone+'/'+pTotal;document.getElementById('aiPageProgress').textContent=aDone+'/'+aTotal;document.getElementById('aiCachedProgress').textContent=Number(d.ai_page_cached||0);document.getElementById('aiFastProgress').textContent=Number(d.ai_fast_done||0)+'/'+Number(d.ai_fast_total||0);document.getElementById('aiVlProgress').textContent=Number(d.ai_vl_done||0)+'/'+Number(d.ai_vl_total||0);const cur=Number(d.ai_current_page||0);document.getElementById('aiCurrentPage').textContent=cur?String(cur):'-';document.getElementById('aiCurrentElapsed').textContent=cur?fmtClock(d.ai_current_elapsed_seconds):'-';document.getElementById('aiLastPageTime').textContent=Number(d.ai_page_last_seconds||0)>0?fmtClock(d.ai_page_last_seconds):'-';document.getElementById('aiPageEta').textContent=fmtEta(d.ai_page_eta_seconds);document.getElementById('aiElapsed').textContent=running?fmtClock(d.ai_elapsed_seconds):'-';let op=0;if(stage==='assign'&&pTotal)op=pDone*100/pTotal;else if(aTotal)op=aDone*100/aTotal;document.getElementById('aiOverallBar').style.width=Math.min(100,op)+'%';document.getElementById('aiOverallLabel').textContent=stage==='fast_ocr'?'PP-OCRv5 Korean FAST 분석 중':(stage==='vl_select'?'FAST 결과 판정 / VL 대상 선별':(stage==='assign'?'최종 품번 배정 중':(stage.startsWith('infer')?'PaddleOCR-VL 정밀검증 중':'AI 작업')));const pct=Math.max(0,Math.min(100,Number(d.ai_download_percent||0))),src=d.ai_download_source||'';const downloading=['source','download','model','engine_load'].includes(stage)&&running;document.getElementById('aiDownloadBox').style.display=downloading?'block':'none';document.getElementById('aiDownloadSource').textContent=src||'확인 중';document.getElementById('aiDownloadPercent').textContent=pct.toFixed(2)+'%';document.getElementById('aiDownloadBar').style.width=pct+'%';const got=Number(d.ai_downloaded_bytes||0),tot=Number(d.ai_download_total_bytes||0);document.getElementById('aiDownloadBytes').textContent=got?(fmtBytes(got)+(tot?' / '+fmtBytes(tot):'')):'-';document.getElementById('aiDownloadSpeed').textContent=fmtSpeed(d.ai_download_speed_bps);document.getElementById('aiDownloadEta').textContent=fmtEta(d.ai_download_eta_seconds);renderLiveAtomic(d);const rb=document.getElementById('reviewBtn'),rc=document.getElementById('reviewCount'),rh=document.getElementById('reviewHint');if(rb&&Number(d.ai_review_count||0)>0){rb.style.display='inline-block';if(rc)rc.textContent=Number(d.ai_review_count||0);if(rh)rh.textContent=(d.ai_review_status==='running'?'분석 중에도 현재 저장된 후보를 볼 수 있습니다.':'결과를 검토한 뒤 AI 자동 매칭 확정을 눌러주세요.');}}catch(e){}}
async function startFullAi(){if(!confirm('AI 전체 재매칭을 시작할까요? 현재 적용 중인 AI 매칭은 유지한 채 새 후보를 다시 계산합니다. 수동고정은 보호되고, 변경된 PDF 페이지만 AI 분석합니다. 기존 페이지는 캐시로 즉시 재판정합니다.'))return;document.getElementById('aiStartBtn').disabled=true;try{const r=await fetch('/bonus-ai/start',{method:'POST',headers:{'Accept':'application/json'}}),d=await r.json();if(!d.ok)alert(d.message||'시작 실패');await refreshStatus();}catch(e){alert('시작 요청 실패: '+e);}} async function startNewOnlyAi(){if(!confirm('새로 업로드되거나 변경된 번외 PDF만 매칭할까요? 기존 PDF와 기존 확정 매칭은 재계산하지 않습니다.'))return;const b=document.getElementById('aiNewBtn');if(b)b.disabled=true;try{const r=await fetch('/bonus-ai/start-new-only',{method:'POST',headers:{'Accept':'application/json'}}),d=await r.json();if(!d.ok)alert(d.message||'시작 실패');await refreshStatus();}catch(e){alert('새 번외 매칭 시작 실패: '+e);}} async function stopMatching(){if(!confirm('현재 AI 매칭을 중단할까요? 완료된 페이지 캐시는 유지됩니다.'))return;try{await fetch('/api/scan-stop',{method:'POST'});refreshStatus();}catch(e){}} setInterval(refreshStatus,1000);refreshStatus();
</script></body></html>"""


def _ignore_ai_review_codes(codes=None, clear_all=False):
    review=_load_ai_review()
    rows=review.get('rows') or []
    targets={clean_code(c) for c in (codes or []) if clean_code(c)}
    changed=False
    for r in rows:
        selected=clean_code(r.get('selected_code')); proposed=clean_code(r.get('proposed_code'))
        if clear_all or (targets and (selected in targets or proposed in targets)):
            r['status']='ignored'; r['selected_code']=''; r['needs_manual']=True
            r['reset_at']=datetime.now().isoformat(timespec='seconds'); changed=True
    if changed:
        review['message']='초기화된 품번은 기존 AI 검토 결과에서도 재적용되지 않도록 제외 처리했습니다.'
        _save_ai_review(review)


AI_REVIEW_HTML=r"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AI 매칭 결과 검토 V5.1</title><style>body{font-family:Malgun Gothic,Arial;margin:0;background:#f3f5f7;color:#181818}.wrap{max-width:1540px;margin:auto;padding:22px}.panel{background:#fff;border-radius:12px;padding:17px;margin-bottom:15px;box-shadow:0 2px 10px #0000000d}.btn{display:inline-block;border:0;border-radius:7px;padding:9px 13px;background:#102c73;color:white;text-decoration:none;font-weight:700;cursor:pointer}.green{background:#26734d}.orange{background:#ad5b00}.red{background:#c51f2c}.gray{background:#555}.muted{color:#6b6b6b}.ok{color:#16753d;font-weight:800}.warn{color:#b45a00;font-weight:800}.bad{color:#c00;font-weight:800}.stats{display:flex;gap:9px;flex-wrap:wrap;margin-top:10px}.stat{background:#f2f5f8;padding:8px 11px;border-radius:7px}.tablebox{overflow:auto;max-height:720px;border:1px solid #ddd}table{width:100%;border-collapse:collapse;font-size:13px}th,td{padding:8px;border-bottom:1px solid #e2e2e2;vertical-align:top;text-align:left}th{position:sticky;top:0;background:#edf1f7;z-index:2}.thumb{width:150px;max-height:215px;object-fit:contain;border:1px solid #ccc;background:#eee}.suggest{margin:3px 0;padding-left:18px;line-height:1.5}.codeinput{padding:8px;min-width:275px;border:1px solid #bbb;border-radius:6px}.provisional{background:#fff9e9}.manualrow{background:#fff4f4}.applied{background:#eff9f2}.inline{display:inline-block;margin:2px}</style></head><body><div class="wrap"><div class="panel"><a class="btn gray" href="/bonus-ai">← AI 매칭</a> <a class="btn" href="/bonus/manual?mode=ai">현재 번외 매칭/수동수정</a> <a class="btn orange" href="/bonus/manual?mode=ai">품번 검색·오매칭 빠른 수정</a><h2>AI 매칭 결과 / 검토 · V5.1</h2><p>상태: <b>{{review.status or '없음'}}</b> · 시작 {{review.started_at or '-'}} {% if review.finished_at %}· 종료 {{review.finished_at}}{% endif %}</p><p>{{review.message or ''}}</p><div class="stats"><span class="stat">검토 행 <b>{{rows|length}}</b></span><span class="stat">자동확정 후보 <b>{{auto_count}}</b></span><span class="stat">수동확인 <b>{{manual_count}}</b></span><span class="stat">분석중 후보 <b>{{provisional_count}}</b></span><span class="stat">AI 저장 매칭 <b>{{matches|length}}</b></span></div>{% if rows and review.status!='running' %}<form class="inline" method="post" action="/bonus-ai/review/confirm-auto" onsubmit="return confirm('검토된 자동확정 후보를 실제 이미지 매칭에 반영할까요? 수동고정은 보호됩니다.')"><button class="btn green">AI 자동 매칭 확정</button></form>{% endif %}<span class="muted">정확 품번 직접 인식 또는 <b>84% 이상 + 후보차 6%p 이상 + 상품명 강한 일치 + 2개 이상의 교차근거</b>가 있는 후보만 자동확정 대상입니다. AI 전체 재매칭 완료 시 자동확정 후보는 실제 이미지 매칭에 자동 반영됩니다. 이 버튼은 검토 후 다시 적용할 때 사용합니다.</span></div><div class="panel"><div class="tablebox"><table><thead><tr><th>번외 페이지</th><th>AI 제안</th><th>근거/후보</th><th>상태</th><th>수동 변경</th></tr></thead><tbody>{% for r in rows %}<tr class="{{'provisional' if not r.final else ('manualrow' if r.needs_manual else ('applied' if r.status in ['manual_fixed','applied'] else ''))}}"><td><div><b>{{r.file}}</b> · {{r.page_label}}페이지</div><a target="_blank" href="{{url_for('bonus_page_preview',filename=r.file,page=r.page)}}"><img class="thumb" loading="lazy" src="{{url_for('bonus_page_preview',filename=r.file,page=r.page)}}"></a></td><td>{% if r.proposed_code %}<b>{{r.proposed_code}}</b><br>{{r.title or ''}}<br><span class="ok">{{r.score}}%</span>{% else %}<span class="bad">후보 없음</span>{% endif %}<div class="muted">{{r.method}}</div></td><td><div class="muted" style="max-width:410px;max-height:95px;overflow:auto">{{r.text or '-'}}</div>{% if r.suggestions %}<ol class="suggest">{% for s in r.suggestions %}<li><b>{{s.code}}</b> · {{s.title}} · {{s.score}}%{% if s.gender %} · {{s.gender}}{% endif %}{% if s.season %} · 시즌 {{s.season}}{% endif %}{% if s.category %} · 품종 {{s.category}}{% endif %}</li>{% endfor %}</ol>{% endif %}</td><td>{% if not r.final %}<span class="warn">분석중 후보</span>{% elif r.status=='manual_fixed' %}<span class="ok">수동고정 완료</span>{% elif r.status=='applied' %}<span class="ok">자동확정 반영됨</span>{% elif r.status=='gender_blocked' %}<span class="bad">성별 불일치 자동차단</span>{% elif r.needs_manual %}<span class="bad">수동확인 필요</span>{% else %}<span class="ok">자동확정 후보</span>{% endif %}</td><td><form method="post" action="/bonus-ai/review/manual"><input type="hidden" name="row_id" value="{{r.id}}"><input class="codeinput" list="allcodes" name="code" value="{{r.selected_code or r.proposed_code or ''}}" placeholder="품번 입력/검색" required> <button class="btn orange">이 페이지로 수동고정</button></form>{% if r.final and r.status not in ['manual_fixed','applied'] %}<form class="inline" method="post" action="/bonus-ai/review/ignore"><input type="hidden" name="row_id" value="{{r.id}}"><button class="btn gray">이 후보 제외</button></form>{% endif %}</td></tr>{% else %}<tr><td colspan="5">아직 저장된 AI 매칭 결과가 없습니다.</td></tr>{% endfor %}</tbody></table></div><datalist id="allcodes">{% for i in items %}<option value="{{i.code}}">{{i.code}} | {{i.title_ko}} | {{i.gender}}</option>{% endfor %}</datalist></div></div></body></html>"""


@app.get('/bonus-ai/review')
def bonus_ai_review_page():
    review=_load_ai_review(); rows=list(review.get('rows') or [])
    rows.sort(key=lambda r:(str(r.get('file') or ''),int(r.get('page',0)),not bool(r.get('final')),clean_code(r.get('proposed_code'))))
    _,items,_,_=items_map(); matches=load_bonus_matches(mode='ai')
    auto_count=sum(1 for r in rows if r.get('final') and not r.get('needs_manual') and r.get('proposed_code') and r.get('status') not in ('ignored','manual_fixed'))
    manual_count=sum(1 for r in rows if r.get('final') and r.get('needs_manual'))
    provisional_count=sum(1 for r in rows if not r.get('final'))
    return render_template_string(AI_REVIEW_HTML,review=review,rows=rows,items=items,matches=matches,auto_count=auto_count,manual_count=manual_count,provisional_count=provisional_count)


@app.post('/bonus-ai/review/manual')
def bonus_ai_review_manual():
    row_id=str(request.form.get('row_id') or '').strip(); code=clean_code(request.form.get('code'))
    review=_load_ai_review(); rows=review.get('rows') or []
    row=next((r for r in rows if str(r.get('id'))==row_id),None)
    _,items,_,_=items_map(); valid={clean_code(i.get('code')) for i in items}
    if row and code in valid:
        source_id=_normalize_webhard_rel(row.get('file')); page=int(row.get('page',0))
        if source_id and _resolve_webhard_pdf(source_id):
            _set_shared_manual_bonus(code,source_id,page)
            row['selected_code']=code; row['status']='manual_fixed'; row['needs_manual']=False; row['manual_fixed_at']=datetime.now().isoformat(timespec='seconds')
            _save_ai_review(review)
    return redirect('/bonus-ai/review')


@app.post('/bonus-ai/review/ignore')
def bonus_ai_review_ignore():
    row_id=str(request.form.get('row_id') or '').strip(); review=_load_ai_review()
    row=next((r for r in (review.get('rows') or []) if str(r.get('id'))==row_id),None)
    if row:
        row['status']='ignored'; row['selected_code']=''; _save_ai_review(review)
    return redirect('/bonus-ai/review')


def _commit_ai_review_auto(activate=True, apply_notice=True):
    """Commit final high-confidence AI rows and then re-assert official notice truth."""
    review=_load_ai_review(); rows=[r for r in (review.get('rows') or []) if r.get('final')]
    manual_overrides=_load_manual_overrides(mode='ai'); data=dict(load_bonus_matches(mode='ai'))
    final_files={_normalize_webhard_rel(r.get('file')) for r in rows if _normalize_webhard_rel(r.get('file'))}
    final_files.update(_normalize_webhard_rel(x) for x in (review.get('scanned_files') or []) if _normalize_webhard_rel(x))
    data={c:rec for c,rec in data.items() if not (_bonus_source_id(rec) in final_files and str(rec.get('source_type') or 'auto') not in ('manual','notice_auto') and clean_code(c) not in manual_overrides)}
    candidates=[]
    try:
        by_code=_item_by_code(load_items(force=False)[0])
    except Exception:
        by_code={}
    for r in rows:
        if r.get('status') in ('ignored','manual_fixed') or r.get('needs_manual'): continue
        code=clean_code(r.get('selected_code') or r.get('proposed_code')); source_id=_normalize_webhard_rel(r.get('file'))
        if not code or code in manual_overrides or not source_id: continue
        item=by_code.get(code)
        ig=_ai_item_gender(item) if item else _normalize_gender_value(r.get('item_gender'))
        pg=_normalize_gender_value(r.get('page_gender'))
        sg=_normalize_gender_value(r.get('source_gender'))
        # Last safety net before persistence: automatic application can never cross
        # explicit male/female evidence, even if an earlier scorer regressed later.
        if ((pg in ('남성','여성') and ig in ('남성','여성') and pg!=ig) or
            (sg in ('남성','여성') and ig in ('남성','여성') and sg!=ig)):
            r['status']='gender_blocked'; r['needs_manual']=True
            r['gender_blocked_at']=datetime.now().isoformat(timespec='seconds')
            continue
        if get_bonus_fallback_choice(code):
            exact_future=bool(r.get('notice_exact')) or bool(r.get('filename_authoritative')) or ('NOTICE_IMAGE_EXACT' in str(r.get('text') or '') and code in str(r.get('text') or '')) or _code_present_in_text(r.get('text') or '',code)
            if not exact_future: continue
            _drop_fallback_without_refresh(code)
        candidates.append((int(r.get('score') or 0),code,source_id,int(r.get('page',0)),r))
    best={}
    for tup in sorted(candidates,key=lambda x:(-x[0],x[2],x[3])): best.setdefault(tup[1],tup)
    applied=0
    for score,code,source_id,page,row in best.values():
        data[code]={'file':source_id,'source':source_id,'page':page,'source_type':'auto'}
        row['status']='applied'; row['applied_at']=datetime.now().isoformat(timespec='seconds'); applied+=1
    save_bonus_matches(data,mode='ai')
    notice_applied=0
    if apply_notice:
        _set_scan_status(ai_stage='notice_link',message='AI 자동확정 저장 완료 · 공지 PDF 정답DB와 Webhard 번외를 최종 교차연동 중')
        notice_applied=_notice_apply_to_webhard()
    _sync_protected_matches_between_modes()
    if activate: set_bonus_match_mode('ai')
    load_items(force=True)
    review['confirmed_at']=datetime.now().strftime('%Y-%m-%d %H:%M:%S'); review['confirmed_count']=applied
    review['message']=f'AI 자동확정 {applied}개 자동 적용 · 공지 정답 직접연동 {notice_applied}개 · AI 번외 적용으로 자동 전환했습니다. 수동고정은 그대로 보호됩니다.'
    _save_ai_review(review)
    return applied,notice_applied


@app.post('/bonus-ai/review/confirm-auto')
def bonus_ai_review_confirm_auto():
    _commit_ai_review_auto(activate=True,apply_notice=True)
    return redirect('/bonus-ai/review')


@app.get('/bonus-ai')
def bonus_ai_page():
    ok,status=ai_engine_status(); cache=_load_ai_cache().get('pages',{})
    pdf_paths=sorted((p for p in WEBHARD_SYNC_DIR.rglob('*.pdf') if p.is_file()),key=lambda p:_sync_source_key(p))
    all_pdfs=[_sync_source_key(p) for p in pdf_paths]
    try: new_only_count=len(_ai_new_or_changed_pdfs(pdf_paths))
    except Exception: new_only_count=0
    review=_load_ai_review(); review_rows=review.get('rows') or []
    return render_template_string(AI_MATCH_HTML,ai_ok=ok,ai_status=status,scan=get_scan_status(),cache_count=len(cache),all_pdfs=all_pdfs,new_only_count=new_only_count,single_ready=AI_SINGLE_RESULT_FILE.exists(),review_ready=bool(review_rows),review_count=len(review_rows),review_status=review.get('status',''))

@app.post('/bonus-ai/start-new-only')
def bonus_ai_start_new_only():
    ok=start_ai_new_only_job()
    return jsonify({'ok':ok,'message':'새 번외만 AI 후보확정 시작됨' if ok else '이미 다른 AI 매칭 작업이 실행 중입니다.','status':get_scan_status()})

@app.post('/bonus-ai/start')
def bonus_ai_start():
    ok=start_ai_full_rematch_job()
    return jsonify({'ok':ok,'message':'AI 전체 매칭 시작됨' if ok else '이미 다른 AI 매칭 작업이 실행 중입니다.','status':get_scan_status()})

@app.get('/bonus-ai/start')
def bonus_ai_start_compat():
    start_ai_full_rematch_job()
    return redirect('/bonus-ai')

@app.post('/bonus-ai/test-one')
def bonus_ai_test_one():
    sid=_normalize_webhard_rel(request.form.get('filename',''))
    if sid and _resolve_webhard_pdf(sid):
        if not start_ai_single_job(sid):
            _set_scan_status(message='단일 PDF 테스트 시작 보류',error='이미 다른 AI 매칭 작업이 실행 중입니다.')
    else:
        _set_scan_status(message='단일 PDF 테스트 시작 실패',error='선택한 PDF를 찾을 수 없습니다.')
    return redirect('/bonus-ai')

@app.get('/bonus-ai/result')
def bonus_ai_result():
    try: rec=json.loads(AI_SINGLE_RESULT_FILE.read_text('utf-8'))
    except Exception: return redirect('/bonus-ai')
    sid=_normalize_webhard_rel(rec.get('filename','')); _,items,_,_=items_map()
    return render_template_string(BONUS_HTML,results=rec.get('results') or [],filename=sid,items=items,matches=load_bonus_matches(mode='ai'),ocr_status='AI: PP-OCRv5 Korean FAST + PaddleOCR-VL 1.6 fallback',ocr_threshold=round(AI_AUTO_THRESHOLD*100),ocr_margin=round(AI_MARGIN_THRESHOLD*100))

@app.get('/bonus-ai/analyze/<path:filename>')
def bonus_ai_analyze(filename):
    sid=_normalize_webhard_rel(filename); path=_resolve_webhard_pdf(sid)
    if not path: return redirect('/bonus-ai')
    _,items,_,_=items_map()
    # Single-file debug uses existing AI cache. If missing, ask the full test job to build it.
    with fitz.open(str(path)) as doc:
        missing=any(not _ai_page_text(path,p) for p in range(doc.page_count))
    if missing: return redirect('/bonus-ai')
    results=match_pdf_pages_ai(path,items)
    return render_template_string(BONUS_HTML,results=results,filename=sid,items=items,matches=load_bonus_matches(mode='ai'),ocr_status='AI: PP-OCRv5 Korean FAST + PaddleOCR-VL 1.6 fallback',ocr_threshold=round(AI_AUTO_THRESHOLD*100),ocr_margin=round(AI_MARGIN_THRESHOLD*100))
# ---------------- end AI engine ----------------

def calculate_discount_percent(normal, sale):
    """Return markdown percentage from normal price to sale price.

    Example: 39,900 -> 11,900 = 70.18%, therefore the V4.4 special-price rule applies.
    """
    try:
        normal = float(normal or 0)
        sale = float(sale or 0)
    except Exception:
        return 0.0
    if normal <= 0 or sale <= 0 or sale >= normal:
        return 0.0
    return max(0.0, min(100.0, (normal - sale) / normal * 100.0))


def load_items(force=False):
    global _ITEMS_CACHE, _CACHE_MTIME, _PRODUCT_INDEX
    ensure_price_master_file()
    # A stale V4.4.53~59 install may contain a legacy/empty workbook at the live
    # master path. Never let that turn the main page into HTTP 500. Prefer the
    # validated live master, then the current promotion workbook, then the
    # bundled 8/28 master seed as a read-only emergency fallback.
    live_master_ok = _price_master_header_ok(PRICE_MASTER_FILE)
    seed_master_ok = _price_master_header_ok(PRICE_MASTER_TEMPLATE)
    if live_master_ok:
        source_xlsx = PRICE_MASTER_FILE
        using_master = True
    elif CURRENT_XLSX.exists():
        source_xlsx = CURRENT_XLSX
        using_master = False
    elif seed_master_ok:
        source_xlsx = PRICE_MASTER_TEMPLATE
        using_master = True
        _write_price_master_status({
            'ok': False,
            'message': '기존 가격정책 마스터 형식이 맞지 않아 초기 마스터를 임시로 사용 중입니다. 복구패치를 적용해 주세요.',
            'updated_at': datetime.now().isoformat(timespec='seconds'),
            'source': PRICE_MASTER_TEMPLATE.name,
        })
    else:
        return [], '', '엑셀 미등록'
    bonus_mode=get_bonus_match_mode()
    active_bonus_file=_bonus_map_file(bonus_mode)
    bonus_mtime = active_bonus_file.stat().st_mtime_ns if active_bonus_file.exists() else -1
    mode_mtime = BONUS_MODE_FILE.stat().st_mtime_ns if BONUS_MODE_FILE.exists() else -1
    choice_mtime = VISUAL_CHOICE_FILE.stat().st_mtime_ns if VISUAL_CHOICE_FILE.exists() else -1
    current_mtime = CURRENT_XLSX.stat().st_mtime_ns if CURRENT_XLSX.exists() else -1
    template_sig = tuple(
        p.stat().st_mtime_ns if p.exists() else -1
        for p in (TEMPLATE_DIR / 'NEW_ARRIVAL.pdf', ADULT_SMALL_TEMPLATE, CLEARANCE_TEMPLATE, PRICE_REDUCTION_MAIN)
    )
    mtime = (source_xlsx.stat().st_mtime_ns, current_mtime, bonus_mode, bonus_mtime, mode_mtime, choice_mtime, template_sig)
    if not force and _ITEMS_CACHE is not None and _CACHE_MTIME == mtime:
        return _ITEMS_CACHE

    _PRODUCT_INDEX = None
    build_product_index()
    wb = load_workbook(source_xlsx, data_only=True, read_only=True)
    ws = wb[PRICE_MASTER_SHEET] if using_master and PRICE_MASTER_SHEET in wb.sheetnames else wb.active
    rows = list(ws.iter_rows(values_only=True))
    workbook_policy_map, workbook_policy_source = build_workbook_price_policy_map(wb)
    header_idx = None
    header_values = []
    for idx, row in enumerate(rows[:40]):
        vals = [str(v or '').strip() for v in row]
        if any(x in vals for x in ('스타일', '품번')) and '정상가' in vals:
            header_idx = idx
            header_values = vals
            break
    if header_idx is None:
        wb.close()
        raise ValueError('헤더 행을 찾지 못했습니다. 품번/스타일과 정상가 열이 필요합니다.')

    def col(*names):
        for name in names:
            if name in header_values:
                return header_values.index(name)
        return None

    cols = {
        'code': col('스타일', '품번'), 'title_ko': col('상품명'),
        'title_en': col('상품영문', '상품명(영문)', '영문명'), 'gender': col('성별'),
        'zone': col('조닝', '종류'), 'color': col('컬러'),
        'normal': col('정상가'), 'sale': col('조정가', '할인가'),
        'promotion': col('프로모션 내용'), 'season': col('시즌', '구분'),
        'event_start': col('행사시작일'), 'event_end': col('행사종료일'),
        'return_policy': col('기간종료후정책'), 'return_price': col('기간종료후가격'),
        'raw_policy': col('원본정책문구'),
    }

    policy_col, policy_col_name = find_price_policy_column(rows, header_idx, header_values, cols.get('code'))
    source_name = LAST_NAME.read_text('utf-8').strip() if LAST_NAME.exists() else source_xlsx.name
    workbook_date_range = '' if using_master else detect_workbook_date_range(wb, rows, source_name)
    today=datetime.now().date()

    items = []
    active_ranges=[]
    for row in rows[header_idx + 1:]:
        def get(key):
            c = cols.get(key)
            return row[c] if c is not None and c < len(row) else None
        code = clean_code(get('code'))
        if not code:
            continue
        normal = n(get('normal'))
        sale = n(get('sale'))
        promo = str(get('promotion') or '').strip()
        if not using_master:
            multi = []
            for c, label in ((11, '2장'), (12, '3장'), (13, '4장')):
                if c < len(row):
                    value = n(row[c])
                    if value > 0:
                        multi.append(f'{label} {value:,}원')
            if not promo and multi:
                promo = ' / '.join(multi)
        gender = infer_gender_from_code(code, get('gender'))
        policy_raw = row[policy_col] if policy_col is not None and policy_col < len(row) else ''
        declared_policy = normalize_price_policy(policy_raw)
        price_policy = declared_policy
        policy_source = f'{ws.title}:{policy_col_name}:{str(policy_raw or "").strip()}' if price_policy else ''
        if not price_policy:
            for value in row:
                candidate=normalize_price_policy(value)
                if candidate:
                    price_policy=candidate; declared_policy=candidate; policy_raw=value; policy_source=f'{ws.title}:행자동탐색:{value}'; break
        if not price_policy and code in workbook_policy_map:
            price_policy=workbook_policy_map[code]; declared_policy=price_policy
            policy_source=workbook_policy_source.get(code,'워크북자동탐색')
            if not policy_raw: policy_raw=price_policy
        if not price_policy and (policy_col is not None or workbook_policy_map):
            price_policy = '정상가' if (sale<=0 or normal<=0 or sale>=normal) else '가격인하'
            declared_policy=price_policy
            policy_source = '안전보정:가격비교'
            if not policy_raw: policy_raw=price_policy

        item_date_range=workbook_date_range
        if using_master:
            # H is the declared persistent state; I/J are the temporary overlay window.
            # When the window is not active, K/L restore the price/policy automatically.
            start_date=_master_date(get('event_start'))
            end_date=_master_date(get('event_end'))
            return_policy=normalize_price_policy(get('return_policy'))
            return_price=n(get('return_price'))
            item_date_range=_master_date_range_text(get('event_start'),get('event_end'))
            if declared_policy=='기간한정':
                in_window=(start_date is None or today>=start_date) and (end_date is None or today<=end_date)
                if in_window:
                    price_policy='기간한정'
                    if item_date_range: active_ranges.append(item_date_range)
                else:
                    price_policy=return_policy or ('정상가' if (normal>0 and sale>=normal) else '가격인하')
                    if price_policy=='정상가':
                        sale=normal
                    elif return_price>0:
                        sale=return_price
                    phase='예정' if start_date and today<start_date else '종료'
                    policy_raw=f'기간한정 {phase} → {price_policy}'
                    policy_source=f'가격정책마스터:기간자동복귀:{price_policy}'
                    item_date_range=''
            elif price_policy=='정상가':
                # normal rows never keep old red discount styling
                sale=normal if normal>0 else sale
            if get('raw_policy') and not (declared_policy=='기간한정' and price_policy!='기간한정'):
                policy_raw=get('raw_policy')
            policy_source=policy_source or '가격정책마스터'

        base_is_disc = sale > 0 and (normal == 0 or sale < normal)
        discount_percent = calculate_discount_percent(normal, sale)
        is_disc = base_is_disc if not price_policy else (price_policy in ('기간한정','가격인하') and sale > 0 and (normal<=0 or sale<normal))
        title_ko_display=clean_display_product_title(get('title_ko'))
        route = resolve_item_visual(code, gender, is_disc, discount_percent, promo, price_policy, str(get('zone') or '').strip(), title_ko_display)
        item = {
            'code': code, 'title_ko': title_ko_display,
            'title_en': str(get('title_en') or '').strip(),
            'gender': gender, 'zone': str(get('zone') or '').strip(),
            'color': str(get('color') or '').strip(), 'normal': normal, 'sale': sale,
            'normal_fmt': f'{normal:,}원' if normal else '-',
            'sale_fmt': (f'{sale:,}원' if is_disc and sale else '-'), 'promotion': promo,
            'price_policy': price_policy,
            'declared_price_policy': declared_policy,
            'price_policy_raw': str(policy_raw or '').strip(),
            'price_policy_column': ('가격정책 마스터' if using_master else (policy_col_name or ('워크북 자동탐색' if workbook_policy_map else ''))),
            'price_policy_source': policy_source,
            'season': str(get('season') or '').strip(),
            'date_range': item_date_range, 'is_discount': is_disc,
            'discount_percent': round(discount_percent, 1),
            'discount_percent_fmt': (f'{discount_percent:.1f}%'.replace('.0%', '%') if is_disc else '-'),
        }
        item.update(route)
        items.append(item)
    wb.close()
    if using_master:
        uniq=[]
        for r in active_ranges:
            if r and r not in uniq: uniq.append(r)
        date_range = uniq[0] if len(uniq)==1 else (f'복수 기간 {len(uniq)}개' if uniq else '')
        loaded = (LAST_NAME.read_text('utf-8').strip() if LAST_NAME.exists() else '최초 마스터') + ' · 마스터 자동동기화'
    else:
        date_range=workbook_date_range
        loaded = LAST_NAME.read_text('utf-8').strip() if LAST_NAME.exists() else source_xlsx.name
    _ITEMS_CACHE = (items, date_range, loaded)
    _CACHE_MTIME = mtime
    return _ITEMS_CACHE

def _row_metrics(im):
    """Return lightweight row statistics used for source-bar detection."""
    probe_w = 360
    scale = probe_w / max(1, im.width)
    probe_h = max(1, round(im.height * scale))
    probe = im.convert('RGB').resize((probe_w, probe_h), Image.Resampling.BILINEAR)
    rows = []
    for y in range(probe_h):
        colors = list(probe.crop((0, y, probe_w, y + 1)).getdata())
        n = max(1, len(colors))
        mr = sum(c[0] for c in colors) / n
        mg = sum(c[1] for c in colors) / n
        mb = sum(c[2] for c in colors) / n
        # Mean distance from the row mean: low values indicate a flat label band.
        dev = sum((abs(c[0]-mr)+abs(c[1]-mg)+abs(c[2]-mb))/3 for c in colors) / n
        rows.append((mr, mg, mb, dev))
    return rows, probe_h, probe


def _detect_bonus_visual_bottom(im):
    """Detect the beginning of a source PDF's own lower information strip.

    The lower strip may be white, gray, or tinted. We look only in the final
    quarter of the page, score full-width horizontal transitions, and prefer a
    boundary followed by a comparatively flat region. This avoids mistaking
    internal product photos or text panels for the source information bar.
    """
    rows, ph, probe = _row_metrics(im)
    if ph < 40:
        return im.height

    start = int(ph * 0.73)
    end = int(ph * 0.88)
    candidates = []
    for y in range(start, end):
        r0 = rows[max(0, y-2)]
        r1 = rows[y]
        transition = (abs(r1[0]-r0[0]) + abs(r1[1]-r0[1]) + abs(r1[2]-r0[2])) / 3
        row_a = list(probe.crop((0, max(0, y-2), probe.width, max(0, y-2)+1)).getdata())
        row_b = list(probe.crop((0, y, probe.width, y+1)).getdata())
        change_coverage = sum(
            1 for a, b in zip(row_a, row_b)
            if (abs(a[0]-b[0])+abs(a[1]-b[1])+abs(a[2]-b[2]))/3 >= 18
        ) / max(1, probe.width)

        below = rows[y:max(y+1, int(ph * 0.94))]
        flat_ratio = sum(1 for r in below if r[3] <= 24) / max(1, len(below))
        avg_dev = sum(r[3] for r in below) / max(1, len(below))

        if transition < 8 or change_coverage < 0.22 or flat_ratio < 0.55:
            continue
        score = (
            transition * 1.2
            + change_coverage * 55
            + flat_ratio * 35
            - (y / ph) * 30
            - avg_dev * 0.15
        )
        candidates.append((score, y))

    if not candidates:
        return im.height

    _, y_probe = max(candidates, key=lambda v: v[0])
    y_full = round(y_probe * im.height / ph)
    # Remove a small safety band above the detected source-bar boundary;
    # headquarters files often place the outlined gender box immediately above
    # the rest of their information strip.
    margin = max(2, round(im.height * 0.04))
    return max(1, min(im.height, y_full - margin))


def _edge_background_color(im):
    """Estimate a neutral fill colour from the artwork edges."""
    rgb = im.convert('RGB')
    w, h = rgb.size
    sw = max(1, w // 80)
    sh = max(1, h // 80)
    samples = []
    for box in ((0, 0, w, sh), (0, h-sh, w, h), (0, 0, sw, h), (w-sw, 0, w, h)):
        samples.extend(list(rgb.crop(box).resize((40, 4), Image.Resampling.BILINEAR).getdata()))
    if not samples:
        return (255, 255, 255)
    samples.sort(key=lambda c: c[0] + c[1] + c[2])
    mid = samples[len(samples)//2]
    return tuple(int(v) for v in mid)


def _fit_bonus_artwork(art, target_w, target_h):
    """Fit complete artwork into a fixed frame without cutting text or models."""
    art = art.convert('RGB')
    if art.width <= 0 or art.height <= 0:
        return Image.new('RGB', (target_w, target_h), 'white')
    bg = _edge_background_color(art)
    frame = Image.new('RGB', (target_w, target_h), bg)

    # Small safety inset prevents artwork typography from visually colliding
    # with the standard bottom bar while preserving the complete composition.
    inset_x = max(0, round(target_w * 0.006))
    inset_y = max(0, round(target_h * 0.006))
    avail_w = max(1, target_w - inset_x * 2)
    avail_h = max(1, target_h - inset_y * 2)
    scale = min(avail_w / art.width, avail_h / art.height)
    nw = max(1, round(art.width * scale))
    nh = max(1, round(art.height * scale))
    fitted = art.resize((nw, nh), Image.Resampling.LANCZOS)
    x = (target_w - nw) // 2
    y = (target_h - nh) // 2
    frame.paste(fitted, (x, y))
    return frame


def load_generation_queue():
    if not QUEUE_FILE.exists():
        return []
    try:
        raw = json.loads(QUEUE_FILE.read_text('utf-8'))
        return [clean_code(x) for x in raw if clean_code(x)]
    except Exception:
        return []


def save_generation_queue(codes):
    unique=[]; seen=set()
    for code in codes:
        code=clean_code(code)
        if code and code not in seen:
            unique.append(code); seen.add(code)
    QUEUE_FILE.write_text(json.dumps(unique, ensure_ascii=False, indent=2), encoding='utf-8')
    return unique


def visual_signature(pathstr):
    raw=str(pathstr or '')
    page=0
    if '::page=' in raw:
        raw,p=raw.rsplit('::page=',1)
        try: page=int(p)
        except Exception: page=0
    p=Path(raw) if raw else TEMPLATE_DIR/'NEW_ARRIVAL.pdf'
    try:
        st=p.stat(); base=f'{p.resolve()}|{page}|{st.st_size}|{st.st_mtime_ns}'
    except OSError:
        base=f'{p}|{page}|missing'
    return hashlib.sha1(base.encode('utf-8',errors='ignore')).hexdigest()[:16]


def item_preview_version(item):
    payload=RENDER_REVISION+'|'+('|'.join(str(item.get(k,'')) for k in ('code','gender','title_ko','title_en','normal','sale','discount_percent','date_range','price_policy','price_policy_raw','price_policy_source','visual','visual_mode','bonus_choice','requires_bonus_choice')))
    payload += '|'+visual_signature(item.get('visual'))+'|'+POP_LAYOUT_REV
    return hashlib.sha1(payload.encode('utf-8',errors='ignore')).hexdigest()[:16]


def _render_cache_key(pathstr):
    return f'{str(pathstr)}|{visual_signature(pathstr)}'

def render_visual_a4(pathstr):
    cache_key = _render_cache_key(pathstr)
    cached = _RENDER_CACHE.get(cache_key)
    if cached is not None:
        _RENDER_CACHE.move_to_end(cache_key)
        return cached.copy()
    """Render the complete source page at true A4 size.

    NEW ARRIVAL and every bonus PDF follow one identical rule: preserve the
    source page without automatic trimming, then generate_one() covers the
    final 210 x 50 mm of the finished 210 x 240 mm POP with the standard bar.
    This fixed physical overlay hides headquarters' original lower gender and
    product-information area without unreliable image-content detection.
    """
    page_index = 0
    raw_path = str(pathstr or '')
    if '::page=' in raw_path:
        raw_path, page_text = raw_path.rsplit('::page=', 1)
        try:
            page_index = max(0, int(page_text))
        except Exception:
            page_index = 0
    p = Path(raw_path) if raw_path else TEMPLATE_DIR / 'NEW_ARRIVAL.pdf'
    if not p.exists():
        p = TEMPLATE_DIR / 'NEW_ARRIVAL.pdf'
    canvas = Image.new('RGB', (A4_W_PX, A4_H_PX), 'white')
    try:
        if p.suffix.lower() == '.pdf':
            doc = fitz.open(str(p))
            page = doc.load_page(min(page_index, max(0, doc.page_count - 1)))
            scale = DPI / 72.0
            pix = page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False)
            im = Image.frombytes('RGB', [pix.width, pix.height], pix.samples)
            doc.close()
        else:
            im = Image.open(p).convert('RGB')

        # Full-page actual-size normalization only; no bonus-specific cropping.
        if im.size != canvas.size:
            im = im.resize(canvas.size, Image.Resampling.LANCZOS)
        canvas.paste(im, (0, 0))
        _RENDER_CACHE[cache_key] = canvas.copy()
        _RENDER_CACHE.move_to_end(cache_key)
        while len(_RENDER_CACHE) > _RENDER_CACHE_MAX:
            _RENDER_CACHE.popitem(last=False)
        return canvas
    except Exception as exc:
        print(f'Visual load error: {exc}', flush=True)
        return canvas

def draw_right(draw, xy_right, text, font_obj, fill):
    box = draw.textbbox((0,0), text, font=font_obj)
    draw.text((xy_right[0]-(box[2]-box[0]), xy_right[1]), text, font=font_obj, fill=fill)

def clip_text_to_width(draw, text, font_obj, max_width):
    """Keep the fixed font size and shorten only the text when it exceeds the PPT box."""
    text = str(text or '').strip()
    if not text:
        return ''
    if draw.textbbox((0,0), text, font=font_obj)[2] <= max_width:
        return text
    ellipsis = '…'
    lo, hi = 0, len(text)
    while lo < hi:
        mid = (lo + hi + 1) // 2
        candidate = text[:mid].rstrip() + ellipsis
        if draw.textbbox((0,0), candidate, font=font_obj)[2] <= max_width:
            lo = mid
        else:
            hi = mid - 1
    return text[:lo].rstrip() + ellipsis

def _tag(draw, x, y, text, fnt, bg, fg='white', pad_x_mm=1.0, pad_y_mm=0.25):
    box = draw.textbbox((0,0), text, font=fnt)
    w, h = box[2]-box[0], box[3]-box[1]
    px = round(pad_x_mm * MM_TO_PX)
    py = round(pad_y_mm * MM_TO_PX)
    draw.rectangle((x, y, x+w+px*2, y+h+py*2), fill=bg)
    draw.text((x+px, y+py-box[1]), text, font=fnt, fill=fg)
    return x+w+px*2

def _fit_text_fixed_box(draw, text, font_obj, left, top, right, fill, align='left'):
    """Draw inside a fixed PPT text box. Both box edges stay immovable."""
    text = str(text or '').strip()
    if not text:
        return
    max_width = max(1, right - left)
    text = clip_text_to_width(draw, text, font_obj, max_width)
    box = draw.textbbox((0, 0), text, font=font_obj)
    width = box[2] - box[0]
    x = right - width if align == 'right' else left
    draw.text((x, top), text, font=font_obj, fill=fill)


def _fit_text_shrink_box(draw, text, font_path, start_pt, min_pt, left, top, right, fill, align='left'):
    """Keep both box edges fixed and reduce font size until the complete text fits."""
    text = str(text or '').strip()
    if not text:
        return
    max_width = max(1, right-left)
    chosen = None
    chosen_size = start_pt
    for pt in range(int(start_pt), int(min_pt)-1, -1):
        fnt = font(font_path, pt_px(pt))
        box = draw.textbbox((0,0), text, font=fnt)
        if box[2]-box[0] <= max_width:
            chosen = fnt
            chosen_size = pt
            break
    if chosen is None:
        chosen_size = min_pt
        chosen = font(font_path, pt_px(min_pt))
        # Last resort only for extraordinarily long names: preserve all characters by horizontal compression.
        box = draw.textbbox((0,0), text, font=chosen)
        tw, th = max(1, box[2]-box[0]), max(1, box[3]-box[1])
        layer = Image.new('RGBA', (tw+8, th+8), (255,255,255,0))
        ld = ImageDraw.Draw(layer)
        ld.text((4-box[0],4-box[1]), text, font=chosen, fill=fill)
        target_w = max_width
        layer = layer.resize((target_w, layer.height), Image.Resampling.LANCZOS)
        x = right-target_w if align=='right' else left
        draw._image.alpha_composite(layer, (x, top)) if draw._image.mode=='RGBA' else draw._image.paste(layer.convert('RGB'), (x,top), layer)
        return
    box = draw.textbbox((0,0), text, font=chosen)
    width = box[2]-box[0]
    x = right-width if align=='right' else left
    draw.text((x,top), text, font=chosen, fill=fill)


def _fixed_tag(draw, box_mm, text, font_obj, bg, fg='white', dpi=DPI):
    """Draw a tag in a fixed physical rectangle at either print or preview DPI."""
    scale = float(dpi) / 25.4
    l, t, r, b = [round(v * scale) for v in box_mm]
    draw.rectangle((l, t, r, b), fill=bg)
    text = clip_text_to_width(draw, text, font_obj, max(1, r-l-round(1.4*scale)))
    tb = draw.textbbox((0,0), text, font=font_obj)
    th = tb[3]-tb[1]
    tw = tb[2]-tb[0]
    x = l + max(0, ((r-l)-tw)//2) - tb[0]
    y = t + max(0, ((b-t)-th)//2) - tb[1]
    draw.text((x, y), text, font=font_obj, fill=fg)


def _pt_px_for_dpi(pt, dpi):
    return max(1, round(float(pt) * float(dpi) / 72.0))


def _font_for_dpi(path, pt, dpi, bold=False):
    return font(path, _pt_px_for_dpi(pt, dpi), fallback_bold=bold)


def _box_px(box_mm, dpi):
    scale = dpi / 25.4
    return tuple(round(v * scale) for v in box_mm)


def _fit_one_line(draw, text, font_path, start_pt, min_pt, box_mm, fill, dpi, align='left', bold=False):
    text = str(text or '').strip()
    if not text:
        return
    left, top, right, bottom = _box_px(box_mm, dpi)
    max_w = max(1, right-left)
    chosen = _font_for_dpi(font_path, min_pt, dpi, bold)
    for pt in range(int(start_pt), int(min_pt)-1, -1):
        candidate = _font_for_dpi(font_path, pt, dpi, bold)
        bbox = draw.textbbox((0,0), text, font=candidate)
        if bbox[2]-bbox[0] <= max_w:
            chosen = candidate
            break
    bbox = draw.textbbox((0,0), text, font=chosen)
    tw, th = bbox[2]-bbox[0], bbox[3]-bbox[1]
    x = right-tw-bbox[0] if align == 'right' else left-bbox[0]
    y = top-bbox[1] + max(0, ((bottom-top)-th)//2)
    draw.text((x,y), text, font=chosen, fill=fill)


def _title_char_count(text):
    """Count visible product-name characters; spaces are ignored for the 11-character store rule."""
    return len(re.sub(r'\s+', '', str(text or '').strip()))


def _smart_title_lines(text, max_chars=11):
    """Return one or exactly two clean lines using the store's 11-character rule.

    Important example:
      [분노의 질주] 가먼트다잉 그래픽 T (반팔)
    becomes
      [분노의 질주]
      가먼트다잉 그래픽 T (반팔)

    Bracketed collaboration/collection names are treated as a semantic prefix, so we do
    not create the awkward '[분노의 질주] 가먼트다잉 / 그래픽 T (반팔)' split.
    """
    text = re.sub(r'\s+', ' ', str(text or '').strip())
    if not text or _title_char_count(text) <= max_chars:
        return [text]

    # Prefer a leading [collection / collaboration] block as line 1.
    m = re.match(r'^(\[[^\]]+\])\s+(.+)$', text)
    if m and m.group(2).strip():
        return [m.group(1).strip(), m.group(2).strip()]

    words = text.split(' ')
    if len(words) >= 2:
        best_cut = None
        best_score = None
        for cut in range(1, len(words)):
            left = ' '.join(words[:cut]).strip()
            right = ' '.join(words[cut:]).strip()
            if not right:
                continue
            left_n = _title_char_count(left)
            right_n = _title_char_count(right)
            # HQ two-line sample uses visually balanced rows. First avoid any line
            # exceeding the 11-visible-character guide, then choose the most balanced split.
            overflow = max(0, left_n - max_chars) + max(0, right_n - max_chars)
            score = (overflow * 1000, abs(left_n - right_n), max(left_n, right_n))
            if best_score is None or score < best_score:
                best_score = score
                best_cut = cut
        if best_cut:
            return [' '.join(words[:best_cut]).strip(), ' '.join(words[best_cut:]).strip()]

    # No word boundary exists. Split at the 11th visible character without dropping spaces.
    visible = 0
    cut = 0
    for i, ch in enumerate(text):
        if not ch.isspace():
            visible += 1
        if visible >= max_chars:
            cut = i + 1
            break
    if cut <= 0 or cut >= len(text):
        cut = max(1, len(text)//2)
    return [text[:cut].rstrip(), text[cut:].lstrip()]


def _fit_smart_title(draw, text, font_path, start_pt, min_pt, box_mm, fill, dpi, bold=False):
    """Draw a product name in one line, or exactly two lines when it exceeds 11 chars.

    One-line names are intentionally placed a little lower so the baseline sits
    visually between the gender tag and the English subtitle, matching the store POP.
    Two-line names stay top-anchored to preserve the original locked field alignment.
    """
    text = str(text or '').strip()
    if not text:
        return 1
    lines = _smart_title_lines(text, 11)
    left, top, right, bottom = _box_px(box_mm, dpi)
    max_w, max_h = max(1, right-left), max(1, bottom-top)
    chosen = _font_for_dpi(font_path, min_pt, dpi, bold)
    for pt in range(int(start_pt), int(min_pt)-1, -1):
        candidate = _font_for_dpi(font_path, pt, dpi, bold)
        boxes = [draw.textbbox((0,0), line, font=candidate) for line in lines]
        widths = [b[2]-b[0] for b in boxes]
        heights = [b[3]-b[1] for b in boxes]
        line_gap = max(1, round(pt * dpi / 72 * 0.10)) if len(lines) == 2 else 0
        if max(widths or [0]) <= max_w and sum(heights) + line_gap <= max_h:
            chosen = candidate
            break
    boxes = [draw.textbbox((0,0), line, font=chosen) for line in lines]
    heights = [b[3]-b[1] for b in boxes]
    if len(lines) == 2:
        gap = max(1, round((bottom-top-sum(heights)) * 0.18))
        y = top
    else:
        gap = 0
        spare = max(0, (bottom-top-sum(heights)))
        y = top + round(spare * 0.46)
    for line, b in zip(lines, boxes):
        draw.text((left-b[0], y-b[1]), line, font=chosen, fill=fill)
        y += (b[3]-b[1]) + gap
    return len(lines)


def _split_two_lines(text, draw, fnt, max_w):
    text = str(text or '').strip()
    if not text:
        return ['']
    if draw.textbbox((0,0), text, font=fnt)[2] <= max_w:
        return [text]
    words = text.split()
    candidates = []
    if len(words) > 1:
        for cut in range(1, len(words)):
            a=' '.join(words[:cut]); b=' '.join(words[cut:])
            width=max(draw.textbbox((0,0),a,font=fnt)[2],draw.textbbox((0,0),b,font=fnt)[2])
            candidates.append((width,abs(len(a)-len(b)),a,b))
    else:
        for cut in range(1, len(text)):
            a=text[:cut]; b=text[cut:]
            width=max(draw.textbbox((0,0),a,font=fnt)[2],draw.textbbox((0,0),b,font=fnt)[2])
            candidates.append((width,abs(len(a)-len(b)),a,b))
    if not candidates:
        return [text]
    _,__,a,b=min(candidates)
    return [a,b]


def _fit_two_lines(draw, text, font_path, start_pt, min_pt, box_mm, fill, dpi, bold=False):
    text = str(text or '').strip()
    if not text:
        return
    left, top, right, bottom = _box_px(box_mm, dpi)
    max_w, max_h = max(1,right-left), max(1,bottom-top)
    lines=[text]; chosen=_font_for_dpi(font_path,min_pt,dpi,bold)
    for pt in range(int(start_pt), int(min_pt)-1, -1):
        candidate=_font_for_dpi(font_path,pt,dpi,bold)
        proposed=_split_two_lines(text,draw,candidate,max_w)
        line_heights=[]; widths=[]
        for line in proposed:
            bb=draw.textbbox((0,0),line,font=candidate)
            widths.append(bb[2]-bb[0]); line_heights.append(bb[3]-bb[1])
        gap=round(pt*dpi/72*0.06) if len(proposed)>1 else 0
        if max(widths or [0])<=max_w and sum(line_heights)+gap<=max_h:
            chosen=candidate; lines=proposed; break
    metrics=[draw.textbbox((0,0),line,font=chosen) for line in lines]
    heights=[b[3]-b[1] for b in metrics]
    gap=max(0,round((bottom-top-sum(heights))/max(1,len(lines)+1)))
    y=top+gap
    for line,b in zip(lines,metrics):
        draw.text((left-b[0],y-b[1]),line,font=chosen,fill=fill)
        y += (b[3]-b[1])+gap


def _english_visible_count(text):
    return len(re.sub(r'\s+', '', str(text or '').strip()))


def _english_two_line_parts(text, draw, font_obj, max_width):
    """Always return exactly two non-empty lines, preferring word boundaries.

    The best split is the one that first avoids width overflow and then balances
    the two rows. Character splits are included as a fallback for long tokens.
    """
    text = re.sub(r'\s+', ' ', str(text or '').strip())
    if not text:
        return ['', '']
    candidates = []
    words = text.split(' ')
    if len(words) > 1:
        for cut in range(1, len(words)):
            a = ' '.join(words[:cut]).strip()
            b = ' '.join(words[cut:]).strip()
            if a and b:
                wa = draw.textbbox((0,0), a, font=font_obj)[2]
                wb = draw.textbbox((0,0), b, font=font_obj)[2]
                overflow = max(0, wa-max_width) + max(0, wb-max_width)
                candidates.append((overflow, max(wa,wb), abs(wa-wb), a, b))
    # Character-boundary fallback. Prefer spaces, hyphens and closing brackets.
    for cut in range(1, len(text)):
        a = text[:cut].rstrip(); b = text[cut:].lstrip()
        if not a or not b:
            continue
        wa = draw.textbbox((0,0), a, font=font_obj)[2]
        wb = draw.textbbox((0,0), b, font=font_obj)[2]
        overflow = max(0, wa-max_width) + max(0, wb-max_width)
        boundary_penalty = 0 if text[cut-1:cut] in (' ', '-', ')', ']') or text[cut:cut+1] in (' ', '-', '(', '[') else 1
        candidates.append((overflow, max(wa,wb), abs(wa-wb)+boundary_penalty*1000, a, b))
    if not candidates:
        mid=max(1,len(text)//2)
        return [text[:mid].rstrip(), text[mid:].lstrip()]
    _,__,___,a,b=min(candidates)
    return [a,b]


def _draw_line_keep_13pt_inside(draw, text, font_obj, left, top, right, fill):
    """Draw one 13pt line inside a hard right edge.

    Normal case uses the unmodified font. Only if one indivisible token still
    exceeds the hard boundary do we horizontally condense that rendered row,
    preserving its 13pt vertical height rather than letting it enter the triangle.
    """
    text=str(text or '').strip()
    if not text:
        return
    bbox=draw.textbbox((0,0),text,font=font_obj)
    tw=max(1,bbox[2]-bbox[0]); th=max(1,bbox[3]-bbox[1])
    max_w=max(1,right-left)
    if tw <= max_w:
        draw.text((left-bbox[0], top-bbox[1]), text, font=font_obj, fill=fill)
        return
    layer=Image.new('RGBA',(tw+8,th+8),(255,255,255,0))
    ld=ImageDraw.Draw(layer)
    ld.text((4-bbox[0],4-bbox[1]),text,font=font_obj,fill=fill)
    target_w=max_w
    layer=layer.resize((target_w,layer.height),Image.Resampling.LANCZOS)
    if getattr(draw,'_image',None) is not None:
        draw._image.paste(layer.convert('RGB'),(left,top),layer)


def _draw_english_title(draw, text, title_line_count, left_mm, right_mm, one_line_top_mm, two_line_top_mm, two_line_bottom_mm, fill, dpi):
    """Render English product title without ever crossing its hard right boundary.

    - >30 visible chars: ALWAYS two lines.
    - <=30 chars: one line only when the real 13pt width fits; otherwise two lines.
    - Two-line split is width-aware, not just character-count based.
    """
    text=re.sub(r'\s+',' ',str(text or '').strip()).upper()
    if not text:
        return
    one_top_mm=one_line_top_mm(title_line_count) if callable(one_line_top_mm) else float(one_line_top_mm)
    two_top_mm_v=two_line_top_mm(title_line_count) if callable(two_line_top_mm) else float(two_line_top_mm)
    two_bottom_mm_v=two_line_bottom_mm(title_line_count) if callable(two_line_bottom_mm) else float(two_line_bottom_mm)
    left_px,_,right_px,_=_box_px((left_mm,two_top_mm_v,right_mm,two_bottom_mm_v),dpi)
    max_w=max(1,right_px-left_px)
    fnt=_font_for_dpi(FONT_DIN_REGULAR_EFFECTIVE,13,dpi,False)
    one_w=draw.textbbox((0,0),text,font=fnt)[2]
    must_wrap=(_english_visible_count(text)>30 or one_w>max_w)
    if not must_wrap:
        top_px=_box_px((left_mm,one_top_mm,right_mm,two_bottom_mm_v),dpi)[1]
        _draw_line_keep_13pt_inside(draw,text,fnt,left_px,top_px,right_px,fill)
        return
    lines=_english_two_line_parts(text,draw,fnt,max_w)
    top_px=_box_px((left_mm,two_top_mm_v,right_mm,two_bottom_mm_v),dpi)[1]
    bottom_px=_box_px((left_mm,two_top_mm_v,right_mm,two_bottom_mm_v),dpi)[3]
    sample=draw.textbbox((0,0),'AG',font=fnt)
    line_h=max(1,sample[3]-sample[1])
    available=max(1,bottom_px-top_px)
    gap=max(1,min(round(0.7*dpi/25.4),available-2*line_h))
    if 2*line_h+gap>available:
        gap=max(0,available-2*line_h)
    y1=top_px
    y2=top_px+line_h+gap
    _draw_line_keep_13pt_inside(draw,lines[0],fnt,left_px,y1,right_px,fill)
    _draw_line_keep_13pt_inside(draw,lines[1],fnt,left_px,y2,right_px,fill)


def _draw_adult_english_strict(draw, text, left_mm, top_mm, right_mm, bottom_mm, fill, dpi, start_pt=25, min_pt=18):
    """Adult-small English title renderer with a hard 30-character two-line rule.

    If visible characters exceed 30, this function ALWAYS draws exactly two lines.
    It may reduce font size to fit the fixed box, but it is never allowed to collapse
    the text back into one line. Shorter text also wraps when its real width exceeds
    the safe right edge.
    """
    text = re.sub(r'\s+', ' ', str(text or '').strip()).upper()
    if not text:
        return 0
    l,t,r,b = _box_px((left_mm, top_mm, right_mm, bottom_mm), dpi)
    max_w = max(1, r-l)
    max_h = max(1, b-t)
    probe = _font_for_dpi(FONT_DIN_REGULAR_EFFECTIVE, start_pt, dpi, False)
    one_w = draw.textbbox((0,0), text, font=probe)[2]
    force_two = (_english_visible_count(text) > 30) or (one_w > max_w)
    if not force_two:
        _fit_one_line(draw, text, FONT_DIN_REGULAR_EFFECTIVE, start_pt, min_pt,
                      (left_mm, top_mm, right_mm, bottom_mm), fill, dpi, 'left')
        return 1

    chosen = _font_for_dpi(FONT_DIN_REGULAR_EFFECTIVE, min_pt, dpi, False)
    chosen_lines = _english_two_line_parts(text, draw, chosen, max_w)
    for pt in range(int(start_pt), int(min_pt)-1, -1):
        fnt = _font_for_dpi(FONT_DIN_REGULAR_EFFECTIVE, pt, dpi, False)
        lines = _english_two_line_parts(text, draw, fnt, max_w)
        boxes = [draw.textbbox((0,0), ln, font=fnt) for ln in lines]
        widths = [bb[2]-bb[0] for bb in boxes]
        heights = [bb[3]-bb[1] for bb in boxes]
        gap = max(1, round(0.8*dpi/25.4))
        if max(widths or [0]) <= max_w and sum(heights)+gap <= max_h:
            chosen = fnt
            chosen_lines = lines
            break

    boxes = [draw.textbbox((0,0), ln, font=chosen) for ln in chosen_lines]
    heights = [bb[3]-bb[1] for bb in boxes]
    gap = max(1, round(0.8*dpi/25.4))
    total_h = sum(heights)+gap
    y = t + max(0, (max_h-total_h)//2)
    for ln, bb in zip(chosen_lines, boxes):
        draw.text((l-bb[0], y-bb[1]), ln, font=chosen, fill=fill)
        y += (bb[3]-bb[1]) + gap
    return 2


def _restore_adult_small_triangle(a4, original_a4, dpi):
    """Restore the fixed lower-right gender triangle after all live-text edits.

    The mask intentionally includes a small white safety margin left/up of the
    triangle. This guarantees that clearing/redrawing product text can never cut
    into the original diagonal shape or print on top of it.
    """
    mask=Image.new('L',a4.size,0)
    md=ImageDraw.Draw(mask)
    # A4 coordinates. POP cut area is y=32..262 mm; the triangle rises from the
    # lower-right corner. These points include a conservative no-text margin.
    pts=[
        (_box_px((102.0,262.0,102.0,262.0),dpi)[0], _box_px((102.0,262.0,102.0,262.0),dpi)[1]),
        (_box_px((210.0,262.0,210.0,262.0),dpi)[0], _box_px((210.0,262.0,210.0,262.0),dpi)[1]),
        (_box_px((210.0,158.0,210.0,158.0),dpi)[0], _box_px((210.0,158.0,210.0,158.0),dpi)[1]),
    ]
    md.polygon(pts,fill=255)
    a4.paste(original_a4,(0,0),mask)

def _draw_old_price_arrow(draw, text, font_obj, box_mm, dpi, color=(230,0,18), line_y_ratio=0.56, arrow_extra_mm=0.8):
    """Draw a compact HQ old-price strike arrow around the actual price text.

    The previous fixed placeholder-wide shaft looked unnecessarily long on 4- and
    5-digit prices. V4.4.51 measures the right-aligned normal-price text and draws
    only a small lead-in before it plus a short tail after it, while keeping the
    official single diagonal mark at the LEFT side.
    """
    text=str(text or '').strip()
    if not text:
        return
    l,t,r,b=_box_px(box_mm,dpi)
    y=round(t+(b-t)*line_y_ratio)
    width=max(2,round(0.28*dpi/25.4))
    head=max(3,round(2.2*dpi/25.4))
    bbox=draw.textbbox((0,0),text,font=font_obj)
    tw=max(1,bbox[2]-bbox[0])
    # Text is right-aligned in the old-price field. Keep only a compact margin.
    text_left=r-tw
    lead=round(2.6*dpi/25.4)
    tail=round(float(arrow_extra_mm)*dpi/25.4)
    line_left=max(l,text_left-lead)
    line_right=min(r+tail, r+round(1.0*dpi/25.4))
    draw.line((line_left,y,line_right,y),fill=color,width=width)
    draw.line((line_left,y,line_left+head,y+head),fill=color,width=width)


def _draw_adult_small_fields(a4, item, dpi):
    """Fill ONLY the five live placeholders from the supplied TT_소형 POP-1.pptx.

    The 3-page template artwork is not reconstructed by code. `TT_ADULT_SMALL.pdf`
    is a direct blank-field render of the user's PPTX, preserving the slide border,
    red old-price arrow, gender + 기간한정 tags and the gender-colored lower-right
    triangle exactly as supplied.

    PPT placeholder geometry / typography (source slide layout):
      - sale price: x 23.765, y 51.063, w 185.264, h 67.204 mm / DINPro-Bold 152pt / red
      - old normal price: x 29.118, y 114.874, w 111.852, h 18.002 mm / DINPro-Medium 44pt
      - period: x 82.560, y 182.409, w 70.008, h 13.999 mm / DINPro-Medium 17pt / red (store-unified)
      - Korean product name: x 26.733, y 196.099, w 112.450, h 17.718 mm / NanumBarunGothic 36pt
      - English product name: x 27.963, y 212.495, w 111.852, h 9.681 mm / DINPro-Regular 25pt

    Gender page selection is performed before this function using the first digit of
    the final four style-code digits: 1=남성(page2), 2=여성(page3), 3=공용(page1).
    """
    d=ImageDraw.Draw(a4)
    black=(0,0,0); red=(230,0,18)

    normal=int(item.get('normal') or 0)
    sale=int(item.get('sale') or 0)
    is_discount=(sale>0 and normal>0 and sale<normal)

    # Exact PPT main-price placeholder. Period-limited adult-small POP is a discount POP.
    current = sale if is_discount else (normal if normal>0 else sale)
    if current:
        _fit_one_line(d,f'{current:,}',FONT_DIN_BOLD,152,72,
                      (23.765,51.063,209.029,118.267),red if is_discount else black,dpi,'left',True)

    # R7 adult-small normal-price arrow alignment. The source PDF contains the
    # official arrow slightly low, so erase only that blank arrow band, redraw the
    # live normal price, then place the same red right-hook arrow through the exact
    # horizontal/vertical centre of the rendered price text. Other template artwork
    # (border/tags/triangle) is untouched.
    if is_discount and normal>0:
        clear_l,clear_t,clear_r,clear_b=_box_px((20.0,119.2,100.0,133.1),dpi)
        d.rectangle((clear_l,clear_t,clear_r,clear_b),fill='white')
        old_text=f'{normal:,}'
        old_box=(29.118,114.874,140.970,132.876)
        _fit_one_line(d,old_text,FONT_DIN_MEDIUM,44,23,old_box,black,dpi,'left')
        l,t,r,b=_box_px(old_box,dpi)
        chosen=_font_for_dpi(FONT_DIN_MEDIUM,23,dpi,False)
        for pt in range(44,22,-1):
            cand=_font_for_dpi(FONT_DIN_MEDIUM,pt,dpi,False)
            bb=d.textbbox((0,0),old_text,font=cand)
            if bb[2]-bb[0] <= max(1,r-l):
                chosen=cand; break
        bb=d.textbbox((0,0),old_text,font=chosen)
        tw=max(1,bb[2]-bb[0])
        text_left=l
        text_right=l+tw
        y=round((t+b)/2)
        margin=round(2.4*dpi/25.4)
        line_left=max(0,text_left-margin)
        line_right=min(a4.width-1,text_right+margin)
        width=max(2,round(0.28*dpi/25.4))
        head=max(3,round(2.2*dpi/25.4))
        d.line((line_left,y,line_right,y),fill=red,width=width)
        # Official adult-small artwork has the diagonal hook at the RIGHT end.
        d.line((line_right,y,line_right-head,y+head),fill=red,width=width)

    # 기간한정 only: date text is the PPT placeholder, not a separately invented position.
    if normalize_price_policy(item.get('price_policy'))=='기간한정':
        _fit_one_line(d,item.get('date_range',''),FONT_DIN_MEDIUM,17,17,
                      (82.560,182.409,152.568,196.408),red,dpi,'left')

    # V4.4.53 adult-small lock: tag row -> Korean title -> English title are
    # vertically separated. The live title may never touch the fixed gender/policy row.
    FIELD_LEFT=26.733
    TITLE_RIGHT=132.000
    EN_RIGHT=126.000
    title=str(item.get('title_ko') or '').strip()
    title_lines=_smart_title_lines(title,11)
    if len(title_lines)<=1:
        _fit_one_line(d,title,FONT_KO,36,31,
                      (FIELD_LEFT,202.000,TITLE_RIGHT,214.600),black,dpi,'left')
        en_top=216.000; en_bottom=233.800
    else:
        _fit_two_lines(d,title,FONT_KO,31,27,
                       (FIELD_LEFT,200.300,TITLE_RIGHT,221.600),black,dpi,False)
        en_top=223.000; en_bottom=241.500

    # Hard rule restored: >30 visible English characters = exactly two lines.
    # Shorter English also wraps if the real 25pt width exceeds the triangle-safe edge.
    _draw_adult_english_strict(d,item.get('title_en'),FIELD_LEFT,en_top,EN_RIGHT,en_bottom,black,dpi,25,18)

def _draw_clearance_fields(a4, item, dpi):
    d=ImageDraw.Draw(a4)
    black=(20,20,20); red=(230,0,18); gray=(45,45,45)
    _fit_one_line(d, f"{item.get('normal',0):,}" if item.get('normal') else '', FONT_DIN_MEDIUM, 24, 17,
                  (163.14,222.76,195.03,234.30), black, dpi, 'right')
    _fit_one_line(d, f"{item.get('sale',0):,}" if item.get('sale') else '', FONT_DIN_BOLD, 65, 40,
                  (127.75,228.53,195.03,256.20), red, dpi, 'right', True)

    # Exact left alignment rule for SPECIAL PRICE: gender tag, Korean title and English title.
    FIELD_LEFT = 19.30
    SAFE_RIGHT = 127.02
    line_count = _fit_smart_title(d, item.get('title_ko',''), FONT_KO, 27, 17,
                                  (FIELD_LEFT,230.40,SAFE_RIGHT,253.30), black, dpi, True)
    en_top = 254.00 if line_count == 2 else 246.50
    _fit_one_line(d, str(item.get('title_en') or '').upper(), FONT_DIN_MEDIUM, 12.7, 8,
                  (FIELD_LEFT,en_top,SAFE_RIGHT,264.00), gray, dpi, 'left')


def _draw_promo_offer_fields(a4, item, dpi):
    """Render socks 4-for-10,000 using the user-supplied 1.pptx official layout.

    Static artwork (4장 box, 기간한정 tag, gender tag, border and lower-right gender
    triangle) comes from TT_SOCKS_4_FOR_10000.pdf. The gender page is selected by the
    standard final-4-digit rule: 1xxx=남성/blue, 2xxx=여성/pink, 3xxx=공용/green.
    """
    d=ImageDraw.Draw(a4)
    red=(230,0,18); black=(0,0,0)

    # Exact main-price placeholder geometry inherited from the supplied PPTX.
    _fit_one_line(d,'10,000',FONT_DIN_BOLD,152,72,
                  (23.765,51.063,209.029,118.267),red,dpi,'left',True)

    # Store rule: only 기간한정 carries event period, standardized at DINPro-Medium 17pt.
    if normalize_price_policy(item.get('price_policy'))=='기간한정':
        _fit_one_line(d,item.get('date_range',''),FONT_DIN_MEDIUM,17,17,
                      (82.560,182.409,152.568,196.408),red,dpi,'left')

    FIELD_LEFT=26.733; TITLE_RIGHT=132.000; EN_RIGHT=126.000
    title=str(item.get('title_ko') or '').strip()
    title_lines=_smart_title_lines(title,11)
    if len(title_lines)<=1:
        _fit_one_line(d,title,FONT_KO,36,31,
                      (FIELD_LEFT,202.000,TITLE_RIGHT,214.600),black,dpi,'left')
        en_top=216.000; en_bottom=233.800
    else:
        _fit_two_lines(d,title,FONT_KO,31,27,
                       (FIELD_LEFT,200.300,TITLE_RIGHT,221.600),black,dpi,False)
        en_top=223.000; en_bottom=241.500
    _draw_adult_english_strict(d,item.get('title_en'),FIELD_LEFT,en_top,EN_RIGHT,en_bottom,black,dpi,25,18)

def render_price_reduction_a4(dpi):
    """Build the new price-reduction small POP from the supplied PPT artwork.

    The PPT red visual is kept as the main 180 mm artwork; the 50 mm bottom bar is
    generated separately so gender/policy/title/price are always live Excel data.
    """
    w=round(A4_W_MM*dpi/25.4); h=round(A4_H_MM*dpi/25.4)
    canvas=Image.new('RGB',(w,h),'white')
    try:
        art=Image.open(PRICE_REDUCTION_MAIN).convert('RGB')
        visual_h=round(VISUAL_VISIBLE_H_MM*dpi/25.4)
        art=ImageOps.fit(art,(w,visual_h),method=Image.Resampling.LANCZOS,centering=(0.5,0.5))
        top=round(CUT_TOP_MM*dpi/25.4)
        canvas.paste(art,(0,top))
    except Exception as exc:
        print('Price reduction artwork error:',exc,flush=True)
    return canvas


def render_custom_template_a4(item, dpi):
    if dpi == DPI:
        a4 = render_visual_a4(item.get('visual'))
    else:
        a4 = _render_visual_preview(item.get('visual'))
    if item.get('visual_mode') == 'promo_offer':
        _draw_promo_offer_fields(a4, item, dpi)
    else:
        _draw_adult_small_fields(a4, item, dpi)
    return a4


def generate_bottom_bar(item):
    """Render the fixed 210 x 44 mm bottom bar for the current price policy.

    Fixed typography requested by store:
      - event period: DINPro-Medium 17pt
      - Korean product title: NanumBarunGothic 26pt
      - English product title: DINPro-Regular 13pt
      - crossed-out normal price: DINPro-Medium 23pt
      - discounted sale price: DINPro-Bold 58pt
      - non-discount normal price: DINPro-Bold 59pt

    Only 기간한정 shows the event period. 가격인하 and 정상가 never show it.
    Gender, Korean title and English title share one exact left edge.
    """
    bar=Image.new('RGB',(A4_W_PX,BAR_H_PX),'white'); d=ImageDraw.Draw(bar)
    black=(20,20,20); gray=(45,45,45); red=(230,0,18); gender_bg=(32,32,32); policy_bg=(196,0,18)
    f_gender=font(FONT_KO,pt_px(11)); f_policy=font(FONT_KO,pt_px(11))
    f_date=font(FONT_DIN_MEDIUM,pt_px(17))
    f_main=font(FONT_DIN_BOLD,pt_px(58),fallback_bold=True)
    f_old=font(FONT_DIN_MEDIUM,pt_px(23))

    # V4.4.51 measured 210 x 44 mm lower bar.
    # Gender, Korean title and English title MUST share the exact same left edge.
    # Keep a visible vertical gap below the tag row so a 1- or 2-line title can never
    # collide with the gender/policy/date row.
    FIELD_LEFT=18.12
    GENDER_BOX=(FIELD_LEFT,4.35,28.75,10.05)
    POLICY_BOX=(29.92,4.35,47.05,10.05)
    # Move event period slightly right from the policy tag (about 2 mm gap).
    DATE_LEFT,DATE_RIGHT,DATE_TOP=49.10,97.10,3.05
    TITLE_LEFT,TITLE_RIGHT=FIELD_LEFT,108.79
    EN_LEFT,EN_RIGHT=FIELD_LEFT,109.22
    PRICE_LEFT,PRICE_RIGHT,PRICE_TOP=123.48,193.49,8.70
    OLD_LEFT,OLD_RIGHT,OLD_TOP=157.18,192.36,2.25

    gender=infer_gender_from_code(item.get('code'),item.get('gender')) or '공용'
    policy=normalize_price_policy(item.get('price_policy')) or '정상가'
    _fixed_tag(d,GENDER_BOX,gender,f_gender,gender_bg)

    if policy in ('기간한정','가격인하'):
        _fixed_tag(d,POLICY_BOX,policy,f_policy,policy_bg)
        if policy=='기간한정':
            _fit_text_fixed_box(d,item.get('date_range',''),f_date,
                round(DATE_LEFT*MM_TO_PX),round(DATE_TOP*MM_TO_PX),round(DATE_RIGHT*MM_TO_PX),red,'left')

    # V4.4.51 spacing lock. The tag row ends at 10.05 mm; title starts below it.
    # All left anchors are FIELD_LEFT so gender/title/English form one straight line.
    ko_count=len(_smart_title_lines(item.get('title_ko',''),11))
    if ko_count==1:
        title_lines=_fit_smart_title(d,item.get('title_ko',''),FONT_KO,26,26,
            (TITLE_LEFT,12.55,TITLE_RIGHT,23.55),black,DPI,False)
        _draw_english_title(d,item.get('title_en'),title_lines,EN_LEFT,EN_RIGHT,
            26.65,26.15,35.70,gray,DPI)
    else:
        title_lines=_fit_smart_title(d,item.get('title_ko',''),FONT_KO,26,26,
            (TITLE_LEFT,11.85,TITLE_RIGHT,28.70),black,DPI,False)
        _draw_english_title(d,item.get('title_en'),title_lines,EN_LEFT,EN_RIGHT,
            31.55,31.05,42.40,gray,DPI)

    normal=int(item.get('normal') or 0); sale=int(item.get('sale') or 0)
    show_discount = policy in ('기간한정','가격인하') and sale>0
    if show_discount:
        old=f'{normal:,}' if normal else ''
        current=f'{sale:,}' if sale else ''
        _fit_text_shrink_box(d,old,FONT_DIN_MEDIUM,23,18,
            round(OLD_LEFT*MM_TO_PX),round(OLD_TOP*MM_TO_PX),round(OLD_RIGHT*MM_TO_PX),black,'right')
        if old:
            _draw_old_price_arrow(
                d, old, f_old,
                (OLD_LEFT, OLD_TOP, OLD_RIGHT, 10.7), DPI,
                red, 0.56, 0.8
            )
        _fit_text_shrink_box(d,current,FONT_DIN_BOLD,58,48,
            round(PRICE_LEFT*MM_TO_PX),round(PRICE_TOP*MM_TO_PX),round(PRICE_RIGHT*MM_TO_PX),red,'right')
    else:
        price=f'{normal:,}' if normal else (f'{sale:,}' if sale else '')
        _fit_text_shrink_box(d,price,FONT_DIN_BOLD,59,48,
            round(PRICE_LEFT*MM_TO_PX),round(PRICE_TOP*MM_TO_PX),round(PRICE_RIGHT*MM_TO_PX),black,'right')
    return bar

def save_a4_pdf(a4_image, pdf_path):
    """Save a true A4 page. Print at Actual size / 100%."""
    tmp = CACHE_DIR / '_a4_page.png'
    a4_image.save(tmp, 'PNG', dpi=(DPI,DPI))
    a4 = fitz.paper_rect('a4')
    doc = fitz.open()
    page = doc.new_page(width=a4.width, height=a4.height)
    page.insert_image(page.rect, filename=str(tmp))
    # Clear full-width cut guides. Cut exactly on both dashed lines to obtain 210 x 235 mm.
    for idx, mm in enumerate((CUT_TOP_MM, CUT_BOTTOM_MM)):
        y = mm / 25.4 * 72
        dash = 8.0
        gap = 5.0
        x = 0.0
        while x < a4.width:
            page.draw_line(fitz.Point(x,y), fitz.Point(min(a4.width,x+dash),y), color=(.55,.55,.55), width=.45)
            x += dash+gap
        label_y = y-9 if idx == 0 else y+3
        page.insert_text(fitz.Point(8,label_y), f'CUT HERE - 210 x {int(CUT_H_MM)} mm', fontsize=7, color=(.45,.45,.45), fontname='helv')
    doc.save(str(pdf_path), deflate=True)
    doc.close()

def generate_one(item,out_path=None):
    if item.get('visual_mode') == 'price_reduction':
        a4_page = render_price_reduction_a4(DPI)
        bar = generate_bottom_bar(item)
        a4_page.paste(bar, (0, BAR_TOP_PX))
    elif item.get('visual_mode') in {'adult_small', 'promo_offer'}:
        a4_page = render_custom_template_a4(item, DPI)
    else:
        a4_page = render_visual_a4(item.get('visual'))
        bar = generate_bottom_bar(item)
        a4_page.paste(bar, (0, BAR_TOP_PX))
    pop = a4_page.crop((0, CUT_TOP_PX, A4_W_PX, CUT_TOP_PX + POP_H_PX))
    if out_path:
        out_path = Path(out_path)
        pop.save(out_path, 'PNG', dpi=(DPI,DPI))
        save_a4_pdf(a4_page, out_path.with_suffix('.pdf'))
    return pop

def items_map():
    # R8: read-only fast path. Never scan/consume workflow input rows here.
    # Price-policy changes are committed only by the explicit apply button.
    its,dr,ln=load_items(); return {i['code']:i for i in its},its,dr,ln



def load_sync_state():
    if not SYNC_STATE_FILE.exists():
        return {}
    try:
        return json.loads(SYNC_STATE_FILE.read_text('utf-8'))
    except Exception:
        return {}


def save_sync_state(data):
    SYNC_STATE_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


def safe_filename(name):
    return re.sub(r'[^0-9A-Za-z가-힣._-]+', '_', Path(name).name)


def _sync_source_key(src):
    """Return a stable POSIX-style path relative to webhard_sync."""
    try:
        return src.resolve().relative_to(WEBHARD_SYNC_DIR.resolve()).as_posix()
    except Exception:
        return src.name


def _apply_automatic_bonus_matches(source_id, results, refresh_items=True):
    """Persist direct webhard_sync source paths; no duplicate PDF copy is created."""
    source_id = _normalize_webhard_rel(source_id)
    if not source_id:
        return 0
    automatic = [r for r in results if r.get('code') and not r.get('needs_manual')]
    if not automatic:
        return 0
    data = load_bonus_matches(mode='ocr')
    manual_overrides = _load_manual_overrides(mode='ocr')
    saved = 0
    for r in automatic:
        code = clean_code(r['code'])
        if not code or code in manual_overrides:
            continue
        if get_bonus_fallback_choice(code):
            if not _exact_bonus_evidence(r,code):
                continue
            clear_bonus_fallback_choice(code)
        data[code] = {'file': source_id, 'source': source_id, 'page': int(r['page']), 'source_type':'auto'}
        saved += 1
    if saved:
        save_bonus_matches(data,mode='ocr')
        if refresh_items:
            load_items(force=True)
    return saved


def _set_scan_status(**kwargs):
    with _SCAN_STATUS_LOCK:
        _SCAN_STATUS.update(kwargs)


def get_scan_status():
    with _SCAN_STATUS_LOCK:
        return dict(_SCAN_STATUS)


def _run_scan_job(force=False, retry_manual=False, source='자동'):
    """Run one complete Webhard scan outside Flask request threads."""
    if not _SCAN_LOCK.acquire(blocking=False):
        return False
    try:
        _SCAN_CANCEL.clear()
        _set_scan_status(
            running=True, mode=('미매칭 OCR 재분석' if retry_manual else source),
            started_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            finished_at='', message='PDF 확인 및 매칭 중', error='', processed=0, cancel_requested=False
        )
        state = scan_webhard_folder(force=force, retry_manual=retry_manual)
        _raise_if_scan_cancelled()
        _set_scan_status(
            running=False, finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            message='분석 완료', processed=len(state), error='', cancel_requested=False
        )
    except ScanCancelled:
        _set_scan_status(running=False, finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'), message='OCR 매칭 중단 완료', error='', cancel_requested=False)
    except Exception as exc:
        _set_scan_status(
            running=False, finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            message='분석 오류', error=f'{type(exc).__name__}: {exc}'[:300]
        )
    finally:
        _SCAN_LOCK.release()
    return True


def start_scan_job(force=False, retry_manual=False, source='자동'):
    if get_scan_status().get('running'):
        return False
    threading.Thread(
        target=_run_scan_job,
        kwargs={'force': force, 'retry_manual': retry_manual, 'source': source},
        daemon=True
    ).start()
    return True


def scan_webhard_folder(force=False, retry_manual=False):
    """Analyze PDFs in webhard_sync in place; no bonus_pdfs duplicate is made."""
    state = load_sync_state()
    changed = False
    now = time.time()
    items = load_items(force=False)[0]
    ocr_ok, ocr_message = ocr_engine_status()
    excel_sig = str(CURRENT_XLSX.stat().st_mtime_ns) if CURRENT_XLSX.exists() else 'no-excel'
    analysis_context = f'{OCR_CACHE_VERSION}|{MATCH_ALGORITHM_VERSION}|ocr={int(ocr_ok)}|excel={excel_sig}'
    try:
        pdfs = sorted(
            (p for p in WEBHARD_SYNC_DIR.rglob('*') if p.is_file() and p.suffix.lower() == '.pdf'),
            key=lambda p: (p.stat().st_mtime_ns, _sync_source_key(p))
        )
    except OSError:
        pdfs = []

    current_keys = set()
    for src in pdfs:
        _raise_if_scan_cancelled()
        try:
            st = src.stat()
        except OSError:
            continue
        key = _sync_source_key(src)
        current_keys.add(key)
        rec = state.get(key, {})
        sig = f'{st.st_size}:{st.st_mtime_ns}'
        if rec.get('sig') != sig:
            rec = {
                'sig': sig, 'first_seen': now, 'status': 'waiting', 'size': st.st_size,
                'relative_path': key, 'source_file': key
            }
            state[key] = rec
            changed = True
            if not force:
                continue

        if not force and now - float(rec.get('first_seen', now)) < 3:
            continue

        unresolved = rec.get('status') in ('manual_required', 'error', 'ready', 'waiting')
        context_changed = rec.get('analysis_context') != analysis_context
        should_analyze = (
            force or rec.get('analyzed_sig') != sig
            or (unresolved and (retry_manual or context_changed))
        )
        if should_analyze:
            try:
                _raise_if_scan_cancelled()
                force_page_ocr = bool(unresolved and retry_manual)
                results = match_pdf_pages(src, items, force_ocr=force_page_ocr)
                auto_count = _apply_automatic_bonus_matches(key, results)
                manual_count = sum(1 for r in results if r.get('needs_manual') or not r.get('code'))
                status = 'auto_matched' if results and manual_count == 0 and auto_count == len(results) else 'manual_required'
                rec.update({
                    'status': status, 'source_file': key,
                    'detected_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'analyzed_sig': sig, 'auto_count': auto_count,
                    'manual_count': manual_count,
                    'page_count': len({int(r.get('page', 0)) for r in results}) if results else 0,
                    'relative_path': key, 'analysis_context': analysis_context,
                    'ocr_status': ocr_message, 'error': ''
                })
                rec.pop('bonus_file', None)
            except ScanCancelled:
                raise
            except Exception as e:
                rec.update({
                    'status': 'error', 'source_file': key,
                    'detected_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'relative_path': key, 'analysis_context': analysis_context,
                    'ocr_status': ocr_message, 'error': str(e)[:300]
                })
                rec.pop('bonus_file', None)
        elif rec.get('status') == 'waiting':
            rec['status'] = 'ready'
        state[key] = rec
        changed = True

    for key in list(state):
        if key not in current_keys:
            state[key]['source_missing'] = True
        else:
            state[key].pop('source_missing', None)

    if changed:
        save_sync_state(state)
    return state


def _reset_sync_records(target_files=None):
    reset_all = target_files is None
    targets = {_normalize_webhard_rel(x) for x in (target_files or []) if _normalize_webhard_rel(x)}
    state = load_sync_state()
    changed = False
    for key, rec in state.items():
        source_id = _normalize_webhard_rel(rec.get('relative_path') or rec.get('source_file') or key)
        if not reset_all and source_id not in targets:
            continue
        rec['status'] = 'ready'
        rec['auto_count'] = 0
        rec['manual_count'] = 0
        rec.pop('analysis_context', None)
        rec.pop('analyzed_sig', None)
        changed = True
    if changed:
        save_sync_state(state)


def reset_bonus_mappings(code=None, filename=None, reset_sync=True, preserve_manual=False, mode='ocr'):
    mode=_normalize_bonus_mode(mode)
    data = dict(load_bonus_matches(mode=mode))
    code = clean_code(code) if code else ''
    filename = _normalize_webhard_rel(filename) if filename else ''
    removed_files = set()
    removed_codes = set()
    next_data = {}
    removed = 0
    for saved_code, rec in data.items():
        source_id = _bonus_source_id(rec)
        should_remove = bool(
            (code and clean_code(saved_code) == code) or
            (filename and source_id == filename) or
            (not code and not filename)
        )
        if should_remove:
            removed += 1
            removed_codes.add(clean_code(saved_code))
            if source_id:
                removed_files.add(source_id)
        else:
            next_data[saved_code] = rec
    if preserve_manual:
        manual=_load_manual_overrides(mode=mode)
        for mcode,mrec in manual.items():
            if isinstance(mrec,dict) and _bonus_source_id(mrec):
                rec=dict(mrec); rec['source_type']='manual'; next_data[clean_code(mcode)]=rec
    save_bonus_matches(next_data,mode=mode)
    if preserve_manual:
        # Keep manual learning/overrides during an automatic re-match.
        pass
    else:
        _remove_ocr_learning(removed_codes, clear_all=(not code and not filename))
        _remove_manual_overrides(removed_codes, filename=filename, clear_all=(not code and not filename), mode=mode)
    load_items(force=True)
    if reset_sync:
        if code or filename:
            if removed_files:
                _reset_sync_records(removed_files)
        else:
            _reset_sync_records(None)
    return removed


def _run_full_rematch_job():
    """Clear mappings and re-evaluate every PDF directly under webhard_sync."""
    if not _SCAN_LOCK.acquire(blocking=False):
        return False
    try:
        _SCAN_CANCEL.clear()
        _set_scan_status(
            running=True, mode='전 품번 재매칭',
            started_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            finished_at='', message='기존 매칭 초기화 중', error='', processed=0, cancel_requested=False
        )
        reset_bonus_mappings(reset_sync=True, preserve_manual=True, mode='ocr')
        items = load_items(force=False)[0]
        state = load_sync_state()
        ocr_ok, _ = ocr_engine_status()
        excel_sig = str(CURRENT_XLSX.stat().st_mtime_ns) if CURRENT_XLSX.exists() else 'no-excel'
        analysis_context = f'{OCR_CACHE_VERSION}|{MATCH_ALGORITHM_VERSION}|ocr={int(ocr_ok)}|excel={excel_sig}'
        pdfs = sorted(
            (p for p in WEBHARD_SYNC_DIR.rglob('*') if p.is_file() and p.suffix.lower() == '.pdf'),
            key=lambda p: (p.stat().st_mtime_ns, _sync_source_key(p))
        )
        total_auto = 0
        total_manual = 0
        for idx, pdf in enumerate(pdfs, start=1):
            _raise_if_scan_cancelled()
            source_id = _sync_source_key(pdf)
            _set_scan_status(message=f'{idx}/{len(pdfs)} 분석 중: {source_id[:80]}', processed=idx-1)
            rec = state.setdefault(source_id, {'relative_path': source_id, 'source_file': source_id})
            try:
                results = match_pdf_pages(pdf, items, force_ocr=False)
                auto_count = _apply_automatic_bonus_matches(source_id, results, refresh_items=False)
                manual_count = sum(1 for r in results if r.get('needs_manual') or not r.get('code'))
                total_auto += auto_count
                total_manual += manual_count
                rec.update({
                    'status': 'auto_matched' if results and manual_count == 0 else 'manual_required',
                    'auto_count': auto_count, 'manual_count': manual_count,
                    'page_count': len({int(r.get('page', 0)) for r in results}) if results else 0,
                    'analysis_context': analysis_context,
                    'detected_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'relative_path': source_id, 'source_file': source_id,
                })
                rec.pop('bonus_file', None)
            except ScanCancelled:
                raise
            except Exception as exc:
                rec.update({
                    'status': 'error', 'error': f'{type(exc).__name__}: {exc}'[:300],
                    'relative_path': source_id, 'source_file': source_id
                })
            state[source_id] = rec
        save_sync_state(state)
        _set_scan_status(message='OCR 재매칭 계산 완료 · 공지 PDF 정답DB 최종 교차연동 중')
        notice_applied=_notice_apply_to_webhard()
        _sync_protected_matches_between_modes(); set_bonus_match_mode('ocr'); load_items(force=True)
        _set_scan_status(
            running=False, finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            message=f'OCR 전 품번 재매칭 완료 · 자동 {total_auto}개 · 공지 정답 직접연동 {notice_applied}개 · 수동확인 {total_manual}개 · 현재 적용 엔진 OCR',
            processed=len(pdfs), error=''
        )
    except ScanCancelled:
        _set_scan_status(running=False, finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'), message='OCR 전 품번 재매칭 중단 완료', error='', cancel_requested=False)
    except Exception as exc:
        _set_scan_status(
            running=False, finished_at=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            message='전 품번 재매칭 오류', error=f'{type(exc).__name__}: {exc}'[:300], cancel_requested=False
        )
    finally:
        _SCAN_LOCK.release()
    return True


def start_full_rematch_job():
    if get_scan_status().get('running'):
        return False
    threading.Thread(target=_run_full_rematch_job, daemon=True).start()
    return True

def webhard_watch_loop():
    # Legacy scheduler retained for compatibility but not started in V4.4.37.
    # A longer interval prevents 7 GB folder rescans from competing with previews.
    time.sleep(3)
    while True:
        try:
            start_scan_job(source='자동 새 파일 확인')
        except Exception as e:
            print('WEBHARD WATCH ERROR:', e, flush=True)
        time.sleep(30)


SYNC_HTML = r"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>웹하드 다운로드 폴더</title><style>body{font-family:Malgun Gothic,Arial;margin:0;background:#f3f5f7}.wrap{max-width:1200px;margin:auto;padding:24px}.panel{background:#fff;padding:18px;border-radius:12px;margin-bottom:16px}.btn{background:#102c73;color:#fff;border:0;border-radius:7px;padding:10px 15px;text-decoration:none;font-weight:700;cursor:pointer;display:inline-block}.green{background:#26734d}.gray{background:#555}.orange{background:#a85a00}.muted{color:#666}code{background:#f0f2f5;padding:3px 7px;border-radius:5px}table{width:100%;border-collapse:collapse}th,td{padding:10px;border-bottom:1px solid #ddd;text-align:left}th{background:#edf1f7}.ready{color:#15733a;font-weight:700}.wait{color:#b66a00;font-weight:700}</style></head><body><div class="wrap"><div class="panel"><a class="btn gray" href="/">← 메인 화면</a> <a class="btn green" href="/sync/open-folder">다운로드 폴더 열기</a> <a class="btn orange" href="/bonus-ai">AI 번외 매칭 관리</a><h2>웹하드 다운로드 폴더</h2><p><b>2026년 10월 1일부터 일반 OCR 분석 기능은 제거되었습니다.</b> 새 번외 PDF는 이 폴더에 두고 <b>AI 번외 매칭 관리</b>에서 전체 재매칭 또는 단일 PDF 테스트를 실행하세요.</p><p><code>{{folder}}</code></p></div><div class="panel"><h3>감지된 PDF 기록</h3><table><thead><tr><th>폴더/파일명</th><th>기존 상태</th><th>자동 연결</th><th>감지 시각</th></tr></thead><tbody>{% for name,rec in rows %}<tr><td>{{rec.relative_path or name}}</td><td class="{{'ready' if rec.status=='auto_matched' else 'wait'}}">{% if rec.status=='auto_matched' %}자동 매칭·대체 완료{% elif rec.status=='manual_required' %}수동 확인 필요{% elif rec.status=='error' %}기존 분석 오류{% elif rec.status=='ready' %}대기{% else %}다운로드 확인 기록{% endif %}</td><td>{{rec.auto_count or 0}}개</td><td>{{rec.detected_at or '-'}}</td></tr>{% else %}<tr><td colspan="4">아직 PDF가 없습니다.</td></tr>{% endfor %}</tbody></table></div></div></body></html>"""

@app.get('/sync')
def sync_page():
    state = load_sync_state()
    rows = sorted(state.items(), key=lambda kv: kv[1].get('detected_at',''), reverse=True)
    return render_template_string(
        SYNC_HTML, folder=str(WEBHARD_SYNC_DIR), rows=rows, scan=get_scan_status()
    )

@app.get('/sync/start')
def sync_start():
    # Legacy OCR sync analysis retired; AI matching is the only supported engine.
    return redirect('/bonus-ai')

@app.get('/sync/open-folder')
def sync_open_folder():
    try:
        if os.name == 'nt':
            os.startfile(str(WEBHARD_SYNC_DIR))
        else:
            subprocess.Popen(['xdg-open', str(WEBHARD_SYNC_DIR)])
    except Exception:
        pass
    return redirect('/sync')

@app.get('/sync/analyze/<path:filename>')
def sync_analyze(filename):
    # Legacy OCR per-file analysis retired; use AI single-PDF test/review instead.
    return redirect('/bonus-ai')

BONUS_HTML = r"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>번외 PDF 자동매칭</title><style>body{font-family:Malgun Gothic,Arial;margin:0;background:#f3f5f7}.wrap{max-width:1480px;margin:auto;padding:24px}.panel{background:white;padding:18px;border-radius:12px;margin-bottom:16px}.btn{background:#102c73;color:white;border:0;border-radius:7px;padding:10px 15px;text-decoration:none;font-weight:700;cursor:pointer;display:inline-block}.green{background:#26734d}.red{background:#d10b18}.gray{background:#555}.orange{background:#a85a00}.inline{display:inline-block;margin:3px}table{width:100%;border-collapse:collapse;font-size:13px}th,td{border-bottom:1px solid #ddd;padding:9px;text-align:left;vertical-align:top}th{background:#edf1f7}select{width:100%;min-width:300px;padding:7px}.score-high{color:#16753d;font-weight:700}.score-low{color:#c00;font-weight:700}.muted{color:#777}.auto{color:#16753d;font-weight:700}.manual{color:#c00;font-weight:700}.rule{background:#eef7f1;padding:12px;border-radius:8px;line-height:1.7}.danger{background:#fff1f1;border:1px solid #f0b7b7;padding:12px;border-radius:8px;margin-top:12px}.suggest{line-height:1.65;margin:4px 0;padding-left:20px}.small{font-size:12px}.page-thumb{display:block;width:180px;max-height:255px;object-fit:contain;background:#eee;border:1px solid #ccc;border-radius:5px}</style></head><body><div class="wrap"><div class="panel"><a class="btn" href="/">← 메인 화면</a> <a class="btn gray" href="/sync">웹하드 상태</a> <a class="btn orange" href="/bonus-ai">AI 페이지 매칭 TEST</a> <a class="btn green" href="/bonus/manual?mode=ai">품번 검색·오매칭 빠른 수정</a><h2>AI 번외 PDF 매칭 결과</h2><p><b>AI 상태:</b> {{ocr_status}} · <b>자동확정:</b> 고속 후보검색 + 폴더/제품라인 충돌차단 + 다중품번 멤버십</p><div class="rule"><b>AI 번외 매칭 결과</b><br>파일명 품번·상품명·성별·시즌·품종·제품라인과 AI 페이지 분석 결과를 교차검증합니다. 자동확정이 애매한 페이지는 AI 검토창 또는 품번 검색·오매칭 빠른 수정에서 확인할 수 있으며 수동고정은 다음 AI 재매칭에서도 보호됩니다.</div><p class="muted">10월 1일부터 일반 OCR 사용자 모드는 제공하지 않습니다. 전체 재매칭과 단일 PDF 테스트는 AI 번외 매칭 관리 화면에서 실행하세요.</p></div>{% if results %}<div class="panel"><form action="/bonus/save" method="post"><input type="hidden" name="filename" value="{{filename}}"><table><thead><tr><th>페이지</th><th>페이지 미리보기</th><th>인식 내용</th><th>판정 방식</th><th>추천 후보</th><th>상태</th><th>최종 연결</th></tr></thead><tbody>{% for r in results %}<tr><td><b>{{r.page_label}}</b></td><td><a href="{{url_for('bonus_page_preview', filename=filename, page=r.page)}}" target="_blank"><img class="page-thumb" loading="lazy" src="{{url_for('bonus_page_preview', filename=filename, page=r.page)}}"></a></td><td>{{r.text or 'AI 인식 내용 없음'}}</td><td>{{r.method}}<br><span class="small muted">선택 점수 {{r.score}}% · 후보 차이 {{r.margin or 0}}%p</span></td><td>{% if r.suggestions %}<ol class="suggest">{% for s in r.suggestions %}<li><b>{{s.code}}</b> · {{s.title}}{% if s.gender %} · {{s.gender}}{% endif %}{% if s.category %} · 품종 {{s.category}}{% endif %} <span class="{{'score-high' if s.score>=ocr_threshold else 'score-low'}}">{{s.score}}%</span></li>{% endfor %}</ol>{% else %}-{% endif %}</td><td class="{{'manual' if r.needs_manual else 'auto'}}">{{'수동 확인 필요' if r.needs_manual else '자동배정 완료'}}</td><td><input type="hidden" name="page" value="{{r.page}}"><input type="hidden" name="ocr_text" value="{{r.text|e}}"><select name="code"><option value="">연결하지 않음</option>{% for i in items %}<option value="{{i.code}}" {{'selected' if i.code==r.code else ''}}>{{i.code}} | {{i.title_ko}}</option>{% endfor %}</select></td></tr>{% endfor %}</tbody></table><p><button class="btn red">확인한 매칭 저장</button></p></form></div>{% endif %}<div class="panel"><h3>현재 저장된 번외 매칭 · {{matches|length}}개</h3><table><tr><th>품번</th><th>PDF</th><th>페이지</th><th>페이지 미리보기</th><th>상태/변경</th></tr>{% for code,rec in matches.items() %}<tr><td><b>{{code}}</b></td><td>{{rec.file}}</td><td>{{rec.page+1}}</td><td><a href="{{url_for('bonus_page_preview', filename=rec.file, page=rec.page)}}" target="_blank"><img class="page-thumb" loading="lazy" src="{{url_for('bonus_page_preview', filename=rec.file, page=rec.page)}}"></a></td><td><div style="margin-bottom:7px"><b>{{'수동고정' if rec.source_type=='manual' else '자동매칭'}}</b></div><a class="btn green" href="/bonus/edit-code/{{code}}">수동 수정</a> <form class="inline" action="/bonus/reset-code" method="post" onsubmit="return confirm('{{code}} 연결을 해제할까요?')"><input type="hidden" name="code" value="{{code}}"><button class="btn gray">초기화</button></form></td></tr>{% else %}<tr><td colspan="5">저장된 번외 매칭이 없습니다.</td></tr>{% endfor %}</table></div></div></body></html>"""

@app.get('/bonus/page-preview/<path:filename>/<int:page>')
def bonus_page_preview(filename, page):
    source_id = _normalize_webhard_rel(filename)
    pdf_path = _resolve_webhard_pdf(source_id or filename)
    if not pdf_path:
        return ('not found', 404)
    try:
        st = pdf_path.stat()
        key = hashlib.sha1(f'{pdf_path.resolve()}|{st.st_size}|{st.st_mtime_ns}|{page}|thumb-v4.4.36'.encode('utf-8')).hexdigest()[:24]
        cache_path = CACHE_DIR / f'bonus_page_{key}.jpg'
        if not cache_path.exists():
            with fitz.open(str(pdf_path)) as doc:
                if page < 0 or page >= doc.page_count:
                    return ('page not found', 404)
                p = doc.load_page(page)
                pix = p.get_pixmap(matrix=fitz.Matrix(1.15, 1.15), alpha=False)
                im = Image.frombytes('RGB', (pix.width, pix.height), pix.samples)
                if im.width > 420:
                    nh = round(im.height * 420 / im.width)
                    im = im.resize((420, nh), Image.Resampling.LANCZOS)
                im.save(cache_path, 'JPEG', quality=82, optimize=True, progressive=True)
        response = send_from_directory(CACHE_DIR, cache_path.name, mimetype='image/jpeg')
        response.headers['Cache-Control'] = 'public, max-age=31536000, immutable'
        return response
    except Exception as exc:
        return (f'preview error: {exc}', 500)



NOTICE_HTML=r"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>공지 PDF 자동동기화</title><style>body{font-family:Malgun Gothic,Arial;margin:0;background:#f3f5f7}.wrap{max-width:1350px;margin:auto;padding:22px}.panel{background:#fff;padding:18px;border-radius:12px;margin-bottom:15px}.btn{display:inline-block;border:0;border-radius:7px;padding:9px 13px;background:#102c73;color:#fff;text-decoration:none;font-weight:700;cursor:pointer}.green{background:#26734d}.gray{background:#555}.orange{background:#a85a00}.red{background:#b71c1c}.muted{color:#666}.ok{color:#16753d;font-weight:800}.bad{color:#c00;font-weight:800}.status{background:#eef3fb;padding:13px;border-radius:8px;line-height:1.8}table{width:100%;border-collapse:collapse;font-size:13px}th,td{padding:9px;border-bottom:1px solid #ddd;text-align:left;vertical-align:middle}th{background:#edf1f7}.thumb{width:90px;max-height:125px;object-fit:contain;border:1px solid #ddd;background:#eee}.search{padding:9px;min-width:360px}</style></head><body><div class="wrap"><div class="panel"><a class="btn gray" href="/">← 메인 화면</a><h2>본사 공지 PDF 정답DB · V5.1</h2><p>GitHub <code>notice_pdfs</code> 폴더를 자동 확인합니다. V3 파서는 본사 공지의 <b>POP 썸네일 + 카테고리 + 품번 + 제작일자</b>를 같은 셀의 정답으로 저장하며, 한 셀에 여러 품번이 적혀 있으면 그 품번들은 같은 공식 POP를 공유하는 것으로 기록합니다. 남성/여성 섹션도 함께 저장해 반대 성별 자동배정을 차단합니다.</p><div class="status"><b id="nstage">{{status.stage}}</b> · <span id="nmsg">{{status.message}}</span><br><span id="nerr" class="bad">{{status.error}}</span><br><span class="muted">마지막 확인 <span id="nlast">{{status.last_sync_at or '-'}}</span> · GitHub PDF <span id="nremote">{{status.remote_count}}</span>개 · 분석성공 <span id="nok">{{status.parse_success_files}}</span>개 · 분석실패/0건 <span id="nfail">{{status.parse_failed_files}}</span>개 · 정답DB <span id="ncount">{{index_count}}</span>품번 · 파서 V<span id="nparser">{{status.parser_version}}</span> · 마지막 직접적용 <span id="napplied">{{status.applied_matches}}</span>개</span></div><p><form method="post" action="/notice/sync-now" style="display:inline"><button class="btn green">GitHub 공지 지금 확인</button></form> <form method="post" action="/notice/rebuild" style="display:inline" onsubmit="return confirm('GitHub의 모든 공지 PDF를 다시 내려받아 정답DB를 재구축할까요? 기존 DB는 재구축이 정상 완료될 때까지 보호됩니다.')"><button class="btn red">전체 공지 정답DB 재구축</button></form> <form method="post" action="/notice/relink-webhard" style="display:inline" onsubmit="return confirm('현재 공지 정답DB를 기준으로 webhard_sync 전체를 다시 대조할까요? 수동고정은 절대 덮어쓰지 않습니다.')"><button class="btn orange">공지DB ↔ 웹하드 정답 재연결</button></form></p><p class="muted"><b>전체 재구축</b>은 모든 공지를 V3 셀 단위로 다시 읽습니다. 같은 품번에 같은 제작일자의 공식 POP가 여러 개면 모두 정답 후보로 보존합니다. <b>정답 재연결</b>은 AI 전체 재매칭 없이 현재 Webhard만 다시 대조하며, 우선순위는 수동고정 &gt; 본사 공지DB &gt; AI입니다.</p></div><div class="panel"><h3>테스트/긴급용 로컬 공지 등록</h3><form method="post" action="/notice/upload" enctype="multipart/form-data"><input type="file" name="pdf" accept=".pdf" required> <button class="btn orange">이 PDF 정답DB에 적용</button></form></div><div class="panel"><h3>현재 공지 정답 DB</h3><form method="get"><input class="search" name="q" value="{{q}}" placeholder="품번 또는 카테고리 검색"><button class="btn">검색</button> <a class="btn gray" href="/notice">초기화</a></form><table><thead><tr><th>POP</th><th>품번</th><th>카테고리</th><th>성별</th><th>제작일자</th><th>공식 변형</th><th>출처</th></tr></thead><tbody>{% for code,rec in rows %}<tr><td>{% if rec.card_file %}<img class="thumb" src="/notice/card/{{rec.card_file}}">{% else %}<span class="muted">텍스트 추출</span>{% endif %}</td><td><b>{{code}}</b></td><td>{{rec.category or '-'}}</td><td>{{rec.gender_scope or '-'}}</td><td>{{rec.production_date or '-'}}</td><td>{{rec.variant_count or 1}}개{% if rec.shared_codes and rec.shared_codes|length>1 %}<br><span class="muted">공용셀 {{rec.shared_codes|join(', ')}}</span>{% endif %}</td><td>{{rec.source_name}} · {{rec.page}}P{% if rec.parse_method %} · {{rec.parse_method}}{% endif %}</td></tr>{% else %}<tr><td colspan="7">공지 DB가 없습니다. GitHub notice_pdfs 폴더에 공지를 올리거나 전체 재구축을 실행하세요.</td></tr>{% endfor %}</tbody></table></div></div><script>async function ns(){try{let r=await fetch('/api/notice-status',{cache:'no-store'}),d=await r.json();document.getElementById('nstage').textContent=d.stage||'대기';document.getElementById('nmsg').textContent=d.message||'';document.getElementById('nerr').textContent=d.error||'';document.getElementById('nlast').textContent=d.last_sync_at||'-';document.getElementById('nremote').textContent=d.remote_count||0;document.getElementById('nok').textContent=d.parse_success_files||0;document.getElementById('nfail').textContent=d.parse_failed_files||0;document.getElementById('ncount').textContent=d.indexed_codes||0;document.getElementById('nparser').textContent=d.parser_version||0;document.getElementById('napplied').textContent=d.applied_matches||0}catch(e){}}setInterval(ns,1800);</script></body></html>"""

@app.get('/notice')
def notice_page():
    q=str(request.args.get('q') or '').strip().upper(); idx=_load_notice_index(); rows=[]
    for code,rec in sorted((idx.get('items') or {}).items()):
        hay=f"{code} {rec.get('category','')} {rec.get('source_name','')}".upper()
        if q and q not in hay: continue
        rows.append((code,rec))
        if len(rows)>=250: break
    return render_template_string(NOTICE_HTML,status=get_notice_status(),index_count=len(idx.get('items') or {}),rows=rows,q=q)

@app.get('/api/notice-status')
def notice_status_api(): return jsonify(get_notice_status())

@app.post('/notice/sync-now')
def notice_sync_now():
    start_notice_sync(force=True)
    return redirect('/notice')

@app.post('/notice/rebuild')
def notice_rebuild():
    start_notice_sync(force=True,rebuild=True)
    return redirect('/notice')

@app.post('/notice/relink-webhard')
def notice_relink_webhard():
    def worker():
        if not _NOTICE_SYNC_LOCK.acquire(blocking=False):
            _notice_status(running=False,stage='대기',message='다른 공지 작업이 진행 중입니다.',error='')
            return
        try:
            _notice_status(running=True,stage='정답 재연결',message='본사 공지DB ↔ 현재 Webhard 전체 재대조 중',error='',applied_matches=0)
            applied=_notice_apply_to_webhard()
            state=_load_notice_state(); idx=_load_notice_index(force=True)
            payload={'items':idx.get('items') or {},'variants':idx.get('variants') or {}}
            state['last_applied_revision']=hashlib.sha1(json.dumps(payload,sort_keys=True,ensure_ascii=False).encode('utf-8')).hexdigest()
            state['last_webhard_signature']=_notice_webhard_signature()
            now=datetime.now().isoformat(timespec='seconds'); state['last_sync_at']=now; state['parser_version']=NOTICE_PARSER_VERSION
            _notice_write_json(NOTICE_STATE_FILE,state)
            _notice_status(running=False,stage='완료',message=f'공지DB ↔ Webhard 정답 재연결 완료 · 새/수정 적용 {applied}개',error='',last_sync_at=now,applied_matches=applied,indexed_codes=len(idx.get('items') or {}))
        except Exception as exc:
            _notice_status(running=False,stage='오류',message='공지DB ↔ Webhard 정답 재연결 실패',error=f'{type(exc).__name__}: {exc}')
            _notice_log(f'relink failed {type(exc).__name__}: {exc}')
        finally:
            _NOTICE_SYNC_LOCK.release()
    threading.Thread(target=worker,daemon=True,name='notice-relink').start()
    return redirect('/notice')

@app.post('/notice/upload')
def notice_upload():
    f=request.files.get('pdf')
    if not f or not f.filename: return redirect('/notice')
    safe=safe_filename(f.filename); path=CACHE_DIR/f'notice_manual_{int(time.time())}_{safe}'
    f.save(path)
    def worker():
        try: _notice_sync_once(force=False,local_pdf=path,local_name=f.filename)
        finally:
            try: path.unlink()
            except OSError: pass
    threading.Thread(target=worker,daemon=True,name='notice-local').start()
    return redirect('/notice')

@app.get('/notice/card/<path:name>')
def notice_card(name):
    safe=Path(name).name
    return send_from_directory(NOTICE_CARD_DIR,safe,mimetype='image/jpeg')

@app.get('/bonus')
def bonus_page():
    # Legacy OCR management page retired on 2026-10-01.
    return redirect('/bonus-ai')

@app.post('/bonus/analyze')
def bonus_analyze():
    # Legacy OCR upload/analyze endpoint retired; keep old bookmarks/forms safe.
    return redirect('/bonus-ai')

@app.post('/bonus/save')
def bonus_save():
    # Shared AI-result manual save. Legacy OCR learning is intentionally not executed.
    filename=_normalize_webhard_rel(request.form.get('filename','')); pages=request.form.getlist('page'); codes=request.form.getlist('code')
    for page,code in zip(pages,codes):
        code=clean_code(code)
        if code and filename:
            _set_shared_manual_bonus(code,filename,int(page))
    load_items(force=True)
    return redirect('/bonus-ai')


def _manual_pdf_candidates(code, items, limit=18):
    code=clean_code(code); item=next((i for i in items if clean_code(i.get('code'))==code),None)
    if not item: return []
    rows=[]; cache=_load_ocr_cache()
    for pdf in WEBHARD_SYNC_DIR.rglob('*.pdf'):
        try:
            source_id=_sync_source_key(pdf); filename_codes=extract_filename_codes(pdf.name,items)
            source_desc=_source_description(pdf,filename_codes)
            exact=code in {clean_code(x) for x in filename_codes}
            best_page=0; best=max(_title_match_score(source_desc,item),0.0)
            with fitz.open(str(pdf)) as doc:
                for pno in range(doc.page_count):
                    key=_ocr_cache_key(pdf,pno); rec=cache.get(key) if isinstance(cache,dict) else None
                    txt=''
                    if isinstance(rec,dict):
                        txt=str(rec.get('text') or '')
                        if not txt and isinstance(rec.get('regions'),dict): txt=' '.join(str(v or '') for v in rec['regions'].values())
                    s=_title_match_score(txt,item) if txt else 0.0
                    if s>best: best=s; best_page=pno
                anchor,conflict,_,_=_anchor_relation(source_desc,item)
                score=best + (0.60 if exact else 0) + (0.15 if anchor else 0) - (0.35 if conflict and not exact else 0)
                if exact or score>=0.38:
                    rows.append({'file':source_id,'page':best_page,'page_label':best_page+1,'score':round(max(0,min(1.5,score))*100),'exact':exact,'anchor':anchor,'conflict':conflict})
        except Exception:
            continue
    rows.sort(key=lambda r:(-bool(r['exact']),bool(r['conflict']),-r['score'],r['file']))
    return rows[:limit]


MANUAL_MANAGER_HTML=r"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>번외 오매칭 빠른 수정</title><style>body{font-family:Malgun Gothic,Arial;margin:0;background:#f3f5f7}.wrap{max-width:1350px;margin:auto;padding:22px}.panel{background:white;padding:18px;border-radius:12px;margin-bottom:15px}.btn{display:inline-block;border:0;border-radius:7px;padding:9px 12px;background:#102c73;color:white;text-decoration:none;font-weight:700;cursor:pointer}.green{background:#26734d}.orange{background:#a85a00}.gray{background:#555}.red{background:#c51f2c}.purple{background:#6d3bb5}.muted{color:#666}.search{padding:11px;width:min(620px,70vw);font-size:16px}table{width:100%;border-collapse:collapse}th,td{padding:9px;border-bottom:1px solid #ddd;text-align:left;vertical-align:middle}th{background:#edf1f7}.inline{display:inline-block;margin:2px}.lock{font-weight:800;color:#a85a00}</style></head><body><div class="wrap"><div class="panel"><a class="btn gray" href="{{back_url}}">← 돌아가기</a><h2>번외 오매칭 빠른 수정 · AI 적용</h2><p>잘못 연결된 <b>품번 또는 상품명만 검색</b>해서 바로 수정할 수 있습니다. 번외가 없으면 NEW ARRIVAL 또는 성인소형을 눌러 대체 고정할 수 있습니다.</p><form method="get" action="/bonus/manual"><input type="hidden" name="mode" value="{{mode}}"><input class="search" name="q" value="{{q}}" placeholder="예: MSG2PP2501 또는 상품명"><button class="btn">검색</button> <a class="btn gray" href="/bonus/manual?mode={{mode}}">초기화</a></form><p class="muted">대체 고정 품번은 기존 자동 재매칭으로 다시 덮어쓰지 않습니다. PDF 페이지에서 정확한 품번이 직접 인식되거나 사용자가 수동으로 실제 번외를 지정하면 대체 고정이 해제됩니다. 8/28 이후 가격정책 리스트에서는 가격인하=PPT 고정, 기간한정=번외→성인소형, 정상가=번외→NEW ARRIVAL 규칙이 우선합니다.</p></div><div class="panel"><table><thead><tr><th>품번</th><th>상품명</th><th>현재 번외</th><th>대체 상태</th><th>바로 수정</th></tr></thead><tbody>{% for r in rows %}<tr><td><b>{{r.code}}</b></td><td>{{r.title}}</td><td>{% if r.match %}{{r.match.file}} / {{r.match.page+1}}P · {{'수동' if r.match.source_type=='manual' else '자동'}}{% else %}<span class="muted">없음</span>{% endif %}</td><td>{% if r.fallback=='new_arrival' %}<span class="lock">NEW ARRIVAL 대체 고정</span>{% elif r.fallback=='adult_small' %}<span class="lock">성인소형 대체 고정</span>{% else %}-{% endif %}</td><td><a class="btn green" href="/bonus/edit-code/{{r.code}}?mode={{mode}}">PDF 수동 수정</a><form class="inline" method="post" action="/bonus/fallback-choice" onsubmit="return confirm('{{r.code}} 번외 연결을 해제하고 NEW ARRIVAL로 대체 고정할까요?')"><input type="hidden" name="code" value="{{r.code}}"><input type="hidden" name="mode" value="{{mode}}"><input type="hidden" name="choice" value="new_arrival"><button class="btn purple">NEW ARRIVAL</button></form><form class="inline" method="post" action="/bonus/fallback-choice" onsubmit="return confirm('{{r.code}} 번외 연결을 해제하고 성인소형 POP로 대체 고정할까요?')"><input type="hidden" name="code" value="{{r.code}}"><input type="hidden" name="mode" value="{{mode}}"><input type="hidden" name="choice" value="adult_small"><button class="btn orange">성인소형</button></form><form class="inline" method="post" action="/bonus/reset-code" onsubmit="return confirm('{{r.code}}의 AI 번외 연결과 대체 고정을 초기화할까요?')"><input type="hidden" name="code" value="{{r.code}}"><input type="hidden" name="return_to" value="manual"><input type="hidden" name="mode" value="{{mode}}"><button class="btn red">완전 초기화</button></form></td></tr>{% else %}<tr><td colspan="5">검색 결과가 없습니다.</td></tr>{% endfor %}</tbody></table></div></div></body></html>"""


@app.get('/bonus/manual')
def bonus_manual_manager():
    mode='ai'
    q=str(request.args.get('q') or '').strip().upper()
    _,items,_,_=items_map(); matches=load_bonus_matches(mode=mode); fallbacks=_load_bonus_fallback_choices()
    filtered=items
    if q:
        filtered=[i for i in items if q in clean_code(i.get('code')) or q in str(i.get('title_ko') or '').upper() or q in str(i.get('title_en') or '').upper()]
    elif len(items)>120:
        # Unfiltered page stays light; search is the intended workflow.
        filtered=items[:120]
    rows=[]
    for i in filtered:
        code=clean_code(i.get('code'))
        rows.append({'code':code,'title':str(i.get('title_ko') or ''),'match':(_shared_manual_override(code) or matches.get(code)),'fallback':get_bonus_fallback_choice(code)})
    back_url='/bonus-ai/review' if mode=='ai' else '/bonus'
    return render_template_string(MANUAL_MANAGER_HTML,mode=mode,q=q,rows=rows,back_url=back_url)


@app.post('/bonus/fallback-choice')
def bonus_fallback_choice():
    code=clean_code(request.form.get('code','')); choice=str(request.form.get('choice') or '').strip().lower()
    mode='ai'
    if code and choice in {'new_arrival','adult_small'}:
        # Remove the stale mapping from BOTH stores so switching OCR/AI cannot make it reappear.
        reset_bonus_mappings(code=code,reset_sync=True,preserve_manual=False,mode='ocr')
        reset_bonus_mappings(code=code,reset_sync=True,preserve_manual=False,mode='ai')
        _ignore_ai_review_codes([code])
        set_bonus_fallback_choice(code,choice)
    return redirect(f'/bonus/edit-code/{code}?mode={mode}' if code else f'/bonus/manual?mode={mode}')


@app.post('/bonus/fallback-clear')
def bonus_fallback_clear():
    code=clean_code(request.form.get('code','')); mode='ai'
    if code: clear_bonus_fallback_choice(code)
    return redirect(f'/bonus/edit-code/{code}?mode={mode}' if code else f'/bonus/manual?mode={mode}')


EDIT_MATCH_HTML=r"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>번외 매칭 수동 수정</title><style>body{font-family:Malgun Gothic,Arial;margin:0;background:#f3f5f7}.wrap{max-width:1200px;margin:auto;padding:24px}.panel{background:#fff;padding:18px;border-radius:12px;margin-bottom:16px}.btn{background:#102c73;color:#fff;border:0;border-radius:7px;padding:9px 13px;text-decoration:none;font-weight:700;cursor:pointer;display:inline-block}.green{background:#26734d}.gray{background:#555}.orange{background:#a85a00}.purple{background:#6d3bb5}.red{background:#c51f2c}table{width:100%;border-collapse:collapse}th,td{padding:9px;border-bottom:1px solid #ddd;text-align:left;vertical-align:middle}th{background:#edf1f7}.thumb{width:120px;max-height:170px;object-fit:contain;border:1px solid #ccc;background:#eee}.muted{color:#666}.bad{color:#c00;font-weight:700}.lock{color:#a85a00;font-weight:800}input{padding:9px;min-width:420px}.inline{display:inline-block;margin:2px}</style></head><body><div class="wrap"><div class="panel"><a class="btn gray" href="/bonus/manual?mode={{mode}}">← 품번 검색/빠른 수정</a><h2>{{code}} · {{item.title_ko}} 수동 수정 · AI</h2>{% if current %}<p>현재 번외: <b>{{current.file}}</b> / {{current.page+1}}페이지 · {{'수동고정' if current.source_type=='manual' else '자동매칭'}}</p><img class="thumb" src="{{url_for('bonus_page_preview',filename=current.file,page=current.page)}}">{% else %}<p class="muted">현재 번외 연결 없음</p>{% endif %}{% if fallback=='new_arrival' %}<p class="lock">현재 NEW ARRIVAL 대체 고정 중</p>{% elif fallback=='adult_small' %}<p class="lock">현재 성인소형 POP 대체 고정 중</p>{% endif %}</div><div class="panel"><h3>번외가 없거나 오매칭이면 대체 POP 고정</h3><p class="muted">이 버튼을 누르면 기존 AI 오매칭을 해제하고 선택한 POP를 사용합니다. 자동 재매칭이 같은 오매칭을 다시 덮어쓰지 못합니다.</p><form class="inline" method="post" action="/bonus/fallback-choice"><input type="hidden" name="code" value="{{code}}"><input type="hidden" name="mode" value="{{mode}}"><input type="hidden" name="choice" value="new_arrival"><button class="btn purple">NEW ARRIVAL로 대체</button></form><form class="inline" method="post" action="/bonus/fallback-choice"><input type="hidden" name="code" value="{{code}}"><input type="hidden" name="mode" value="{{mode}}"><input type="hidden" name="choice" value="adult_small"><button class="btn orange">성인소형 POP로 대체</button></form>{% if fallback %}<form class="inline" method="post" action="/bonus/fallback-clear"><input type="hidden" name="code" value="{{code}}"><input type="hidden" name="mode" value="{{mode}}"><button class="btn gray">대체 고정만 해제</button></form>{% endif %}</div><div class="panel"><h3>PDF 직접 선택</h3><p class="muted">추천에 원하는 PDF가 없어도 webhard_sync 안의 모든 PDF를 직접 지정할 수 있습니다. 수동으로 실제 번외를 지정하면 대체 고정은 자동 해제됩니다.</p><form method="post" action="/bonus/edit-code-save"><input type="hidden" name="code" value="{{code}}"><input type="hidden" name="mode" value="{{mode}}"><input list="allpdfs" name="filename" placeholder="PDF 파일/폴더명 검색" required><datalist id="allpdfs">{% for f in all_pdfs %}<option value="{{f}}">{% endfor %}</datalist> <input style="min-width:70px;width:70px" type="number" name="page_display" min="1" value="1"> <button class="btn green">직접 고정</button></form></div><div class="panel"><h3>추천 PDF</h3><p class="muted">파일명 품번, 폴더/파일 제품라인, 저장된 AI 분석 상품명을 함께 사용합니다. 원하는 번외가 없으면 위 대체 버튼을 사용하세요.</p><table><tr><th>미리보기</th><th>PDF / 페이지</th><th>근거</th><th>변경</th></tr>{% for r in candidates %}<tr><td><img class="thumb" loading="lazy" src="{{url_for('bonus_page_preview',filename=r.file,page=r.page)}}"></td><td>{{r.file}}<br>{{r.page_label}}페이지</td><td>{{r.score}}점 {% if r.exact %}· 파일명 품번{% endif %}{% if r.anchor %} · 제품라인 일치{% endif %}{% if r.conflict %}<span class="bad"> · 라인충돌</span>{% endif %}</td><td><form method="post" action="/bonus/edit-code-save"><input type="hidden" name="code" value="{{code}}"><input type="hidden" name="mode" value="{{mode}}"><input type="hidden" name="filename" value="{{r.file}}"><input type="hidden" name="page" value="{{r.page}}"><button class="btn green">이 PDF로 고정</button></form></td></tr>{% else %}<tr><td colspan="4">추천 후보 없음</td></tr>{% endfor %}</table></div></div></body></html>"""


@app.get('/bonus/edit-code/<code>')
def bonus_edit_code(code):
    code=clean_code(code); mode='ai'
    _,items,_,_=items_map(); item=next((i for i in items if clean_code(i.get('code'))==code),None)
    if not item: return redirect(f'/bonus/manual?mode={mode}')
    current=_shared_manual_override(code) or load_bonus_matches(mode=mode).get(code)
    candidates=_manual_pdf_candidates(code,items)
    all_pdfs=sorted(_sync_source_key(p) for p in WEBHARD_SYNC_DIR.rglob('*.pdf') if p.is_file())
    return render_template_string(EDIT_MATCH_HTML,code=code,item=item,current=current,candidates=candidates,all_pdfs=all_pdfs,mode=mode,fallback=get_bonus_fallback_choice(code))


@app.post('/bonus/edit-code-save')
def bonus_edit_code_save():
    code=clean_code(request.form.get('code','')); filename=_normalize_webhard_rel(request.form.get('filename',''))
    mode='ai'
    try:
        if request.form.get('page_display'):
            page=max(0,int(request.form.get('page_display','1'))-1)
        else:
            page=max(0,int(request.form.get('page','0')))
    except Exception: page=0
    if code and filename and _resolve_webhard_pdf(filename):
        _set_shared_manual_bonus(code,filename,page)
    return redirect(f'/bonus/edit-code/{code}?mode={mode}')


@app.post('/bonus/reset-code')
def bonus_reset_code():
    code=clean_code(request.form.get('code','')); mode='ai'
    if code:
        reset_bonus_mappings(code=code,mode='ocr')
        reset_bonus_mappings(code=code,mode='ai')
        _ignore_ai_review_codes([code])
        clear_bonus_fallback_choice(code)
    if request.form.get('return_to')=='manual': return redirect(f'/bonus/manual?mode={mode}&q={code}')
    return redirect('/bonus-ai/review' if mode=='ai' else '/bonus')


@app.post('/bonus/reset-file')
def bonus_reset_file():
    filename=request.form.get('filename','')
    reset_bonus_mappings(filename=filename,mode='ocr')
    reset_bonus_mappings(filename=filename,mode='ai')
    return redirect('/bonus-ai')


@app.post('/bonus/reset-all')
def bonus_reset_all():
    reset_bonus_mappings(mode='ocr')
    reset_bonus_mappings(mode='ai')
    _ignore_ai_review_codes(clear_all=True)
    # Deliberate NEW ARRIVAL/adult-small fallback locks are kept.
    return redirect('/bonus-ai')


@app.post('/bonus/rematch-all')
def bonus_rematch_all():
    # Legacy OCR full-rematch endpoint retired; never start the old OCR job.
    return redirect('/bonus-ai')

@app.get('/api/scan-status')
def api_scan_status():
    st=get_scan_status()
    try: st['ai_cache_count']=len(_load_ai_cache().get('pages',{}))
    except Exception: st['ai_cache_count']=0
    st['single_ready']=AI_SINGLE_RESULT_FILE.exists()
    try:
        review=_load_ai_review(); st['ai_review_count']=len(review.get('rows') or []); st['ai_review_status']=str(review.get('status') or '')
    except Exception:
        st['ai_review_count']=0; st['ai_review_status']=''
    return jsonify(st)

@app.post('/api/scan-stop')
def api_scan_stop():
    request_scan_stop()
    return jsonify({'ok':True,'status':get_scan_status()})


MANUAL_HTML = r'''<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TOPTEN POP 자동화 매뉴얼</title><style>
*{box-sizing:border-box}body{margin:0;background:#eef2f7;font-family:Malgun Gothic,Arial,sans-serif;color:#111}.wrap{max-width:1500px;margin:auto;padding:18px}.head{background:#0d255f;color:#fff;border-radius:14px;padding:18px 22px;display:flex;gap:12px;align-items:center;justify-content:space-between;flex-wrap:wrap}.head h1{font-size:23px;margin:0}.actions{display:flex;gap:8px;flex-wrap:wrap}.btn{border:0;border-radius:8px;padding:10px 15px;background:#1765d8;color:white;text-decoration:none;font-weight:800;display:inline-block}.btn.gray{background:#555}.btn.green{background:#26734d}.card{margin-top:14px;background:#fff;border-radius:14px;padding:14px;box-shadow:0 2px 12px #00000012}.viewer{text-align:center;background:#e4e9f0;border-radius:10px;padding:10px;min-height:320px}.viewer img{display:block;margin:auto;max-width:100%;height:auto;background:white;box-shadow:0 2px 14px #0003}.pager{display:flex;justify-content:center;align-items:center;gap:7px;flex-wrap:wrap;margin-top:12px}.page{padding:8px 11px;border-radius:8px;background:#eef3fb;color:#102c73;text-decoration:none;font-weight:800}.page.on{background:#102c73;color:white}.meta{color:#666;font-size:13px;margin-top:8px}@media(max-width:700px){.wrap{padding:8px}.head{padding:14px}.head h1{font-size:18px}.card{padding:8px}}
</style></head><body><div class="wrap"><div class="head"><div><h1>📘 TOPTEN POP 자동화 V5.1 매장 사용법</h1><div style="opacity:.85;margin-top:5px">총 {{page_count}}페이지 · 프로그램 안에서 바로 넘겨보는 매장용 매뉴얼</div></div><div class="actions"><a class="btn gray" href="/">← 메인화면</a><a class="btn green" href="/manual/download">PDF 다운로드</a></div></div><div class="card"><div class="viewer"><img src="/manual/page/{{page}}.png?v={{manual_mtime}}" alt="매뉴얼 {{page}}페이지"></div><div class="pager">{% if page>1 %}<a class="page" href="/manual?page={{page-1}}">‹ 이전</a>{% endif %}{% for p in range(1,page_count+1) %}<a class="page {{'on' if p==page else ''}}" href="/manual?page={{p}}">{{p}}</a>{% endfor %}{% if page<page_count %}<a class="page" href="/manual?page={{page+1}}">다음 ›</a>{% endif %}</div><div class="meta">저장 위치: data\manual\TOPTEN_POP_V5.1_매장_사용법_가이드.pdf · 최초 실행 시 1회 자동 설치</div></div></div></body></html>'''


def _store_manual_validate(path):
    path=Path(path)
    if not path.exists() or path.stat().st_size < 10000:
        raise ValueError('매뉴얼 PDF가 없거나 파일 크기가 비정상입니다.')
    doc=fitz.open(str(path))
    try:
        pages=int(doc.page_count or 0)
        if pages < 1:
            raise ValueError('매뉴얼 PDF 페이지가 없습니다.')
        return pages
    finally:
        doc.close()


def _write_store_manual_status(ok,message,pages=0):
    try:
        STORE_MANUAL_DIR.mkdir(parents=True,exist_ok=True)
        STORE_MANUAL_STATUS_FILE.write_text(json.dumps({
            'ok':bool(ok),'message':str(message),'pages':int(pages or 0),
            'updated_at':datetime.now().isoformat(timespec='seconds')
        },ensure_ascii=False,indent=2),encoding='utf-8')
    except Exception:
        pass


def ensure_store_manual():
    # Install the bundled store manual once into protected data\manual.
    STORE_MANUAL_DIR.mkdir(parents=True,exist_ok=True)
    STORE_MANUAL_PAGE_DIR.mkdir(parents=True,exist_ok=True)
    try:
        pages=_store_manual_validate(STORE_MANUAL_FILE)
        return {'ok':True,'pages':pages,'installed':False,'message':'기존 매뉴얼 사용'}
    except Exception:
        pass
    if not STORE_MANUAL_BUNDLED_FILE.exists():
        msg='배포본에 매뉴얼 PDF가 없습니다.'
        _write_store_manual_status(False,msg,0)
        return {'ok':False,'pages':0,'installed':False,'message':msg}
    tmp=STORE_MANUAL_DIR/'manual_install.tmp.pdf'
    try:
        shutil.copy2(STORE_MANUAL_BUNDLED_FILE,tmp)
        pages=_store_manual_validate(tmp)
        os.replace(tmp,STORE_MANUAL_FILE)
        for p in STORE_MANUAL_PAGE_DIR.glob('page_*.png'):
            try: p.unlink()
            except OSError: pass
        msg=f'매뉴얼 최초 설치 완료 ({pages}페이지)'
        _write_store_manual_status(True,msg,pages)
        return {'ok':True,'pages':pages,'installed':True,'message':msg}
    except Exception as exc:
        try: tmp.unlink(missing_ok=True)
        except Exception: pass
        msg=f'매뉴얼 설치 실패: {type(exc).__name__}: {exc}'
        _write_store_manual_status(False,msg,0)
        return {'ok':False,'pages':0,'installed':False,'message':msg}


@app.get('/manual')
def store_manual_view():
    st=ensure_store_manual()
    if not st.get('ok'):
        return f"매뉴얼을 준비하지 못했습니다.<br>{st.get('message','')}",500
    page_count=int(st.get('pages') or 1)
    try: page=int(request.args.get('page','1'))
    except Exception: page=1
    page=max(1,min(page_count,page))
    return render_template_string(MANUAL_HTML,page=page,page_count=page_count,manual_mtime=int(STORE_MANUAL_FILE.stat().st_mtime))


@app.get('/manual/page/<int:page>.png')
def store_manual_page(page):
    st=ensure_store_manual()
    if not st.get('ok'):
        return '매뉴얼이 없습니다.',404
    page_count=int(st.get('pages') or 0)
    if page < 1 or page > page_count:
        return '페이지를 찾을 수 없습니다.',404
    STORE_MANUAL_PAGE_DIR.mkdir(parents=True,exist_ok=True)
    target=STORE_MANUAL_PAGE_DIR/f'page_{page:02d}.png'
    try:
        stale=(not target.exists()) or target.stat().st_mtime < STORE_MANUAL_FILE.stat().st_mtime
    except Exception:
        stale=True
    if stale:
        doc=fitz.open(str(STORE_MANUAL_FILE))
        try:
            pg=doc.load_page(page-1)
            pix=pg.get_pixmap(matrix=fitz.Matrix(1.35,1.35),alpha=False)
            tmp=target.with_suffix('.tmp.png')
            pix.save(str(tmp))
            os.replace(tmp,target)
        finally:
            doc.close()
    return send_from_directory(str(STORE_MANUAL_PAGE_DIR),target.name,mimetype='image/png',max_age=3600)


@app.get('/manual/download')
def store_manual_download():
    st=ensure_store_manual()
    if not st.get('ok'):
        return '매뉴얼이 없습니다.',404
    return send_from_directory(str(STORE_MANUAL_FILE.parent),STORE_MANUAL_FILE.name,as_attachment=True)

@app.get('/health')
def health():
    return {'status': 'ok'}

@app.get('/api/site-notice')
def api_site_notice():
    response=jsonify(get_site_notice(force=request.args.get('force')=='1'))
    response.headers['Cache-Control']='no-store, no-cache, must-revalidate, max-age=0'
    return response

@app.route('/')
def index():
    # R8: browsing must stay fast. The live workbook is NOT scanned/applied on GET.
    # Only the explicit '변경리스트 반영' button consumes due workflow rows.
    mp,all_items,date_range,loaded=items_map(); q=request.args.get('q','').strip().upper()
    items=all_items
    if q: items=[i for i in items if q in i['code'] or q in i['title_ko'].upper()]
    queue_codes=load_generation_queue()
    queue_items=[mp[c] for c in queue_codes if c in mp]
    if len(queue_items)!=len(queue_codes): save_generation_queue([i['code'] for i in queue_items])
    generated=[p.name for p in sorted(OUTPUT_DIR.glob('*.pdf'),key=lambda p:p.stat().st_mtime,reverse=True)[:20]]
    init=''
    policy_column_name=next((i.get('price_policy_column') for i in all_items if i.get('price_policy_column')), '')
    master_status=get_price_master_status()
    central_master_status=get_central_price_master_status()
    return render_template_string(HTML,items=items,queue_items=queue_items,date_range=date_range,loaded_name=loaded,q=q,normal_count=sum(not i['is_discount'] for i in items),sale_count=sum(i['is_discount'] for i in items),matched_count=sum(bool(i.get('bonus_available')) for i in items),missing_count=sum(not bool(i.get('bonus_available')) for i in items),generated=generated,initial_preview=init,missing_fonts=missing_required_fonts(),bonus_mode=get_bonus_match_mode(),ai_match_count=len(load_bonus_matches(mode='ai')),policy_column_name=policy_column_name,price_reduction_count=sum(i.get('price_policy')=='가격인하' for i in all_items),period_limited_count=sum(i.get('price_policy')=='기간한정' for i in all_items),policy_normal_count=sum(i.get('price_policy')=='정상가' for i in all_items),policy_unknown_count=sum(i.get('price_policy') not in PRICE_POLICY_VALUES for i in all_items),master_status=master_status,central_master_status=central_master_status,master_count=len(all_items))

@app.post('/bonus/mode')
def bonus_mode_select():
    # Compatibility only: AI is the sole store-facing engine from 2026-10-01.
    set_bonus_match_mode('ai')
    _set_scan_status(message='AI 번외 자동결과를 적용합니다. 수동고정/공지 정답은 그대로 유지됩니다.')
    return redirect('/')


@app.post('/bonus-ai/rematch-main')
def bonus_ai_rematch_main():
    if not start_ai_full_rematch_job():
        _set_scan_status(message='AI 전체 재매칭 시작 보류',error='이미 다른 AI 매칭 작업이 실행 중입니다.')
    return redirect('/bonus-ai')


@app.post('/upload')
def upload():
    f=request.files.get('excel')
    if f and f.filename:
        f.save(CURRENT_XLSX); LAST_NAME.write_text(f.filename,encoding='utf-8')
        try:
            sync_price_master_from_xlsx(CURRENT_XLSX,f.filename)
        except Exception as exc:
            _write_price_master_status({
                'ok':False,'message':f'프로모션 파일은 저장했지만 마스터 동기화 실패: {exc}',
                'source':f.filename,'updated_at':datetime.now().isoformat(timespec='seconds')
            })
        # New spreadsheet/master truth = remove stale previews.
        for old in CACHE_DIR.glob('preview_fast_*'):
            try: old.unlink()
            except OSError: pass
        load_items(force=True)
    return redirect('/')

@app.get('/price-master/download')
def price_master_download():
    ensure_price_master_file()
    if not PRICE_MASTER_FILE.exists():
        return '가격정책 마스터 파일이 없습니다.',404
    return send_from_directory(str(PRICE_MASTER_FILE.parent),PRICE_MASTER_FILE.name,as_attachment=True)

@app.post('/price-master/central-sync')
def price_master_central_sync():
    sync_central_price_master(force=True,source='manual_button')
    return redirect('/')

@app.post('/price-master/apply-live')
def price_master_apply_live():
    result=_apply_live_price_master_inputs('변경리스트 수동반영 버튼')
    if not result.get('errors'):
        for old in CACHE_DIR.glob('preview_fast_*'):
            try: old.unlink()
            except OSError: pass
        load_items(force=True)
    return redirect('/')

@app.post('/price-master/upload')
def price_master_upload():
    global _PRICE_MASTER_SCHEMA_READY
    f=request.files.get('master')
    if not f or not f.filename:
        return redirect('/')
    ensure_price_master_file()
    tmp=DATA_DIR / 'price_policy_master_upload.tmp.xlsx'
    try:
        f.save(tmp)
        # V4.4.60 R1: process the two editable workflow sheets before installing the file.
        result=apply_price_master_embedded_inputs(tmp,f.filename)
        test=load_workbook(tmp,data_only=False,read_only=True)
        try:
            ws,header_row,h=_find_master_sheet_and_headers(test,require_rows=True)
            required=('품번','상품명','상품영문','정상가','조정가','프로모션 내용','가격정책','행사시작일','행사종료일','기간종료후정책','기간종료후가격')
            missing=[x for x in required if x not in h]
            if missing:
                raise ValueError('필수 열 누락: '+', '.join(missing))
            valid=0
            for r in range(header_row+1,min(ws.max_row,header_row+200)+1):
                if clean_code(ws.cell(r,h['품번']).value): valid+=1
            if valid < 1:
                raise ValueError('유효한 품번 행이 없습니다.')
        finally:
            test.close()
        os.replace(tmp,PRICE_MASTER_FILE)
        _PRICE_MASTER_SCHEMA_READY=True
        msg='수정한 가격정책 마스터를 적용했습니다.'
        if result.get('processed'):
            msg+=f" · 입력 {result['processed']}건 처리"
        if result.get('duplicates'):
            msg+=f" · 중복 {result['duplicates']}건 정리"
        if result.get('added'):
            msg+=f" · 신규 품번 {result['added']}건"
        if result.get('errors'):
            msg+=f" · 확인필요 {result['errors']}건"
        _write_price_master_status({
            'ok':result.get('errors',0)==0,'message':msg,
            'source':f.filename,'updated_at':datetime.now().isoformat(timespec='seconds')
        })
        for old in CACHE_DIR.glob('preview_fast_*'):
            try: old.unlink()
            except OSError: pass
        load_items(force=True)
    except Exception as exc:
        try:
            if tmp.exists(): tmp.unlink()
        except Exception: pass
        _write_price_master_status({
            'ok':False,'message':f'마스터 적용 실패: {exc}',
            'source':getattr(f,'filename',''),'updated_at':datetime.now().isoformat(timespec='seconds')
        })
    return redirect('/')

@app.get('/api/item/<code>')
def api_item(code):
    mp,_,_,_=items_map(); i=mp.get(clean_code(code))
    if not i: return jsonify({})
    result=dict(i); result['preview_version']=item_preview_version(i)
    return jsonify(result)

@app.get('/api/visual-choice-required')
def visual_choice_required():
    # Backward-compatible endpoint. V4.4 has no E/F choice popup.
    return jsonify({'items': []})


@app.post('/api/visual-choice')
def visual_choice_save():
    code = clean_code(request.form.get('code',''))
    choice = request.form.get('choice','')
    if not set_carryover_visual_choice(code, choice):
        return jsonify({'ok': False, 'error': '선택을 저장할 수 없습니다.'}), 400
    return jsonify({'ok': True, 'code': code, 'choice': choice})

def _render_visual_preview(pathstr):
    """Render only a screen-sized A4 image; never create a print PDF for preview."""
    page_index = 0
    raw_path = str(pathstr or '')
    if '::page=' in raw_path:
        raw_path, page_text = raw_path.rsplit('::page=', 1)
        try: page_index = max(0, int(page_text))
        except Exception: page_index = 0
    p = Path(raw_path) if raw_path else TEMPLATE_DIR / 'NEW_ARRIVAL.pdf'
    if not p.exists(): p = TEMPLATE_DIR / 'NEW_ARRIVAL.pdf'
    w = round(A4_W_MM * PREVIEW_DPI / 25.4)
    h = round(A4_H_MM * PREVIEW_DPI / 25.4)
    canvas = Image.new('RGB', (w, h), 'white')
    try:
        if p.suffix.lower() == '.pdf':
            with fitz.open(str(p)) as doc:
                page = doc.load_page(min(page_index, max(0, doc.page_count - 1)))
                pix = page.get_pixmap(matrix=fitz.Matrix(PREVIEW_DPI/72, PREVIEW_DPI/72), alpha=False)
                im = Image.frombytes('RGB', (pix.width, pix.height), pix.samples)
        else:
            im = Image.open(p).convert('RGB')
        if im.size != canvas.size:
            im = im.resize(canvas.size, Image.Resampling.LANCZOS)
        canvas.paste(im, (0, 0))
    except Exception as exc:
        print('Preview visual error:', exc, flush=True)
    return canvas


def generate_fast_preview(item, path):
    scale = PREVIEW_DPI / DPI
    if item.get('visual_mode') == 'price_reduction':
        a4 = render_price_reduction_a4(PREVIEW_DPI)
        bar = generate_bottom_bar(item)
        bar = bar.resize((a4.width, round(BAR_H_PX * scale)), Image.Resampling.LANCZOS)
        a4.paste(bar, (0, round(BAR_TOP_PX * scale)))
    elif item.get('visual_mode') in {'adult_small', 'promo_offer'}:
        a4 = render_custom_template_a4(item, PREVIEW_DPI)
    else:
        a4 = _render_visual_preview(item.get('visual'))
        bar = generate_bottom_bar(item)
        bar = bar.resize((a4.width, round(BAR_H_PX * scale)), Image.Resampling.LANCZOS)
        a4.paste(bar, (0, round(BAR_TOP_PX * scale)))
    top = round(CUT_TOP_PX * scale)
    pop_h = round(POP_H_PX * scale)
    pop = a4.crop((0, top, a4.width, min(a4.height, top + pop_h)))
    if pop.width > PREVIEW_MAX_WIDTH:
        nh = round(pop.height * PREVIEW_MAX_WIDTH / pop.width)
        pop = pop.resize((PREVIEW_MAX_WIDTH, nh), Image.Resampling.LANCZOS)
    pop.save(path, 'JPEG', quality=88, optimize=True, progressive=True)


@app.get('/preview/<code>')
def preview(code):
    mp,_,_,_=items_map(); i=mp.get(clean_code(code))
    if not i:return ('not found',404)
    version=item_preview_version(i)
    path=CACHE_DIR/f'preview_fast_{i["code"]}_{version}.jpg'
    if not path.exists():
        generate_fast_preview(i,path)
        for old in CACHE_DIR.glob(f'preview_fast_{i["code"]}_*.jpg'):
            if old != path:
                try: old.unlink()
                except OSError: pass
    response=send_from_directory(CACHE_DIR,path.name,mimetype='image/jpeg')
    response.headers['Cache-Control']='public, max-age=31536000, immutable'
    return response

def queue_payload():
    mp,_,_,_=items_map()
    codes=load_generation_queue()
    return [{'code':c,'title_ko':mp[c].get('title_ko','')} for c in codes if c in mp]

@app.post('/queue/add')
def queue_add():
    old=load_generation_queue(); incoming=request.form.getlist('codes')
    new=save_generation_queue(old+incoming)
    return jsonify({'added':len(new)-len(old),'items':queue_payload()})

@app.post('/queue/remove')
def queue_remove():
    remove={clean_code(x) for x in request.form.getlist('codes')}
    save_generation_queue([c for c in load_generation_queue() if c not in remove])
    return jsonify({'items':queue_payload()})

@app.post('/queue/clear')
def queue_clear():
    save_generation_queue([])
    return jsonify({'items':[]})

@app.post('/queue/generate')
def queue_generate():
    mp,_,_,_=items_map(); codes=load_generation_queue(); generated=[]; failed=[]
    for code in codes:
        item=mp.get(code)
        if not item:
            failed.append(code); continue
        try:
            generate_one(item,OUTPUT_DIR/f'POP_{item["code"]}.png'); generated.append(code)
        except Exception:
            failed.append(code)
    save_generation_queue(failed)
    return jsonify({'generated':len(generated),'failed':failed,'items':queue_payload()})

@app.post('/generate')
def generate():
    mp,items,_,_=items_map(); mode=request.form.get('mode'); codes=request.form.getlist('codes')
    targets=items if mode=='all' else [mp[c] for c in codes if c in mp]
    for i in targets: generate_one(i,OUTPUT_DIR/f'POP_{i["code"]}.png')
    return redirect('/')

@app.get('/output/<name>')
def output(name): return send_from_directory(OUTPUT_DIR,name,as_attachment=False)

def _runtime_safe_cleanup():
    """Remove only known disposable artifacts; never touch store/user assets or OCR/AI/notice caches."""
    removed=0
    # App bytecode is disposable and is often accidentally carried by update ZIPs.
    for p in (ROOT/'__pycache__', ROOT/'app'/'__pycache__'):
        try:
            if p.exists(): shutil.rmtree(p,ignore_errors=True); removed+=1
        except Exception: pass
    # State files are meaningful only during updater/bootstrap handoff. If app.py is running,
    # that handoff has already completed. Path-probe caches are recreated when needed.
    transient=[
        DATA_DIR/'pending_finalize.json', DATA_DIR/'pending_RUN.cmd', DATA_DIR/'finalizer_spawned.json',
        DATA_DIR/'python_path.txt', DATA_DIR/'tesseract_path.txt',
        DATA_DIR/'tessdata_path.txt', DATA_DIR/'ocr_languages_check.txt', DATA_DIR/'local_test_active.json',
        ROOT/'run_log.txt', ROOT/'run_setup_log.txt', ROOT/'auto_update_log.txt',
    ]
    for p in transient:
        try:
            if p.exists() and p != PID_FILE: p.unlink(); removed+=1
        except Exception: pass
    # Known temporary files only. Persistent preview/OCR/AI caches remain protected.
    patterns=('topten_notice_*.pdf','*.tmp','*.part','_a4_page.png')
    for pat in patterns:
        for p in CACHE_DIR.glob(pat):
            try: p.unlink(); removed+=1
            except Exception: pass
    # Old screen previews are reproducible; keep recent ones, remove >14 days.
    cutoff=time.time()-14*86400
    for p in CACHE_DIR.glob('preview_fast_*.jpg'):
        try:
            if p.stat().st_mtime < cutoff: p.unlink(); removed+=1
        except Exception: pass
    # AI job scratch may be removed only while no matching job is running.
    try:
        if not get_scan_status().get('running'):
            scratch=DATA_DIR/'ai_jobs'
            if scratch.exists(): shutil.rmtree(scratch,ignore_errors=True); removed+=1
    except Exception: pass
    # Keep diagnostics but bound disk use by retaining the tail of oversized logs.
    try:
        for p in LOG_DIR.glob('*.log'):
            try:
                if p.stat().st_size > RUNTIME_LOG_MAX_BYTES:
                    with p.open('rb') as f:
                        f.seek(max(0,p.stat().st_size-RUNTIME_LOG_KEEP_BYTES)); tail=f.read()
                    p.write_bytes(tail); removed+=1
            except Exception: pass
    except Exception: pass
    return removed


def _runtime_maintenance_loop():
    while True:
        try: _runtime_safe_cleanup()
        except Exception: pass
        time.sleep(RUNTIME_CLEANUP_INTERVAL_SECONDS)


def _price_policy_effective_date_loop():
    """Activate reserved price-policy rows at their local 적용일 without a re-save.

    The check is intentionally lightweight and runs once per minute. The existing
    apply lock prevents races with a manual refresh/apply action.
    """
    while True:
        try:
            if PRICE_MASTER_FILE.exists():
                summary=_price_master_pending_summary(PRICE_MASTER_FILE)
                if summary.get('due'):
                    result=_apply_live_price_master_inputs('적용일 백그라운드 자동반영')
                    if result.get('processed') or result.get('duplicates'):
                        # Master replacement changes mtime, so the next load rebuilds items.
                        load_items(force=True)
        except Exception as exc:
            try:
                _write_price_master_status({
                    'ok':False,'message':f'적용일 백그라운드 자동반영 확인 실패: {exc}',
                    'source':PRICE_MASTER_FILE.name,'updated_at':datetime.now().isoformat(timespec='seconds')
                })
            except Exception:
                pass
        time.sleep(60)


def configured_port():
    try:
        return int(os.environ.get('TOPTEN_POP_PORT', '8080'))
    except Exception:
        return 8080

if __name__=='__main__':
    p = configured_port()
    PID_FILE.write_text(str(os.getpid()), encoding='ascii')
    # V4.4.37: safe maintenance removes only disposable update/temp artifacts. User data,
    # webhard PDFs, notice DB/cards, OCR/AI caches, mappings, templates, fonts and outputs are protected.
    _runtime_safe_cleanup()
    # V5.1.1: install the bundled store manual once into protected data\manual.
    try:
        ensure_store_manual()
    except Exception:
        pass
    # V5.1: central master sync runs once per program launch, never inside browser GETs.
    # If GitHub is unavailable or validation fails, the existing local master remains untouched.
    try:
        sync_central_price_master(force=False,source='program_start')
    except Exception:
        pass
    # R8 one-time migration: undo any future rows that older R6 consumed too early.
    # After this, price-policy workflow is button-only; browsing never scans/applies it.
    try:
        _repair_premature_future_rows_r8_once()
    except Exception as exc:
        try:
            _write_price_master_status({'ok':False,'message':f'R8 시작 복구 확인 실패: {exc}','source':PRICE_MASTER_FILE.name,'updated_at':datetime.now().isoformat(timespec='seconds')})
        except Exception:
            pass
    threading.Thread(target=_runtime_maintenance_loop,daemon=True,name='runtime-maintenance').start()
    threading.Thread(target=_central_price_master_loop,daemon=True,name='central-price-master').start()
    # R8: effective-date background watcher intentionally disabled. Use the explicit button.
    # Legacy OCR auto watcher stays disabled. Official notices sync independently.
    threading.Thread(target=_notice_autosync_loop,daemon=True,name='notice-autosync').start()
    print(f'READY http://127.0.0.1:{p}', flush=True)
    try:
        app.run('127.0.0.1', p, debug=False, threaded=True, use_reloader=False)
    finally:
        try:
            if PID_FILE.exists() and PID_FILE.read_text('ascii').strip() == str(os.getpid()):
                PID_FILE.unlink()
        except Exception:
            pass
